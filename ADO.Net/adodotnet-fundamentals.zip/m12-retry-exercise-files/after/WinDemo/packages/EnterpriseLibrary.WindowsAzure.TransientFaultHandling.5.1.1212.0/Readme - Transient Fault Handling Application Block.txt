﻿MICROSOFT ENTERPRISE LIBRARY 5.0 INTEGRATION PACK FOR WINDOWS AZURE 
TRANSIENT FAULT HANDLING APPLICATION BLOCK ("TOPAZ")
5.1.1212.0

Summary: The Transient Fault Handling Application Block makes your Windows Azure application more resilient to transient failures by providing intelligent retry logic mechanisms.

The most up-to-date version of the release notes and known issues is available online:
http://entlib.codeplex.com/wikipage?title=ELAzureReleaseNotes


Microsoft patterns & practices
http://msdn.microsoft.com/practices
