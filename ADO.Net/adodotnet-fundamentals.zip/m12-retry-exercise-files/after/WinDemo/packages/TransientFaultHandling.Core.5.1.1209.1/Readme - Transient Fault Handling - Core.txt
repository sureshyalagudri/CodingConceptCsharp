TRANSIENT FAULT HANDLING CORE
5.1.1209.1

What's in this release?
=======================
The Transient Fault Handling Core provides the retry mechanisms to make your application more resilient to transient faults in both synchronous and asynchronous scenarios. 


Note:
=====
The Transient Fault Handling Core doesn't have configuration support included. If you want to use the Enterprise Library configuration support, install the Transient Fault Handling Application Block (available as a NuGet package).



Microsoft patterns & practices
http://msdn.microsoft.com/practices

