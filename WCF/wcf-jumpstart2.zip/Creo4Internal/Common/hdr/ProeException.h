#ifndef PROEEXCEPTION_H
#define PROEEXCEPTION_H


#include <exception>
#include <string>

//Commented line from VS 2003 project thrown an error modified for VS 2008
//class ProeException : exception
class ProeException : std::exception
{
public:

	ProeException(const std::string &file, int line);
	ProeException(const std::string &file, int line, int result);
	ProeException(const std::string &file, int line, int result, const std::string &message);

	const std::string& GetFile() const;
	int GetLine() const;
	int GetResult() const;
	const std::string& GetMsg() const;
	std::string m_message;

private:

	std::string m_file;
	int m_line;
	int m_result;
	
} ;


#endif	// PROEEXCEPTION_H