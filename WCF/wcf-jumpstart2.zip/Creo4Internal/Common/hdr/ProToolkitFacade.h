#ifndef PROTOOLKITFACADE_H
#define PROTOOLKITFACADE_H



// This module is a facade between the RuleStream code and
// the Pro/TOOLKIT API.  It attempts to abstract the details
// of Pro/TOOLKIT from the RuleStream code.  In theory, you
// should be able to replace the Pro/TOOLKIT calls in this
// module with another CAD system & RuleStream would still 
// work.  However, in reality, this will probably not work
// as there are other parts of the code that are tightly 
// coupled to Pro/TOOLKIT.  Still, having the facade is 
// beneficial as it lets you push all the gritty details 
// of the CAD system down to the lowest level.  For a good
// example of this, see the GeometryFacadeRegenerateSolid()
// function.

//added to find memory leaks
/*#define _CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>*/



// C/C++ header files.
#include <cstdarg>
#include <iostream>

using namespace std;


// Windows application files.
#include <windows.h>




// Pro/Toolkit header files.
#include <ProToolkit.h>
#include <ProAsmcomp.h>
#include <ProColor.h>
#include <ProCore.h>
#include <ProDimension.h>
#include <ProDrawing.h>
#include <ProDtlnote.h>
#include <ProDtlsyminst.h>
#include <ProFeature.h>
#include <ProFeatType.h>
#include <ProLayer.h>
#include <ProParameter.h>
#include <ProSolid.h>
#include <ProToolkitDll.h>	
#include <ProWstring.h>	
#include <ProWindows.h>
#include <ProUdf.h>
#include <ProDwgtable.h>


// Renames of various Pro/TOOLKIT types.

// Assembly
#define GEOMETRY_FACADE_ASM_ALIGN_OFF PRO_ASM_ALIGN_OFF
#define GEOMETRY_FACADE_ASM_ALIGN_ANG_OFF PRO_ASM_ALIGN_ANG_OFF
#define GEOMETRY_FACADE_ASM_ALIGN PRO_ASM_ALIGN
#define GEOMETRY_FACADE_ASM_PNT_ON_LINE PRO_ASM_PNT_ON_LINE
#define GEOMETRY_FACADE_ASM_PNT_ON_SRF PRO_ASM_PNT_ON_SRF
#define GEOMETRY_FACADE_ASM_FIX PRO_ASM_FIX
#define GEOMETRY_FACADE_ASM_INSERT PRO_ASM_INSERT
#define GEOMETRY_FACADE_ASM_ORIENT PRO_ASM_ORIENT
#define GEOMETRY_FACADE_ASM_CSYS PRO_ASM_CSYS
#define GEOMETRY_FACADE_ASM_TANGENT PRO_ASM_TANGENT
#define GEOMETRY_FACADE_ASM_EDGE_ON_SRF PRO_ASM_EDGE_ON_SRF
#define GEOMETRY_FACADE_ASM_DEF_PLACEMENT PRO_ASM_DEF_PLACEMENT
#define GEOMETRY_FACADE_ASM_ASM_SUBSTITUTE PRO_ASM_SUBSTITUTE
#define GEOMETRY_FACADE_ASM_AUTO PRO_ASM_AUTO
#define GEOMETRY_FACADE_ASM_MATE_OFF PRO_ASM_MATE_OFF
#define GEOMETRY_FACADE_ASM_MATE_ANG_OFF PRO_ASM_MATE_ANG_OFF
#define GEOMETRY_FACADE_ASM_MATE PRO_ASM_MATE
#define GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE PRO_ASM_ALIGN_NODEP_ANGLE
#define GEOMETRY_FACADE_ASM_LINE_ANGLE PRO_ASM_LINE_ANGLE
#define GEOMETRY_FACADE_ASM_EDGE_ON_SRF_ANG PRO_ASM_EDGE_ON_SRF_ANG

// Color
#define GEOMETRY_FACADE_COLOR_ERROR PRO_COLOR_ERROR
#define GEOMETRY_FACADE_COLOR_WARNING PRO_COLOR_WARNING
#define GEOMETRY_FACADE_COLOR_METHOD_DEFAULT PRO_COLOR_METHOD_DEFAULT
#define GEOMETRY_FACADE_COLOR_METHOD_TYPE PRO_COLOR_METHOD_TYPE
#define GEOMETRY_FACADE_COLOR_METHOD_RGB PRO_COLOR_METHOD_RGB

// Datum
#define GEOMETRY_FACADE_DATUM_SIDE_YELLOW PRO_DATUM_SIDE_YELLOW

// Dimension
#define GEOMETRY_FACADE_DIMENSION PRO_DIMENSION
#define GEOMETRY_FACADE_DIMTYPE_LINEAR PRODIMTYPE_LINEAR
#define GEOMETRY_FACADE_DIMTYPE_ANGLE PRODIMTYPE_ANGLE
#define GEOMETRY_FACADE_DIMTYPE_DIAMETER PRODIMTYPE_DIAMETER
#define GEOMETRY_FACADE_DIMTYPE_RADIUS PRODIMTYPE_RADIUS
#define GEOMETRY_FACADE_DIMTYPE_UNKNOWN PRODIMTYPE_UNKNOWN

// Display
#define GEOMETRY_FACADE_DISPSTYLE_DEFAULT PRO_DISPSTYLE_DEFAULT
#define GEOMETRY_FACADE_DISPSTYLE_WIREFRAME PRO_DISPSTYLE_WIREFRAME
#define GEOMETRY_FACADE_DISPSTYLE_HIDDEN_LINE PRO_DISPSTYLE_HIDDEN_LINE
#define GEOMETRY_FACADE_DISPSTYLE_NO_HIDDEN PRO_DISPSTYLE_NO_HIDDEN
#define GEOMETRY_FACADE_DISPSTYLE_SHADED PRO_DISPSTYLE_SHADED
#define GEOMETRY_FACADE_DISPMODE_SYMBOLIC PRODISPMODE_SYMBOLIC
#define GEOMETRY_FACADE_DISPMODE_NUMERIC PRODISPMODE_NUMERIC

// Drawing
#define GEOMETRY_FACADE_DRAW_TABLE PRO_DRAW_TABLE
#define GEOMETRY_FACADE_DWGCREATE_DISPLAY_DRAWING PRODWGCREATE_DISPLAY_DRAWING

// Errors
#define GEOMETRY_FACADE_BAD_CONTEXT PRO_TK_BAD_CONTEXT
#define GEOMETRY_FACADE_BAD_INPUTS PRO_TK_BAD_INPUTS
#define GEOMETRY_FACADE_CONTINUE PRO_TK_CONTINUE
#define GEOMETRY_FACADE_GENERAL_ERROR PRO_TK_GENERAL_ERROR
#define GEOMETRY_FACADE_INVALID_TYPE PRO_TK_INVALID_TYPE
#define GEOMETRY_FACADE_NO_ERROR PRO_TK_NO_ERROR	// PRO_TK_NO_ERROR == PRODEV_NO_ERROR
#define GEOMETRY_FACADE_NO_LICENSE PRO_TK_NO_LICENSE
#define GEOMETRY_FACADE_NOT_FOUND PRO_TK_E_NOT_FOUND
#define GEOMETRY_FACADE_USER_ABORT PRO_TK_USER_ABORT
#define GEOMETRY_FACADE_EMPTY PRO_TK_EMPTY 

// Features
#define GEOMETRY_FACADE_FEAT_SUPPRESSED PRO_FEAT_SUPPRESSED
#define GEOMETRY_FACADE_FEAT_COMPONENT PRO_FEAT_COMPONENT
#define GEOMETRY_FACADE_FEAT_DELETE_CLIP PRO_FEAT_DELETE_CLIP
#define GEOMETRY_FACADE_FEAT_RESUME_INCLUDE_PARENTS PRO_FEAT_RESUME_INCLUDE_PARENTS
#define GEOMETRY_FACADE_FEAT_ACTIVE PRO_FEAT_ACTIVE
#define GEOMETRY_FACADE_FEATURE PRO_FEATURE

// Layers
#define GEOMETRY_FACADE_LAYER_TYPE_NORMAL PRO_LAYER_TYPE_NORMAL
#define GEOMETRY_FACADE_LAYER_TYPE_DISPLAY PRO_LAYER_TYPE_DISPLAY
#define GEOMETRY_FACADE_LAYER_TYPE_HIDDEN PRO_LAYER_TYPE_HIDDEN
#define GEOMETRY_FACADE_LAYER_TYPE_NONE PRO_LAYER_TYPE_NONE
#define GEOMETRY_FACADE_LAYER PRO_LAYER
#define GEOMETRY_FACADE_LAYER_TYPE_BLANK PRO_LAYER_TYPE_BLANK
#define GEOMETRY_FACADE_LAYER_FEAT PRO_LAYER_FEAT

// Model
#define GEOMETRY_FACADE_MDL_UNUSED PRO_MDL_UNUSED
#define GEOMETRY_FACADE_MDL_MFG PRO_MDL_MFG
#define GEOMETRY_FACADE_MDL_LAYOUT PRO_MDL_LAYOUT
#define GEOMETRY_FACADE_MDL_2DSECTION PRO_MDL_2DSECTION
#define GEOMETRY_FACADE_MDL_DRAWING PRO_MDL_DRAWING
#define GEOMETRY_FACADE_MDL_DWGFORM PRO_MDL_DWGFORM
#define GEOMETRY_FACADE_MDL_REPORT PRO_MDL_REPORT
#define GEOMETRY_FACADE_MDL_MARKUP PRO_MDL_MARKUP
#define GEOMETRY_FACADE_MDL_DIAGRAM PRO_MDL_DIAGRAM
#define GEOMETRY_FACADE_MDL_PART PRO_MDL_PART
#define GEOMETRY_FACADE_MDL_ASSEMBLY PRO_MDL_ASSEMBLY

// Parameters
#define GEOMETRY_FACADE_PARAM_DOUBLE PRO_PARAM_DOUBLE
#define GEOMETRY_FACADE_PARAM_STRING PRO_PARAM_STRING
#define GEOMETRY_FACADE_PARAM_INTEGER PRO_PARAM_INTEGER
#define GEOMETRY_FACADE_PARAM_BOOLEAN PRO_PARAM_BOOLEAN
#define GEOMETRY_FACADE_PARAM_NOTE_ID PRO_PARAM_NOTE_ID
#define GEOMETRY_FACADE_PARAM_VOID PRO_PARAM_VOID

// Regeneration
#define GEOMETRY_FACADE_REGEN_NO_FLAGS PRO_REGEN_NO_FLAGS
#define GEOMETRY_FACADE_REGEN_AGAIN PRO_TK_REGEN_AGAIN

// Selection
#define GEOMETRY_FACADE_SEL_3D_PART SEL_3D_PART

// Size
#define GEOMETRY_FACADE_CONNECT_ID_SIZE PRO_CONNECTID_SIZE
#define GEOMETRY_FACADE_PATH_SIZE PRO_PATH_SIZE
#define GEOMETRY_FACADE_LINE_SIZE PRO_LINE_SIZE
#define GEOMETRY_FACADE_NAME_SIZE PRO_NAME_SIZE
#define GEOMETRY_FACADE_TYPE_SIZE PRO_TYPE_SIZE
#define GEOMETRY_FACADE_FILE_NAME_SIZE PRO_FILE_NAME_SIZE

// Surface
#define GEOMETRY_FACADE_SURF_PROPS_SET PRODEV_SURF_PROPS_SET
#define GEOMETRY_FACADE_SURF_PROPS_NOT_SET PRODEV_SURF_PROPS_NOT_SET
#define GEOMETRY_FACADE_SURFACE PRO_SURFACE

// Types
#define GEOMETRY_FACADE_B_TRUE PRO_B_TRUE
#define GEOMETRY_FACADE_B_FALSE PRO_B_FALSE
#define GEOMETRY_FACADE_POINT PRO_POINT
#define GEOMETRY_FACADE_AXIS PRO_AXIS
#define GEOMETRY_FACADE_CSYS PRO_CSYS
#define GEOMETRY_FACADE_TYPE_INVALID PRO_TYPE_INVALID

// Units
#define GEOMETRY_FACADE_UNIT_INCH PRO_UNITLENGTH_IN
#define GEOMETRY_FACADE_UNIT_FOOT PRO_UNITLENGTH_FT
#define GEOMETRY_FACADE_UNIT_MM PRO_UNITLENGTH_MM
#define GEOMETRY_FACADE_UNIT_CM PRO_UNITLENGTH_CM
#define GEOMETRY_FACADE_UNIT_M PRO_UNITLENGTH_M
#define GEOMETRY_FACADE_UNIT_MCM PRO_UNITLENGTH_MICRON //UNIT_MCM is PRO_UNITLENGTH_MICRON in Creo 3.0
#define GEOMETRY_FACADE_UNITSYSTEM_MLT PRO_UNITSYSTEM_MLT
#define GEOMETRY_FACADE_UNITSYSTEM_FLT PRO_UNITSYSTEM_FLT
#define GEOMETRY_FACADE_UNITTYPE_MASS PRO_UNITTYPE_MASS
#define GEOMETRY_FACADE_UNITSYSTEM_MLT PRO_UNITSYSTEM_MLT
#define GEOMETRY_FACADE_UNITTYPE_FORCE PRO_UNITTYPE_FORCE
#define GEOMETRY_FACADE_UNITTYPE_LENGTH PRO_UNITTYPE_LENGTH
#define GEOMETRY_FACADE_UNITTYPE_TIME PRO_UNITTYPE_TIME
#define GEOMETRY_FACADE_UNITTYPE_TEMPERATURE PRO_UNITTYPE_TEMPERATURE
#define GEOMETRY_FACADE_UNITTYPE_ANGLE PRO_UNITTYPE_ANGLE

// Values
#define GEOMETRY_FACADE_VALUE_TYPE_INT PRO_VALUE_TYPE_INT
#define GEOMETRY_FACADE_VALUE_UNUSED PRO_VALUE_UNUSED
#define GEOMETRY_FACADE_VALUE_TYPE_STRING PRO_VALUE_TYPE_STRING
#define GEOMETRY_FACADE_VALUE_TYPE_WSTRING PRO_VALUE_TYPE_WSTRING
#define GEOMETRY_FACADE_VALUE_TYPE_DOUBLE PRO_VALUE_TYPE_DOUBLE


// Renames of Pro/TOOLKIT macros.
#define GeometryFacadeMdlToSolid(model) ProMdlToSolid(model)
#define GEOMETRY_FACADE_DLL_EXPORT PRO_TK_DLL_EXPORT

//UDF
#define GEOMETRY_FACADE_UDFOPT_NO_REDEFINE PROUDFOPT_NO_REDEFINE

//TABLE
#define GEOMETRY_FACADE_HORZJUST_LEFT PROHORZJUST_LEFT
#define GEOMETRY_FACADE_HORZJUST_CENTER PROHORZJUST_CENTER
#define GEOMETRY_FACADE_HORZJUST_RIGHT PROHORZJUST_RIGHT


// Typedef's of Pro/TOOLKIt types.

typedef ProAppData GeometryFacadeAppData;
typedef ProArgument GeometryFacadeArgument;
typedef ProArray GeometryFacadeArray;
typedef ProAsmcomp GeometryFacadeAsmComp;
typedef ProAsmcompconstraint GeometryFacadeAsmCompConstraint;
typedef ProAsmcompConstrType GeometryFacadeAsmCompConstraintType;
typedef ProAsmcomppath GeometryFacadeAsmCompPath;
typedef ProAssembly GeometryFacadeAssembly;
typedef ProBoolean GeometryFacadeBoolean;
typedef ProCharLine GeometryFacadeCharLine;
typedef ProCharName GeometryFacadeCharName;
typedef ProCharPath GeometryFacadeCharPath;
typedef ProColor GeometryFacadeColor;
typedef ProColormap GeometryFacadeColorMap;
typedef ProColortype GeometryFacadeColorType;
typedef ProDatumside GeometryFacadeDatumSide;
typedef ProDimension GeometryFacadeDimension;
typedef ProDimensionFilterAction GeometryFacadeDimensionFilterAction;
typedef ProDimensiontype GeometryFacadeDimensionType;
typedef ProDimensionVisitAction GeometryFacadeDimensionVisitAction;
typedef ProDisplayMode GeometryFacadeDisplayMode;
typedef ProDrawing GeometryFacadeDrawing;
typedef ProDrawingSheetInfo GeometryFacadeDrawingSheetInfo;
typedef ProDrawingViewDisplay GeometryFacadeDrawingViewDisplay;
typedef ProDtlattach GeometryFacadeDetailAttach;
typedef ProDtlattachType GeometryFacadeDetailAttachType;
typedef ProDtlnote GeometryFacadeDetailNote;
typedef ProDtlnotedata GeometryFacadeDetailNoteData;
typedef ProDtlnoteline GeometryFacadeDetailNoteLine;
typedef ProDtlnotetext GeometryFacadeDetailNoteText;
typedef ProDtlsymdef GeometryFacadeDetailSymbolDef;
typedef ProDtlsymdefdata GeometryFacadeDetailSymbolDefData;
typedef ProDtlsymdefattachType GeometryFacadeDetailSymbolDefAttachType;
typedef ProDtlsyminst GeometryFacadeDetailSymbolInst;
typedef ProDtlsyminstdata GeometryFacadeDetailSymbolInstData;
typedef ProDwgcreateErrs GeometryFacadeDrawingCreateErrors;
typedef ProDwgcreateOptions GeometryFacadeDrawingCreateOptions;
typedef ProDwgtable GeometryFacadeDrawingTable;
typedef ProError GeometryFacadeError;
typedef ProFamilyName GeometryFacadeFamilyName;
typedef ProFeatStatus GeometryFacadeFeatureStatus;
typedef ProFeattype GeometryFacadeFeatureType;
typedef ProFeature GeometryFacadeFeature;
typedef ProFeatureDeleteOptions GeometryFacadeFeatureDeleteOptions;
typedef ProFeatureFilterAction GeometryFacadeFeatureFilterAction;
typedef ProFeatureResumeOptions GeometryFacadeFeatureResumeOptions;
typedef ProFeatureVisitAction GeometryFacadeFeatureVisitAction;
typedef ProFileName GeometryFacadeFileName;
typedef ProHorizontalJustification GeometryFacadeHorizontalJustification;
typedef ProIdTable GeometryFacadeIdTable;
typedef ProLayer GeometryFacadeLayer;
typedef ProLayerAction GeometryFacadeLayerAction;
typedef ProLayerDisplay GeometryFacadeLayerDisplay;
typedef ProLayerItem GeometryFacadeLayerItem;
typedef ProLayerType GeometryFacadeLayerType;
typedef ProLine GeometryFacadeLine;
typedef ProMassProperty GeometryFacadeMassProperty;
typedef ProMatrix GeometryFacadeMatrix;
typedef ProMdl GeometryFacadeMdl;
typedef ProMdldata GeometryFacadeMdlData;
typedef ProMdlType GeometryFacadeMdlType;
typedef ProMdlfileType GeometryFacadeMdlfileType;
typedef ProModel GeometryFacadeModel;
typedef ProModelitem GeometryFacadeModelItem;
typedef ProAsmitem GeometryFacadeAsmItem;
typedef ProMdlName GeometryFacadeName;
typedef ProParameter GeometryFacadeParameter;
typedef ProParameterAction GeometryFacadeParameterAction;
typedef ProParameterFilter GeometryFacadeParameterFilter;
typedef ProParamvalue GeometryFacadeParameterValue;
typedef ProParamvalueType GeometryFacadeParameterValueType;
typedef ProPart GeometryFacadePart;
typedef ProPath GeometryFacadePath;
typedef ProPoint3d GeometryFacadePoint3D;
typedef ProProcessHandle GeometryFacadeProcessHandle;
typedef ProSelection GeometryFacadeSelection;
typedef ProSolid GeometryFacadeSolid;
typedef ProSurfaceAppearanceProps GeometryFacadeSurfaceProperties;
typedef ProToolkitDllHandle GeometryFacadeToolkitDllHandle;
typedef ProType GeometryFacadeType;
typedef ProUnititem GeometryFacadeUnitItem;
typedef ProUnitsystem GeometryFacadeUnitSystem;
typedef ProUnitsystemType GeometryFacadeUnitSystemType;
typedef ProUnitType GeometryFacadeUnitType;
typedef ProValueData GeometryFacadeValueData;
typedef ProVector GeometryFacadeVector;
typedef ProVerticalJustification GeometryFacadeVerticalJustification;
typedef ProView GeometryFacadeView;
typedef ProWstring GeometryFacadeWideString;
typedef ProUdfdata GeometryFacadeUdfdata;
typedef ProUdfvardim GeometryFacadeUdfvardim; 
typedef ProUdfVardimType GeometryFacadeUdfVardimType;
typedef ProUdfRequiredRef GeometryFacadeUdfRequiredRef;
typedef ProUdfreference GeometryFacadeUdfreference;
typedef ProUdfCreateOption GeometryFacadeUdfCreateOption;
typedef ProGroup GeometryFacadeGroup;
typedef ProUdfextsymbol GeometryFacadeUdfextsymbol;
typedef ProHorzJust GeometryFacadeHorzJust;
typedef ProDwgtabledata GeometryFacadeDwgtabledata;
typedef ProDwgtableSizetype GeometryFacadeDwgtableSizetype;
typedef wchar_t GeometryFacadeWideChar;
typedef ProToleranceTable GeometryFacadeToleranceTable;


// Renames/wrappers for Pro/TOOLKIT functions.

void GeometryFacadeActivateWindow(int windowId);

void GeometryFacadeAddArrayObject(GeometryFacadeArray *array, int index, int numObjects, const void *object);
void GeometryFacadeAddLayerItem(GeometryFacadeLayer *layer, const GeometryFacadeLayerItem *layerItem);

GeometryFacadeArray GeometryFacadeAllocateArray(int numObjects, int objectSize, int reallocationSize);
GeometryFacadeAsmCompConstraint GeometryFacadeAllocateAsmCompConstraint();
GeometryFacadeSelection GeometryFacadeAllocateSelection(const GeometryFacadeAsmCompPath *asmCompPath, const GeometryFacadeModelItem *modelItem);

void GeometryFacadeAssembleAsmComp(const GeometryFacadeAssembly ownerAssembly, const GeometryFacadeSolid componentModel, GeometryFacadeMatrix initialPosition, GeometryFacadeAsmComp *feature);

void GeometryFacadeBackupMdl(const GeometryFacadeMdl handle, const GeometryFacadeMdlData *modelInfo);

void GeometryFacadeChangeDirectory(const GeometryFacadePath path);

void GeometryFacadeClearMessage();
void GeometryFacadeClearWindow(int windowId);

void GeometryFacadeCloseCurrentWindow();

void GeometryFacadeCollectDetailNoteDataLeaders(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailAttach **leaders);
void GeometryFacadeCollectDetailNoteDataLines(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailNoteLine **lines);
void GeometryFacadeCollectDetailNoteLineTexts(const GeometryFacadeDetailNoteLine line, GeometryFacadeDetailNoteText **text);
void GeometryFacadeCollectDrawingDetailNotes(const GeometryFacadeDrawing drawing, const GeometryFacadeDetailSymbolDef *symbol, int sheet, GeometryFacadeDetailNote **notes);
void GeometryFacadeCollectDrawingDetailSymbolDefs(const GeometryFacadeDrawing drawing, GeometryFacadeDetailSymbolDef **symbolDefs);
void GeometryFacadeCollectDrawingDetailSymbolInsts(const GeometryFacadeDrawing drawing, int sheet, GeometryFacadeDetailSymbolInst **symbolInsts);
void GeometryFacadeCollectDrawingTables(const GeometryFacadeDrawing drawing, GeometryFacadeDrawingTable **tables);
void GeometryFacadeCollectDrawingViews(const GeometryFacadeDrawing drawing, GeometryFacadeView **views);

int GeometryFacadeCompareWideString(const GeometryFacadeWideChar *wstr1, const GeometryFacadeWideChar *wstr2, int numChars);

void GeometryFacadeCopyWideString(const GeometryFacadeWideChar *source, GeometryFacadeWideChar *target, int numChars);

int GeometryFacadeCountDrawingSheets(const GeometryFacadeDrawing drawing);
int GeometryFacadeCountDrawingTableColumns(const GeometryFacadeDrawingTable *table);
int GeometryFacadeCountDrawingTableRows(const GeometryFacadeDrawingTable *table);

void GeometryFacadeCreateDrawingFromTemplate(const GeometryFacadeName newName, const GeometryFacadeName drawingTemplate, const GeometryFacadeModel *newModel, const GeometryFacadeDrawingCreateOptions options, GeometryFacadeDrawing *drawing);
void GeometryFacadeCreateLayer(const GeometryFacadeMdl owner, const GeometryFacadeName layerName, const GeometryFacadeLayer *layer);
void GeometryFacadeCreateParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeName name, const GeometryFacadeParameterValue *value, GeometryFacadeParameter *parameter);

void GeometryFacadeDeleteFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureDeleteOptions *deleteOptions, int numOptions);

void GeometryFacadeDisplayMdl(const GeometryFacadeMdl mdl);
void GeometryFacadeDisplayMessage(const GeometryFacadeFileName fileName, const GeometryFacadeCharLine messageName, const char *message);

void GeometryFacadeEnterDrawingTableText(const GeometryFacadeDrawingTable *table, int column, int row, const GeometryFacadeWideString *lines);

void GeometryFacadeEraseMdl(const GeometryFacadeMdl handle);

void GeometryFacadeExecuteToolkitTask(const GeometryFacadeToolkitDllHandle handle, const GeometryFacadeCharPath functionName, const GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);

void GeometryFacadeFreeArgumentArray(GeometryFacadeArgument **arg);
void GeometryFacadeFreeAsmCompConstraintArray(const GeometryFacadeAsmCompConstraint *constraintArray);
void GeometryFacadeFreeArray(const GeometryFacadeArray *array);
void GeometryFacadeFreeDetailNoteLine(const GeometryFacadeDetailNoteLine line);
void GeometryFacadeFreeDetailNoteText(const GeometryFacadeDetailNoteText text);

void GeometryFacadeGetArgumentByLabel(const GeometryFacadeArgument *argArray, const GeometryFacadeName label, GeometryFacadeValueData *data);
int GeometryFacadeGetArraySize(const GeometryFacadeArray array);
void GeometryFacadeGetAsmCompConstraintAsmReference(const GeometryFacadeAsmCompConstraint constraint, GeometryFacadeSelection *asmReference, GeometryFacadeDatumSide *asmOrient);
void GeometryFacadeGetAsmCompConstraintCompReference(const GeometryFacadeAsmCompConstraint constraint, GeometryFacadeSelection *compReference, GeometryFacadeDatumSide *compOrient);
double GeometryFacadeGetAsmCompConstraintOffset(const GeometryFacadeAsmCompConstraint constraint);
void GeometryFacadeGetAsmCompConstraints(const GeometryFacadeAsmComp *component, GeometryFacadeAsmCompConstraint **constraints);
GeometryFacadeAsmCompConstraintType GeometryFacadeGetAsmCompConstraintType(const GeometryFacadeAsmCompConstraint constraint);
void GeometryFacadeGetAsmCompMdl(const GeometryFacadeAsmComp *featureHandle, GeometryFacadeMdl *mdlHandle);
void GeometryFacadeGetAsmCompPathMdl(const GeometryFacadeAsmCompPath *path, GeometryFacadeMdl *model);
void GeometryFacadeGetAsmCompPosition(const GeometryFacadeAsmComp *component, GeometryFacadeMatrix position);
void GeometryFacadeGetCurrentDirectory(GeometryFacadePath path);
void GeometryFacadeGetCurrentMdl(GeometryFacadeMdl *handle);
int GeometryFacadeGetCurrentWindow();
void GeometryFacadeGetDimensionSymbol(const GeometryFacadeDimension *dimension, GeometryFacadeName symbol);
GeometryFacadeDimensionType GeometryFacadeGetDimensionType(const GeometryFacadeDimension *dimension);
double GeometryFacadeGetDimensionValue(const GeometryFacadeDimension *dimension);
void GeometryFacadeGetDetailAttachment(const GeometryFacadeDetailAttach attachment, GeometryFacadeDetailAttachType *type, GeometryFacadeView *view, GeometryFacadeVector location, GeometryFacadeSelection *attachPoint);
void GeometryFacadeGetDetailNoteData(const GeometryFacadeDetailNote *note, const GeometryFacadeDetailSymbolDef *symbol, const GeometryFacadeDisplayMode mode, GeometryFacadeDetailNoteData *noteData);
double GeometryFacadeGetDetailNoteDataAngle(const GeometryFacadeDetailNoteData noteData);
void GeometryFacadeGetDetailNoteDataAttachment(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailAttach *attachment);
GeometryFacadeColor GeometryFacadeGetDetailNoteDataColor(const GeometryFacadeDetailNoteData noteData);
void GeometryFacadeGetDetailNoteDataElbowLength(const GeometryFacadeDetailNoteData data, GeometryFacadeBoolean *isDefault, double *elbowLength);
int GeometryFacadeGetDetailNoteDataId(const GeometryFacadeDetailNoteData noteData);
void GeometryFacadeGetDetailNoteDataJustified(const GeometryFacadeDetailNoteData noteData, GeometryFacadeHorizontalJustification *hJustification, GeometryFacadeVerticalJustification *vJustification);
GeometryFacadeBoolean GeometryFacadeGetDetailNoteDataReadOnly(const GeometryFacadeDetailNoteData noteData);
void GeometryFacadeGetDetailNoteModelRef(const GeometryFacadeDetailNote *note, const GeometryFacadeDetailSymbolInst *symbolInst, int lineIndex, int textIndex, GeometryFacadeMdl *model);
void GeometryFacadeGetDetailNoteTextFont(const GeometryFacadeDetailNoteText text, GeometryFacadeName font);
double GeometryFacadeGetDetailNoteTextHeight(const GeometryFacadeDetailNoteText text);
double GeometryFacadeGetDetailNoteTextSlant(const GeometryFacadeDetailNoteText text);
void GeometryFacadeGetDetailNoteTextString(const GeometryFacadeDetailNoteText text, GeometryFacadeLine str);
double GeometryFacadeGetDetailNoteTextThickness(const GeometryFacadeDetailNoteText text);
GeometryFacadeBoolean GeometryFacadeGetDetailNoteTextUnderLine(const GeometryFacadeDetailNoteText text);
double GeometryFacadeGetDetailNoteTextWidth(const GeometryFacadeDetailNoteText text);
void GeometryFacadeGetDetailSymbolDefData(const GeometryFacadeDetailSymbolDef *symbolDef, GeometryFacadeDetailSymbolDefData *data);
double GeometryFacadeGetDetailSymbolDefDataHeight(const GeometryFacadeDetailSymbolDefData symbolDefData);
int GeometryFacadeGetDetailSymbolDefDataId(const GeometryFacadeDetailSymbolDefData symbolDefData);
double GeometryFacadeGetDetailSymbolInstDataAngle(const GeometryFacadeDetailSymbolInstData data);
GeometryFacadeDetailSymbolDefAttachType GeometryFacadeGetDetailSymbolInstDataAttachType(const GeometryFacadeDetailSymbolInstData data);
GeometryFacadeColor GeometryFacadeGetDetailSymbolInstDataColor(const GeometryFacadeDetailSymbolInstData data);
void GeometryFacadeGetDetailSymbolInstDataElbowLength(const GeometryFacadeDetailSymbolInstData data, GeometryFacadeBoolean *isDefault, double *elbowLength);
void GeometryFacadeGetDetailSymbolInstData(const GeometryFacadeDetailSymbolInst *symbolInst, const GeometryFacadeDisplayMode mode, GeometryFacadeDetailSymbolInstData *data);
double GeometryFacadeGetDetailSymbolInstDataHeight(const GeometryFacadeDetailSymbolInstData data);
int GeometryFacadeGetDetailSymbolInstDataId(const GeometryFacadeDetailSymbolInstData data);
int GeometryFacadeGetDrawingCreateErrorsCount(const GeometryFacadeDrawingCreateErrors errors);
void GeometryFacadeGetDrawingFormat(const GeometryFacadeDrawing drawing, int sheet, GeometryFacadeName formatName);
double GeometryFacadeGetDrawingScale(const GeometryFacadeDrawing drawing, const GeometryFacadeSolid solid, int sheet);
GeometryFacadeDrawingSheetInfo GeometryFacadeGetDrawingSheetInfo(const GeometryFacadeDrawing drawing, int sheet);
void GeometryFacadeGetDrawingTableCellNote(const GeometryFacadeDrawingTable *table, int column, int row, GeometryFacadeDetailNote *note);
GeometryFacadeDrawingViewDisplay GeometryFacadeGetDrawingViewDisplay(const GeometryFacadeDrawing drawing, const GeometryFacadeView view);
void GeometryFacadeSetDrawingViewDisplay(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeDrawingViewDisplay *displayStatus);
void GeometryFacadeSetDrawingViewMdlNameSet(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeName mdlViewName, GeometryFacadeName Orientation, double xAngle, double yAngle);
void GeometryFacadeGetDrawingViewOutline(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadePoint3D outline[2]);
double GeometryFacadeGetDrawingViewScale(const GeometryFacadeDrawing drawing, const GeometryFacadeView view);
void GeometryFacadeGetDrawingViewScale(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, double dScale);
int GeometryFacadeGetDrawingViewSheet(const GeometryFacadeDrawing drawing, const GeometryFacadeView view);
void GeometryFacadeGetDrawingViewSolid(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeSolid *solid);
GeometryFacadeFeatureStatus GeometryFacadeGetFeatureStatus(const GeometryFacadeFeature *featureHandle);
GeometryFacadeFeatureType GeometryFacadeGetFeatureType(const GeometryFacadeFeature *featureHandle);
void GeometryFacadeGetFeatureTypeName(const GeometryFacadeFeature *feature, GeometryFacadeName featureTypeName);
GeometryFacadeLayerDisplay GeometryFacadeGetLayerDisplayStatus(const GeometryFacadeLayer *layer);
void GeometryFacadeGetMdlData(const GeometryFacadeMdl handle, GeometryFacadeMdlData *data);
int GeometryFacadeGetMdlId(const GeometryFacadeMdl model);
void GeometryFacadeGetMdlLayer(const GeometryFacadeMdl owner, const GeometryFacadeName layerName, GeometryFacadeLayer *layer);
void GeometryFacadeGetMdlName(const GeometryFacadeMdl handle, GeometryFacadeName name);
void GeometryFacadeGetMdlPrincipalUnitSystem(const GeometryFacadeMdl mdl, GeometryFacadeUnitSystem *principalSystem);
GeometryFacadeMdlType GeometryFacadeGetMdlType(const GeometryFacadeMdl mdl);
GeometryFacadeMdlfileType GeometryFacadeGetMdlFileType(const GeometryFacadeMdl mdl);
int GeometryFacadeGetMdlWindow(const GeometryFacadeMdl mdl);
void GeometryFacadeGetModelItemName(const GeometryFacadeModelItem *item, GeometryFacadeName name);
void GeometryFacadeGetParameterValue(const GeometryFacadeParameter *parameter, GeometryFacadeParameterValue *value);
void GeometryFacadeGetParameterValueValue(const GeometryFacadeParameterValue *handle, const GeometryFacadeParameterValueType type, void *value);
int GeometryFacadeGetSolidFeatureStatus(const GeometryFacadeSolid solid, int **featureIdArray, GeometryFacadeFeatureStatus **statusArray);
GeometryFacadeMassProperty GeometryFacadeGetSolidMassProperty(const GeometryFacadeSolid solid, const GeometryFacadeName coordinateSystemName);
void GeometryFacadeGetSurfaceProperties(const GeometryFacadeModelItem *modelItem, GeometryFacadeSurfaceProperties *properties);
void GeometryFacadeGetMdlVisibleAppearanceprops(const GeometryFacadeAsmItem *modelItem, GeometryFacadeSurfaceProperties *properties);
void GeometryFacadeGetToolkitApplTextPath(GeometryFacadePath textPath);
GeometryFacadeUnitSystemType GeometryFacadeGetUnitSystemType(const GeometryFacadeUnitSystem *system);
void GeometryFacadeGetUnitSystemUnit(const GeometryFacadeUnitSystem *system, const GeometryFacadeUnitType type, GeometryFacadeUnitItem *unit);

void GeometryFacadeHighlightSelection(const GeometryFacadeSelection selection, const GeometryFacadeColorType color);

void GeometryFacadeInitAsmCompPath(const GeometryFacadeSolid solidHandle, const GeometryFacadeIdTable memberIdTable, int tableSize, GeometryFacadeAsmCompPath *handle);
void GeometryFacadeInitFeature(const GeometryFacadeSolid ownerHandle, int featureId, GeometryFacadeFeature *featureHandle);
void GeometryFacadeInitLayerItem(const GeometryFacadeLayerType type, int id, const GeometryFacadeMdl owner, GeometryFacadeLayerItem *item);
void GeometryFacadeInitModelItem(const GeometryFacadeMdl ownerHandle, int itemId, const GeometryFacadeType itemType, GeometryFacadeModelItem *handle);
void GeometryFacadeInitModelItemByName(const GeometryFacadeMdl mdl, const GeometryFacadeType type, const GeometryFacadeName name, GeometryFacadeModelItem *item);
void GeometryFacadeInitParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeName name, GeometryFacadeParameter *parameter);

GeometryFacadeBoolean GeometryFacadeIsDetailNoteDataMirrored(const GeometryFacadeDetailNoteData data);
GeometryFacadeBoolean GeometryFacadeIsDetailSymbolInstDataDisplayed(const GeometryFacadeDetailSymbolInstData data);

void GeometryFacadeLoadMdl(const GeometryFacadePath fullPath, const GeometryFacadeMdlType type, const GeometryFacadeBoolean askUserAboutReps, GeometryFacadeMdl *handle);
void GeometryFacadeLoadDll(const char *appName, const GeometryFacadeCharPath execFile, const GeometryFacadeCharPath textDir, const GeometryFacadeBoolean userDisplay, GeometryFacadeToolkitDllHandle *handle);

void GeometryFacadeMdlToModelItem(const GeometryFacadeMdl mdl, GeometryFacadeModelItem *modelItem);

void GeometryFacadeRefitWindow(int windowId);
void GeometryFacadeObjectwindowCreate(GeometryFacadeName object_name,GeometryFacadeType object_type,int *p_window_id);

void GeometryFacadeRefreshWindow(int windowId);

void GeometryFacadeRegenerateAsmComp(const GeometryFacadeAsmComp *compHandle, const GeometryFacadeBoolean updateSoft);
void GeometryFacadeRegenerateDrawingSheet(const GeometryFacadeDrawing drawing, int sheet);
void GeometryFacadeRegenerateDrawingView(const GeometryFacadeDrawing drawing, int viewId);
void GeometryFacadeRegenerateSolid(const GeometryFacadeSolid handle, int flags);

void GeometryFacadeRemoveAsmCompConstraint(const GeometryFacadeAsmComp *featureHandle, int index);
void GeometryFacadeRemoveLayerItem(const GeometryFacadeLayer *layer, const GeometryFacadeLayerItem *layerItem);

//void convrted to GeometryFacadeError for assembly component renaming
void GeometryFacadeRenameMdl(const GeometryFacadeMdl handle, const GeometryFacadeName newName);

void GeometryFacadeRepaintWindow(int windowId);

void GeometryFacadeResumeFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureResumeOptions *resumeOptions, int numOptions);

void GeometryFacadeRetrieveMdl(const char *name, const GeometryFacadeMdlType type, GeometryFacadeMdl *handle);
void GeometryFacadeRetrieveMdl(wchar_t *name, const GeometryFacadeMdlType type, GeometryFacadeMdl *handle);

void GeometryFacadeSaveLayerDisplayStatus(const GeometryFacadeMdl owner);
void GeometryFacadeSaveMdl(const GeometryFacadeMdl handle);

void GeometryFacadeSetAsmCompConstraintAsmReference(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeSelection asmReference, const GeometryFacadeDatumSide asmOrient);
void GeometryFacadeSetAsmCompConstraintCompReference(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeSelection compReference, const GeometryFacadeDatumSide compOrient);
void GeometryFacadeSetAsmCompConstraintOffset(const GeometryFacadeAsmCompConstraint constraint, double offset);
void GeometryFacadeSetAsmCompConstraints(const GeometryFacadeAsmCompPath *componentPath, const GeometryFacadeAsmComp *component, const GeometryFacadeAsmCompConstraint *constraints);
void GeometryFacadeSetAsmCompConstraintType(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeAsmCompConstraintType type);
void GeometryFacadeSetAsmCompPosition(const GeometryFacadeAsmCompPath *componentPath, const GeometryFacadeAsmComp *component, GeometryFacadeMatrix position);
void GeometryFacadeSetCurrentDrawingSheet(const GeometryFacadeDrawing drawing, int currentSheet);
void GeometryFacadeSetDimensionValue(const GeometryFacadeDimension *dimension, double value);
void GeometryFacadeSetDimensionDecimalValue(const GeometryFacadeDimension *dimension, int value);
void GeometryFacadeSetDimensionToleranceValue(const GeometryFacadeDimension *dimension, double upper, double lower);
void GeometryFacadeGetDimensionToleranceValue(const GeometryFacadeDimension *dimension, double *upper, double *lower);
void GeometryFacadeSetDimensionToleranceDecimalValue(const GeometryFacadeDimension *dimension, int value);
void GeometryFacadeSetDimensionTableNameColumnValue(const GeometryFacadeDimension *dimension, GeometryFacadeToleranceTable table, GeometryFacadeName value, int column);
void GeometryFacadeGetDimensionTableNameColumnValue(const GeometryFacadeDimension *dimension, GeometryFacadeToleranceTable *table, GeometryFacadeName value, int *column);
void GeometryFacadeSetDrawingScale(const GeometryFacadeDrawing drawing, const GeometryFacadeSolid solid, int sheet, double scale);
void GeometryFacadeSetLayerDisplayStatus(const GeometryFacadeLayer *layer, const GeometryFacadeLayerDisplay displayStatus);
void GeometryFacadeSetParameterValue(const GeometryFacadeParameter *parameter, const GeometryFacadeParameterValue *value);
void GeometryFacadeSetParamValue(GeometryFacadeParameterValue *parameter, const wchar_t *value, const GeometryFacadeParameterValueType valueType);
void GeometryFacadeSetSolidFeatureStatus(const GeometryFacadeSolid solid, int *featureIdArray, const GeometryFacadeFeatureStatus *statusArray, int numFeatures, const GeometryFacadeBoolean canFix);
void GeometryFacadeSetSurfaceProperties(const GeometryFacadeModelItem *modelItem, const GeometryFacadeSurfaceProperties *properties);
void GeometryFacadeSetValueDataString(GeometryFacadeValueData *value, const char *str);
void GeometryFacadeSetValueDataWstring(GeometryFacadeValueData *value, const wchar_t *str);

void GeometryFacadeStopEngineer();

GeometryFacadeWideChar* GeometryFacadeStringToWideString(GeometryFacadeWideChar *wstr, const char *str);

void GeometryFacadeSuppressFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureDeleteOptions *suppressOptions, int numOptions);

void GeometryFacadeVisitFeatureDimension(const GeometryFacadeFeature *feature, const GeometryFacadeDimensionVisitAction visit, const GeometryFacadeDimensionFilterAction filter, const GeometryFacadeAppData data);
void GeometryFacadeVisitMdlLayer(const GeometryFacadeMdl model, const GeometryFacadeLayerAction visitAction, const GeometryFacadeLayerAction filterAction, const GeometryFacadeAppData appData);
void GeometryFacadeVisitParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeParameterFilter filter, const GeometryFacadeParameterAction action, const GeometryFacadeAppData data);
void GeometryFacadeVisitSolidDimension(const GeometryFacadeSolid solid, const GeometryFacadeBoolean referenceDimensions, const GeometryFacadeDimensionVisitAction action, const GeometryFacadeDimensionFilterAction filter, const GeometryFacadeAppData data);
void GeometryFacadeVisitSolidFeature(const GeometryFacadeSolid handle, const GeometryFacadeFeatureVisitAction visitAction, const GeometryFacadeFeatureFilterAction filterAction, const GeometryFacadeAppData appData);

char* GeometryFacadeWideStringToString(char *str, const GeometryFacadeWideChar *wstr);

std::string GetErrorString(int error);


void GeometryFacadeAsmCompMdl(const GeometryFacadeFeature *featureHandle, GeometryFacadeMdl *mdlHandle);
void GeometryFacadeSolidFamtableCheck(const GeometryFacadeMdl model);
void GeometryFacadeSolidCreate(GeometryFacadeName name,GeometryFacadeType type,GeometryFacadeSolid* p_handle);
void GeometryFacadeUdfdataAlloc(GeometryFacadeUdfdata *data);
void GeometryFacadeUdfdataPathSet(GeometryFacadeUdfdata data,GeometryFacadePath path);
void GeometryFacadeUdfdataVardimsGet(GeometryFacadeUdfdata data,GeometryFacadeUdfvardim** variant_dims);
void GeometryFacadeUdfvardimNameGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeName name);
void GeometryFacadeUdfvardimPromptGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeLine prompt);
void GeometryFacadeUdfvardimDefaultvalueGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeUdfVardimType* value_type,double* dim_value);
void GeometryFacadeUdfvardimProarrayFree(GeometryFacadeUdfvardim *var_dim);
void GeometryFacadeUdfdataUdfvardimAdd(GeometryFacadeUdfdata data,GeometryFacadeUdfvardim variant_dims);
void GeometryFacadeUdfdataRequiredreferencesGet(GeometryFacadeUdfdata data,GeometryFacadeUdfRequiredRef** required_references);
void GeometryFacadeUdfrequiredrefPromptGet(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeLine prompt);
void GeometryFacadeUdfrequiredrefTypeGet(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeType *type);
void GeometryFacadeUdfrequiredrefIsannotationref(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeBoolean *is_annotation_ref);
void GeometryFacadeUdfrequiredrefProarrayFree(GeometryFacadeUdfRequiredRef *required_references);
void GeometryFacadeUdfreferenceAlloc(GeometryFacadeLine prompt,GeometryFacadeSelection ref_item,GeometryFacadeBoolean external,GeometryFacadeUdfreference* reference);
void GeometryFacadeUdfdataReferenceAdd(GeometryFacadeUdfdata data,GeometryFacadeUdfreference reference);
void GeometryFacadeUdfCreate(GeometryFacadeSolid solid,GeometryFacadeUdfdata data,GeometryFacadeAsmCompPath* asm_reference,GeometryFacadeUdfCreateOption* options,int n_options,GeometryFacadeGroup* udf);
void GeometryFacadeUdfDimensionsCollect(GeometryFacadeGroup* udf,GeometryFacadeDimension** dims);
void GeometryFacadeUdfDimensionNameGet(GeometryFacadeGroup* udf,GeometryFacadeDimension* dim,GeometryFacadeLine name);
void GeometryFacadeUdfdataExternalsymbolsGet(GeometryFacadeUdfdata data,GeometryFacadeUdfextsymbol** external_symbols);
void GeometryFacadeUdfUpdate(GeometryFacadeGroup *group);
void GeometryFacadeDwgtabledataAlloc(GeometryFacadeDwgtabledata* data);
void GeometryFacadeDwgtabledataSizetypeSet(GeometryFacadeDwgtabledata data,GeometryFacadeDwgtableSizetype size_type);
void GeometryFacadeDwgtabledataColumnsSet(GeometryFacadeDwgtabledata data,int column,double* widths,GeometryFacadeHorzJust* justifications);
void GeometryFacadeDwgtabledataRowsSet(GeometryFacadeDwgtabledata data,int n_rows,double* heights);
void GeometryFacadeDwgtabledataOriginSet(GeometryFacadeDwgtabledata data,GeometryFacadePoint3D origin);
void GeometryFacadeDwgtableDisplay(GeometryFacadeDrawingTable *table);
void GeometryFacadeDrawingTableCreate(GeometryFacadeDrawing drawing,GeometryFacadeDwgtabledata data,int display,GeometryFacadeDrawingTable* table);
void GeometryFacadeDwgtableDelete(GeometryFacadeDrawingTable *table,int display);
void GeometryFacadeDrawingSheetTrfGet(GeometryFacadeDrawing drawing,int sheet,GeometryFacadeName sheet_size,GeometryFacadeMatrix transform);
int GeometryFacadeUtilMatrixInvert(double m[4][4],double output[4][4]);
void GeometryFacadePntTrfEval(GeometryFacadeVector in_point,GeometryFacadeMatrix trf,GeometryFacadeVector out_point);
void GeometryFacadeGroupFeaturesCollect(GeometryFacadeGroup *oGroup,GeometryFacadeFeature **oFeats);
void GeometryFacadeModelitemDefaultnameGet(GeometryFacadeModelItem *item,GeometryFacadeName name);
/*void GeometryFacadeSetDetailNoteTexts(const GeometryFacadeDetailNoteLine text,GeometryFacadeDetailNoteText str);
void GeometryFacadeSetDetailNoteTextString(const GeometryFacadeDetailNoteText text,GeometryFacadeLine str);
void GeometryFacadeSetDetailNoteDataLines(const GeometryFacadeDetailNoteData data,GeometryFacadeDetailNoteLine line);
void GeometryFacadeEraseDetailNote(const GeometryFacadeDetailNote text);
void GeometryFacadeModifyDetailNote(const GeometryFacadeDetailNote text,GeometryFacadeDetailSymbolDef symbol,const GeometryFacadeDetailNoteData data);
void GeometryFacadeShowDetailNote(const GeometryFacadeDetailNote note);*/

void GeometryFacadeMdlInit(GeometryFacadeName name, GeometryFacadeMdlfileType fileType, GeometryFacadeMdl *handle);
void GeometryFacadeAsmcompAsmitemInit(GeometryFacadeMdl model, int id, GeometryFacadeType type, GeometryFacadeName name,  GeometryFacadeAsmCompPath *path, GeometryFacadeAsmItem *handle);

#endif	// PROTOOLKITFACADE_H