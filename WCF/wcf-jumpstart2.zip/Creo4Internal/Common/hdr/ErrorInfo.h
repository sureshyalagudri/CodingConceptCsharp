#ifndef ERRORINFO_H
#define ERRORINFO_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"
#include "ProeException.h"


// Structure used to hold error information when a Pro/TOOLKIT API call fails.
// Not reentrant.
struct ErrorInfo
{
	ErrorInfo() : 

		file("Uninitialized"), 
		line(0), 
		method("Uninitialized"), 
		result(GEOMETRY_FACADE_NO_ERROR), 
		message("Uninitialized"), 
		stackframe(0), 
		hasError(false) 
	{

	}

	std::string file;
	int line;
	std::string method;
	GeometryFacadeError result;
	std::string message;
	int stackframe;
	bool hasError;
} ;


// I'm not a big fan of macros, but the CHECK_RESULT_THROW macro is 
// a real time & space saver.  Using it prevents having to write 
// if-else ladders for error checking.  Since the Pro/TOOLKIT API is C,
// you have to check the return value of EVERY API call for
// GEOMETRY_FACADE_NO_ERROR.  This results in code that looks like this:
//
// if ( ( result = fillPathTable(theIdPath, table, &tableSize) ) == GEOMETRY_FACADE_NO_ERROR )
// {
//		if ( ( result = GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)currentModel, table, tableSize - 1, &path ) ) == GEOMETRY_FACADE_NO_ERROR )
//		{
//			if ( ( result = GeometryFacadeGetAsmCompPathMdl(&path, &owner) ) == GEOMETRY_FACADE_NO_ERROR )
//			{
//				if ( ( result = GeometryFacadeInitModelItem(owner, dimensionID, GEOMETRY_FACADE_DIMENSION, &modelItem) ) == GEOMETRY_FACADE_NO_ERROR )
//				{
//					if ( ( result = GeometryFacadeGetDimensionValue( (GeometryFacadeDimension*)&modelItem, &value ) ) == GEOMETRY_FACADE_NO_ERROR )
//					{
//
//					}
//				}
//			}
//		}
// }
//
// As you can imagine, writing this kind of code becomes very tedious.
//
// Using the CHECK_RESULT_THROW macro, the above code becomes:
//
// fillPathTable(theIdPath, table, &tableSize);
// 
// GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)currentModel, table, tableSize - 1, &path ); 
//
// GeometryFacadeGetAsmCompPathMdl(&path, &owner); 
//
// GeometryFacadeInitModelItem(owner, dimensionID, GEOMETRY_FACADE_DIMENSION, &modelItem);
//
// GeometryFacadeGetDimensionValue( (GeometryFacadeDimension*)&modelItem, &value );
//
// GeometryFacadeSetDimensionValue( (GeometryFacadeDimension*)&modelItem, theValue );
//
// Which, in my opinion, is much easier to read (and write).
//
// Aside from error checking, upon a Pro/TOOLKIT failure the macro also populates 
// a structure with useful error information that can be obtained through a call to
// GetErrorString().  The structure contains useful information, such as the file & line
// number where the error occured, as well as the function signature in which the error occured.
//
// Here is an example of what the CHECK_RESULT_THROW macro does undet the covers.  Given this code:
//
// GeometryFacadeGetCurrentMdl(&model);
//
// The compiler will generate the following:
//
// {
//     extern ErrorInfo g_errorInfo; 
//	   g_errorInfo.stackframe++; 
//	   GeometryFacadeError result = GeometryFacadeGetCurrentMdl(&model); 
//	   g_errorInfo.stackframe--; 
//	   if (result == GEOMETRY_FACADE_NO_ERROR)
//     {
//	       if (!g_errorInfo.stackframe) 
//	       { 
//	           g_errorInfo.hasError = false; 
//	       } 
//	   }
//	   else
//	   { 
//	       if (!g_errorInfo.hasError) 
//		   { 
//		       g_errorInfo.file = strrchr("c:\\develop\\rulestream\\6.4.2\\proe\\addin\\src\\Mdl.cpp", '\\') + 1; 
//			   g_errorInfo.line = 43; 
//			   g_errorInfo.method = "GeometryFacadeGetCurrentMdl(&model)"; 
//			   g_errorInfo.result = result;
//			   g_errorInfo.message = GetProErrorString(result); 
//		       g_errorInfo.hasError = true; 
//		   } 
//	       if (!g_errorInfo.stackframe) 
//	       { 
//	           g_errorInfo.hasError = false; 
//	       } 
//         return g_errorInfo.result;  
//     }
// }
//
// As you can see, the macro generated code to test for the return value
// of GEOMETRY_FACADE_NO_ERROR, and if that is not what was returned, populates an
// error structure with various useful information & then returns the error
// that was returned from the Pro/TOOLKIT API call.  The caller can then
// test the return value & if it is non-zero (GEOMETRY_FACADE_NO_ERROR is 0), it can
// call the GetErrorString() function to get more information about the error.
// GetErrorString() will return a string formatted like the following:
//
// File: Mdl.cpp
// Line: 43
// Method: ProModelCurrentGet(&model)
// Message: GEOMETRY_FACADE_GENERAL_ERROR
//
// There are two prerequisites for using the CHECK_RESULT_THROW macro:
//
// 1) The function containing the CHECK_RESULT_THROW macro must have a return 
//    type of GeometryFacadeError.
// 2) The function being checked must return GEOMETRY_FACADE_NO_ERROR (0) upon success.
//
// Note that if a series of calls result in multiple CHECK_RESULT_THROW macros being 
// called, the last one called will be the one whose information is provided 
// when GetProErrorString() & whose error code is returned.  To me, this is the 
// desired bahavior and actually required more work to get the macro to behave 
// accordingly.  Another alternative would have been to maintain a stack trace.
#if 0
#define CHECK_RESULT_THROW(function) \
{ \
	/* The real g_errorInfo is in Utils.cpp. */ \
	extern ErrorInfo g_errorInfo; \
	\
	/* 
		Increment the stackframe count.
		This is needed to ensure that the error information
		from the last CHECK_RESULT_THROW() call (in nested calls)
		is the info that is returned.
	*/ \
	g_errorInfo.stackframe++; \
	\
	/* Call the function. */ \
	GeometryFacadeError result = function; \
	\
	/* Decrement the stack frame count */ \
	g_errorInfo.stackframe--; \
	\
	/* Check for errors. */ \
	if (result == GEOMETRY_FACADE_NO_ERROR) \
	{ \
		/* No errors.  If we're at the top-level stack frame, reset the hasError flag. */ \
		if (!g_errorInfo.stackframe) \
		{ \
			g_errorInfo.hasError = false; \
		} \
	} \
	else \
	{ \
		/* 
			An error has occured.  If an error occured during a previous
			nested call to CHECK_RESULT_THROW(), don't overwrite that error info. 
		*/ \
		if (!g_errorInfo.hasError) \
		{ \
			/* Set the various error info. */ \
			\
			/* Set the basename of the source file. */ \
			g_errorInfo.file = strrchr(__FILE__, '\\') + 1; \
			\
			/* Set the source line number. */ \
			g_errorInfo.line = __LINE__; \
			\
			/* The # macro operator will return the function pointer as a string. */ \
			g_errorInfo.method = #function; \
			\
			/* Store the Pro/TOOLKIT error. */ \
			g_errorInfo.result = result; \
			\
			/* Translate the Pro/TOOLKIT error to its string equivalent. */ \
			g_errorInfo.message = GetProErrorString(result); \
			\
			/* 
				Flag used to determine if an error has been previously set in 
				nested calls to CHECK_RESULT_THROW().
			*/ \
			g_errorInfo.hasError = true; \
		} \
		\
		/* If we're at the top-level stack frame, reset the hasError flag. */ \
		if (!g_errorInfo.stackframe) \
		{ \
			g_errorInfo.hasError = false; \
		} \
		/* 
			Return the stored version of result, as this will probably
			be different in nested CHECK_RESULT_THROW() calls.
		*/ \
		return g_errorInfo.result; \
	} \
	/* 
		Don't return anything in case of success, 
		else the function that called CHECK_RESULT_THROW()
		will more than likely terminate early.
	*/ \
} 
#endif


#define CHECK_RESULT_NO_THROW(function) \
{ \
	/* The real g_errorInfo is in ErrorInfo.cpp. */ \
	extern ErrorInfo g_errorInfo; \
	\
	/* Call the function & store the Pro/TOOLKIT error. */ \
	g_errorInfo.result = function; \
	\
	/* 
		Set the various error info. 
		This must be done each time 
		so that g_errorInfo is updated.
	*/ \
	\
	/* Set the basename of the source file. */ \
	g_errorInfo.file = strrchr(__FILE__, '\\') + 1; \
	\
	/* Set the source line number. */ \
	g_errorInfo.line = __LINE__; \
	\
	/* The # macro operator will return the function pointer as a string. */ \
	g_errorInfo.method = #function; \
	\
	/* Translate the Pro/TOOLKIT error to its string equivalent. */ \
	g_errorInfo.message = GetProErrorString(g_errorInfo.result); \
} 


#define CHECK_RESULT_THROW(function) \
{ \
	CHECK_RESULT_NO_THROW(function) \
	extern ErrorInfo g_errorInfo; \
	if (g_errorInfo.result != GEOMETRY_FACADE_NO_ERROR) \
	{ \
		/* 
			Throw an exception.
		*/ \
		throw ProeException(g_errorInfo.result, g_errorInfo.message); \
	} \
}


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetErrorString_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
GeometryFacadeError GetErrorResult(char **output);
std::string GetProErrorString(int error);


#endif // ERRORINFO_H
