#ifndef UTILITY_H
#define UTILITY_H


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"


#define BETWEEN(a,b,c) ((a)<=(b) && (b)<=(c))


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetAddInErrorInfo_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT const char* GetWrapperErrorInfo();
}


// Public functions.
char* AppendStrings(char **string1, ...);
GeometryFacadeError Collect2ParamDBVisitAction(void *object, GeometryFacadeAppData appData);
GeometryFacadeError Collect3ParamDBVisitAction(void *object, GeometryFacadeError status, GeometryFacadeAppData appData);
GeometryFacadeError CollectAsmcomp(GeometryFacadeAssembly assembly, GeometryFacadeAsmComp **asmComps);
void CollectMdlLayers(GeometryFacadeMdl model, GeometryFacadeLayer **layers);  
void CollectParameters(GeometryFacadeModelItem *modelItem, GeometryFacadeParameter **parameters);
GeometryFacadeError CollectSolidFeaturesWithFilter(GeometryFacadeSolid solid, GeometryFacadeFeatureFilterAction filter, GeometryFacadeFeature **features);
void DebugPrintf(char *format, ...);
void fillPathTable(std::string idPath, int *table, int *tableSize);
void fillPathTable(std::wstring idPath, int *table, int *tableSize);
void GetAsmcomp(GeometryFacadeAsmCompPath path, GeometryFacadeAsmComp *asmComp);
void GetAsmcompMdl(std::string idPath, GeometryFacadeMdl *model);
void GetAsmcompMdl(std::wstring idPath, GeometryFacadeMdl *model);
void GetAsmcompPath(std::string idPath, GeometryFacadeAsmCompPath *path);
void GetAsmcompPath(std::wstring idPath, GeometryFacadeAsmCompPath *path);
char* GetIniFile();
char* GetLogFile();
char* GetSoftwareVersion();
void GetParentAsmCompPath(const char *idPath, GeometryFacadeAsmCompPath *path);
bool IsLoggingEnabled();
void SaveErrorInfo(const ProeException &ex);
void SetIniFile(const char *iniFile);
void SetSoftwareVersion(const char *version);
void GetParentAsmcompPath(GeometryFacadeAsmCompPath path, GeometryFacadeAsmCompPath *parentPath);
void StringUpper(char *inputString, char *outputString);
int UtilStrcmp(char *s, char *t);
int UtilStrcmp(wchar_t *s, wchar_t *t);
std::string GetValidStringValue(std::string sStringValue);
void AddWStringToMsgString(std::string &msgString, std::wstring addString);

#endif // UTILITY_H