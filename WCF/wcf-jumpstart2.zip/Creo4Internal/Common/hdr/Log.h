#ifndef LOG_H
#define LOG_H


#include <ostream>
#include <fstream>
#include <sstream>
#include <string>

#define DllExport __declspec(dllexport)


// Simple logging class.
// Note that when _DEBUG isn't defined, the
// class basically becomes a do-nothing shell.
// This should allow the compiler to optimize 
// it away & thus there will be no overhead.
class Log
{
public:

	DllExport static Log Instance(const std::string file, int line, bool raw = false);
	DllExport static void Destroy();

	DllExport virtual ~Log();

	//template<class T>
	//Log& operator<<(const T &obj);

	// Overloads for native types.
	// The above commented out function template would
	// have been nice, but you cannot export function
	// templates (you can only export function definitions,
	// not function declarations).
	DllExport Log& operator<<(const std::string &obj);
	DllExport Log& operator<<(const std::wstring &obj);
	DllExport Log& operator<<(const char *obj);
	DllExport Log& operator<<(const unsigned char *obj);
	DllExport Log& operator<<(const long double &obj);
	DllExport Log& operator<<(const double &obj);
	DllExport Log& operator<<(const long long &obj);
	DllExport Log& operator<<(const unsigned long long &obj);
	DllExport Log& operator<<(const long &obj);
	DllExport Log& operator<<(const unsigned long &obj);
	DllExport Log& operator<<(const int &obj);
	DllExport Log& operator<<(const unsigned int &obj);
	DllExport Log& operator<<(const short &obj);
	DllExport Log& operator<<(const unsigned short &obj);
	DllExport Log& operator<<(const char &obj);
	DllExport Log& operator<<(const unsigned char &obj);

	// Overload for manipulators.
	DllExport Log& operator<<(std::ostream& (*func)(std::ostream &ostrm));

private:

	// This is a singleton, so make the constructor private.
	Log(const std::string &logfile);

	// No need to allow copying & assignment.
	//Commented line from VS 2003 project thrown an error modified for VS 2008
	//	Log(const &log);
	Log(const Log& log);
	//Commented line from VS 2003 project thrown an error modified for VS 2008
	//operator=(const Log &);
	Log operator=(const Log &);

	static Log *s_instance;
	static std::string s_logfile;
	static bool s_loggingEnabled;
	static std::ofstream s_ofs;
	static std::stringstream s_sstrm;
} ;


//template<class T>
//Log& Log::operator<<(const T &obj)
//{
//#ifdef _DEBUG
//
//	s_sstrm << obj;
//
//#endif
//
//	return *this;
//}


// Macro to allow setting of the current filename and line number.
#define LOG Log::Instance(__FILE__, __LINE__, false)
#define LOGRAW Log::Instance(__FILE__, __LINE__, true)


#endif	// LOG_H
