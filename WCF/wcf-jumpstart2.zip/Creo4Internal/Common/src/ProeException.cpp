#include <string>


#include "ProeException.h"


ProeException::ProeException(const std::string &file, int line) :

	m_file(file),
	m_line(line)

{

}


ProeException::ProeException(const std::string &file, int line, int result) :

	m_file(file),
	m_line(line),
	m_result(result)

{

}


ProeException::ProeException(const std::string &file, int line, int result, const std::string &message) :

	m_file(file),
	m_line(line),
	m_result(result),
	m_message(message)

{

}


const std::string& ProeException::GetFile() const
{
	return m_file;
}


int ProeException::GetLine() const
{
	return m_line;
}


int ProeException::GetResult() const
{
	return m_result;
}


const std::string& ProeException::GetMsg() const
{
	return m_message;
}
