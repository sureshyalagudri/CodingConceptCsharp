// C/C++ header files.
#include <cstdarg>
#include <io.h>


// Windows application files.
#include <windows.h>
#include <sys/types.h>
#include <sys/stat.h>


// Pro/Toolkit header files.
#include <ProToolkit.h>
#include <ProAsmcomp.h>
#include <ProColor.h>
#include <ProCore.h>
#include <ProDimension.h>
#include <ProDrawing.h>
#include <ProDtlnote.h>
#include <ProDtlsyminst.h>
#include <ProDwgtable.h>
#include <ProFeature.h>
#include <ProFeatType.h>
#include <ProLayer.h>
#include <ProMessage.h>
#include <ProModelitem.h>
#include <ProParameter.h>
#include <ProSolid.h>
#include <ProToolkitDll.h>	
#include <ProWindows.h>
#include <ProWstring.h>	
#include <ProDrawingView.h>


// Application header files.
#include "ProeException.h"
#include "Utility.h"
#include "ProToolkitFacade.h"
#include "Log.h"

void GeometryFacadeActivateWindow(int windowId)
{
	// ProWindowActivate() returns PRO_TK_BAD_CONTEXT when
	// Pro/ENGINEER is run in non-graphics mode, so ignore this error.
	ProError result = ProWindowActivate(windowId);
	if (result != PRO_TK_NO_ERROR && result != PRO_TK_BAD_CONTEXT)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeAddArrayObject(GeometryFacadeArray *array, int index, int numObjects, const void *object)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProArrayObjectAdd( array, index, numObjects, const_cast<void*>(object) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeAddLayerItem(GeometryFacadeLayer *layer, const GeometryFacadeLayerItem *layerItem)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerItemAdd( layer, const_cast<GeometryFacadeLayerItem*>(layerItem) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeArray GeometryFacadeAllocateArray(int numObjects, int objectSize, int reallocationSize)
{
	// NOTE: The caller is responsible for freeing the memory allocated by this function!
	ProError result = PRO_TK_NO_ERROR;
	ProArray array;
	if ( ( result = ProArrayAlloc(numObjects, objectSize, reallocationSize, &array) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return array;
}


GeometryFacadeAsmCompConstraint GeometryFacadeAllocateAsmCompConstraint()
{
	// NOTE: The caller is responsible for freeing the memory allocated by this function!
	ProError result = PRO_TK_NO_ERROR;
	ProAsmcompconstraint constraint;
	if ( ( result = ProAsmcompconstraintAlloc(&constraint) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return constraint;
}


GeometryFacadeSelection GeometryFacadeAllocateSelection(const GeometryFacadeAsmCompPath *asmCompPath, const GeometryFacadeModelItem *modelItem)
{
	// NOTE: The caller is responsible for freeing the memory allocated by this function!
	ProError result = PRO_TK_NO_ERROR;
	ProSelection selection;
	if ( ( result = ProSelectionAlloc(const_cast<ProAsmcomppath*>(asmCompPath), const_cast<ProModelitem*>(modelItem), &selection) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return selection;
}


void GeometryFacadeAssembleAsmComp(const GeometryFacadeAssembly ownerAssembly, const GeometryFacadeSolid componentModel, GeometryFacadeMatrix initialPosition, GeometryFacadeAsmComp *feature)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompAssemble(ownerAssembly, componentModel, initialPosition, feature) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeBackupMdl(const GeometryFacadeMdl handle, const GeometryFacadeMdlData *modelInfo)
{
	ProError result = PRO_TK_NO_ERROR;
	ProMdldata * data = const_cast<ProMdldata*>(modelInfo);
	if ( ( result = ProMdlnameBackup( handle,  data->path) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeChangeDirectory(const GeometryFacadePath path)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDirectoryChange( const_cast<wchar_t*>(path) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeClearMessage()
{
	ProMessageClear();
}


void GeometryFacadeClearWindow(int windowId)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWindowClear(windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCloseCurrentWindow()
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWindowCurrentClose() ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDetailNoteDataLeaders(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailAttach **leaders)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotedataLeadersCollect(noteData, leaders) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDetailNoteDataLines(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailNoteLine **lines )
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotedataLinesCollect(noteData, lines) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDetailNoteLineTexts(const GeometryFacadeDetailNoteLine line, GeometryFacadeDetailNoteText **text)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotelineTextsCollect(line, text) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDrawingDetailNotes(const GeometryFacadeDrawing drawing, const GeometryFacadeDetailSymbolDef *symbol, int sheet, GeometryFacadeDetailNote **notes)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingDtlnotesCollect(drawing, const_cast<ProDtlsymdef*>(symbol), sheet, notes) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDrawingDetailSymbolDefs(const GeometryFacadeDrawing drawing, GeometryFacadeDetailSymbolDef **symbolDefs)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingDtlsymdefsCollect(drawing, symbolDefs) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDrawingDetailSymbolInsts(const GeometryFacadeDrawing drawing, int sheet, GeometryFacadeDetailSymbolInst **symbolInsts)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingDtlsyminstsCollect(drawing, sheet, symbolInsts) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDrawingTables(const GeometryFacadeDrawing drawing, GeometryFacadeDrawingTable **tables)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingTablesCollect(drawing, tables) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCollectDrawingViews(const GeometryFacadeDrawing drawing, GeometryFacadeView **views)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewsCollect(drawing, views) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeCompareWideString(const GeometryFacadeWideChar *wstr1, const GeometryFacadeWideChar *wstr2, int numChars)
{
	ProError result = PRO_TK_NO_ERROR;
	int comp = 0;
	if ( ( result = ProWstringCompare(const_cast<wchar_t*>(wstr1), const_cast<wchar_t*>(wstr2), numChars, &comp) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return comp;
}


void GeometryFacadeCopyWideString(const GeometryFacadeWideChar *source, GeometryFacadeWideChar *target, int numChars)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWstringCopy(const_cast<wchar_t*>(source), target, numChars) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeCountDrawingSheets(const GeometryFacadeDrawing drawing)
{
	ProError result = PRO_TK_NO_ERROR;
	int numSheets = 0;
	if ( ( result = ProDrawingSheetsCount(drawing, &numSheets) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return numSheets;
}


int GeometryFacadeCountDrawingTableColumns(const GeometryFacadeDrawingTable *table)
{
	ProError result = PRO_TK_NO_ERROR;
	int numColumns = 0;
	if ( ( result = ProDwgtableColumnsCount(const_cast<ProDwgtable*>(table), &numColumns) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return numColumns;
}


int GeometryFacadeCountDrawingTableRows(const GeometryFacadeDrawingTable *table)
{
	ProError result = PRO_TK_NO_ERROR;
	int numRows = 0;
	if ( ( result = ProDwgtableRowsCount(const_cast<ProDwgtable*>(table), &numRows) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return numRows;
}


void GeometryFacadeCreateDrawingFromTemplate(const GeometryFacadeName newName, const GeometryFacadeName drawingTemplate, const GeometryFacadeModel *newModel, const GeometryFacadeDrawingCreateOptions options, GeometryFacadeDrawing *drawing)
{
	ProError result = PRO_TK_NO_ERROR;
	ProDwgcreateErrs arrErrors;
	result = ProDrawingFromTmpltCreate(const_cast<wchar_t*>(newName), const_cast<wchar_t*>(drawingTemplate), const_cast<ProModel*>(newModel), options, drawing, &arrErrors);
	if (result == PRO_TK_DWGCREATE_ERRORS)
	{
		//Get the Error list and write to Log
		int iErrors = GeometryFacadeGetDrawingCreateErrorsCount(arrErrors);
		LOG << "Number of Errors: " << iErrors << endl;

		//for(int i=0; i<iErrors; i++)
		//{
			//Get Error Sheet Name 
			int iErrNum = 0;
			int iSheetnum = 0;
			result = ProDwgcreateErrSheetGet(drawing[0], arrErrors/*&arrErrors[i]*/, iErrNum, &iSheetnum);
			if (result == PRO_TK_NO_ERROR)
			{
				LOG << "Error number: " << iErrNum << endl;
				LOG << "Sheet number: " << iSheetnum << endl;
			}

			//Get Errorr View Name 
			iErrNum = 0;
			ProLine wchrViewName;
			result = ProDwgcreateErrViewNameGet(drawing[0], arrErrors/*&arrErrors[i]*/, iErrNum, wchrViewName);
			if (result == PRO_TK_NO_ERROR)
			{
				LOG << "Error number: " << iErrNum << endl;
				ProCharLine chrLine;
				GeometryFacadeWideStringToString(chrLine, wchrViewName);
				LOG << "Sheet number: " << chrLine<< endl;
			}
			//Get Error object Name 
			iErrNum = 0;
			ProLine wchrObjName;
			result = ProDwgcreateErrObjNameGet(drawing[0], arrErrors/*&arrErrors[i]*/, iErrNum, wchrObjName);
			if (result == PRO_TK_NO_ERROR)
			{
				LOG << "Error number: " << iErrNum << endl;
				ProCharLine chrLine;
				GeometryFacadeWideStringToString(chrLine, wchrObjName);
				LOG << "Sheet number: " << chrLine<< endl;
			}
		//}
		//Free Drawing create error 
		ProDwgcreateErrsFree(&arrErrors);
	}
	else if ( result != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCreateLayer(const GeometryFacadeMdl owner, const GeometryFacadeName layerName, const GeometryFacadeLayer *layer)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerCreate( owner, const_cast<wchar_t*>(layerName), const_cast<ProLayer*>(layer) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeCreateParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeName name, const GeometryFacadeParameterValue *value, GeometryFacadeParameter *parameter)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProParameterCreate(const_cast<ProModelitem*>(owner), const_cast<wchar_t*>(name), const_cast<ProParamvalue*>(value), parameter) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeDeleteFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureDeleteOptions *deleteOptions, int numOptions)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProFeatureDelete(solid, const_cast<int*>(featureIds), featureCount, const_cast<ProFeatureDeleteOptions*>(deleteOptions), numOptions) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeDisplayMdl(const GeometryFacadeMdl mdl)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlDisplay(mdl) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeDisplayMessage(const GeometryFacadeFileName fileName, const GeometryFacadeCharLine messageName, const char *message)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMessageDisplay(const_cast<wchar_t*>(fileName), const_cast<char*>(messageName), message) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeEnterDrawingTableText(const GeometryFacadeDrawingTable *table, int column, int row, const GeometryFacadeWideString *lines)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtableTextEnter( const_cast<ProDwgtable*>(table), column, row, const_cast<ProWstring*>(lines) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeEraseMdl(const GeometryFacadeMdl handle)
{
	// Although not in the Pro/TOOLKIT API documentation,
	// a call to ProMdlErase() does not take effect
	// until control is returned to Pro/Engineer.
	// See TPI 105030 for details.
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlErase(handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeExecuteToolkitTask(const GeometryFacadeToolkitDllHandle handle, const GeometryFacadeCharPath functionName, const GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	ProError result = PRO_TK_NO_ERROR;
	ProError functionReturn;
	if ( ( result = ProToolkitTaskExecute(handle, const_cast<char*>(functionName), const_cast<ProArgument*>(inputArguments), outputArguments, &functionReturn) ) != PRO_TK_NO_ERROR )
	{
		// The ProToolkitTaskExecute() call failed for
		// some reason.  This could be because the function
		// itself failed (unlikely) or the underlying DLL
		// function failed (more likely).  Determine which
		// of these occured.

		// ProToolkitTaskExecute() returns PRO_TK_USER_ABORT
		// if the DLL function returns something besides
		// PRO_TK_NO_ERROR.
		if (functionReturn == PRO_TK_USER_ABORT)
		{
			// The DLL function failed.
			throw ProeException( __FILE__, __LINE__, functionReturn, GetErrorString(functionReturn) );
		}
		else
		{
			// The ProToolkitTaskExecute() call failed.
			throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
		}
	}
}


void GeometryFacadeFreeArgumentArray(GeometryFacadeArgument **arg)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProArgumentProarrayFree(arg) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeFreeAsmCompConstraintArray(const GeometryFacadeAsmCompConstraint *constraintArray)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintArrayFree( const_cast<ProAsmcompconstraint*>(constraintArray) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeFreeArray(const GeometryFacadeArray *array)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProArrayFree( const_cast<ProArray*>(array) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeFreeDetailNoteLine(const GeometryFacadeDetailNoteLine line)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotelineFree(line) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeFreeDetailNoteText(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotetextFree(text) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}



void GeometryFacadeGetArgumentByLabel(const GeometryFacadeArgument *argArray, const GeometryFacadeName label, GeometryFacadeValueData *data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProArgumentByLabelGet(const_cast<ProArgument*>(argArray), const_cast<wchar_t*>(label), data) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeGetArraySize(const GeometryFacadeArray array)
{
	ProError result = PRO_TK_NO_ERROR;
	int size;
	if ( ( result = ProArraySizeGet(array, &size) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return size;
}


void GeometryFacadeGetAsmCompConstraintAsmReference(const GeometryFacadeAsmCompConstraint constraint, GeometryFacadeSelection *asmReference, GeometryFacadeDatumSide *asmOrient)
{
	ProError result = PRO_TK_NO_ERROR;
	;
	if ( ( result = ProAsmcompconstraintAsmreferenceGet(constraint, asmReference, asmOrient) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetAsmCompConstraintCompReference(const GeometryFacadeAsmCompConstraint constraint, GeometryFacadeSelection *compReference, GeometryFacadeDatumSide *compOrient)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintCompreferenceGet(constraint, compReference, compOrient) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetAsmCompConstraintOffset(const GeometryFacadeAsmCompConstraint constraint)
{
	ProError result = PRO_TK_NO_ERROR;
	double offset = 0.0;
	if ( ( result = ProAsmcompconstraintOffsetGet(constraint, &offset) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return offset;
}


void GeometryFacadeGetAsmCompConstraints(const GeometryFacadeAsmComp *component, GeometryFacadeAsmCompConstraint **constraints)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompConstraintsGet(const_cast<ProAsmcomp*>(component), constraints) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeAsmCompConstraintType GeometryFacadeGetAsmCompConstraintType(const GeometryFacadeAsmCompConstraint constraint)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeAsmCompConstraintType type;
	if ( ( result = ProAsmcompconstraintTypeGet(constraint, &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}


void GeometryFacadeGetAsmCompMdl(const GeometryFacadeAsmComp *featureHandle, GeometryFacadeMdl *mdlHandle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompMdlGet(const_cast<ProAsmcomp*>(featureHandle), mdlHandle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
//Another version created for visiting & renaming purpose
void GeometryFacadeAsmCompMdl(const GeometryFacadeFeature *featureHandle, GeometryFacadeMdl *mdlHandle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompMdlGet(const_cast<ProAsmcomp*>(featureHandle), mdlHandle) ) != PRO_TK_NO_ERROR )
	{
		  throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetAsmCompPathMdl(const GeometryFacadeAsmCompPath *path, GeometryFacadeMdl *model)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcomppathMdlGet(const_cast<ProAsmcomppath*>(path), model) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetAsmCompPosition(const GeometryFacadeAsmComp *component, GeometryFacadeMatrix position)
{	
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompPositionGet(const_cast<ProAsmcomp*>(component), position) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetCurrentDirectory(GeometryFacadePath path)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDirectoryCurrentGet(path) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetCurrentMdl(GeometryFacadeMdl *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlCurrentGet(handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeMdlInit(GeometryFacadeName name, GeometryFacadeMdlfileType fileType, GeometryFacadeMdl *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlnameInit(name, fileType, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

int GeometryFacadeGetCurrentWindow()
{
	ProError result = PRO_TK_NO_ERROR;
	int windowId = 0;
	if ( ( result = ProWindowCurrentGet(&windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return windowId;
}


void GeometryFacadeGetDimensionSymbol(const GeometryFacadeDimension *dimension, GeometryFacadeName symbol)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionSymbolGet(const_cast<ProDimension*>(dimension), symbol) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeDimensionType GeometryFacadeGetDimensionType(const GeometryFacadeDimension *dimension)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeDimensionType type;
	if ( ( result = ProDimensionTypeGet(const_cast<ProDimension*>(dimension), &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}


double GeometryFacadeGetDimensionValue(const GeometryFacadeDimension *dimension)
{
	ProError result = PRO_TK_NO_ERROR;
	double value = 0.0;
	if ( ( result = ProDimensionValueGet(const_cast<ProDimension*>(dimension), &value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return value;
}


void GeometryFacadeGetDetailAttachment(const GeometryFacadeDetailAttach attachment, GeometryFacadeDetailAttachType *type, GeometryFacadeView *view, GeometryFacadeVector location, GeometryFacadeSelection *attachPoint)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlattachGet(attachment, type, view, location, attachPoint) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetDetailNoteData(const GeometryFacadeDetailNote *note, const GeometryFacadeDetailSymbolDef *symbol, const GeometryFacadeDisplayMode mode, GeometryFacadeDetailNoteData *noteData)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteDataGet(const_cast<ProDtlnote*>(note), const_cast<ProDtlsymdef*>(symbol), mode, noteData) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDetailNoteDataAngle(const GeometryFacadeDetailNoteData noteData)
{
	ProError result = PRO_TK_NO_ERROR;
	double angle = 0.0;
	if ( ( result = ProDtlnotedataAngleGet(noteData, &angle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return angle;
}


void GeometryFacadeGetDetailNoteDataAttachment(const GeometryFacadeDetailNoteData noteData, GeometryFacadeDetailAttach *attachment)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotedataAttachmentGet(noteData, attachment) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeColor GeometryFacadeGetDetailNoteDataColor(const GeometryFacadeDetailNoteData noteData)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeColor color;
	if ( ( result = ProDtlnotedataColorGet(noteData, &color) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return color;
}


void GeometryFacadeGetDetailNoteDataElbowLength(const GeometryFacadeDetailNoteData data, GeometryFacadeBoolean *isDefault, double *elbowLength)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotedataElbowlengthGet(data, const_cast<ProBoolean*>(isDefault), elbowLength) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeGetDetailNoteDataId(const GeometryFacadeDetailNoteData noteData)
{
	ProError result = PRO_TK_NO_ERROR;
	int id = 0;
	if ( ( result = ProDtlnotedataIdGet(noteData, &id) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return id;
}


void GeometryFacadeGetDetailNoteDataJustified(const GeometryFacadeDetailNoteData noteData, GeometryFacadeHorizontalJustification *hJustification, GeometryFacadeVerticalJustification *vJustification)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotedataJustifGet(noteData, hJustification, vJustification) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeBoolean GeometryFacadeGetDetailNoteDataReadOnly(const GeometryFacadeDetailNoteData noteData)
{
	ProError result = PRO_TK_NO_ERROR;
	ProBoolean readOnly = PRO_B_FALSE;
	if ( ( result = ProDtlnotedataReadonlyGet(noteData, &readOnly) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return readOnly;
}


void GeometryFacadeGetDetailNoteModelRef(const GeometryFacadeDetailNote *note, const GeometryFacadeDetailSymbolInst *symbolInst, int lineIndex, int textIndex, GeometryFacadeMdl *model)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteModelrefGet(const_cast<ProDtlnote*>(note), const_cast<ProDtlsyminst*>(symbolInst), lineIndex, textIndex, model) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetDetailNoteTextFont(const GeometryFacadeDetailNoteText text, GeometryFacadeName font)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotetextFontGet(text, font) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDetailNoteTextHeight(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	double height = 0.0;
	if ( ( result = ProDtlnotetextHeightGet(text, &height) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return height;
}


double GeometryFacadeGetDetailNoteTextSlant(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	double slantAngle = 0.0;
	if ( ( result = ProDtlnotetextSlantGet(text, &slantAngle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return slantAngle;
}


void GeometryFacadeGetDetailNoteTextString(const GeometryFacadeDetailNoteText text, GeometryFacadeLine str)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotetextStringGet(text,str) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

/*
TODO:
void GeometryFacadeSetDetailNoteTextString(const GeometryFacadeDetailNoteText text,GeometryFacadeLine str)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnotetextStringSet(text,str) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeSetDetailNoteTexts(const GeometryFacadeDetailNoteLine *text,const GeometryFacadeDetailNoteText *str)
{
	ProError result = PRO_TK_NO_ERROR;
	//GeometryFacadeLine
	if ( ( result = ProDtlnotelineTextsSet(text,const_cast<GeometryFacadeLine*>(str)) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
																					
void GeometryFacadeSetDetailNoteDataLines(const GeometryFacadeDetailNoteData data,GeometryFacadeDetailNoteLine line)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteldataLinesSet(data,&line) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

//ProDtlnoteErase
void GeometryFacadeEraseDetailNote(GeometryFacadeDetailNote text)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteErase(&text) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

//ProDtlnoteModify
void GeometryFacadeModifyDetailNote(GeometryFacadeDetailNote text,GeometryFacadeDetailSymbolDef symbol,const GeometryFacadeDetailNoteData data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteModify(&text,&symbol,data) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

//ProDtlnoteShow
void GeometryFacadeShowDetailNote(GeometryFacadeDetailNote text)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlnoteShow(&text) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}*/
double GeometryFacadeGetDetailNoteTextThickness(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	double thickness = 0.0;
	if ( ( result = ProDtlnotetextThicknessGet(text, &thickness) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return thickness;
}


GeometryFacadeBoolean GeometryFacadeGetDetailNoteTextUnderLine(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	ProBoolean underline = PRO_B_FALSE;
	if ( ( result = ProDtlnotetextUlineGet(text, &underline) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return underline;
}


double GeometryFacadeGetDetailNoteTextWidth(const GeometryFacadeDetailNoteText text)
{
	ProError result = PRO_TK_NO_ERROR;
	double widthFactor = 0.0;
	if ( ( result = ProDtlnotetextWidthGet(text, &widthFactor) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return widthFactor;
}


void GeometryFacadeGetDetailSymbolDefData(const GeometryFacadeDetailSymbolDef *symbolDef, GeometryFacadeDetailSymbolDefData *data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlsymdefDataGet(const_cast<ProDtlsymdef*>(symbolDef), data) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDetailSymbolDefDataHeight(const GeometryFacadeDetailSymbolDefData symbolDefData)
{
	ProError result = PRO_TK_NO_ERROR;
	double height = 0.0;
	if ( ( result = ProDtlsymdefdataHeightGet(symbolDefData, &height) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return height;
}


int GeometryFacadeGetDetailSymbolDefDataId(const GeometryFacadeDetailSymbolDefData symbolDefData)
{
	ProError result = PRO_TK_NO_ERROR;
	int id = 0;
	if ( ( result = ProDtlsymdefdataIdGet(symbolDefData, &id) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return id;
}


double GeometryFacadeGetDetailSymbolInstDataAngle(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	double angle = 0.0;
	if ( ( result = ProDtlsyminstdataAngleGet(data, &angle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return angle;
}


GeometryFacadeDetailSymbolDefAttachType GeometryFacadeGetDetailSymbolInstDataAttachType(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeDetailSymbolDefAttachType type;
	if ( ( result = ProDtlsyminstdataAttachtypeGet(data, &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}


GeometryFacadeColor GeometryFacadeGetDetailSymbolInstDataColor(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeColor color;
	if ( ( result = ProDtlsyminstdataColorGet(data, &color) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return color;
}


void GeometryFacadeGetDetailSymbolInstDataElbowLength(const GeometryFacadeDetailSymbolInstData data, GeometryFacadeBoolean *isDefault, double *elbowLength)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlsyminstdataElbowlengthGet(data, isDefault, elbowLength) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetDetailSymbolInstData(const GeometryFacadeDetailSymbolInst *symbolInst, const GeometryFacadeDisplayMode mode, GeometryFacadeDetailSymbolInstData *data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDtlsyminstDataGet(const_cast<ProDtlsyminst*>(symbolInst), mode, data) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDetailSymbolInstDataHeight(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	double height = 0.0;
	if ( ( result = ProDtlsyminstdataHeightGet(data, &height) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return height;
}


int GeometryFacadeGetDetailSymbolInstDataId(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	int id = 0;
	if ( ( result = ProDtlsyminstdataIdGet(data, &id) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return id;
}


int GeometryFacadeGetDrawingCreateErrorsCount(const GeometryFacadeDrawingCreateErrors errors)
{
	ProError result = PRO_TK_NO_ERROR;
	int count = 0;
	if ( ( result = ProDwgcreateErrsCountGet(errors, &count) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return count;
}


void GeometryFacadeGetDrawingFormat(const GeometryFacadeDrawing drawing, int sheet, GeometryFacadeName formatName)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingFormatGet(drawing, sheet, formatName) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDrawingScale(const GeometryFacadeDrawing drawing, const GeometryFacadeSolid solid, int sheet)
{
	ProError result = PRO_TK_NO_ERROR;
	double scale = 0.0;
	if ( ( result = ProDrawingScaleGet(drawing, solid, sheet, &scale) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return scale;
}


GeometryFacadeDrawingSheetInfo GeometryFacadeGetDrawingSheetInfo(const GeometryFacadeDrawing drawing, int sheet)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeDrawingSheetInfo sheetInfo;
	if ( ( result = ProDrawingSheetInfoGet(drawing, sheet, &sheetInfo) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return sheetInfo;
}


void GeometryFacadeGetDrawingTableCellNote(const GeometryFacadeDrawingTable *table, int column, int row, GeometryFacadeDetailNote *note)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtableCellNoteGet(const_cast<ProDwgtable*>(table), column, row, note) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeDrawingViewDisplay GeometryFacadeGetDrawingViewDisplay(const GeometryFacadeDrawing drawing, const GeometryFacadeView view)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeDrawingViewDisplay displayStatus;
	if ( ( result = ProDrawingViewDisplayGet(drawing, view, &displayStatus) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return displayStatus;
}

void GeometryFacadeSetDrawingViewDisplay(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeDrawingViewDisplay *displayStatus)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewDisplaySet(drawing, view, displayStatus) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

}

void GeometryFacadeSetDrawingViewMdlNameSet(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeName mdlViewName, GeometryFacadeName Orientation, double xAngle, double yAngle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewOrientationFromNameSet(drawing, view, mdlViewName, Orientation, xAngle, yAngle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

}

void GeometryFacadeGetDrawingViewOutline(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadePoint3D outline[2])
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewOutlineGet(drawing, view, outline) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


double GeometryFacadeGetDrawingViewScale(const GeometryFacadeDrawing drawing, const GeometryFacadeView view)
{
	ProError result = PRO_TK_NO_ERROR;
	double scale = 0.0;
	if ( ( result = ProDrawingViewScaleGet(drawing, view, &scale) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return scale;
}

void GeometryFacadeGetDrawingViewScale(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, double dScale)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewScaleSet(drawing, view, dScale) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeGetDrawingViewSheet(const GeometryFacadeDrawing drawing, const GeometryFacadeView view)
{
	ProError result = PRO_TK_NO_ERROR;
	int sheet = 0;
	if ( ( result = ProDrawingViewSheetGet(drawing, view, &sheet) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return sheet;
}


void GeometryFacadeGetDrawingViewSolid(const GeometryFacadeDrawing drawing, const GeometryFacadeView view, GeometryFacadeSolid *solid)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingViewSolidGet(drawing, view, solid) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeFeatureStatus GeometryFacadeGetFeatureStatus(const GeometryFacadeFeature *featureHandle)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeFeatureStatus status;
	if ( ( result = ProFeatureStatusGet(const_cast<ProFeature*>(featureHandle), &status) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return status;
}


GeometryFacadeFeatureType GeometryFacadeGetFeatureType(const GeometryFacadeFeature *featureHandle)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeFeatureType type;
	if ( ( result = ProFeatureTypeGet(const_cast<ProFeature*>(featureHandle), &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}


void GeometryFacadeGetFeatureTypeName(const GeometryFacadeFeature *feature, GeometryFacadeName featureTypeName)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProFeatureTypenameGet(const_cast<ProFeature*>(feature), featureTypeName) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeLayerDisplay GeometryFacadeGetLayerDisplayStatus(const GeometryFacadeLayer *layer)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeLayerDisplay displayStatus;
	if ( ( result = ProLayerDisplaystatusGet(const_cast<ProLayer*>(layer), &displayStatus) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return displayStatus;
}


void GeometryFacadeGetMdlData(const GeometryFacadeMdl handle, GeometryFacadeMdlData *data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlDataGet(handle, data) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeGetMdlId(const GeometryFacadeMdl model)
{
	ProError result = PRO_TK_NO_ERROR;
	int id = 0;
	if ( ( result = ProMdlIdGet(model, &id) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return id;
}


void GeometryFacadeGetMdlLayer(const GeometryFacadeMdl owner, const GeometryFacadeName layerName, GeometryFacadeLayer *layer)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlLayerGet(owner, const_cast<wchar_t*>(layerName), layer) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetMdlName(const GeometryFacadeMdl handle, GeometryFacadeName name)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlMdlnameGet(handle, name) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetMdlPrincipalUnitSystem(const GeometryFacadeMdl mdl, GeometryFacadeUnitSystem *principalSystem)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlPrincipalunitsystemGet(mdl, principalSystem) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeMdlType GeometryFacadeGetMdlType(const GeometryFacadeMdl mdl)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeMdlType type;
	if ( ( result = ProMdlTypeGet(mdl, &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}

GeometryFacadeMdlfileType GeometryFacadeGetMdlFileType(const GeometryFacadeMdl mdl)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeMdlfileType type;
	if ( ( result = ProMdlFiletypeGet(mdl, &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}

int GeometryFacadeGetMdlWindow(const GeometryFacadeMdl mdl)
{
	ProError result = PRO_TK_NO_ERROR;
	int windowId = 0;
	if ( ( result = ProMdlWindowGet(mdl, &windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return windowId;
}


void GeometryFacadeGetModelItemName(const GeometryFacadeModelItem *item, GeometryFacadeName name)
{
	ProError result = PRO_TK_NO_ERROR;
	result = ProModelitemNameGet(const_cast<ProModelitem*>(item), name);

	if(result == GEOMETRY_FACADE_NOT_FOUND)
		result = ProModelitemDefaultnameGet(const_cast<ProModelitem*>(item),name);

	if (result != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetParameterValue(const GeometryFacadeParameter *parameter, GeometryFacadeParameterValue *value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProParameterValueGet(const_cast<ProParameter*>(parameter), value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeGetParameterValueValue(const GeometryFacadeParameterValue *handle, const GeometryFacadeParameterValueType type, void *value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProParamvalueValueGet(handle, type, value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


int GeometryFacadeGetSolidFeatureStatus(const GeometryFacadeSolid solid, int **featureIdArray, GeometryFacadeFeatureStatus **statusArray)
{
	ProError result = PRO_TK_NO_ERROR;
	int numFeatures = 0;
	if ( ( result = ProSolidFeatstatusGet(solid, featureIdArray, statusArray, &numFeatures) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return numFeatures;
}


GeometryFacadeMassProperty GeometryFacadeGetSolidMassProperty(const GeometryFacadeSolid solid, const GeometryFacadeName coordinateSystemName)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeMassProperty massProperty;
	if ( ( result = ProSolidMassPropertyGet(solid, const_cast<wchar_t*>(coordinateSystemName), &massProperty) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return massProperty;
}


void GeometryFacadeGetSurfaceProperties(const GeometryFacadeModelItem *modelItem, GeometryFacadeSurfaceProperties *properties)
{

	int result = ProSurfaceAppearancepropsGet(const_cast<ProModelitem*>(modelItem), properties);
	if (result == PRO_TK_NOT_EXIST)
	{
		// If the part has never had it's surface properties
		// set before (either through Pro/Engineer or ProSurfaceAppearancepropsSet(),
		// ProSurfaceAppearancepropsGet() will fail with a PRO_TK_NOT_EXIST error.
		// Therefore, we need to explicitly set all the fields in
		// properties.  The below values are what Pro/Engineer
		// uses for defaults.
		properties->ambient =      0.50000000000000000;
		properties->diffuse =      0.80000000000000004;
		properties->highlite =     0.13000000000000000;
		properties->shininess =    0.13000000000000000;
		//properties->threshold =    0;
		properties->transparency = 0.00000000000000000;
		properties->color_rgb[0] = 0.87839999999999996;
		properties->color_rgb[1] = 0.94899999999999995;
		properties->color_rgb[2] = 1.00000000000000000;
	}
	else
	{
		if (result != PRO_TK_NO_ERROR)
		{
			throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
		}
	}
}

void GeometryFacadeGetMdlVisibleAppearanceprops(const GeometryFacadeAsmItem *modelItem, GeometryFacadeSurfaceProperties *properties)
{

	int result = ProMdlVisibleAppearancepropsGet(const_cast<GeometryFacadeAsmItem*>(modelItem), properties);
	if (result == PRO_TK_NOT_EXIST)
	{
		// If the part has never had it's surface properties
		// set before (either through Pro/Engineer or ProSurfaceAppearancepropsSet(),
		// ProMdlVisibleAppearancepropsSet() will fail with a PRO_TK_NOT_EXIST error.
		// Therefore, we need to explicitly set all the fields in
		// properties.  The below values are what Pro/Engineer
		// uses for defaults.
		properties->ambient =      0.50000000000000000;
		properties->diffuse =      0.80000000000000004;
		properties->highlite =     0.13000000000000000;
		properties->shininess =    0.13000000000000000;
		//properties->threshold =    0;
		properties->transparency = 0.00000000000000000;
		properties->color_rgb[0] = 0.87839999999999996;
		properties->color_rgb[1] = 0.94899999999999995;
		properties->color_rgb[2] = 1.00000000000000000;
	}
	else
	{
		if (result != PRO_TK_NO_ERROR)
		{
			throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
		}
	}
}

void GeometryFacadeAsmcompAsmitemInit(GeometryFacadeMdl model, int id, GeometryFacadeType type, GeometryFacadeName name,  GeometryFacadeAsmCompPath *path, GeometryFacadeAsmItem *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompAsmitemInit(model, id, type, name, path, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeGetToolkitApplTextPath(GeometryFacadePath textPath)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProToolkitApplTextPathGet(textPath) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeUnitSystemType GeometryFacadeGetUnitSystemType(const GeometryFacadeUnitSystem *system)
{
	ProError result = PRO_TK_NO_ERROR;
	GeometryFacadeUnitSystemType type;
	if ( ( result = ProUnitsystemTypeGet(const_cast<ProUnitsystem*>(system), &type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return type;
}


void GeometryFacadeGetUnitSystemUnit(const GeometryFacadeUnitSystem *system, const GeometryFacadeUnitType type, GeometryFacadeUnitItem *unit)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUnitsystemUnitGet(const_cast<ProUnitsystem*>(system), type, unit) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeHighlightSelection(const GeometryFacadeSelection selection, const GeometryFacadeColorType color)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProSelectionHighlight(selection, color) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeInitAsmCompPath(const GeometryFacadeSolid solidHandle, const GeometryFacadeIdTable memberIdTable, int tableSize, GeometryFacadeAsmCompPath *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcomppathInit(solidHandle, const_cast<int*>(memberIdTable), tableSize, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeInitFeature(const GeometryFacadeSolid ownerHandle, int featureId, GeometryFacadeFeature *featureHandle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProFeatureInit(ownerHandle, featureId, featureHandle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeInitLayerItem(const GeometryFacadeLayerType type, int id, const GeometryFacadeMdl owner, GeometryFacadeLayerItem *item)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerItemInit(type, id, owner, item) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}	


void GeometryFacadeInitModelItem(const GeometryFacadeMdl ownerHandle, int itemId, const GeometryFacadeType itemType, GeometryFacadeModelItem *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProModelitemInit(ownerHandle, itemId, itemType, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeInitModelItemByName(const GeometryFacadeMdl mdl, const GeometryFacadeType type, const GeometryFacadeName name, GeometryFacadeModelItem *item)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProModelitemByNameInit(mdl, type, const_cast<wchar_t*>(name), item) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeInitParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeName name, GeometryFacadeParameter *parameter)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProParameterInit(const_cast<ProModelitem*>(owner), const_cast<wchar_t*>(name), parameter) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


GeometryFacadeBoolean GeometryFacadeIsDetailNoteDataMirrored(const GeometryFacadeDetailNoteData data)
{
	ProError result = PRO_TK_NO_ERROR;
	ProBoolean mirrored = PRO_B_FALSE;
	if ( ( result = ProDtlnotedataIsMirrored(data, &mirrored) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return mirrored;
}


GeometryFacadeBoolean GeometryFacadeIsDetailSymbolInstDataDisplayed(const GeometryFacadeDetailSymbolInstData data)
{
	ProError result = PRO_TK_NO_ERROR;
	ProBoolean isDisplayed = PRO_B_FALSE;
	if ( ( result = ProDtlsyminstdataIsDisplayed(data, &isDisplayed) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}

	return isDisplayed;
}


void GeometryFacadeLoadMdl(const GeometryFacadePath fullPath, const GeometryFacadeMdlType type, const GeometryFacadeBoolean askUserAboutReps, GeometryFacadeMdl *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlLoad(const_cast<wchar_t*>(fullPath), type, askUserAboutReps, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeLoadDll(const char *appName, const GeometryFacadeCharPath execFile, const GeometryFacadeCharPath textDir, const GeometryFacadeBoolean userDisplay, GeometryFacadeToolkitDllHandle *handle)
{
	GeometryFacadeName wAppName;
	GeometryFacadeStringToWideString(wAppName, appName);

	GeometryFacadeError userErrorReturn;	// The error return from the DLL's user_initialize() function.  May be NULL.
	GeometryFacadePath wUserStringReturn; 	// A message from Pro/ENGINEER if there was a problem before the DLL's user_initialize()
	// function was run, or from user_initialize() if it was run but returned an error. 
	// Never written if userErrorReturn is PRO_TK_NO_ERROR.  May be NULL.

	// Explicitly check for the existence of textDir.
	// If it isn't there, ProToolkitDllLoad() will just
	// return the cryptic PRO_TK_COMM_ERROR error.
	// Note that if the message file doesn't exist in
	// textDir\text, ProToolkitDllLoad() will still throw
	// a PRO_TK_COMM_ERROR, but unfortunately, there is
	// no (easy) way to check for this file here since
	// we don't know it's name.

	// textDir doesn't contain the "text" subdirectory.
	std::string messageDir = std::string(textDir) + "text";
	LOG << "Enterd common to load DLL " << endl;
	int rval = 0;
	if ( rval = _access(messageDir.c_str(), 0) )
	{
		// textDir doesn't exist.

		// Since this function is not executed in the AddIn,
		// we need to save the error information here.
		std::string message = "The message directory '" + messageDir + "' does not exist.";
		ProeException ex(__FILE__, __LINE__, rval, message);
		SaveErrorInfo(ex);
		throw ex;
	}
	LOG << "Text directory path :" << messageDir << endl;
	// textDir does exist, but is it a directory?
	struct _stat statBuf;
	rval = _stat(messageDir.c_str(), &statBuf);
	if ( !(statBuf.st_mode & S_IFDIR) )
	{
		// textDir exists but isn't a directory.

		// Since this function is not executed in the AddIn,
		// we need to save the error information here.
		std::string message = "The message directory '" + messageDir + "' is a file, not a directory.";
		ProeException ex(__FILE__, __LINE__, rval, message);
		SaveErrorInfo(ex);
		throw ex;
	}

	LOG << "Inputs to DllLoad:" << endl;
	LOG << "1st input AppName: " << appName << endl;
	LOG << "2nd input execFile: " << execFile << endl;
	LOG << "3rd input textdir: " << textDir << endl;
	LOG << "4th input userDisplay: " << userDisplay << endl;
//	LOG << "5th input handle: " << handle << endl;
//	LOG << "7th input UserStringReturn: " << wUserStringReturn << endl;
	

	LOG << "Activating window here"<< endl;
	int windowID = GeometryFacadeGetCurrentWindow();
	GeometryFacadeActivateWindow(windowID);

	//cout << "going for sleep 5 secs"<< endl;
	//Sleep(5*1000);

	ProError result = PRO_TK_NO_ERROR;
	LOG << "calling Proe API to load dll" << endl;

	if ( ( result = ProToolkitDllLoad(wAppName, const_cast<char*>(execFile), const_cast<char*>(textDir), userDisplay, handle, &userErrorReturn, wUserStringReturn) ) != PRO_TK_NO_ERROR )
	{
		// Since this function is not executed in the AddIn,
		// we need to save the error information here.
		//
		// Note that a PRO_TK_COMM_ERROR probably means that the
		// message file doesn't exist.  See above for more info.
	//	std::string sFailureMsg = "Load DLL failed userErrorReturn is : ";
	//	std::stringstream ss;
	//	ss << userErrorReturn;
	//	sFailureMsg.append(ss.str());		
	//	ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
	//	ex.m_message = sFailureMsg;
	//	SaveErrorInfo(ex);		
		LOG << "Load DLL failed userErrorReturn is : " << userErrorReturn << endl;
//		LOG << "string returned frm Addin dll is wUserStringReturn: " << wUserStringReturn << endl;
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		LOG << "ERROR:	in Load DLL"<<endl;		
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;
		throw ex;
	}

	//cout << "going to sleep for 10 secs" << endl;
	//Sleep(5*1000);

	LOG << "DLL loaded & result is " << result << endl;
	LOG << "userErrorReturn is " << userErrorReturn << endl;
//	LOG << "wUserStringReturn is " << wUserStringReturn << endl;

	// The ProToolkitDllLoad() function executed correctly - now
	// see if the user_initialize() function returned any errors.
	if (userErrorReturn != PRO_TK_NO_ERROR)
	{
		static char userStringReturn[1024];
		GeometryFacadeWideStringToString(userStringReturn, wUserStringReturn);
	//	std::string sFailureMsg = "Failed to return Clean User Error message : ";
	//	sFailureMsg.append(userStringReturn);		
	//	ProeException ex(__FILE__, __LINE__, userErrorReturn, userStringReturn);
	//	ex.m_message = sFailureMsg;
	//	SaveErrorInfo(ex);

		LOG << "userStringReturn is" << userStringReturn << endl;
		// Since this function is not executed in the AddIn,
		// we need to save the error information here.
		LOG << "userErrorReturn is not clean detailed exception below"<<endl;		
		ProeException ex(__FILE__, __LINE__, userErrorReturn, userStringReturn);
		SaveErrorInfo(ex);
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;
		throw ex;
	}

	LOG << "Load dll completed in common" << endl;
}


void GeometryFacadeMdlToModelItem(const GeometryFacadeMdl mdl, GeometryFacadeModelItem *modelItem)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlToModelitem(mdl, modelItem) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRefitWindow(int windowId)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWindowRefit(windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRefreshWindow(int windowId)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWindowRefresh(windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRegenerateAsmComp(const GeometryFacadeAsmComp *compHandle, const GeometryFacadeBoolean updateSoft)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompRegenerate(const_cast<ProAsmcomp*>(compHandle), updateSoft) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRegenerateDrawingSheet(const GeometryFacadeDrawing drawing, int sheet)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgSheetRegenerate(drawing, sheet) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRegenerateDrawingView(const GeometryFacadeDrawing drawing, int viewId)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgViewRegenerate(drawing, viewId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRegenerateSolid(const GeometryFacadeSolid handle, int flags)
{
	ProError result = PRO_TK_NO_ERROR;
	int retry = 0;
	do
	{
		// Three is an arbitrary number.  The Pro/TOOLKIT documentation
		// doesn't tell you if you will need to regenerate more than twice,
		// so rather than take a chance on getting stuck in an endless loop,
		// we will regenerate a maximum of three times.  If the PRO_TK_REGEN_AGAIN
		// error is ever returned, we will know that this number needs to be
		// increased.
		if (retry++ >= 3)
		{
			break;
		}

		// ProSolidRegenerate() returns PRO_TK_REGEN_AGAIN if the model is
		// too complex to be regenerated the first time.
		
		// TODO: The PRO_REGEN_CAN_FIX flag generates much more user-friendly
		// errors in Pro/ENGINEER when a regeneration error occurs.  However,
		// it wouldn't be good to allow the user to fix the model.  Perhaps
		// this flag should be enabled for debug builds?
		//result = ProSolidRegenerate(ProMdlToSolid(model), PRO_REGEN_CAN_FIX);
		result = ProSolidRegenerate(ProMdlToSolid(handle), flags);
	} while (result == PRO_TK_REGEN_AGAIN || result == PRO_TK_GENERAL_ERROR);

	if (result != PRO_TK_NO_ERROR)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRemoveAsmCompConstraint(const GeometryFacadeAsmComp *featureHandle, int index)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompConstrRemove(const_cast<ProAsmcomp*>(featureHandle), index) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRemoveLayerItem(const GeometryFacadeLayer *layer, const GeometryFacadeLayerItem *layerItem)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerItemRemove( const_cast<ProLayer*>(layer), const_cast<ProLayerItem*>(layerItem) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRenameMdl(const GeometryFacadeMdl handle, const GeometryFacadeName newName)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlRename( handle, const_cast<wchar_t*>(newName) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
	
}


void GeometryFacadeRepaintWindow(int windowId)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProWindowRepaint(windowId) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeResumeFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureResumeOptions *resumeOptions, int numOptions)
{
	// NOTE: The Pro/TOOLKIT documentation for ProFeatureResume() states
	// that an error is returned if a feature is already resumed.
	// Unfortunately, they do not say what that error is.  I suspect
	// it is PRO_TK_GENERAL_ERROR.
	ProError result = ProFeatureResume(solid, const_cast<int*>(featureIds), featureCount, const_cast<ProFeatureResumeOptions*>(resumeOptions), numOptions);
	if ( ( result == PRO_TK_NO_ERROR || result == PRO_TK_GENERAL_ERROR ) )
	{
		// Fool the code into thinking everything is ok.
		result = PRO_TK_NO_ERROR;
	}
	else
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeRetrieveMdl(const char *name, const GeometryFacadeMdlType type, GeometryFacadeMdl *handle)
{
	GeometryFacadeFamilyName wName;
	GeometryFacadeStringToWideString(wName, name);
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlRetrieve(wName, type, handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeRetrieveMdl(wchar_t *name, const GeometryFacadeMdlType type, GeometryFacadeMdl *handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ((result = ProMdlRetrieve(name, type, handle)) != PRO_TK_NO_ERROR)
	{
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}
}


void GeometryFacadeSaveLayerDisplayStatus(const GeometryFacadeMdl owner)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerDisplaystatusSave(owner) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSaveMdl(const GeometryFacadeMdl handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlSave(handle) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompConstraintAsmReference(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeSelection asmReference, const GeometryFacadeDatumSide asmOrient)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintAsmreferenceSet(constraint, asmReference, asmOrient) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompConstraintCompReference(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeSelection compReference, const GeometryFacadeDatumSide compOrient)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintCompreferenceSet(constraint, compReference, compOrient) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompConstraintOffset(const GeometryFacadeAsmCompConstraint constraint, double offset)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintOffsetSet(constraint, offset) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompConstraints(const GeometryFacadeAsmCompPath *componentPath, const GeometryFacadeAsmComp *component, const GeometryFacadeAsmCompConstraint *constraints)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompConstraintsSet( const_cast<ProAsmcomppath*>(componentPath), const_cast<ProAsmcomp*>(component), const_cast<ProAsmcompconstraint*>(constraints) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompConstraintType(const GeometryFacadeAsmCompConstraint constraint, const GeometryFacadeAsmCompConstraintType type)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompconstraintTypeSet(constraint, type) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetAsmCompPosition(const GeometryFacadeAsmCompPath *componentPath, const GeometryFacadeAsmComp *component, GeometryFacadeMatrix position)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProAsmcompPositionSet(const_cast<ProAsmcomppath*>(componentPath), const_cast<ProAsmcomp*>(component), position) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetCurrentDrawingSheet(const GeometryFacadeDrawing drawing, int currentSheet)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingCurrentSheetSet(drawing, currentSheet) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetDimensionValue(const GeometryFacadeDimension *dimension, double value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionValueSet(const_cast<ProDimension*>(dimension), value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetDrawingScale(const GeometryFacadeDrawing drawing, const GeometryFacadeSolid solid, int sheet, double scale)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingScaleSet(drawing, solid, sheet, scale) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetLayerDisplayStatus(const GeometryFacadeLayer *layer, const GeometryFacadeLayerDisplay displayStatus)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProLayerDisplaystatusSet(const_cast<ProLayer*>(layer), displayStatus) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetParameterValue(const GeometryFacadeParameter *parameter, const GeometryFacadeParameterValue *value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProParameterValueSet( const_cast<ProParameter*>(parameter), const_cast<ProParamvalue*>(value) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeSetParamValue(GeometryFacadeParameterValue *parameter, const wchar_t *value, const GeometryFacadeParameterValueType valueType)
{
	ProError result = PRO_TK_NO_ERROR;
	if ((result = ProParamvalueSet(parameter, value, valueType)) != PRO_TK_NO_ERROR)
	{
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}
}

void GeometryFacadeSetSolidFeatureStatus(const GeometryFacadeSolid solid, int *featureIdArray, const GeometryFacadeFeatureStatus *statusArray, int numFeatures, const GeometryFacadeBoolean canFix)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProSolidFeatstatusSet(solid, featureIdArray, const_cast<ProFeatStatus*>(statusArray), numFeatures, canFix) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetSurfaceProperties(const GeometryFacadeModelItem *modelItem, const GeometryFacadeSurfaceProperties *properties)
{
	int result = PRO_TK_NO_ERROR;
	if ( ( result =  ProSurfaceAppearancepropsSet(const_cast<ProModelitem*>(modelItem), const_cast<ProSurfaceAppearanceProps*>(properties) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeSetValueDataString(GeometryFacadeValueData *value, const char *str)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProValuedataStringSet( value, const_cast<char*>(str) ) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeSetValueDataWstring(GeometryFacadeValueData *value, const wchar_t *str)
{
	ProError result = PRO_TK_NO_ERROR;
	if ((result = ProValuedataWstringSet(value, const_cast<wchar_t*>(str))) != PRO_TK_NO_ERROR)
	{
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}
}

void GeometryFacadeStopEngineer()
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProEngineerEnd() ) != PRO_TK_NO_ERROR )
	{
		// Since this function is not executed in the AddIn,
		// we need to save the error information here.
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		throw ex;
	}
}


GeometryFacadeWideChar* GeometryFacadeStringToWideString(GeometryFacadeWideChar *wstr, const char *str)
{
	return ProStringToWstring( wstr, const_cast<char*>(str) );
}


void GeometryFacadeSuppressFeature(const GeometryFacadeSolid solid, const int *featureIds, int featureCount, const GeometryFacadeFeatureDeleteOptions *suppressOptions, int numOptions)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProFeatureSuppress(solid, const_cast<int*>(featureIds), featureCount, const_cast<ProFeatureDeleteOptions*>(suppressOptions), numOptions) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeVisitFeatureDimension(const GeometryFacadeFeature *feature, const GeometryFacadeDimensionVisitAction visit, const GeometryFacadeDimensionFilterAction filter, const GeometryFacadeAppData data)
{
	// Not all features have dimensions.  For those that
	// don't, PRO_TK_E_NOT_FOUND is returned.
	// TODO: Investigate a better way to determine whether
	// or not a feature has any dimensions.
	ProError result = ProFeatureDimensionVisit(const_cast<ProFeature*>(feature), visit, filter, data);
	if (result != PRO_TK_NO_ERROR && result != PRO_TK_E_NOT_FOUND)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeVisitMdlLayer(const GeometryFacadeMdl model, const GeometryFacadeLayerAction visitAction, const GeometryFacadeLayerAction filterAction, const GeometryFacadeAppData appData)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProMdlLayerVisit(model, visitAction, filterAction, appData) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeVisitParameter(const GeometryFacadeModelItem *owner, const GeometryFacadeParameterFilter filter, const GeometryFacadeParameterAction action, const GeometryFacadeAppData data)
{
	//NOT ALL PARTS WILL HAVE PARAMETERS
	ProError result = PRO_TK_NO_ERROR;
	result = ProParameterVisit(const_cast<ProModelitem*>(owner), filter, action, data);
	if (result != PRO_TK_NO_ERROR && result != PRO_TK_E_NOT_FOUND)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeVisitSolidDimension(const GeometryFacadeSolid solid, const GeometryFacadeBoolean referenceDimensions, const GeometryFacadeDimensionVisitAction action, const GeometryFacadeDimensionFilterAction filter, const GeometryFacadeAppData data)
{
	// Not all parts have dimensions.  For those that
	// don't, PRO_TK_E_NOT_FOUND is returned.
	// TODO: Investigate a better way to determine whether
	// or not a part has any dimensions.
	ProError result = ProSolidDimensionVisit(solid, referenceDimensions, action, filter, data);
	if (result != PRO_TK_NO_ERROR && result != PRO_TK_E_NOT_FOUND)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


void GeometryFacadeVisitSolidFeature(const GeometryFacadeSolid handle, const GeometryFacadeFeatureVisitAction visitAction, const GeometryFacadeFeatureFilterAction filterAction, const GeometryFacadeAppData appData)
{
	ProError result = PRO_TK_NO_ERROR;
	
	
	if ( (result = ProSolidFeatVisit(handle, visitAction, filterAction, appData)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}


char* GeometryFacadeWideStringToString(char *str, const GeometryFacadeWideChar *wstr)
{	
	return ProWstringToString( str, const_cast<wchar_t*>(wstr) );
}

void GeometryFacadeObjectwindowCreate(GeometryFacadeName object_name,GeometryFacadeType object_type,int *p_window_id)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProObjectwindowCreate(object_name,object_type,p_window_id) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeSolidFamtableCheck(const GeometryFacadeMdl model)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProSolidFamtableCheck((GeometryFacadeSolid)model) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeSolidCreate(GeometryFacadeName name,GeometryFacadeType type,GeometryFacadeSolid* p_handle)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProSolidCreate(name,type,p_handle)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfdataAlloc(GeometryFacadeUdfdata *data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataAlloc(data)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfdataPathSet(GeometryFacadeUdfdata data,GeometryFacadePath path)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataPathSet(data,path)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfdataVardimsGet(GeometryFacadeUdfdata data,GeometryFacadeUdfvardim** variant_dims)
{
	ProError result = PRO_TK_NO_ERROR;
	result = ProUdfdataVardimsGet(data,variant_dims);
	if ( result != PRO_TK_NO_ERROR && result != PRO_TK_E_NOT_FOUND)
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfvardimNameGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeName name)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfvardimNameGet(var_dim,name)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}	
}

void GeometryFacadeUdfvardimPromptGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeLine prompt)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfvardimPromptGet(var_dim,prompt)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}	
}

void GeometryFacadeUdfvardimDefaultvalueGet(GeometryFacadeUdfvardim var_dim,GeometryFacadeUdfVardimType* value_type,double* dim_value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfvardimDefaultvalueGet(var_dim,value_type,dim_value)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}	
}

void GeometryFacadeUdfvardimProarrayFree(GeometryFacadeUdfvardim *var_dim)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfvardimProarrayFree(var_dim)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}	
}

void GeometryFacadeUdfdataUdfvardimAdd(GeometryFacadeUdfdata data,GeometryFacadeUdfvardim variant_dims)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataUdfvardimAdd(data,variant_dims)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}	
}

void GeometryFacadeUdfdataRequiredreferencesGet(GeometryFacadeUdfdata data,GeometryFacadeUdfRequiredRef** required_references)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataRequiredreferencesGet(data,required_references)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfrequiredrefPromptGet(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeLine prompt)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfrequiredrefPromptGet(required_references,prompt)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfrequiredrefTypeGet(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeType *type)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfrequiredrefTypeGet(required_references,type)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfrequiredrefIsannotationref(GeometryFacadeUdfRequiredRef required_references,GeometryFacadeBoolean *is_annotation_ref)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfrequiredrefIsannotationref(required_references,is_annotation_ref)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfrequiredrefProarrayFree(GeometryFacadeUdfRequiredRef *required_references)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfrequiredrefProarrayFree(required_references)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfreferenceAlloc(GeometryFacadeLine prompt,GeometryFacadeSelection ref_item,GeometryFacadeBoolean external,GeometryFacadeUdfreference* reference)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfreferenceAlloc(prompt,ref_item,external,reference)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfdataReferenceAdd(GeometryFacadeUdfdata data,GeometryFacadeUdfreference reference)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataReferenceAdd(data,reference)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfCreate(GeometryFacadeSolid solid,GeometryFacadeUdfdata data,GeometryFacadeAsmCompPath* asm_reference,GeometryFacadeUdfCreateOption* options,int n_options,GeometryFacadeGroup* udf)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfCreate(solid,data,asm_reference,options,n_options,udf)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfDimensionsCollect(GeometryFacadeGroup* udf,GeometryFacadeDimension** dims)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfDimensionsCollect(udf,dims)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfDimensionNameGet(GeometryFacadeGroup* udf,GeometryFacadeDimension* dim,GeometryFacadeLine name)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfDimensionNameGet(udf,dim,name)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfdataExternalsymbolsGet(GeometryFacadeUdfdata data,GeometryFacadeUdfextsymbol** external_symbols)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfdataExternalsymbolsGet(data,external_symbols)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeUdfUpdate(GeometryFacadeGroup *group)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProUdfUpdate(group)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtabledataAlloc(GeometryFacadeDwgtabledata* data)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtabledataAlloc(data)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtabledataSizetypeSet(GeometryFacadeDwgtabledata data,GeometryFacadeDwgtableSizetype size_type)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtabledataSizetypeSet(data,size_type)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtabledataColumnsSet(GeometryFacadeDwgtabledata data,int column,double* widths,GeometryFacadeHorzJust* justifications)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtabledataColumnsSet(data,column,widths,justifications)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtabledataRowsSet(GeometryFacadeDwgtabledata data,int n_rows,double* heights)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtabledataRowsSet(data,n_rows,heights)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtabledataOriginSet(GeometryFacadeDwgtabledata data,GeometryFacadePoint3D origin)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtabledataOriginSet(data,origin)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDrawingTableCreate(GeometryFacadeDrawing drawing,GeometryFacadeDwgtabledata data,int display,GeometryFacadeDrawingTable* table)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingTableCreate(drawing,data,display,table)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtableDisplay(GeometryFacadeDrawingTable *table)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtableDisplay(table)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDwgtableDelete(GeometryFacadeDrawingTable *table,int display)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDwgtableDelete(table,display)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeDrawingSheetTrfGet(GeometryFacadeDrawing drawing,int sheet,GeometryFacadeName sheet_size,GeometryFacadeMatrix transform)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDrawingSheetTrfGet(drawing,sheet,sheet_size,transform)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadePntTrfEval(GeometryFacadeVector in_point,GeometryFacadeMatrix trf,GeometryFacadeVector out_point)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProPntTrfEval(in_point,trf,out_point)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeGroupFeaturesCollect(GeometryFacadeGroup *oGroup,GeometryFacadeFeature **oFeats)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProGroupFeaturesCollect(oGroup,oFeats)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

void GeometryFacadeModelitemDefaultnameGet(GeometryFacadeModelItem *item,GeometryFacadeName name)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProModelitemDefaultnameGet(item,name)) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeSetDimensionDecimalValue(const GeometryFacadeDimension *dimension, int value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionDecimalsSet(const_cast<ProDimension*>(dimension), value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeSetDimensionToleranceValue(const GeometryFacadeDimension *dimension, double upper, double lower)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionToleranceSet(const_cast<ProDimension*>(dimension), upper, lower) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeGetDimensionToleranceValue(const GeometryFacadeDimension *dimension, double *upper, double *lower)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionToleranceGet(const_cast<ProDimension*>(dimension), upper, lower) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeSetDimensionToleranceDecimalValue(const GeometryFacadeDimension *dimension, int value)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionTolerancedecimalsSet(const_cast<ProDimension*>(dimension), value) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeSetDimensionTableNameColumnValue(const GeometryFacadeDimension *dimension, GeometryFacadeToleranceTable table, GeometryFacadeName value, int column)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionTollabelSet(const_cast<ProDimension*>(dimension), table, value, column) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}
void GeometryFacadeGetDimensionTableNameColumnValue(const GeometryFacadeDimension *dimension, GeometryFacadeToleranceTable *table, GeometryFacadeName value, int *column)
{
	ProError result = PRO_TK_NO_ERROR;
	if ( ( result = ProDimensionTollabelGet(const_cast<ProDimension*>(dimension), table, value, column) ) != PRO_TK_NO_ERROR )
	{
		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
	}
}

//This is copy of ProUtilMatrixInvert() , this function causes linking errors.
//So for now creating local copy of it. 
int GeometryFacadeUtilMatrixInvert(double m[4][4],double output[4][4])
{
    double vec[3], scale_sq, inv_sq_scale;
    int i,j;

/*--------------------------------------------------------------------*\
    If the matrix is null, return the identity matrix
\*--------------------------------------------------------------------*/
   /* if(m == NULL)
    {
	ProUtilMatrixCopy(NULL, output);
	return(1);
    }*/

/*--------------------------------------------------------------------*\
    Obtain the matrix scale
\*--------------------------------------------------------------------*/
    vec[0] = m[0][0];
    vec[1] = m[0][1];
    vec[2] = m[0][2];
    scale_sq = vec[0] * vec[0] + vec[1] * vec[1] + vec[2] * vec[2];

/*--------------------------------------------------------------------*\
    Check whether there is an inverse, and if not, return 0
\*--------------------------------------------------------------------*/
    if(scale_sq < (.000000001 * .000000001))
	return(0);

/*--------------------------------------------------------------------*\
    Need the inverse scale squared 
\*--------------------------------------------------------------------*/
    inv_sq_scale = 1.0 / scale_sq;

/*--------------------------------------------------------------------*\
    The orientation vectors
\*--------------------------------------------------------------------*/
    for(j=0;j<3;j++)
    {
	for(i=0;i<3;i++)
	    output[j][i] = m[i][j] * inv_sq_scale;
	output[j][3] = 0.0;
    }

/*--------------------------------------------------------------------*\
    The shift vectors
\*--------------------------------------------------------------------*/
    for(i=0;i<3;i++)
    {
	output[3][i] = 0.0;
	for(j=0;j<3;j++)
	    output[3][i] -= m[i][j] * m[3][j] * inv_sq_scale;
    }
    output[3][3] = 1.0;

    return(1);
}




std::string GetErrorString(int error)
{
	// I hate to do this, but there really is
	// no good way of mapping enums to their 
	// string values in C.
	// Since Pro/TOOLKIT is well-established,
	// hopefully an out-of-sync condition between
	// this array & the ProToolkitErrors.h file
	// won't happen very often.
	static std::string errorList[] =
	{
		"PRO_TK_NO_ERROR",					// abs(0)
		"PRO_TK_GENERAL_ERROR",				// abs(-1)
		"PRO_TK_BAD_INPUTS",				// abs(-2)
		"PRO_TK_USER_ABORT",				// abs(-3)
		"PRO_TK_E_NOT_FOUND",				// abs(-4)
		"PRO_TK_E_FOUND",					// abs(-5)
		"PRO_TK_LINE_TOO_LONG",				// abs(-6)
		"PRO_TK_CONTINUE",					// abs(-7)
		"PRO_TK_BAD_CONTEXT",				// abs(-8)
		"PRO_TK_NOT_IMPLEMENTED",			// abs(-9)
		"PRO_TK_OUT_OF_MEMORY",				// abs(-10)
		"PRO_TK_COMM_ERROR",				// abs(-11) 
		"PRO_TK_NO_CHANGE",					// abs(-12)
		"PRO_TK_SUPP_PARENTS",				// abs(-13)
		"PRO_TK_PICK_ABOVE",				// abs(-14)
		"PRO_TK_INVALID_DIR",				// abs(-15)
		"PRO_TK_INVALID_FILE",				// abs(-16)
		"PRO_TK_CANT_WRITE",				// abs(-17)
		"PRO_TK_INVALID_TYPE",				// abs(-18)
		"PRO_TK_INVALID_PTR",				// abs(-19)
		"PRO_TK_UNAV_SEC",					// abs(-20)
		"PRO_TK_INVALID_MATRIX",			// abs(-21)
		"PRO_TK_INVALID_NAME",				// abs(-22)
		"PRO_TK_NOT_EXIST",					// abs(-23)
		"PRO_TK_CANT_OPEN",					// abs(-24)
		"PRO_TK_ABORT",						// abs(-25)
		"PRO_TK_NOT_VALID",					// abs(-26)
		"PRO_TK_INVALID_ITEM",				// abs(-27)
		"PRO_TK_MSG_NOT_FOUND",				// abs(-28)
		"PRO_TK_MSG_NO_TRANS",				// abs(-29)
		"PRO_TK_MSG_FMT_ERROR",				// abs(-30)
		"PRO_TK_MSG_USER_QUIT",				// abs(-31)
		"PRO_TK_MSG_TOO_LONG",				// abs(-32)
		"PRO_TK_CANT_ACCESS",				// abs(-33)
		"PRO_TK_OBSOLETE_FUNC",				// abs(-34)
		"PRO_TK_NO_COORD_SYSTEM",			// abs(-35)
		"PRO_TK_E_AMBIGUOUS",				// abs(-36)
		"PRO_TK_E_DEADLOCK",				// abs(-37)
		"PRO_TK_E_BUSY",					// abs(-38)
		"PRO_TK_E_IN_USE",					// abs(-39)
		"PRO_TK_NO_LICENSE",				// abs(-40)
		"PRO_TK_BSPL_UNSUITABLE_DEGREE",	// abs(-41)
		"PRO_TK_BSPL_NON_STD_END_KNOTS",	// abs(-42)
		"PRO_TK_BSPL_MULTI_INNER_KNOTS",	// abs(-43)
		"PRO_TK_BAD_SRF_CRV",				// abs(-44)
		"PRO_TK_EMPTY",						// abs(-45)
		"PRO_TK_BAD_DIM_ATTACH",			// abs(-46)
		"PRO_TK_NOT_DISPLAYED",				// abs(-47)
		"PRO_TK_CANT_MODIFY",				// abs(-48)
		"PRO_TK_CHECKOUT_CONFLICT",			// abs(-49)
		"PRO_TK_CRE_VIEW_BAD_SHEET",		// abs(-50)
		"PRO_TK_CRE_VIEW_BAD_MODEL",		// abs(-51)
		"PRO_TK_CRE_VIEW_BAD_PARENT",		// abs(-52)
		"PRO_TK_CRE_VIEW_BAD_TYPE",			// abs(-53)
		"PRO_TK_CRE_VIEW_BAD_EXPLODE",		// abs(-54)
		"PRO_TK_UNATTACHED_FEATS",			// abs(-55)
		"PRO_TK_REGEN_AGAIN",				// abs(-56)
		"PRO_TK_DWGCREATE_ERRORS",			// abs(-57)
		"PRO_TK_UNSUPPORTED",				// abs(-58)
		// -59 through -91 are unassigned by Pro/TOOLKIT
		"NOT_USED",							// abs(-59)
		"NOT_USED",							// abs(-60)
		"NOT_USED",							// abs(-61)
		"NOT_USED",							// abs(-62)
		"NOT_USED",							// abs(-63)
		"NOT_USED",							// abs(-64)
		"NOT_USED",							// abs(-65)
		"NOT_USED",							// abs(-66)
		"NOT_USED",							// abs(-67)
		"NOT_USED",							// abs(-68)
		"NOT_USED",							// abs(-69)
		"NOT_USED",							// abs(-70)
		"NOT_USED",							// abs(-71)
		"NOT_USED",							// abs(-72)
		"NOT_USED",							// abs(-73)
		"NOT_USED",							// abs(-74)
		"NOT_USED",							// abs(-75)
		"NOT_USED",							// abs(-76)
		"NOT_USED",							// abs(-77)
		"NOT_USED",							// abs(-78)
		"NOT_USED",							// abs(-79)
		"NOT_USED",							// abs(-80)
		"NOT_USED",							// abs(-81)
		"NOT_USED",							// abs(-82)
		"NOT_USED",							// abs(-83)
		"NOT_USED",							// abs(-84)
		"NOT_USED",							// abs(-85)
		"NOT_USED",							// abs(-86)
		"NOT_USED",							// abs(-87)
		"NOT_USED",							// abs(-88)
		"NOT_USED",							// abs(-89)
		"NOT_USED",							// abs(-90)
		"NOT_USED",							// abs(-91)
		"PRO_TK_APP_NO_LICENSE",			// abs(-92)
		"PRO_TK_APP_XS_CALLBACKS",			// abs(-93)
		"PRO_TK_APP_STARTUP_FAIL",			// abs(-94)
		"PRO_TK_APP_INIT_FAIL",				// abs(-95)
		"PRO_TK_APP_VERSION_MISMATCH",		// abs(-96)
		"PRO_TK_APP_COMM_FAILURE",			// abs(-97)
		"PRO_TK_APP_NEW_VERSION",			// abs(-98)
		"PRO_TK_APP_UNLOCK"					// abs(-99)
	};

	if (error > 0 || error < -99)
	{
		// The passed in error is out of range.
		return "OUT_OF_RANGE";
	}

	return errorList[abs(error)];
}


