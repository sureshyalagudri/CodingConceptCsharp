// C/C++ header files.
#include <cmath>
#include <string>
#include <sstream>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "ErrorInfo.h"


ErrorInfo g_errorInfo;


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetErrorString_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		// Declare the output arguments and call the function.
		std::stringstream strm;
		std::string line;
		strm << g_errorInfo.line;
		strm >> line;

		std::string output = "File: " + g_errorInfo.file + "\n" + 
							"Line: " + line + "\n" + 
							"Method: " + g_errorInfo.method + "\n" + 
							"Message: " + g_errorInfo.message;

		GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1, (GeometryFacadeArray*)outputArguments);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataString( &arg.value, const_cast<char*>( output.c_str() ) );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so return the Pro/TOOLKIT error.
		result = (GeometryFacadeError)ex.GetError();
	}

	return result;
}


// Public functions.
std::string GetProErrorString(int error)
{
	// I hate to do this, but there really is
	// no good way of mapping enums to their 
	// string values in C.
	// Since Pro/TOOLKIT is well-established,
	// hopefully an out-of-sync condition between
	// this array & the ProToolkitErrors.h file
	// won't happen very often.
	//
	// On the bright side, this is a good place
	// to put a breakpoint to see what's going
	// on when a Pro/TOOLKIT function fails
	// (assuming your using one of the CHECK_RESULT macros).
	static std::string errorList[] =
	{
		"PRO_TK_NO_ERROR",					// abs(0)
		"PRO_TK_GENERAL_ERROR",				// abs(-1)
		"PRO_TK_BAD_INPUTS",				// abs(-2)
		"PRO_TK_USER_ABORT",				// abs(-3)
		"PRO_TK_E_NOT_FOUND",				// abs(-4)
		"PRO_TK_E_FOUND",					// abs(-5)
		"PRO_TK_LINE_TOO_LONG",				// abs(-6)
		"PRO_TK_CONTINUE",					// abs(-7)
		"PRO_TK_BAD_CONTEXT",				// abs(-8)
		"PRO_TK_NOT_IMPLEMENTED",			// abs(-9)
		"PRO_TK_OUT_OF_MEMORY",				// abs(-10)
		"PRO_TK_COMM_ERROR",				// abs(-11) 
		"PRO_TK_NO_CHANGE",					// abs(-12)
		"PRO_TK_SUPP_PARENTS",				// abs(-13)
		"PRO_TK_PICK_ABOVE",				// abs(-14)
		"PRO_TK_INVALID_DIR",				// abs(-15)
		"PRO_TK_INVALID_FILE",				// abs(-16)
		"PRO_TK_CANT_WRITE",				// abs(-17)
		"PRO_TK_INVALID_TYPE",				// abs(-18)
		"PRO_TK_INVALID_PTR",				// abs(-19)
		"PRO_TK_UNAV_SEC",					// abs(-20)
		"PRO_TK_INVALID_MATRIX",			// abs(-21)
		"PRO_TK_INVALID_NAME",				// abs(-22)
		"PRO_TK_NOT_EXIST",					// abs(-23)
		"PRO_TK_CANT_OPEN",					// abs(-24)
		"PRO_TK_ABORT",						// abs(-25)
		"PRO_TK_NOT_VALID",					// abs(-26)
		"PRO_TK_INVALID_ITEM",				// abs(-27)
		"PRO_TK_MSG_NOT_FOUND",				// abs(-28)
		"PRO_TK_MSG_NO_TRANS",				// abs(-29)
		"PRO_TK_MSG_FMT_ERROR",				// abs(-30)
		"PRO_TK_MSG_USER_QUIT",				// abs(-31)
		"PRO_TK_MSG_TOO_LONG",				// abs(-32)
		"PRO_TK_CANT_ACCESS",				// abs(-33)
		"PRO_TK_OBSOLETE_FUNC",				// abs(-34)
		"PRO_TK_NO_COORD_SYSTEM",			// abs(-35)
		"PRO_TK_E_AMBIGUOUS",				// abs(-36)
		"PRO_TK_E_DEADLOCK",				// abs(-37)
		"PRO_TK_E_BUSY",					// abs(-38)
		"PRO_TK_E_IN_USE",					// abs(-39)
		"PRO_TK_NO_LICENSE",				// abs(-40)
		"PRO_TK_BSPL_UNSUITABLE_DEGREE",	// abs(-41)
		"PRO_TK_BSPL_NON_STD_END_KNOTS",	// abs(-42)
		"PRO_TK_BSPL_MULTI_INNER_KNOTS",	// abs(-43)
		"PRO_TK_BAD_SRF_CRV",				// abs(-44)
		"PRO_TK_EMPTY",						// abs(-45)
		"PRO_TK_BAD_DIM_ATTACH",			// abs(-46)
		"PRO_TK_NOT_DISPLAYED",				// abs(-47)
		"PRO_TK_CANT_MODIFY",				// abs(-48)
		"PRO_TK_CHECKOUT_CONFLICT",			// abs(-49)
		"PRO_TK_CRE_VIEW_BAD_SHEET",		// abs(-50)
		"PRO_TK_CRE_VIEW_BAD_MODEL",		// abs(-51)
		"PRO_TK_CRE_VIEW_BAD_PARENT",		// abs(-52)
		"PRO_TK_CRE_VIEW_BAD_TYPE",			// abs(-53)
		"PRO_TK_CRE_VIEW_BAD_EXPLODE",		// abs(-54)
		"PRO_TK_UNATTACHED_FEATS",			// abs(-55)
		"PRO_TK_REGEN_AGAIN",				// abs(-56)
		"PRO_TK_DWGCREATE_ERRORS",			// abs(-57)
		"PRO_TK_UNSUPPORTED",				// abs(-58)
		// -59 through -91 are unassigned by Pro/TOOLKIT
		"NOT_USED",							// abs(-59)
		"NOT_USED",							// abs(-60)
		"NOT_USED",							// abs(-61)
		"NOT_USED",							// abs(-62)
		"NOT_USED",							// abs(-63)
		"NOT_USED",							// abs(-64)
		"NOT_USED",							// abs(-65)
		"NOT_USED",							// abs(-66)
		"NOT_USED",							// abs(-67)
		"NOT_USED",							// abs(-68)
		"NOT_USED",							// abs(-69)
		"NOT_USED",							// abs(-70)
		"NOT_USED",							// abs(-71)
		"NOT_USED",							// abs(-72)
		"NOT_USED",							// abs(-73)
		"NOT_USED",							// abs(-74)
		"NOT_USED",							// abs(-75)
		"NOT_USED",							// abs(-76)
		"NOT_USED",							// abs(-77)
		"NOT_USED",							// abs(-78)
		"NOT_USED",							// abs(-79)
		"NOT_USED",							// abs(-80)
		"NOT_USED",							// abs(-81)
		"NOT_USED",							// abs(-82)
		"NOT_USED",							// abs(-83)
		"NOT_USED",							// abs(-84)
		"NOT_USED",							// abs(-85)
		"NOT_USED",							// abs(-86)
		"NOT_USED",							// abs(-87)
		"NOT_USED",							// abs(-88)
		"NOT_USED",							// abs(-89)
		"NOT_USED",							// abs(-90)
		"NOT_USED",							// abs(-91)
		"PRO_TK_APP_NO_LICENSE",			// abs(-92)
		"PRO_TK_APP_XS_CALLBACKS",			// abs(-93)
		"PRO_TK_APP_STARTUP_FAIL",			// abs(-94)
		"PRO_TK_APP_INIT_FAIL",				// abs(-95)
		"PRO_TK_APP_VERSION_MISMATCH",		// abs(-96)
		"PRO_TK_APP_COMM_FAILURE",			// abs(-97)
		"PRO_TK_APP_NEW_VERSION",			// abs(-98)
		"PRO_TK_APP_UNLOCK"					// abs(-99)
	};

	if (error > 0 || error < -99)
	{
		// The passed in error is out of range.
		return "OUT_OF_RANGE";
	}

	return errorList[abs(error)];
}


