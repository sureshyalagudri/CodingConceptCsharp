#include <ostream>
#include <fstream>
#include <sstream>
#include <string>
#include <ctime>


#include "ProeException.h"
#include "Utility.h"
#include "Log.h"


Log* Log::s_instance = NULL;
std::string Log::s_logfile;
bool Log::s_loggingEnabled = false;
std::ofstream Log::s_ofs;
std::stringstream Log::s_sstrm;


Log Log::Instance(const std::string file, int line, bool raw)
{
	// An efficiency so IsLoggingEnabled() is only called once.
	//Commented line from VS 2003 project thrown an error modified for VS 2008
	//static loggingEnabled = s_loggingEnabled = IsLoggingEnabled();
	static bool loggingEnabled = s_loggingEnabled = IsLoggingEnabled();

	if (s_loggingEnabled)
	{
		// TODO: should have a mutex here.
		if (s_instance == NULL)
		{
			// Create a new Log instance.
			s_instance = new Log( GetLogFile() );
		}

		// Get the current date & time as a string.
		time_t currentTime = time(0);
		tm now = *localtime(&currentTime);
		char strtime[BUFSIZ];
		strftime(strtime, sizeof(strtime) - 1, "%x %X", &now);

		// Write the date to the stream.
		Log::s_sstrm << strtime << " ";

		if (!raw)
		{
			// Append the date, base filename & line number to the stream.
			Log::s_sstrm << file.substr(file.rfind('\\') + 1) << "[" << line << "]: " ;
		}
	}

	return *s_instance;
}


Log::Log(const std::string &logfile) 
{
	if (s_loggingEnabled)
	{
		// Open the specified log file.  Will append to it if it exists.
		s_ofs.open(logfile.c_str(), std::ios::out | std::ios::app);
		if (!s_ofs)
		{
			// Since this function is not executed in the AddIn,
			// we need to save the error information here.
			ProeException ex(__FILE__, __LINE__, -1, "Failed to open log file '" + logfile + "'.");
			SaveErrorInfo(ex);	
			throw ex;
		}

		s_logfile = logfile;
	}
}


Log::~Log()
{
	// Since this is a singleton, do not delete
	// s_instance in the destructor, else we will recurse.
	// Have the caller invoke Destroy() instead.
	// Do not close the stream in the destructor either.
}


void Log::Destroy()
{
	if (s_loggingEnabled)
	{
		s_ofs.close();

		// Since this is a singleton, we must delete s_instance
		// here & not in the destructor to prevent recursion.
		delete s_instance;
	}
}


Log& Log::operator<<(const std::string &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}

Log& Log::operator<<(const std::wstring &obj)
{
	if (s_loggingEnabled)
	{
		
		std::string s( obj.begin(), obj.end() );
		s_sstrm << s;
	}

	return *this;
}

Log& Log::operator<<(const char *obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned char *obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const long double &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const double &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const long long &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned long long &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const long &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned long &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const int &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned int &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const short &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned short &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const char &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(const unsigned char &obj)
{
	if (s_loggingEnabled)
	{
		s_sstrm << obj;
	}

	return *this;
}


Log& Log::operator<<(std::ostream& (*func)(std::ostream &ostrm))
{
	if (s_loggingEnabled)
	{
		// Call the specified manipulator function.
		func(s_sstrm);
	    
		// If this manipulator is std::endl, write the
		// entry to the log.
		if (func == std::endl)
		{
			s_ofs << s_sstrm.str();

			// Reset the streams.
			s_ofs.flush();
			s_sstrm.str("");
		}
	}

	return *this;
}

//Copy Constructor defined for VS 2008
Log::Log(const Log& log)
{}
