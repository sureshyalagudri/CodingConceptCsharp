// C/C++ header files.
#include <string>
#include <sstream>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Log.h"


// This module is a collection of various utilities.
// Some of the functions in here were taken from the 
// Pro/TOOLKIT example files located in the
// protoolkit\protk_appls\pt_examples directory.
// The files UtilCollect.c & UtilVisit.c from the pt_utils
// subdirectory are of particular interest to us and should be examined 
// to get a good understanding of how Pro/TOOLKIT works.
//
// Note that the ProUtil prefix has been dropped from those
// functions that were taken from the toolkit examples.  This
// was done to avoid confusion with "real" Pro/TOOLKIT functions.


struct ErrorInfo
{
	std::string file;
	int line;
	int result;
	std::string message;
} ;

static ErrorInfo g_errorInfo;
static std::string g_output;


static char g_iniFile[1024];
static char g_version[128];


// Exported functions.

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetAddInErrorInfo_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	// This function is used to retrieve the error information
	// from the AddIn, which is why it is a task.

	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		// Declare the output arguments and call the function.
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataString( &arg.value, GetWrapperErrorInfo() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT const char* GetWrapperErrorInfo()
{
	// This function is used to retrieve the error information
	// from the Wrapper, which is why it isn't a task.

	// Declare the output arguments and call the function.
	std::stringstream strm;

	std::string line;
	strm << g_errorInfo.line;
	strm >> line;

	strm.clear();

	std::string result;
	strm << g_errorInfo.result;
	strm >> result;

	g_output = "File: " + g_errorInfo.file.substr(g_errorInfo.file.rfind('\\') + 1) + "||" + 
			   "Line: " + line + "||" + 
			   "Result: " + result + "||" + 
			   g_errorInfo.message;
			   //"Message: " + g_errorInfo.message;

	return g_output.c_str();
}


// Public functions.
char* AppendStrings(char **string1_ptr, ...) 
{
	size_t newlength, l1, l2;
	char* string2 = "";
	
	va_list ap;						// Will point to each unnamed argument in turn.
	const char *p = *string1_ptr;
	va_start(ap, string1_ptr);		// Point to first element after fmt.
	
	while(string2 != "\n") 
	{
		string2 = va_arg(ap, char*);
		
		l1 = strlen(*string1_ptr);
		l2 = strlen(string2);

		newlength = l1 + l2 + 1;	// Length of strings plus 1 for \n.
		*string1_ptr = (char*)realloc(*string1_ptr , newlength * sizeof(char));	
		if (*string1_ptr == NULL) 
		{
			printf("Error allocating memory in create_memory\n");
			exit(1);
		}

		strcat(*string1_ptr, string2);
		if(*string1_ptr == NULL)
		{
			printf("Error concatenating strings\n");

			return NULL;
		} 
	}

	return *string1_ptr;
}


/*====================================================================*\
    FUNCTION :	AsmcompFilterAction()
    PURPOSE  :	A filter used by AsmCompVisit() to visit
		features which are assembly components
\*====================================================================*/
GeometryFacadeError AsmcompFilterAction(GeometryFacadeFeature *feature, GeometryFacadeAppData app_data)
{
    // Get the feature type.
    GeometryFacadeFeatureType ftype = GeometryFacadeGetFeatureType(feature);

    // If the feature is an assembly component,
	// return NO ERROR,
    // else
	// return CONTINUE
    if (ftype == GEOMETRY_FACADE_FEAT_COMPONENT)
	{
		return GEOMETRY_FACADE_NO_ERROR;
	}

    return GEOMETRY_FACADE_CONTINUE;
}


/*=========================================================================*\
    Function:	Collect2ParamDBVisitAction()
    Purpose:	Add any object given by pointer to the Collection
	Arguments:  void *p_object In: The pointer to the object being visited
				GeometryFacadeAppData app_data In:	In fact it's GeometryFacadeArray**
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
\*=========================================================================*/
GeometryFacadeError Collect2ParamDBVisitAction(void *p_object, GeometryFacadeAppData app_data)
{
    GeometryFacadeArray *p_array;
    
    p_array = (GeometryFacadeArray*)((void**)app_data)[0];

    GeometryFacadeAddArrayObject(p_array, GEOMETRY_FACADE_VALUE_UNUSED, 1, p_object);

    return GEOMETRY_FACADE_NO_ERROR;
}


/*=========================================================================*\
    Function:	Collect3ParamDBVisitAction()
    Purpose:	Add any object given by pointer to the Collection
	Arguments:  void *p_object In: The pointer to the object being visited
				GeometryFacadeError status In: The status returned by filter func
				GeometryFacadeAppData app_data In:	In fact it's GeometryFacadeArray**
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
\*=========================================================================*/
GeometryFacadeError Collect3ParamDBVisitAction(void *p_object, GeometryFacadeError status, GeometryFacadeAppData app_data)
{
    return Collect2ParamDBVisitAction(p_object, app_data);
}


/*=========================================================================*\
    Function:	CollectAsmcomp()
    Purpose:	Return a list of assembly components in the assembly
	Arguments:  GeometryFacadeAssembly p_assy In: The assembly handle
				GeometryFacadeAsmComp **p_asmcomps Out: GeometryFacadeArray with collected asm 
					                         comps. The function allocates 
											 memory for this argument, but 
											 you must free it. To free 
											 the memory, call the function 
											 GeometryFacadeArrayFree()
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
		GEOMETRY_FACADE_BAD_INPUTS - invalid parameters
\*=========================================================================*/
GeometryFacadeError CollectAsmcomp(GeometryFacadeAssembly p_assy, GeometryFacadeAsmComp **p_asmcomps)
{
    return CollectSolidFeaturesWithFilter(p_assy, AsmcompFilterAction, p_asmcomps);
}


/*=========================================================================*\
    Function:	CollectMdlLayers()
    Purpose:	Return a list of layers in the solid
	Arguments:	GeometryFacadeMdl model In:  The model handle
				GeometryFacadeLayer **p_layers Out: GeometryFacadeArray with collected layers.
									The function allocates memory for this argument, but 
									you must free it. To free the memory, call the function 
									GeometryFacadeArrayFree()
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
		GEOMETRY_FACADE_BAD_INPUTS - invalid parameters
\*=========================================================================*/
void CollectMdlLayers(GeometryFacadeMdl model, GeometryFacadeLayer **p_layers)
{
    if( p_layers != NULL )
    {
		*p_layers = (GeometryFacadeLayer*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeLayer), 1);
	
		try
		{
			GeometryFacadeVisitMdlLayer(model, (GeometryFacadeLayerAction)Collect2ParamDBVisitAction, (GeometryFacadeLayerAction)GEOMETRY_FACADE_NO_ERROR, (GeometryFacadeAppData)&p_layers);
		}
		catch(ProeException ex)
		{
			GeometryFacadeFreeArray( (GeometryFacadeArray*)p_layers );
			*p_layers = NULL;
		}
    }
    else
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_BAD_INPUTS);
	}
}


/*=========================================================================*\
    Function:	CollectParameters()
    Purpose:	Return a list of parameters which belong to the model item
	Arguments:  GeometryFacadeModelItem *p_modelitem In: The model item
				GeometryFacadeParameter **p_parameters Out: GeometryFacadeArray with collected parameters.
							 The function allocates memory for this argument, but 
							 you must free it. To free the memory, call the function 
							 GeometryFacadeArrayFree()
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
		GEOMETRY_FACADE_BAD_INPUTS - invalid parameters
\*=========================================================================*/
void CollectParameters(GeometryFacadeModelItem *p_modelitem, GeometryFacadeParameter **p_parameters)
{
    if (p_parameters != NULL)
    {
		*p_parameters = (GeometryFacadeParameter*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeParameter), 1);

		GeometryFacadeVisitParameter(p_modelitem, (GeometryFacadeParameterFilter)GEOMETRY_FACADE_NO_ERROR, (GeometryFacadeParameterAction)Collect3ParamDBVisitAction, (GeometryFacadeAppData)&p_parameters);
		
		GeometryFacadeFreeArray( (GeometryFacadeArray*)p_parameters );
		*p_parameters = NULL;
    }
    else
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_BAD_INPUTS);
	}
}


/*=========================================================================*\
    Function:	CollectSolidFeaturesWithFilter()
    Purpose:	Return a list of features in the solid
	Arguments:  
    GeometryFacadeSolid	GeometryFacadeSolid p_solid In: The solid handle
				GeometryFacadeFeatureFilterAction filter In: Filter function
				GeometryFacadeFeature **p_features Out: GeometryFacadeArray with collected features
											 items. The function allocates 
											 memory for this argument, but 
											 you must free it. To free 
											 the memory, call the function 
											 GeometryFacadeArrayFree()
    Returns:	GEOMETRY_FACADE_NO_ERROR - success;
		GEOMETRY_FACADE_BAD_INPUTS - invalid parameters
\*=========================================================================*/
GeometryFacadeError CollectSolidFeaturesWithFilter(GeometryFacadeSolid p_solid, GeometryFacadeFeatureFilterAction filter, GeometryFacadeFeature **p_features)
{
    if (p_features != NULL)
    {
		*p_features = (GeometryFacadeFeature*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeFeature), 1);

		try
		{
		    GeometryFacadeVisitSolidFeature(p_solid, (GeometryFacadeFeatureVisitAction)Collect3ParamDBVisitAction, (GeometryFacadeFeatureFilterAction)filter, (GeometryFacadeAppData)&p_features);
		}
		catch(ProeException ex)
		{
			GeometryFacadeFreeArray( (GeometryFacadeArray*)p_features );
			*p_features = NULL;
		}
    }
    else
	{
		return GEOMETRY_FACADE_BAD_INPUTS;
	}

    return GEOMETRY_FACADE_NO_ERROR;
}


// Helper function that puts output to the debug window in Visual Studio.
void DebugPrintf(char * format, ...)
{
    static char buf[1024];
    va_list args;

    va_start( args, format );
    vsprintf( buf, format, args );
    va_end( args);

    OutputDebugString(buf);
}


void fillPathTable(std::string theIdPath, int *table, int *tableSize) 
{
	int i = 0;
	char *id;
	int val; 
	char *idPath = _strdup( theIdPath.c_str() );

	id = strtok(idPath, ",");
	while (id != NULL) 
	{
		val = atoi(id);
		//if (val == 0) break;  BAD ASSUMPTION THAT THERE WOULD BE NO ZERO ID NUMBERS!
		table[i] = val;
		i++;
		id = strtok(NULL, ",");
	}

	*tableSize = i;

	free(idPath);
}

void fillPathTable(std::wstring theIdPath, int *table, int *tableSize)
{
	int i = 0;
	wchar_t *id;
	int val;

	try
	{
		wchar_t *idPath = _wcsdup(theIdPath.c_str());
		id = wcstok(idPath, L",");
		while (id != NULL)
		{
			val = _wtoi(id);
			//if (val == 0) break;  BAD ASSUMPTION THAT THERE WOULD BE NO ZERO ID NUMBERS!
			table[i] = val;
			i++;
			id = wcstok(NULL, L",");
		}

		*tableSize = i;

		free(idPath);
	}
	catch (const std::exception &ex)
	{
		LOG << "Caught Exception in fillPathTable:" << ex.what() << endl;
		throw ex;
	}
	
}

void GetAsmcomp(GeometryFacadeAsmCompPath the_path, GeometryFacadeAsmComp *the_asmcomp) 
{
	int feature_id = the_path.comp_id_table[the_path.table_num - 1];
	GeometryFacadeAsmCompPath parent_path;
	GeometryFacadeMdl parent_mdl;
	
	GetParentAsmcompPath(the_path, &parent_path);
	GeometryFacadeGetAsmCompPathMdl(&parent_path, &parent_mdl);
	GeometryFacadeInitFeature(GeometryFacadeMdlToSolid(parent_mdl), feature_id, (GeometryFacadeFeature*)the_asmcomp);
}


void GetAsmcompMdl(std::string theIdPath, GeometryFacadeMdl *theModel) 
{
	GeometryFacadeAsmCompPath path;

	// Get the asm path.
	GetAsmcompPath(theIdPath, &path);

	// Get the owner object.
	GeometryFacadeGetAsmCompPathMdl(&path, theModel);
}

void GetAsmcompMdl(std::wstring theIdPath, GeometryFacadeMdl *theModel)
{
	GeometryFacadeAsmCompPath path;

	// Get the asm path.
	GetAsmcompPath(theIdPath, &path);

	// Get the owner object.
	GeometryFacadeGetAsmCompPathMdl(&path, theModel);
}

void GetAsmcompPath(std::string theIdPath, GeometryFacadeAsmCompPath *thePath) 
{
	GeometryFacadeMdl current_model;
	int table[25];
	int table_size;

	/*GeometryFacadeGetCurrentMdl(&current_model);*/
	int iWinID;
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&current_model);

	fillPathTable(theIdPath, table, &table_size);

	// Get Path to owner of dimension.
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size, thePath );
}

void GetAsmcompPath(std::wstring theIdPath, GeometryFacadeAsmCompPath *thePath)
{
	GeometryFacadeMdl current_model;
	int table[25];
	int table_size;

	/*GeometryFacadeGetCurrentMdl(&current_model);*/
	int iWinID;
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID, &current_model);

	fillPathTable(theIdPath, table, &table_size);

	// Get Path to owner of dimension.
	GeometryFacadeInitAsmCompPath((GeometryFacadeSolid)current_model, table, table_size, thePath);
}


char* GetIniFile()
{
	return g_iniFile;
}


char* GetLogFile()
{
	static char value[1024];
	static char def[1024];

	strncpy(def, "C:\\Documents and Settings\\All Users\\Application Data\\RuleStream\\", sizeof(def) - 1);
	strncat(def, GetSoftwareVersion(), sizeof(def) - strlen(def) - 1);
	strncat(def, "\\ProEngineer.log", sizeof(def) - strlen(def) - 1);

	GetPrivateProfileString("Settings", "ProeLogFile", def, value, sizeof(value), g_iniFile);

	return value;
}


void GetParentAsmCompPath(char *theIdPath, GeometryFacadeAsmCompPath *thePath) 
{
	GeometryFacadeMdl current_model;
	int table[25];
	int table_size;

	GeometryFacadeGetCurrentMdl(&current_model);

	fillPathTable(theIdPath, table, &table_size);

	// Get path to owner of dimension.
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, thePath );
}


void GetParentAsmcompPath(GeometryFacadeAsmCompPath the_path, GeometryFacadeAsmCompPath *the_parent_path)
{
	GeometryFacadeMdl current_model;
	GeometryFacadeGetCurrentMdl(&current_model);

	GeometryFacadeInitAsmCompPath(GeometryFacadeMdlToSolid(current_model), the_path.comp_id_table, the_path.table_num - 1, the_parent_path);
}


char* GetSoftwareVersion()
{
	return g_version;
}


bool IsLoggingEnabled()
{
	static char value[128];
	GetPrivateProfileString("Settings", "ProeLoggingEnabled", "0", value, sizeof(value), g_iniFile);

	return strcmp(value, "1") == 0;
}


void SaveErrorInfo(const ProeException &ex)
{
	// Both the Wrapper & the AddIn can use this
	// function to save the error information.
	g_errorInfo.file = ex.GetFile();
	g_errorInfo.line = ex.GetLine();
	g_errorInfo.result = ex.GetResult();
	g_errorInfo.message = ex.GetMsg();
}


void SetIniFile(const char *iniFile)
{
	// Store the path to RuleStream.ini future use.
    strncpy(g_iniFile, iniFile, sizeof(g_iniFile) - 1);
}


void SetSoftwareVersion(const char *version)
{
	strncpy(g_version, version, sizeof(g_version) - 1);
}


void StringUpper(char *input_string, char *output_string) 
{
    int i = 0;

    while ( input_string[i] != '\0')
    {
		output_string[i] = (char)toupper(input_string[i]);
		i++;
    }

    output_string[i] = '\0';
}


/*====================================================================*\
    FUNCTION :	UtilStrcmp()
    PURPOSE  :	Like strcmp but case-independent
\*====================================================================*/
int UtilStrcmp(char *s, char *t) 
{
    int i = 0;

    while( toupper(s[i]) == toupper(t[i]))
    {
		if( s[i++] == '\0' )
		{
			return(0);
		}
    }

    return(s[i] - t[i]);
}

/*====================================================================*\
FUNCTION :	UtilStrcmp()
PURPOSE  :	Like strcmp but case-independent
\*====================================================================*/
int UtilStrcmp(wchar_t *s, wchar_t *t)
{
	int i = 0;

	while (towupper(s[i]) == towupper(t[i]))
	{
		if (s[i++] == L'\0')
		{
			return(0);
		}
	}

	return(s[i] - t[i]);
}

/*====================================================================*\
    FUNCTION :	GetValidStringValue()
    PURPOSE  :	Gets the valid string value for XML file writing
\*====================================================================*/
std::string GetValidStringValue(std::string sStringValue)
{	
	std::string sFindSplChar[] = {"&" , "<" , ">"};
	std::string sReplSplChar[] = {"&amp;" , "&lt;" , "&gt;"};	

	for(int i = 0; i <= 2 ; i++)
	{
		size_t pos = 0;	
		while ((pos = sStringValue.find(sFindSplChar[i], pos)) != std::string::npos) 
		{
			LOG << "GetValidStringValue: Old String value <" << sStringValue << ">." << endl;
			sStringValue.replace(pos, 1, sReplSplChar[i]);
			pos += 5;
			LOG << "GetValidStringValue: New String value <" << sStringValue << ">." << endl;
		}
	}
	return sStringValue;
}

/*====================================================================*\
FUNCTION :	AddStringToMsgString()
PURPOSE  :	To add a wstring to a string message string.
\*====================================================================*/
void AddWStringToMsgString(std::string &msgString, std:: wstring addString)
{

	char strString[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeWideStringToString(strString, addString.c_str());
	msgString.append(strString);

}
