// C/C++ header files.
#include <string>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Parameters.h"
#include "Log.h"

// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetParameterValue_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	std::string sModelID;
	wstring idPath;

	try
	{
		GeometryFacadeValueData data; 
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		parameterName = data.v.w;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,idPath.c_str());

		stringstream ss;
		ss << path;
		ss >> sModelID;

		// Declare the output arguments and call the function.
		std::wstring sParamVal =  GetParameterValue_wrapper(sModelID , parameterName);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, sParamVal.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed while Getting Current Value for Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		sFailureMsg.append(" Of Model With ID : ");
		sFailureMsg.append(sModelID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetIntParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	std::string sModelID;
	wstring modelID;
	int value;

	try
	{
		GeometryFacadeValueData data; 
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		value = data.v.i;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> sModelID;

		// Declare the output arguments and call the function.
		setIntParameter_wrapper(parameterName, sModelID,value);
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed while Setting Integer Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		std::stringstream ss;
		ss << value;
		sFailureMsg.append(" to the Value : ");
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" Of Model With ID : ");
		sFailureMsg.append(sModelID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetBoolParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	std::string sModelID;
	wstring modelID;
	int value;

	try
	{
		GeometryFacadeValueData data; 
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		value = data.v.i;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> sModelID;

		setBoolParameter_wrapper(parameterName, sModelID,value);

	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed while Setting Boolean Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		std::stringstream ss;
		ss << value;
		sFailureMsg.append(" to the Value : ");
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" Of Model With ID : ");
		sFailureMsg.append(sModelID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}



GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetDoubleParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	std::string sModelID;
	wstring modelID;
	double value;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		value = data.v.d;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> sModelID;

		// Declare the output arguments and call the function.
		setDoubleParameter_wrapper(parameterName, sModelID,value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed while Setting Double Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		std::stringstream ss;
		ss << value;
		sFailureMsg.append(" to the Value : ");
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" Of Model With ID : ");
		sFailureMsg.append(sModelID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetStringParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	std::string sModelID;
	std::wstring value;
	wstring modelID;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		value = data.v.w;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> sModelID;

		// Declare the output arguments and call the function.
		setStringParameter_wrapper(parameterName, sModelID, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed while Setting String Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		sFailureMsg.append(" to the Value : ");
		AddWStringToMsgString(sFailureMsg, value);
		sFailureMsg.append(" Of Model With ID : ");
		sFailureMsg.append(sModelID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetIntParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		// Declare the output arguments and call the function.
		int output = getIntParameter_wrapper(parameterName);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Integer Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDoubleParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{	
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		// Declare the output arguments and call the function.
		double output = getDoubleParameter_wrapper(parameterName);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_DOUBLE;
		arg.value.v.d = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Double Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetStringParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring parameterName;
	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		parameterName = data.v.w;

		// Declare the output arguments and call the function.
		std::wstring output = getStringParameter_wrapper(parameterName);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring(&arg.value, output.c_str());
		GeometryFacadeAddArrayObject((GeometryFacadeArray*)outputArguments, -1, 1, &arg);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get String Parameter : ";
		AddWStringToMsgString(sFailureMsg, parameterName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.
std::wstring GetParameterValue_wrapper(std::string sModelID , std::wstring parameterName)
{
	GeometryFacadeMdl model;	
	GeometryFacadeModelItem modelitem;	
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue value;
	wchar_t cstrVal[GEOMETRY_FACADE_LINE_SIZE];

	if (sModelID.compare("Drawing") == 0)
		GeometryFacadeGetCurrentMdl(&model);
	else
		GetAsmcompMdl(sModelID,&model);

	GeometryFacadeMdlToModelItem(model, &modelitem);
	GeometryFacadeInitParameter(&modelitem, parameterName.c_str(), &parameter);
	GeometryFacadeGetParameterValue(&parameter, &value);

	std::wstringstream stream_value;

	switch (value.type)
	{
	case GEOMETRY_FACADE_PARAM_DOUBLE:
		stream_value << value.value.d_val;
		break;

	case GEOMETRY_FACADE_PARAM_STRING:
		stream_value << value.value.s_val;
		break;

	case GEOMETRY_FACADE_PARAM_INTEGER:
		stream_value << value.value.i_val;
		break;

	case GEOMETRY_FACADE_PARAM_BOOLEAN:
		stream_value << (value.value.l_val == 1) ? "TRUE" : "FALSE";
		break;

	case GEOMETRY_FACADE_PARAM_NOTE_ID:
		stream_value << value.value.i_val;
		break;

	case GEOMETRY_FACADE_PARAM_VOID:
		stream_value << cstrVal;
		break;

	default:
		break;
	}

	return stream_value.str();
}

void setIntParameter_wrapper(std::wstring param_name, std::string sModelID,int value)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;
	
	if (sModelID.compare("Drawing") == 0)
	{
		GeometryFacadeGetCurrentMdl(&model);
	}
	else
	{
		GetAsmcompMdl(sModelID,&model);
	}
	GeometryFacadeMdlToModelItem(model, &modelitem);

	parvalue.type = GEOMETRY_FACADE_PARAM_INTEGER;
	parvalue.value.i_val = value;

	try
	{
		GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);
		GeometryFacadeSetParameterValue(&parameter, &parvalue);
	}
	catch (ProeException ex)
	{
		// TODO: Should this happen for GEOMETRY_FACADE_NOT_FOUND only?
		GeometryFacadeCreateParameter(&modelitem, param_name.c_str(), &parvalue, &parameter);
	}
}

void setBoolParameter_wrapper(std::wstring parameterName,std::string sModelID, int value)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;

	if (sModelID.compare("Drawing") == 0)
	{
		GeometryFacadeGetCurrentMdl(&model);
	}
	else
	{
		GetAsmcompMdl(sModelID,&model);
	}
	GeometryFacadeMdlToModelItem(model, &modelitem);

	parvalue.type = GEOMETRY_FACADE_PARAM_BOOLEAN;
	//parvalue.value.i_val = value;
	parvalue.value.l_val = value;


	try
	{
		GeometryFacadeInitParameter(&modelitem, parameterName.c_str(), &parameter);
		GeometryFacadeSetParameterValue(&parameter, &parvalue);
	}
	catch (ProeException ex)
	{
		// TODO: Should this happen for GEOMETRY_FACADE_NOT_FOUND only?
		GeometryFacadeCreateParameter(&modelitem, parameterName.c_str(), &parvalue, &parameter);
	}
}


void setDoubleParameter_wrapper(std::wstring param_name, std::string sModelID,double value)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;

	if (sModelID.compare("Drawing") == 0)
	{
		GeometryFacadeGetCurrentMdl(&model);
	}
	else
	{
		GetAsmcompMdl(sModelID,&model);
	}
	GeometryFacadeMdlToModelItem(model,&modelitem);

	parvalue.type = GEOMETRY_FACADE_PARAM_DOUBLE;
	parvalue.value.d_val = value;

	try
	{
		GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);
		GeometryFacadeSetParameterValue(&parameter, &parvalue);
	}
	catch (ProeException ex)
	{
		// TODO: Should this happen for GEOMETRY_FACADE_NOT_FOUND only?
		GeometryFacadeCreateParameter(&modelitem, param_name.c_str(), &parvalue, &parameter);
	}
}


void setStringParameter_wrapper(std::wstring param_name, std::string sModelID, std::wstring value)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;

	if (sModelID.compare("Drawing") == 0)
	{
		GeometryFacadeGetCurrentMdl(&model);
	}
	else
	{
		GetAsmcompMdl(sModelID, &model);
	}
	GeometryFacadeMdlToModelItem(model, &modelitem);
	GeometryFacadeSetParamValue(&parvalue, value.c_str(), GEOMETRY_FACADE_PARAM_STRING);

	try
	{
		GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);
		GeometryFacadeSetParameterValue(&parameter, &parvalue);
	}
	catch (ProeException ex)
	{
		// TODO: Should this happen for GEOMETRY_FACADE_NOT_FOUND only?
		GeometryFacadeCreateParameter(&modelitem, param_name.c_str(), &parvalue, &parameter);
	}
}


int getIntParameter_wrapper(std::wstring param_name)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;
	int output = 0;

	GeometryFacadeGetCurrentMdl(&model);
	GeometryFacadeMdlToModelItem(model,&modelitem);

	GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);

	GeometryFacadeGetParameterValue(&parameter, &parvalue);
	if (parvalue.type == GEOMETRY_FACADE_PARAM_INTEGER)
	{
		output = parvalue.value.i_val;
	}
	else
	{
		output = -9999;	// This is not a proper type request.
	}

	return output;
}


double getDoubleParameter_wrapper(std::wstring param_name)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;
	double output = 0.0;

	GeometryFacadeGetCurrentMdl(&model);
	GeometryFacadeMdlToModelItem(model, &modelitem);

	GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);

	GeometryFacadeGetParameterValue(&parameter, &parvalue);
	if (parvalue.type == GEOMETRY_FACADE_PARAM_DOUBLE)
	{
		output = parvalue.value.d_val;
	}
	else
	{
		output = -9999.0;	// This is not a proper type request.
	}

	return output;
}

std::wstring getStringParameter_wrapper(std::wstring param_name)
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;
	GeometryFacadeParameterValue parvalue;

	GeometryFacadeLine s_out;
	std::wstring output;

	GeometryFacadeGetCurrentMdl(&model);
	GeometryFacadeMdlToModelItem(model, &modelitem);

	GeometryFacadeInitParameter(&modelitem, param_name.c_str(), &parameter);

	GeometryFacadeGetParameterValue(&parameter, &parvalue);
	if (parvalue.type == GEOMETRY_FACADE_PARAM_STRING)
	{
		GeometryFacadeGetParameterValueValue(&parvalue, GEOMETRY_FACADE_PARAM_STRING, s_out);
		output = s_out;
	}
	else
	{
		output = L"wrong_type";	// This is not a proper type request.
	}

	return output;
}