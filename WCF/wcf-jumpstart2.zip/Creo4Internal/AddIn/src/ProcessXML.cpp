// C/C++ header files.
#include <string>


// Windows header files.
#include <windows.h>


// Application header files.
#include "Components.h"
#include "Constraints.h"
#include "Dimensions.h"
#include "Models.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "ProcessXML.h"
#include "Log.h"



extern std::string result_string;


using namespace std;
// Do not use the namespace because it causes ambiguity references
// Use the package prefixes instead. -rpm
//using namespace MSXML2;
//This will have data related to file & instance number within assembly
std::map<std::string,int>mInstData;

// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessXMLMessage_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		std::string xml = data.v.s;

		// Declare the output arguments and call the function.
		std::string output = processXMLMessage_wrapper(xml);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataString( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.

// typedef enum
// {
//     GEOMETRY_FACADE_MDL_UNUSED     = PRO_TYPE_UNUSED,
//     GEOMETRY_FACADE_MDL_ASSEMBLY   = PRO_ASSEMBLY,
//     GEOMETRY_FACADE_MDL_PART       = PRO_PART,
//     GEOMETRY_FACADE_MDL_DRAWING    = PRO_DRAWING,
//     PRO_MDL_3DSECTION              = PRO_3DSECTION,
//     GEOMETRY_FACADE_MDL_2DSECTION  = PRO_2DSECTION,
//     GEOMETRY_FACADE_MDL_LAYOUT     = PRO_LAYOUT,
//     GEOMETRY_FACADE_MDL_DWGFORM    = PRO_DWGFORM,
//     GEOMETRY_FACADE_MDL_MFG        = PRO_MFG,
//     GEOMETRY_FACADE_MDL_REPORT     = PRO_REPORT,
//     GEOMETRY_FACADE_MDL_MARKUP     = PRO_MARKUP,
//     GEOMETRY_FACADE_MDL_DIAGRAM    = PRO_DIAGRAM
// } GeometryFacadeMdlType;

// This function is called only for FeatureComponents.
// PARTS and ASSEMBLIES
std::string XMLFeatureTagGet(GeometryFacadeFeature *theFeature_ptr, std::string sSuppressed,std::string &theTag) 
{
	// TYPE, ID, NAME

	int featureID = theFeature_ptr->id;
	GeometryFacadeType featureType = theFeature_ptr->type;
	GeometryFacadeMdl owner = theFeature_ptr->owner;
	GeometryFacadeName owner_name;
	std::string	tag;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	char cBuffer[10] = "0";

	char featureID_string[100];
	sprintf(featureID_string, "%d", featureID);

	GeometryFacadeGetMdlName(owner, owner_name);

	GeometryFacadeMdl model;
	GeometryFacadeName model_name;
	GeometryFacadeCharName model_namestring;	

	GeometryFacadeGetAsmCompMdl(theFeature_ptr, &model);
	GeometryFacadeGetMdlName(model, model_name);
	GeometryFacadeMdlType model_type = GeometryFacadeGetMdlType(model);
	GeometryFacadeWideStringToString(model_namestring, model_name);
  
	switch (model_type) 
	{
		case GEOMETRY_FACADE_MDL_ASSEMBLY:

			tag = "ASM";
			break;

		case GEOMETRY_FACADE_MDL_PART:

			tag = "PRT";
			break;

		default:

			tag = "XXX";
			break;
	}

	// Compare to above.
	GeometryFacadeMdlData data;
	GeometryFacadeGetMdlData(model, &data);

	std::string pathname, filename, device, host,type;
	char dummy[GEOMETRY_FACADE_PATH_SIZE];
	char version[5];

	pathname = GeometryFacadeWideStringToString(dummy, data.path);
	filename = GeometryFacadeWideStringToString(dummy, data.name);
	device = GeometryFacadeWideStringToString(dummy, data.device);
	host = GeometryFacadeWideStringToString(dummy, data.host);
	type = GeometryFacadeWideStringToString(dummy, data.type);

	
	// Adding to the part tag.

	// Check if this is a suppressed feature.
	std::string suppressed_status = sSuppressed;

   sprintf(version, "%d", data.version);

	result = ProSolidFamtableCheck((GeometryFacadeSolid)model);
	if (result == GEOMETRY_FACADE_EMPTY)
	{
		GeometryFacadeMdl pMdlInst;
		result = ProFaminstanceGenericGet(model,true,&pMdlInst);
		LOG << "Model is : " << model_namestring << " Status of Family Table instance Generic Get : " << result << endl;
		if (result == GEOMETRY_FACADE_NO_ERROR)
		{
			GeometryFacadeGetMdlData(pMdlInst, &data);
			filename = GeometryFacadeWideStringToString(dummy, data.name);
		}
	}

	theTag = theTag + "\t\t<" + tag+ " name=\""+ model_namestring+ "\" id=\""+ featureID_string+ 
		"\" suppressed=\""+ suppressed_status+ 
		"\" host=\""+ host+ 
		"\" device=\""+ device+ 
		"\" path=\""+ pathname+  
		"\" file=\""+ filename+ 
		"\" type=\""+ type+
		"\" version=\""+  version+
		"\">"+ "\n";

	return tag;
}

int GetInstanceNumber(std::string filename)
{	
	int iInst = mInstData[filename];	

	if (iInst == NULL)
	{
		mInstData[filename] = 1;
	}
	else
	{		
		mInstData[filename] =  iInst + 1;
	}
	
	return mInstData[filename];
}

std::string XMLModelTagGet(GeometryFacadeMdl theModel, std::string &theTag) 
{
	GeometryFacadeName model_name;
	GeometryFacadeCharLine modelnamestring;
	std::string tag;
	GeometryFacadeAsmCompPath path;

	GeometryFacadeIdTable c_id_table;

	c_id_table [0] = -1; 

	GeometryFacadeSolid theSolid = (GeometryFacadeSolid)theModel;

	GeometryFacadeSelection *p_sel = NULL;
	int n_sel = 0;
	
    GeometryFacadeGetMdlName(theModel, model_name);
    GeometryFacadeMdlType model_type = GeometryFacadeGetMdlType(theModel);
    GeometryFacadeWideStringToString(modelnamestring, model_name);

    GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)theModel, c_id_table, 0, &path );

    int val, i;
    path.comp_id_table;
    for(i=0;i<path.table_num;i++)
	{
	    val = path.comp_id_table[i];
    }
	
    char modelID_string[10];
    int modelID = GeometryFacadeGetMdlId(theModel);
    sprintf(modelID_string, "%d", modelID);

    switch (model_type) 
	{
		case GEOMETRY_FACADE_MDL_ASSEMBLY:

			tag = "ASM";
			break;

		case GEOMETRY_FACADE_MDL_PART:

			tag = "PRT";
			break;

		default:

			tag = "XXX";
			break;
	}

    // Get the file information ...
    GeometryFacadeMdlData data;
    GeometryFacadeGetMdlData(theModel, &data);

    std::string pathname,filename,device,host,type;
    char dummy[GEOMETRY_FACADE_PATH_SIZE];
    char version[5];

    pathname = GeometryFacadeWideStringToString(dummy, data.path);
    filename = GeometryFacadeWideStringToString(dummy, data.name);
    device = GeometryFacadeWideStringToString(dummy, data.device);
    host = GeometryFacadeWideStringToString(dummy, data.host);
    type = GeometryFacadeWideStringToString(dummy, data.type);

    sprintf(version, "%d", data.version);

    theTag = theTag + "\t<" + tag+ " name=\""+ modelnamestring+ "\" id=\""+ modelID_string+ 
							"\" host=\""+ host+
							"\" suppressed=\""+ "No"+ //Added these as deafault "NO" to handle it in Loader
							"\" device=\""+ device+ 
							"\" path=\""+ pathname+  
							"\" file=\""+ filename+ 
							"\" type=\""+ type+
							"\" version=\""+  version+
							"\" PTCVersion=\""+  "Creo Parametric 3.0"+
							"\">"+ "\n";	
    return tag;
}

void GetFamilyTableData(GeometryFacadeMdl theModel,std::string &sScanStr)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	//Check if given model is generic or instance.
	GeometryFacadeMdl pFtPart = NULL;

	result = ProSolidFamtableCheck((GeometryFacadeSolid)theModel);
	if(result == GEOMETRY_FACADE_EMPTY)
	{
		result = ProFaminstanceGenericGet(theModel,PRO_B_TRUE,&pFtPart);		
	}
	else if (result == GEOMETRY_FACADE_NO_ERROR)
	{
		pFtPart = theModel;
	}	

	if(pFtPart != NULL && result == GEOMETRY_FACADE_NO_ERROR)
	{
		//Create "CONFIG" node.
		char *InstName = new char[sizeof(GeometryFacadeName)+1];
		GeometryFacadeName wInstName;

		result = ProMdlNameGet(theModel,wInstName);		
		GeometryFacadeWideStringToString(InstName,wInstName);
		std::ostringstream sTemp;
		sTemp << "\t\t<CONFIG name= \"Family Table\" value= \"" << InstName << "\">\n";
		sScanStr += sTemp.str();

		std::string sXMLStr;
		ProFamtable pfamTable;	
		result = ProFamtableInit(pFtPart,&pfamTable);
		result = ProFamtableInstanceVisit(&pfamTable,(ProFamtableInstanceAction)VisitFamilyTableInstanceAction,NULL,(ProAppData*)&sScanStr);
		sScanStr += "\t\t</CONFIG>\n";
		delete []InstName;
	}
}

GeometryFacadeError VisitFamilyTableInstanceAction(ProFaminstance* instance,ProError status,ProAppData app_data)
{
	if(instance != NULL)
	{
		std::string *XMLstring_ptr = (std::string*)app_data;
		GeometryFacadeMdl pModel = NULL;
		GeometryFacadeName wInstName = {};
		char *InstName = new char[sizeof(GeometryFacadeName)+1];
		status = ProFaminstanceCreate(instance,&pModel);
		LOG << "Result for Instance create : " << status << endl;
		status = ProMdlNameGet(pModel,wInstName);		
		GeometryFacadeWideStringToString(InstName,wInstName);
		LOG << "Instance Name : " << InstName << endl;
		std::ostringstream sXMLStr;
		sXMLStr << "\t\t<FTIN InstanceName=\"" << InstName << "\" InstanceValue=\"" << InstName << "\"></FTIN>\n"; 
		LOG << "XML string for family table instance is : " << sXMLStr.str() << endl;
		*XMLstring_ptr += sXMLStr.str();
		delete []InstName;
		ProMdlErase(pModel);
	}
	return GEOMETRY_FACADE_NO_ERROR;
}
// Private functions.
static char* processXMLMessage_wrapper(std::string the_xml) 
{
	_bstr_t xml(the_xml.c_str());
	HRESULT hr;     
	VARIANT_BOOL isSuccessful = FALSE;
	BSTR status = SysAllocString(xml);

	try 
	{
		XML::IXMLDOMDocument3 *pXMLDOMDoc=NULL;
		XML::IXMLDOMNodeList *pNodes=NULL;
		XML::IXMLDOMNode *pNode=NULL;
		long len=0;

		XML::IXMLDOMElement *doc_root = NULL;

		TESTHR(CoInitialize(NULL));
		pXMLDOMDoc = domFromCOM();

		// Load from a file.
		//TESTHR(pXMLDOMDoc->load(var, &isSuccessful));

		// Load from a string.
		TESTHR(pXMLDOMDoc->loadXML(xml, &isSuccessful));

		if (isSuccessful) 
		{
			// Get the Root of the Document.
			TESTHR(pXMLDOMDoc->get_documentElement(&doc_root));
			if (doc_root != NULL) 
			{
				// Process the document tree recursively.
				processNode(doc_root);
				
				// Get the result of processing the XML model.
				TESTHR(doc_root->get_xml(&status));
			}
		} 
		else 
		{
			printf("Error reading xml\n");
			status = NULL;
         }
    }
    catch(...) 
	{
		printf("Exception while reading xml\n");
        CoUninitialize();
        
		return NULL;
	}

	CoUninitialize();

	// should not write back into the input argument.
	// Instead let us do some mumbo-jumbo :)
	int len;
	char *dummy;
	len = (int)strlen(the_xml.c_str());
	dummy = (char*)malloc(sizeof(char) * (len+1));
	sprintf(dummy, "%ls", status);
	result_string = dummy;

	free(dummy);
  
    ::SysFreeString(status);

	// Force geometry to regen...maybe needed at the component level as well/instead?
	RegenerateCurrentModel_wrapper();
	ZoomAllCurrentModel_wrapper();

	return (char*)result_string.c_str();
}


// Helper function that put output in stdout and debug window
// in Visual Studio:
static void dprintf(char *format, ...)
{
    static char buf[1024];
    va_list args;
    va_start( args, format );
    vsprintf( buf, format, args );
    va_end( args);
    OutputDebugString(buf);
    printf("%s", buf);
}


// Helper function to create a DOM instance: 
static XML::IXMLDOMDocument3* domFromCOM()
{
    HRESULT hr;
    XML::IXMLDOMDocument3 *pxmldoc = NULL;

	try 
	{
		HRCALL( CoCreateInstance(__uuidof(XML::DOMDocument60),
                              NULL,
                              CLSCTX_INPROC_SERVER,
                              __uuidof(XML::IXMLDOMDocument3),
                              (void**)&pxmldoc),
                              "Create a new DOMDocument");

		HRCALL( pxmldoc->put_async(VARIANT_FALSE), "should never fail");
		HRCALL( pxmldoc->put_validateOnParse(VARIANT_FALSE), "should never fail");
		HRCALL( pxmldoc->put_resolveExternals(VARIANT_FALSE), "should never fail");

		return pxmldoc;
	}
	catch(...) 
	{
		if (pxmldoc)
		{
			pxmldoc->Release();
		}
		
		return NULL;
	}
}


static NodeNames getNodeName(_bstr_t the_name) 
{
	if( !wcscmp(the_name, L"Model") ) 
	{
		return MODEL;
	}
	else if( !wcscmp(the_name, L"Component") ) 
	{
		return COMP;
	}
	else if( !wcscmp(the_name, L"SubComp") ) 
	{
		return SUBCOMP;
	}
	else if( !wcscmp(the_name, L"Feature") ) 
	{
		return FEATURE;
	}
	else if( !wcscmp(the_name, L"Mate") ) 
	{
		return CONSTRAINT;
	}
	else if( !wcscmp(the_name, L"Constraint") )
	{
		return CONSTRAINT;
	}
	else if( !wcscmp(the_name, L"Constraints") ) 
	{
		return CONSTRAINTS;
	}
	else if( !wcscmp(the_name, L"Dim") ) 
	{
		return DIM;
	}

	return UNKNOWN;
}


static int getAttributeValueChar(XML::IXMLDOMElement *pElement, _bstr_t the_name, char *the_value) 
{
   HRESULT hr;	
   _variant_t val;
   _bstr_t name = ::SysAllocString(the_name);
	hr = pElement->getAttribute(name, &val);
	::SysFreeString(name);
   sprintf(the_value, "%ls", val.bstrVal);

   return hr;
}
 

static int getAttributeValueInt(XML::IXMLDOMElement *pElement, _bstr_t the_name, int *the_value) 
{
   HRESULT hr;
   char val[100];
   hr = getAttributeValueChar(pElement, the_name, val);
   *the_value = atoi(val);

   return hr;
}


static int getAttributeValueDouble(XML::IXMLDOMElement *pElement, _bstr_t the_name, double *the_value) 
{
   HRESULT hr;
   char val[100];
   hr = getAttributeValueChar(pElement, the_name, val);
   *the_value = atof(val);

   return hr;
}


// Function: processModelNode()
//
// XML Node:   Model
//
// Attributes: Hwnd
//             Project_ID
//             LineItem_ID
//
// Tag: <Model Hwnd="789154" Project_ID="BRB000001" LineItem_ID="6"> ... </Model>
static int processModelNode(XML::IXMLDOMElement *pElement) 
{
	HRESULT hr;
	int Hwnd;

	char Project_ID[10];
	int LineItem_ID;

	char directory[260]; // I chose 260 because that is the size of Pro/Toolkits GeometryFacadePath.
	GeometryFacadePath working_directory; 

	try 
	{
		// Get the Window Handle (int)
		TESTHR(getAttributeValueInt(pElement, "Hwnd", &Hwnd));
		TESTHR(getAttributeValueChar(pElement, "Project_ID", Project_ID));
		TESTHR(getAttributeValueInt(pElement, "LineItem_ID", &LineItem_ID));
		TESTHR(getAttributeValueChar(pElement, "Dir", directory));

		// Change the Pro/E directory to the working directory of the line item.

		char dir[260];
		sprintf(dir, "%s\\%s.%04d", directory,  Project_ID, LineItem_ID);
      
		GeometryFacadeStringToWideString(working_directory, dir);
		GeometryFacadeChangeDirectory(working_directory);		
	}
	catch (...) 
	{
		printf("processModelNode(): error\n");
		//ReleaseString(directory);
		return hr;
	}

   return hr;
}

//
// Function: processCompNode()
//
// XML Node:   Component
//
// Attributes: ObjID
//             Path
//             Type
//             ModelID
//             Cmd
//             Rebuild
//             PartID
//             OptimalPartFile
//             PartFamily
//             PartFamilyID
//             OptimalComponentName
//
// Tag: <Component ObjID="0" Path="" Type="0" ModelID="" Rebuild="1" PartID="1" 
//                 OptimalPartFile="Design Burner Assembly.SLDASM" PartFamily="DesignBurnerHV4Z" 
//                 PartFamilyID="38" OptimalComponentName="Design Burner Assembly"> 
//                 ... 
//      </Component>
//      <Component ObjID="211" Path="" Type="0" ModelID="" Cmd="Add" PartID="5" 
//                 OptimalPartFile="Attachment Plate CS.SLDPRT" PartFamily="AttachmentPlate" 
//                 PartFamilyID="1715" OptimalComponentName="Attachment Plate CS">
static int processCompNode(XML::IXMLDOMElement *pElement) 
{
	HRESULT hr;
	int ObjID;
	char Path[255];
	int Type;
	int ModelID;
	char Cmd[10];
	int Rebuild;
	int PartID;
	char OptimalPartFile[255];
	char PartFamily[255];
	int PartFamilyID;
	char OptimalComponentName[255];

	try 
	{
		TESTHR(getAttributeValueInt(pElement, "ObjID", &ObjID));
		TESTHR(getAttributeValueChar(pElement, "Path", Path));
		TESTHR(getAttributeValueInt(pElement, "Type", &Type));
		TESTHR(getAttributeValueInt(pElement, "ModelID", &ModelID));
		TESTHR(getAttributeValueChar(pElement, "Cmd", Cmd));
		TESTHR(getAttributeValueInt(pElement, "Rebuild", &Rebuild));
		TESTHR(getAttributeValueInt(pElement, "PartID", &PartID));
		TESTHR(getAttributeValueChar(pElement, "OptimalPartFile", OptimalPartFile));
		TESTHR(getAttributeValueChar(pElement, "PartFamily", PartFamily));
		TESTHR(getAttributeValueInt(pElement, "PartFamilyID", &PartFamilyID));
		TESTHR(getAttributeValueChar(pElement, "OptimalComponentName", OptimalComponentName));

		if(!strcmp("Add", Cmd)) 
		{
			if(!strcmp("0", Path)) 
			{
				// Add Root Part
				LoadModel_wrapper(OptimalPartFile);
			} 
			else 
			{
				// Add SubComponent
				_variant_t id;
				id = AddComponent_wrapper(OptimalPartFile, Path);
				// _variant_t val = "4242";
				TESTHR(pElement->setAttribute(L"PartID", id));
				TESTHR(pElement->setAttribute(L"Path", id));
			}
		} 
		else 
		{
			if(!strcmp("Del", Cmd)) 
			{
				// Delete component
				DeleteComponent_wrapper(Path);

			} else 
			{
				// Don't know what other options are possible.
			}
		}
	}
	catch (...) 
	{
		return hr;
	}

   return hr;
}


// Function: processSubCompNode()
//
// XML Node:   SubComp
//
// Attributes: FileName
//
// Tag: <SubComp FileName="Burner Throat Box.PRT"/>
static int processSubCompNode(XML::IXMLDOMElement *pElement) 
{
	// The files will be handled by the manager in .NET.
	return 0;
}


// Function: processFeatureNode()
//
// XML Node:   Feature
//
// Attributes: ID
//             Cmd
//             Name
//             Value
//
// Tag:  <Feature ID="35" Cmd="SPR" Name="rope packing-1" Value="False"/>
//       <Feature ID="2"  Cmd="DIM" Name="OD@Sketch1" Value="1.59385"/>
//       <Feature ID="34" Cmd="FSR" Name="LocalCirPattern1" Value="False"/>
//
// Considering Instead:
//       <Feature ID="6" Cmd="DIM" Name="CoalElbowAngle@Elbow Rotation Plane">3.1415922</Feature>
static int processFeatureNode(XML::IXMLDOMElement *pElement) 
{
	HRESULT hr;
    char ID[10];
    char Cmd[10];
    char Name[255];
    double Value;

	try 
	{
		TESTHR(getAttributeValueChar(pElement, "ID", ID));
		TESTHR(getAttributeValueChar(pElement, "Cmd", Cmd));
		TESTHR(getAttributeValueChar(pElement, "Name", Name));
		TESTHR(getAttributeValueDouble(pElement, "Value", &Value));

		_variant_t id = "0";
		_variant_t value = NULL;

		TESTHR(((IXMLDOMNode*)pElement)->get_nodeValue(&value));
		pElement->get_nodeValue(&value);
		pElement->get_nodeTypedValue(&value);
			
		XML::IXMLDOMNode* parent_node;
		XML::IXMLDOMElement* parent_element;
		char path[50];

		pElement->get_parentNode(&parent_node);
		// Get a pointer the element interface for the current node.
		// If found processs the element.
		TESTHR(parent_node->QueryInterface(IID_IXMLDOMElement, (void**)&parent_element));
		getAttributeValueChar(parent_element, "Path", path);

		// Set the dimension...

		strcat(path,",");
		strcat(path,ID);
		strcat(path,"\n");

		DimensionSetValueByIdPath_wrapper(path, value);

		//ReleaseString(path);

   }
   catch (...) 
   {
      return hr;
   }
	
	return 0;
}


// Function: processConstraintNode()
//
// Constraints must be applied as a group constraints that are all
// added at once replacing previous constraints.  
// It is going to be the responsibility of the geometry manager to
// collect up the constraints for an object and add them to the 
// XML stream as a Constraints collection.
//
// XML Node:   
//
// Tag: <Mate FeatureType1="PLANE" FeatureName1="Hot End Plane" ObjID="153" 
//            FeatureType2="PLANE" FeatureName2="Hot End Plane" MateType="0" 
//            AlignType="0" Flip="False" Distance="0" Angle="0"/>
//
//		<Constraint FeatureType1="PLANE" FeatureName1="Hot End Plane" ObjID="153" 
//                  FeatureType2="PLANE" FeatureName2="Hot End Plane" MateType="0" 
//                  AlignType="0" Flip="False" Distance="0" Angle="0"/>
static int processConstraintNode(XML::IXMLDOMElement *pElement) 
{
	// Constraints must be done as groups not individually.
	return 0;
}


// Function: processConstraintsNode()
//
// XML Node:   
//
// Attributes: 
//
// Tag: <Constraints>
//		<Mate FeatureType1="PLANE" FeatureName1="Top" ObjID="153" 
//            FeatureType2="PLANE" FeatureName2="Top" Distance="0" Angle="0"
//			  MateType="0" AlignType="0" Flip="False" />
//		<Mate FeatureType1="PLANE" FeatureName1="Front" ObjID="153" 
//            FeatureType2="PLANE" FeatureName2="Front" Distance="0" Angle="0"
//			  MateType="0" AlignType="0" Flip="False" />
//		</Constraints>
static int processConstraintsNode(XML::IXMLDOMElement *pElement) 
{
	HRESULT hr;
	BSTR constraints_xml;
	char xml[1000];
	wchar_t wcxml[1000];

	try 
	{
		TESTHR(pElement->get_xml(&constraints_xml));
		sprintf(xml, "%ls", constraints_xml);

		GeometryFacadeStringToWideString(wcxml, xml);
		BuildConstraints_wrapper(wcxml);
	}
	catch (...) 
	{
		return hr;
	}

	return 0;
}


static int processNode(XML::IXMLDOMElement *pElement) 
{
	HRESULT hr;
	BSTR name;
	VARIANT_BOOL hasChild = FALSE;
	long len;
	XML::IXMLDOMNodeList *pNodes=NULL;
    XML::IXMLDOMNode *pNode;

	try 
	{  
		// First process this node/element then recurse.

		TESTHR(pElement->get_baseName(&name));  // strips off the package name if present.
		
		switch (getNodeName(name)) 
		{
			case COMP:

				processCompNode(pElement);
				break;

			case SUBCOMP:

				processSubCompNode(pElement);
				break;

			case FEATURE:

				processFeatureNode(pElement);
				break;

			case CONSTRAINTS:

				processConstraintsNode(pElement);
				break;

			case MODEL:

				processModelNode(pElement);	
				break;
			}

		// Recurse the XML model tree (nodes) if there are kids at this node/element.
		TESTHR(pElement->hasChildNodes(&hasChild));
      
		if (hasChild) 
		{
			TESTHR(pElement->get_childNodes(&pNodes));
			TESTHR(pNodes->get_length(&len));
         
			// There are kids to process each of them.
			for(int i=0; i<len; ++i) 
			{
				// grab each of the nodes one at a time.
				TESTHR(pNodes->get_item(i, &pNode));
               
				// Get a pointer the element interface for the current node.
				// If found processs the element.
				TESTHR(pNode->QueryInterface(IID_IXMLDOMElement, (void**)&pElement));

				if (pElement != NULL) 
				{
					processNode(pElement);	// Recurse.
				}
			}
      }

      return 0;
	}
	catch (...) 
	{
         printf("Exception while reading xml\n");
		 return -1;
	}
}


// Functions used to test
//
//VARIANT VariantString(_bstr_t str)
//{
//    VARIANT var;
//    VariantInit(&var);
//    V_BSTR(&var) = SysAllocString(str);
//    V_VT(&var) = VT_BSTR;
//    return var;
//}
//
//
//int main() {
//    
//	BSTR the_xml;
//
//	/***************************************************************
//	 THIS SECTION IS TO READ THE STRING FROM A FILE FOR TESTING.
//	    IN THE END THE STRING WILL BE PASSED INTO THE FUNCTION FROM VB.
//	\***************************************************************/
//
//	HRESULT hr;
//	VARIANT_BOOL isSuccessful = FALSE;
//	VARIANT var;
//	VariantInit(&var);
//	var = VariantString(L"rsMessage.xml");
//	XML::IXMLDOMDocument3 *pXMLDOMDoc=NULL;
//	XML::IXMLDOMElement *doc_root = NULL;
//	
//	TESTHR(CoInitialize(NULL));
//    pXMLDOMDoc = domFromCOM();
//    pXMLDOMDoc->load(var, &isSuccessful);
//	if(!isSuccessful) {
//
//		return -1;
//	}
//	pXMLDOMDoc->get_documentElement(&doc_root);
//	doc_root->get_xml(&the_xml);
//	CoUninitialize();
//	/***************************************************************/
//
//
//	/***************************************************************
//	 PROCESS THE XML STRING NOW
//	***************************************************************/
//	
//	ProcessXML(the_xml);
//	
//	return 0;
//}

