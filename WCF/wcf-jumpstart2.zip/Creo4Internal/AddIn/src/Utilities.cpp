// C/C++ header files.
#include <string>
#include <stdarg.h>
#include <sstream>


// Windows header files.
#include <windows.h>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Utilities.h"


DECLARE_MSGIFILE


extern std::string result_string;


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DirectoryChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring absolutePath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		absolutePath = data.v.w;

		directoryChange_wrapper(absolutePath);
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Set directory to : ";
		AddWStringToMsgString(sFailureMsg, absolutePath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DirectoryCurrentGet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		// Declare the output arguments and call the function.
		std::wstring output = directoryCurrentGet_wrapper();

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError OutputMessage_task(GeometryFacadeArgument *inputs, GeometryFacadeArgument **outputs)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	char c_string[GEOMETRY_FACADE_LINE_SIZE];

	try
	{
		
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel (inputs, L"ARG1", &data);
		strcpy(c_string, data.v.s);

		// sending to output_string this
		GeometryFacadeDisplayMessage(MSGFILE, "ADDIN %0s", c_string);
		GeometryFacadeClearMessage();

		std::string o_string = outputMessage_wrapper(std::string(c_string));

		// getting  back from the function this
		GeometryFacadeDisplayMessage( MSGFILE, "ADDIN %0s", o_string.c_str() );
		GeometryFacadeClearMessage();
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Outputa Message : ";
		sFailureMsg.append(c_string);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Private functions.
static void directoryChange_wrapper(std::wstring absolutePath) 
{
   GeometryFacadeChangeDirectory(absolutePath.c_str());
}


static wchar_t* directoryCurrentGet_wrapper() 
{
	GeometryFacadePath path;

	GeometryFacadeGetCurrentDirectory(path);

	return path;
}


static std::string outputMessage_wrapper(std::string in_string)
{
	std::string out_string;
	out_string = in_string + std::string("   ....");

	return out_string;
}




