// C/C++ header files.
#include <string>
#include <sstream>


extern "C"
{
	#include <UtilCollect.h>
}


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Layers.h"
#include "Log.h"


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError LayerDisplayStatusSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int layerID;
	int stat;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		layerID = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		stat = data.v.i;

		layerDisplayStatusSet_wrapper(layerID, stat);
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Set Display Status For Layer : ";
		std::stringstream ss;
		ss << layerID;
		sFailureMsg.append(ss.str());
		ss << stat;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.
void GetLayerPropertiesXML(GeometryFacadeMdl model, std::string &output)
{	
	std::stringstream sout;
	ProError result;
	
	sout << "\t\t<LAYERS id = \"1\" name= \"LAYERS\" typename = \"LAYER\">\n";
	result = ProMdlLayerVisit(model,(ProLayerAction)ModelLayerVisitAction,NULL,(ProAppData)&sout);
	sout << "\t\t\t</LAYERS>\n";

	output = output + sout.str();
}


// Private functions.

ProError ModelLayerVisitAction(ProLayer* pLayer,ProAppData pAppData)
{
	std::stringstream *sout = (std::stringstream*)pAppData;
	GeometryFacadeName wname;
	int iNoItem = 0;
	char cname[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeLayerDisplay display_status;
	ProError result;
	ProLayerItem* pLayerItem = NULL;
	

	GeometryFacadeGetModelItemName(pLayer, wname);
	GeometryFacadeWideStringToString(cname, wname);
	display_status = GeometryFacadeGetLayerDisplayStatus(pLayer);

	if (display_status != PRO_LAYER_TYPE_NORMAL)
	result = ProLayerDisplaystatusSet(pLayer,PRO_LAYER_TYPE_NORMAL);

	result = ProLayerItemsPopulate(pLayer,&pLayerItem,&iNoItem);

	if ( iNoItem > 0 && result == PRO_TK_NO_ERROR)
	*sout << "\t\t\t\t<LAYER name=\"" << cname << "\" id=\"" << pLayer->id << "\" display_status=\"" << display_status << "\" Items=\"" << iNoItem << "\">" << "</LAYER>\n";
	
	if (display_status != PRO_LAYER_TYPE_NORMAL)
	result = ProLayerDisplaystatusSet(pLayer,display_status);

	if (result != PRO_TK_NO_ERROR)
	result = PRO_TK_NO_ERROR;

	return result;

}

//LayerStatus 1 is taken as for hiding layer & its component
//LayerStatus 0 is taken as unhiding layer & its component
static void layerDisplayStatusSet_wrapper(int lay_id, int status)
{
	GeometryFacadeMdl model;
	GeometryFacadeLayer layer;
	ProError result;

	GeometryFacadeGetCurrentMdl(&model);

	result = ProModelitemInit(model,lay_id,PRO_LAYER,(ProModelitem*)&layer);

	if ( result == PRO_TK_NO_ERROR)
	{

		if (status == 1)
		{
			GeometryFacadeSetLayerDisplayStatus(&layer, PRO_LAYER_TYPE_BLANK);			
		}
		else
		{
			GeometryFacadeSetLayerDisplayStatus(&layer, GEOMETRY_FACADE_LAYER_TYPE_NORMAL);
		}
	}

	ProLayerDisplaystatusSave(model);

	ProWindowRepaint(-1);	
}


