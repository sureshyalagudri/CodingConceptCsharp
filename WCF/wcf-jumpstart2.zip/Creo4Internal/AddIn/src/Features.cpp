// C/C++ header files.
#include <string>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Features.h"
#include "Log.h"
#include "Utility.h"
#include "ProSolid.h"


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetFeatureDisplayStatus_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int featureID;
	int statusFlag;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		featureID = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		statusFlag = data.v.i;

		// Declare the output arguments and call the function.
		int output;
		setFeatureDisplayStatus_wrapper(featureID, statusFlag, output);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString (arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Set Display Status for feature : ";
		std::stringstream ss;
		ss << featureID;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to the Status : ");
		ss << statusFlag;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SuppressFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	std::wstring staticFile;
	wstring modelID;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		staticFile = data.v.w;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> idPath;

		suppressFeature_wrapper(idPath, staticFile);

		int windowID = GeometryFacadeGetCurrentWindow();
		GeometryFacadeActivateWindow(windowID);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Suppress Feature With ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ResumeFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	std::wstring staticFile;
	wstring modelID;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		staticFile = data.v.w;

		char path[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> idPath;

		resumeFeature_wrapper(idPath, staticFile);

		int windowID = GeometryFacadeGetCurrentWindow();
		GeometryFacadeActivateWindow(windowID);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Resume Feature With ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ShowFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		 showFeature_wrapper(idPath);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Show Feature With ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError HideFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		hideFeature_wrapper(idPath);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Hide Feature With ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetSketchText_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string sFeatId;
	std::wstring sNewText;
	wstring modelID;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG1", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG2", &data);
		sNewText = data.v.w;

		char path[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> sFeatId;

		SetSketchText_wrapper(sFeatId,sNewText);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed while Setting Sketch Text for feature : ";
		sFailureMsg.append(sFeatId);
		sFailureMsg.append(" to new Text : ");
		AddWStringToMsgString(sFailureMsg, sNewText);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetUDFFeatureStatus_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	char cFeatPath[GEOMETRY_FACADE_PATH_SIZE];
	wchar_t *cStatus = NULL;
	wchar_t *cFeat = NULL;
	wstring featID;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG1", &data);
		featID = data.v.w;
		
		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG2", &data);
		cFeat = data.v.w;

		GeometryFacadeGetArgumentByLabel (inputArguments, L"ARG3", &data);
		cStatus = data.v.w;

		GeometryFacadeWideStringToString(cFeatPath,featID.c_str());

		std::wstring cNFeatID = SetUDFFeatureStatus_Wrapper(cFeatPath,cFeat,cStatus);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, cNFeatID.c_str());
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		char feat[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(feat, cFeat);
		char status[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(status, cStatus);
		LOG << "ERROR:	in Set UDF Feature Status INPUTS: FeatPath-" << cFeatPath <<" Feat-"<< feat <<" Status-"<< status <<endl;
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}
// Private functions.
//TRUE: This status is to suppress the feature
//FALSE: This status is to resume the feature 
std::wstring SetUDFFeatureStatus_Wrapper(char *cFeatPath, wchar_t *cFeat, wchar_t *cStatus)
{
	std::wstringstream out;
	int iStatus = _wcsicmp(cStatus,L"True");
	if (iStatus == 0)
	{
		GeometryFacadeAsmCompPath path;
		GeometryFacadeMdl owner;
		int feat_id[1],iFeatID,iNoFeats,num_opts = 1,feat_count = 1;
		GeometryFacadeFeatureDeleteOptions options[2];
		options[0] = PRO_FEAT_DELETE_INDIV_GP_MEMBERS;
		options[1] = PRO_FEAT_DELETE_CLIP_INDIV_GP_MEMBERS;
		GeometryFacadeError result = PRO_TK_NO_ERROR;
		GeometryFacadeFeature *oFeats = NULL;
		GeometryFacadeName wname;

		GeometryFacadeModelItem pGrpItem;
		GetAsmcompPath(cFeatPath,&path); 

		feat_id[0] = path.comp_id_table[path.table_num-1];

		path.table_num = path.table_num - 1;

		GeometryFacadeGetAsmCompPathMdl(&path, &owner);
		GeometryFacadeInitModelItem(owner,feat_id[0],PRO_GROUP,&pGrpItem);

		//Collect all Features of input UDF/Group
		GeometryFacadeGroupFeaturesCollect((ProGroup*)&pGrpItem,&oFeats);
		//Use Pro function here as we will have to add try ctch to handle no feature situation.aprt of negative testing
		ProArraySizeGet(oFeats,&iNoFeats);

		//Loop through each of the feature and look for input feature name to be suppressed
		for(int i = 0;i<iNoFeats;i++)
		{
			GeometryFacadeGetModelItemName(&oFeats[i], wname);

			//comapre each feature name with input feature
			int res = _wcsicmp(wname,cFeat);
			if(res == 0)
			{
				//This is the feature user has selected to be suppressed
				iFeatID = oFeats[i].id;
				GeometryFacadeSuppressFeature((GeometryFacadeSolid)owner,&iFeatID,1,options,2);	
			}
		}
		
		out << iFeatID;
	}
	else
	{
		int feat_count = 1;
		GeometryFacadeFeatureResumeOptions options = GEOMETRY_FACADE_FEAT_RESUME_INCLUDE_PARENTS;
		int num_opts = 1;
		int table[25];
		int table_size;
		int feat_id;
		GeometryFacadeAsmCompPath owner_path;
		GeometryFacadeMdl current_model, owner_mdl;
		GeometryFacadeFeature oFeature;
		GeometryFacadeName wname;

		// Filling a path table allows easy access to the feature id 
		// and parent component path.
		char feat[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(feat, cFeat);
		strcat(cFeatPath, ",");
		strcat(cFeatPath, feat);
		fillPathTable(cFeatPath, table, &table_size);
		feat_id = table[table_size-1];

		// Get Root model.
		GeometryFacadeGetCurrentMdl(&current_model);
		// Get the Asmcomppath for the owner (table_size-1 is path to parent)
		GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &owner_path );
		// Get the owner_mdl
		GeometryFacadeGetAsmCompPathMdl(&owner_path, &owner_mdl);
		GeometryFacadeResumeFeature( (GeometryFacadeSolid)owner_mdl, &feat_id, feat_count, &options, num_opts );
		GeometryFacadeInitFeature((GeometryFacadeSolid)owner_mdl,feat_id,&oFeature);

		GeometryFacadeGetModelItemName(&oFeature, wname);
		out << wname;
	}

	return out.str();
}

void SetSketchText_wrapper(std::string sFeatId,std::wstring sNewText)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iFeatId,iTable[25],iTableSize;
	GeometryFacadeMdl pCurrentMdl, pOwnerMdl;
	GeometryFacadeAsmCompPath pOwnerPath;
	GeometryFacadeFeature pFeature;

	// Filling a path table allows easy access to the feature id 
	//  and parent component path.
	fillPathTable(sFeatId, iTable, &iTableSize);
	iFeatId = iTable[iTableSize-1];

	// Get Root model.
	GeometryFacadeGetCurrentMdl(&pCurrentMdl);
	GeometryFacadeInitAsmCompPath((GeometryFacadeSolid)pCurrentMdl, iTable, iTableSize-1, &pOwnerPath);
	GeometryFacadeGetAsmCompPathMdl(&pOwnerPath, &pOwnerMdl);
	GeometryFacadeInitFeature((GeometryFacadeSolid)pOwnerMdl,iFeatId,&pFeature);

	result = SetTextValue(pFeature,sNewText);
}

GeometryFacadeError SetTextValue(GeometryFacadeFeature pFeature,std::wstring sNewText)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProFeatureElemtreeExtractOptions pOpts =  PRO_FEAT_EXTRACT_NO_OPTS;
	int iNoOfSect,iNoOfId,iProjectedID[2],iProjCount = 0,iNewId,iReplaceId,iEntId[2],iDimID[2],iNoSectErr;
	ProElement pElementTree,pSketchElemt;
	ProSection pSection;
	ProMatrix pLocationMatrix;
	ProIntlist pEntityIdList;
	Pro2dTextdef	*pTextEntity,pNewEntity;
	ProBoolean		pbProjected = PRO_B_FALSE;
	Pro2dPnt pPlacePnt1,pPlacePnt2;
	ProSectionPointType pPointTypes[2];
	ProWSecerror pSectionErrors;
	//ProMsg pwSecErrMsg;
	ProElempathItem pPathItem[2];
	ProElempath pElemtPath;
	ProValue pValue;
	ProValueData pValueData;
	ProErrorlist pErrors;

	result = ProFeatureElemtreeExtract(&pFeature, NULL, pOpts, &pElementTree);
	result = ProFeatureNumSectionsGet(&pFeature,&iNoOfSect);
	result = ProFeatureSectionCopy(&pFeature,iNoOfSect - 1,&pSection);
	result = ProSectionLocationGet(pSection, pLocationMatrix);
	result = ProSectionEntityIdsGet(pSection, &pEntityIdList, &iNoOfId);
	
	for (int i = 0;i<iNoOfId;i++)
	{
		result = ProSectionEntityGet( pSection, pEntityIdList[i], (Pro2dEntdef**)&pTextEntity );

		switch(pTextEntity->type)
		{
			case PRO_2D_LINE:
				ProSectionEntityIsProjection( pSection, pEntityIdList[i], &pbProjected);
				if( pbProjected ) /* check if the entity is of projection or not. If projected, it will be the section X and Y dimension references */
				{
					iProjectedID[iProjCount] = pEntityIdList[i];
					iProjCount++;
				}
				break;

			case PRO_2D_TEXT:
				pNewEntity.type = PRO_2D_TEXT;
				GeometryFacadeCopyWideString(pTextEntity->font_name,pNewEntity.font_name,PRO_VALUE_UNUSED);
				GeometryFacadeCopyWideString(sNewText.c_str(),pNewEntity.string,PRO_VALUE_UNUSED);

				memcpy(pNewEntity.first_corner, pTextEntity->first_corner, sizeof (Pro2dPnt));
				memcpy(pNewEntity.second_corner, pTextEntity->second_corner, sizeof (Pro2dPnt));

				pPlacePnt1[0] = pNewEntity.first_corner[0];
				pPlacePnt1[1] = pNewEntity.first_corner[1];

				pPlacePnt2[0] = pNewEntity.first_corner[0];
				pPlacePnt2[1] = pNewEntity.first_corner[1];

				result = ProSectionEntityAdd(pSection,(Pro2dEntdef*)&pNewEntity,&iNewId);
				iReplaceId = pEntityIdList[i];
				break;
			default :
				break;
		}
	}

	iEntId[0] = iProjectedID[0];
	iEntId[1] = iNewId;

	pPointTypes[0] = PRO_ENT_WHOLE;
	pPointTypes[1] = PRO_ENT_START;

	result = ProSecdimCreate(pSection, iEntId, pPointTypes, 2, PRO_TK_DIM_LINE_POINT, pPlacePnt1, &iDimID[0]);
	iEntId[0] = iProjectedID[1];

	result = ProSecdimCreate( pSection, iEntId, pPointTypes, 2, PRO_TK_DIM_LINE_POINT, pPlacePnt2, &iDimID[1]);

	result = ProSectionEntityReplace( pSection, iReplaceId, iNewId);

	result = ProSecerrorAlloc(&pSectionErrors);
	result = ProSectionAutodim(pSection,&pSectionErrors);
	ProSecerrorCount(&pSectionErrors,&iNoSectErr);
	//for(int k = 0; k < nSecErrs; k++ )
	//{
	//	ProSecerrorMsgGet(pSectionErrors, k, wSecErrMsg );
	//	ProWstringToString (msg,pwSecErrMsg);
	//	fprintf(fp,"Error msg: %s\n",msg);			
	//}

	result = ProSectionRegenerate(pSection, &pSectionErrors);

	pPathItem[0].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	pPathItem[0].path_item.elem_id = PRO_E_STD_SECTION;
	pPathItem[1].type = PRO_ELEM_PATH_ITEM_TYPE_ID;
	pPathItem[1].path_item.elem_id = PRO_E_SKETCHER;

	result = ProElempathAlloc (&pElemtPath);
	result = ProElempathDataSet (pElemtPath, pPathItem, 2);  
	result = ProElemtreeElementGet (pElementTree, pElemtPath, &pSketchElemt);  
	result = ProElementValueGet ( pSketchElemt, &pValue);
	result = ProValueDataGet (pValue, &pValueData);

	pValueData.v.p = pSection; 
	ProValueDataSet(pValue, &pValueData);

	result = ProFeatureRedefine(NULL, &pFeature, pElementTree, NULL, 0, &pErrors);
	result = ProSecerrorFree( &pSectionErrors );
	result = ProSectionFree( &pSection );
	result = ProElempathFree (&pElemtPath);

	return result;

}
static void setFeatureDisplayStatus_wrapper(int feat_id, int status_flag, int &output)	// Status flag can be 0 for hidden or 1 for displayed.
{
	GeometryFacadeMdl current_model;
	GeometryFacadeName w_name;
	GeometryFacadeLayer layer;
	GeometryFacadeLayerItem layer_item;

	GeometryFacadeGetCurrentMdl(&current_model);
	try
	{
		GeometryFacadeGetMdlLayer(current_model, GeometryFacadeStringToWideString(w_name, "RULEBLANK"), &layer);	// RULEBLANK is the reserved rule layer to hide features.
	}
	catch (ProeException ex)
	{
		if (ex.GetResult() == GEOMETRY_FACADE_NOT_FOUND)
		{
			// If this layer does not exist create it.
			GeometryFacadeCreateLayer(current_model, w_name, &layer);
			GeometryFacadeSetLayerDisplayStatus(&layer, GEOMETRY_FACADE_LAYER_TYPE_BLANK);
			GeometryFacadeSaveLayerDisplayStatus(current_model);
		}
		else
		{
			throw;
		}
	}

	GeometryFacadeInitLayerItem(GEOMETRY_FACADE_LAYER_FEAT, feat_id, current_model, &layer_item);

	if (status_flag == 0)
	{
		// Hide it.
		GeometryFacadeAddLayerItem(&layer, &layer_item);
	}
	else
	{
		// Display it.
		GeometryFacadeRemoveLayerItem(&layer, &layer_item);
	}

	GeometryFacadeRepaintWindow(GEOMETRY_FACADE_VALUE_UNUSED);
}


/*
	SuppressFeature

	Suppress a single GeometryFacadeFeature given the feature path.

*/
static void suppressFeature_wrapper(std::string the_Id_path, std::wstring staticFile) 
{
	try
	{
		int feat_count = 1;
		GeometryFacadeFeatureDeleteOptions options = GEOMETRY_FACADE_FEAT_DELETE_CLIP;
		int num_opts = 1;

		int table[25];
		int table_size;
		int feat_id;
		GeometryFacadeAsmCompPath owner_path, new_owner_path;
		GeometryFacadeMdl current_model, owner_mdl;

		// Filling a path table allows easy access to the feature id 
		//  and parent component path.
		fillPathTable(the_Id_path, table, &table_size);
		feat_id = table[table_size-1];

		// Get Root model.
		GeometryFacadeGetCurrentMdl(&current_model);

		// Get the Asmcomppath for the owner (table_size-1 is path to parent).
		GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &owner_path );

		//Check for static file 
		ProError status = PRO_TK_GENERAL_ERROR;
		if(staticFile.compare(L"True")==0)
		{
			GeometryFacadeMdl objMdl;
			status = ProAsmcomppathMdlGet(&owner_path, &objMdl);
			if(status!=PRO_TK_NO_ERROR)
			{
				if(GetAlternateOwnerPath(owner_path, new_owner_path)==true)
				{
					owner_path = new_owner_path;
				}
			}
		}

		// Get the owner_mdl.
		GeometryFacadeGetAsmCompPathMdl(&owner_path, &owner_mdl);

		GeometryFacadeSuppressFeature( (GeometryFacadeSolid)owner_mdl, &feat_id, feat_count, &options, num_opts );
	}
	catch(ProeException ex)
	{
		LOG << "suppressFeature_wrapper: Caught outer exception"<< endl;
		throw ex;
	}
}


static void resumeFeature_wrapper(std::string the_Id_path, std::wstring staticFile) 
{
	try
	{
		int feat_count = 1;
		GeometryFacadeFeatureResumeOptions options = GEOMETRY_FACADE_FEAT_RESUME_INCLUDE_PARENTS;
		int num_opts = 1;

		int table[25];
		int table_size;
		int feat_id;
		GeometryFacadeAsmCompPath owner_path, new_owner_path;
		GeometryFacadeMdl current_model, owner_mdl;

		// Filling a path table allows easy access to the feature id 
		// and parent component path.
		fillPathTable(the_Id_path, table, &table_size);
		feat_id = table[table_size-1];

		// Get Root model.
		GeometryFacadeGetCurrentMdl(&current_model);

		// Get the Asmcomppath for the owner (table_size-1 is path to parent)
		GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &owner_path );

		//Check for static file 
		ProError status = PRO_TK_GENERAL_ERROR;
		if(staticFile.compare(L"True")==0)
		{
			GeometryFacadeMdl objMdl;
			status = ProAsmcomppathMdlGet(&owner_path, &objMdl);
			if(status!=PRO_TK_NO_ERROR)
			{
				if(GetAlternateOwnerPath(owner_path, new_owner_path)==true)
				{
					owner_path = new_owner_path;
				}
			}
		}

		// Get the owner_mdl
		GeometryFacadeGetAsmCompPathMdl(&owner_path, &owner_mdl);

		GeometryFacadeResumeFeature( (GeometryFacadeSolid)owner_mdl, &feat_id, feat_count, &options, num_opts );
	}
	catch(ProeException ex)
	{
		LOG << "resumeFeature_wrapper: Caught outer exception"<< endl;
		throw ex;
	}
}


static void showFeature_wrapper(std::string the_Id_path) 
{
	int feat_count = 1;
	GeometryFacadeFeatureStatus feat_status = GEOMETRY_FACADE_FEAT_ACTIVE;
	int num_features = 1;
	GeometryFacadeBoolean can_fix = GEOMETRY_FACADE_B_FALSE;
	GeometryFacadeFeature feature;
	int table[25];
	int table_size;
	int feat_id;
	GeometryFacadeAsmCompPath owner_path;
	GeometryFacadeMdl current_model, owner_mdl;

	// Filling a path table allows easy access to the feature id 
	// and parent component path.
	fillPathTable(the_Id_path, table, &table_size);
	feat_id = table[table_size-1];
	
	// Get Root model.
	GeometryFacadeGetCurrentMdl(&current_model);

	// Get the Asmcomppath for the owner (table_size-1 is path to parent)
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &owner_path );

	// Get the owner_mdl
	GeometryFacadeGetAsmCompPathMdl(&owner_path, &owner_mdl);

	GeometryFacadeInitFeature( (GeometryFacadeSolid)owner_mdl, feat_id, &feature );

	//GeometryFacadeMdlToModelItem((GeometryFacadeModel)feature,&pMdlItem);
	ProError result = ProModelitemUnhide((ProModelitem*)&feature);

	LOG << "Geomtry/Feature at : " << the_Id_path << " is unhidden with result : " << result << endl;
}


static void hideFeature_wrapper(std::string the_Id_path) 
{
	int feat_count = 1;
	GeometryFacadeBoolean can_fix = GEOMETRY_FACADE_B_FALSE;
	int table[25];
	int table_size;
	int feat_id;
	GeometryFacadeAsmCompPath owner_path;
	GeometryFacadeMdl current_model, owner_mdl;
	GeometryFacadeFeature feature;

	// Filling a path table allows easy access to the feature id 
	//  and parent component path.
	fillPathTable(the_Id_path, table, &table_size);
	feat_id = table[table_size-1];
	
	// Get Root model.
	GeometryFacadeGetCurrentMdl(&current_model);

	// Get the Asmcomppath for the owner (table_size-1 is path to parent).
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &owner_path );

	// Get the owner_mdl.
	GeometryFacadeGetAsmCompPathMdl(&owner_path, &owner_mdl);

	GeometryFacadeInitFeature( (GeometryFacadeSolid)owner_mdl, feat_id, &feature );

	//GeometryFacadeMdlToModelItem((GeometryFacadeModel)feature,&pMdlItem);
	ProError result = ProModelitemHide((ProModelitem*)&feature);

	LOG << "Geomtry/Feature at : " << the_Id_path << " is marked as hidden with result : " << result << endl;
}

/* To get the alternate id path of an static assembly where one of the component is supressed
and other is resumed [both are two instance of same component]. 
Altarnate path is to get resumed component ID 
B-05841 Creo: Ability to suppress an instance of same components in a template assy
*/
bool GetAlternateOwnerPath(GeometryFacadeAsmCompPath path, GeometryFacadeAsmCompPath & new_path)
{
	try
	{
		ProError status;
		bool rightPath = false;

		//Get id
		int id = path.comp_id_table[path.table_num-1];

		ProMdl ownerModel;

		//To get parent of path
		path.comp_id_table[path.table_num-1] = -1;
		path.table_num = path.table_num -1;

		//Get valid parent models in loop until unsupressed file found 
		while( ProAsmcomppathMdlGet(&path, &ownerModel)!=PRO_TK_NO_ERROR)
		{
			GeometryFacadeAsmCompPath parent_path;
			if(GetAlternateOwnerPath(path, parent_path)==true)
			{
				path = parent_path;
				if(path.table_num ==0)
				{
					break;
				}
			}
			else
			{
				break;
			}
		}

		//Get Component and State
		ComponentData objCompdata;
		objCompdata.found=false;
		objCompdata.compid = id;
		objCompdata.compName[0] = NULL;
		objCompdata.compNameContainer.clear();
		ProSolidFeatVisit((GeometryFacadeSolid)ownerModel , (GeometryFacadeFeatureVisitAction)CollectComponentInstanceNamebyID , (GeometryFacadeFeatureFilterAction)ComponentFilterAction , (GeometryFacadeAppData)&objCompdata);

		//If feature is found, collect the all components id by name match
		if(objCompdata.found ==true)
		{
			objCompdata.compNameContainer.clear();
			CollectAllComponentsId(ownerModel, objCompdata);
		}

		//Update the ID and check for valid component
		//Valid component is the resumed component
		int size = path.table_num;
		for(int i = 0; i<(int)objCompdata.compNameContainer.size(); i++)
		{					 
			//Update the is and check 
			path.comp_id_table[size] = stoi(objCompdata.compNameContainer[i]);
			path.table_num = size + 1;

			status = ProAsmcomppathMdlGet(&path, &ownerModel);
			if(status==PRO_TK_NO_ERROR)
			{
				rightPath =  true;
				break;
			}
		}

		//Clearcontainer
		objCompdata.compNameContainer.clear();

		//Assign the path if its right path
		if(rightPath== true)
		{
			new_path = path;
		}
		return rightPath;
	}
	catch (ProeException ex)
	{
		return false;
	}
}

/* 
To collect component ids by name of the component
Mainly used for static file components supress
*/
void CollectAllComponentsId(GeometryFacadeMdl pContainerAsm , ComponentData &objCompData)
{
	GeometryFacadeVisitSolidFeature((GeometryFacadeSolid)pContainerAsm , (GeometryFacadeFeatureVisitAction)CollectComponentsbyId , (GeometryFacadeFeatureFilterAction)ComponentFilterAction , (GeometryFacadeAppData)&objCompData);
}

/*
Filter fucntion to allow only to visit components 
*/
GeometryFacadeError ComponentFilterAction(GeometryFacadeFeature* feature,GeometryFacadeAppData appData)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeFeatureType ftype;

	ftype = GeometryFacadeGetFeatureType(feature);
	//ProFeatureTypeGet(feature,&ftype);

	if (ftype == GEOMETRY_FACADE_FEAT_COMPONENT)
		return (GEOMETRY_FACADE_NO_ERROR);
	return (GEOMETRY_FACADE_CONTINUE);
}

/*
Visit method to get component name with id. 
Use to get the name of the component by its ID
*/
GeometryFacadeError CollectComponentInstanceNamebyID(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData)
{
	try
	{
		if(feature != NULL)
		{
			ComponentData * objCompData = ((ComponentData*)appData);

			GeometryFacadeMdl featMdl;
			GeometryFacadeMdlData featMdlData;
			GeometryFacadeAsmCompMdl(feature,&featMdl);

			//instance current name..
			GeometryFacadeGetMdlData(featMdl , &featMdlData);
			GeometryFacadeMdlType mdlType = GeometryFacadeGetMdlType(featMdl);

			char cFile[GEOMETRY_FACADE_LINE_SIZE];

			ProWstringToString(cFile , featMdlData.name);		

			//now form the name..
			if(mdlType == GEOMETRY_FACADE_MDL_PART)
			{
				strcat(cFile ,".PRT");
			}
			else if(mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
			{
				strcat(cFile ,".ASM");
			}

			//Check Id
			if(feature->id == objCompData->compid)
			{
				strcpy(objCompData->compName, cFile);
				objCompData->found = true;
				return GEOMETRY_FACADE_GENERAL_ERROR;
			}	
		}
		return GEOMETRY_FACADE_NO_ERROR;
	}
	catch (ProeException ex)
	{
		return GEOMETRY_FACADE_NO_ERROR;
	}
}

/*
Visist function to collect Id's of same name components 
*/
GeometryFacadeError CollectComponentsbyId(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData)
{
	try
	{
		if (feature != NULL)
		{
			ComponentData * objCompData = ((ComponentData*)appData);

			GeometryFacadeMdl featMdl;
			GeometryFacadeMdlData featMdlData;
			GeometryFacadeAsmCompMdl(feature, &featMdl);

			//instance current name..
			GeometryFacadeGetMdlData(featMdl, &featMdlData);
			GeometryFacadeMdlType mdlType = GeometryFacadeGetMdlType(featMdl);

			std::stringstream cFileName;
			char cFile[GEOMETRY_FACADE_LINE_SIZE];

			ProWstringToString(cFile, featMdlData.name);

			//now form the name..
			cFileName << cFile;
			if (mdlType == GEOMETRY_FACADE_MDL_PART)
				cFileName << ".PRT";
			else if (mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
				cFileName << ".ASM";

			if (featMdl != NULL && _stricmp(cFileName.str().c_str(), objCompData->compName) == 0)
			{
				//it is a instance component , store its id..
				char sId[10];
				itoa(feature->id, sId, 10);
				objCompData->compNameContainer.push_back(sId);
			}
		}
		return GEOMETRY_FACADE_NO_ERROR;
	}
	catch (ProeException ex)
	{
		return GEOMETRY_FACADE_NO_ERROR;
	}
}

#if 0
static void Hide_Feature_wrapper(std::string the_Id_path) 
{
    int *feat_id_array;
    GeometryFacadeFeatureStatus *status_array;
	GeometryFacadeFeature feature;
	GeometryFacadeName name;

	// Allocate ID and status arrays.
	feat_id_array = (int*)GeometryFacadeAllocateArray(0, sizeof(int), 1);
	status_array = (GeometryFacadeFeatureStatus*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeFeatureStatus), 1);

    // Get a list of features of the specified solid and their statuses.
    num_features = GeometryFacadeGetSolidFeatureStatus( (GeometryFacadeSolid)owner_mdl, &feat_id_array, &status_array );

	GeometryFacadeFeatureType feature_type;
	for(int i = 0; i < num_features; ++i) 
	{
		feat_id = feat_id_array[i];
		feat_status = status_array[i];
		GeometryFacadeInitFeature( (GeometryFacadeSolid)owner_mdl, feat_id, &feature );
		GeometryFacadeGetModelItemName( (GeometryFacadeModelItem*)&feature, name );
		feature_type = GeometryFacadeGetFeatureType(&feature);

		printf("Feature ID: %d   Status: %d", feat_id, feat_status);
		fflush(stdout);
	}

	GeometryFacadeSetSolidFeatureStatus( (GeometryFacadeSolid)owner_mdl, feat_id_array, NULL, num_features, can_fix );
}
#endif

