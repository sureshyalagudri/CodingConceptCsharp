// C/C++ header files.
#include <string>
#include <sstream>
#include <map>

// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Constraints.h"
#include "Log.h"
#include "wchar.h"

#define PI 3.14159265358979323846

// Exported Functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BuildConstraints_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring xml;
	std::string strFP ("FIXPOSITION");
	wchar_t * wxml = NULL;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		wxml = data.v.w;

		xml = wxml;
		std::size_t found= xml.find(L"FIXPOSITION");
		if (found!=std::string::npos)
		{
			LOG << "BuildConstraints_task: Adding Fix position constraint"<< xml << endl;
			BuildFixPosConstraints_wrapper(wxml);
		}
		else
		{
			LOG << "BuildConstraints_task: Adding constraint"<< xml << endl;
			BuildConstraints_wrapper(wxml);
		}
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "BuildConstraints_task::Failed to Apply Constraints: Caught Outer exception";
		std::string constraint(xml.begin(), xml.end());
		sFailureMsg.append(constraint);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}


	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError FixPosition_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		GeometryFacadeValueData data;

		std::string idPath;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		double x;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		x = data.v.d;

		double y;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		y = data.v.d;

		double z;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		z = data.v.d;

		fixPosition_wrapper(idPath, x, y, z);
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ShowConstraints_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;		

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		showConstraints_wrapper(idPath);
	}
	catch (ProeException ex)
	{		
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

//To build Fix position Constraint 
//Added this method for adding fix position constraint 
//More details Check B-05839 
void BuildFixPosConstraints_wrapper(wchar_t * xmlIn)
{
	try
	{
		double xDist, yDist, zDist, xR, yR, zR;
		wchar_t type[255], idPath[255], xVal[255], yVal[255], zVal[255], xRVal[255], yRVal[255], zRVal[255];
		int i, currentLength;
		wchar_t *start = NULL;
		wchar_t *end = NULL;
		wchar_t current[4096];
		wchar_t *startTag = L"<Constraint ";
		wchar_t *endTag = L"</Constraint>";
		wchar_t * offsetEndPtr;
		// parse the constraints XML to find each constraint
		for (i = 0; ;i++) 
		{
			// find location of the start tag in the constraints string.
			start = wcsstr(xmlIn, startTag);

			// exit when there is no start constraint tag found.
			if(!start)
			{
				break;
			}

			// find location of the end tag in the constraints string.
			end = wcsstr(xmlIn, endTag);

			currentLength = int(end - start) + int(wcslen(endTag));

			// Pull the next constraint from the constraints string.
			wcsncpy(current, start, currentLength);

			// Terminate the constraint string.
			current[currentLength] = '\0';

			//Get XML Values X, Y , Z, XR , YR and ZR  
			getXMLAttributeValue(current, L"type", type);
			getXMLAttributeValue(current, L"idpath1", idPath);
			getXMLAttributeValue(current, L"X=", xVal); //X found two time so passed "X="
			getXMLAttributeValue(current, L"Y", yVal);
			getXMLAttributeValue(current, L"Z", zVal);
			getXMLAttributeValue(current, L"XR", xRVal);
			getXMLAttributeValue(current, L"YR", yRVal);
			getXMLAttributeValue(current, L"ZR", zRVal);

			//Convert Values to double
			xDist = wcstod(xVal, &offsetEndPtr);
			yDist = wcstod(yVal, &offsetEndPtr);
			zDist = wcstod(zVal, &offsetEndPtr);
			xR = wcstod(xRVal, &offsetEndPtr);
			yR = wcstod(yRVal, &offsetEndPtr);
			zR = wcstod(zRVal, &offsetEndPtr);

			GeometryFacadeAsmCompPath asmCompPath;
			GeometryFacadeAsmCompPath owner_asmcomp_path;
			GeometryFacadeAsmCompConstraint *asmCompConstraint = NULL;
			GeometryFacadeAsmComp asmcomp;

			//Get Assembly Component
			GetAsmcompPath(idPath , &asmCompPath);
			GetAsmcomp(asmCompPath, &asmcomp);

			//Get Parent assembly component path
			GetParentAsmcompPath(asmCompPath, &owner_asmcomp_path);

			//Manupilate to Radian
			double xAngle = degree2radian(xR);
			double yAngle = degree2radian(yR);
			double zAngle = degree2radian(zR);

			//Build matrix here..
			//As per the Creo position calculation this matrix is built
			ProMatrix matrix;
			matrix[0][0] = cos(yAngle) * cos(zAngle);
			matrix[0][1] = -cos(yAngle) * sin(zAngle);
			matrix[0][2] = sin(yAngle);
			matrix[0][3] = 0;

			matrix[1][0] = cos(xAngle) * sin(zAngle) + cos(zAngle) * sin(xAngle) * sin(yAngle);
			matrix[1][1] = cos(xAngle) * cos(zAngle) - sin(xAngle) * sin(yAngle) * sin(zAngle);
			matrix[1][2] = -cos(yAngle) * sin(xAngle);
			matrix[1][3] = 0;

			matrix[2][0] = sin(xAngle) * sin(zAngle) - cos(xAngle) * cos(zAngle) * sin(yAngle);
			matrix[2][1] = cos(zAngle) * sin(xAngle) + cos(xAngle) * sin(yAngle) * sin(zAngle);
			matrix[2][2] = cos(xAngle) * cos(yAngle);
			matrix[2][3] = 0;

			//Set X, Y & Z Distance 
			matrix[3][0] = xDist;
			matrix[3][1] = yDist;
			matrix[3][2] = zDist;
			matrix[3][3] = 1;

			//Set Assembly Component Position
			GeometryFacadeSetAsmCompPosition(NULL, &asmcomp, matrix);

			//Set the Fix Constraint
			GeometryFacadeAsmCompConstraint constraint;
			GeometryFacadeAsmCompConstraint *constraints;
			constraints = (GeometryFacadeAsmCompConstraint*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeAsmCompConstraint), 1);
			constraint = GeometryFacadeAllocateAsmCompConstraint();
			GeometryFacadeAsmCompConstraintType set_type = GEOMETRY_FACADE_ASM_AUTO;

			//Set type as FIX 
			GeometryFacadeSetAsmCompConstraintType(constraint, PRO_ASM_FIX);

			//Add to Constraints array
			GeometryFacadeAddArrayObject((GeometryFacadeArray*)&constraints, -1, 1, &constraint);

			//Set Constraint of assembly
			GeometryFacadeSetAsmCompConstraints(&owner_asmcomp_path, &asmcomp, constraints);

			//Finally Regen & Repaint
			GeometryFacadeRegenerateAsmComp(&asmcomp, GEOMETRY_FACADE_B_TRUE);
			GeometryFacadeRepaintWindow(GEOMETRY_FACADE_VALUE_UNUSED);

			// Increment the constraints to continue parse.
			xmlIn = end + wcslen(endTag);
		}

	}
	catch(ProeException ex)
	{
		LOG << "BuildFixPosConstraints: FAILED to build Fix Position constraint with inputs as <" << xmlIn  << "> , verify if Geometries to be assembly does have any other constraint" << endl;
		throw ex;
	}
}
// Public functions.

// BuildConstraints_wrapper
//
// Input:  XML string of the following format;
//      <constraints>
//	      <constraint type = "Align" 
//			      path1 ="39,9,9,10" ref1="Plane" name1="TOP"
//			      path2= "39,9,9,11" ref2="Plane" name2="TOP">
//	      </constraint>
//	      <constraint type = "Align" 
//				  path1 ="39,9,9,10" ref1="Plane" name1="FRONT"
//			      path2= "39,9,9,11" ref2="Plane" name2="FRONT">
//	      </constraint>
//     </constraints>
void BuildConstraints_wrapper(wchar_t * xmlIn) 
{
	// XML string is NOT padded with whitespace
	// XML contains <constraints> root tag

	// Verify that the string is a constraint.

	// Find number of the constraint tags.
	int i, current_length;
	wchar_t *start = NULL;
	wchar_t *end = NULL;
	wchar_t *start_tag = L"<Constraint ";
	wchar_t *end_tag = L"</Constraint>";
	GeometryFacadeAsmCompConstraint constraint;
	GeometryFacadeAsmCompConstraint *constraints;
	GeometryFacadeAsmCompPath constrainted_component_path;

	constraints = (GeometryFacadeAsmCompConstraint*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeAsmCompConstraint), 1);

	// parse the constraints XML to find each constraint.  Build the GeometryFacadeAsmCompConstraint.
	for (i = 0; ;i++) 
	{
		// find location of the start tag in the constraints string.
		start = wcsstr(xmlIn, start_tag);

		// exit when there is no start constraint tag found.
		if(!start)
		{
			break;
		}

		// find location of the end tag in the constraints string.
		end = wcsstr(xmlIn, end_tag);

		current_length = int(end - start) + int(wcslen(end_tag));
		
		wchar_t current[4096];
		// Pull the next constraint from the constraints string.
		wcsncpy(current, start, current_length);

		// Terminate the constraint string.
		current[current_length] = '\0';

		// Build the contraint structure.
		constraint = GeometryFacadeAllocateAsmCompConstraint();
		GeometryFacadeAsmCompConstraintType set_type = GEOMETRY_FACADE_ASM_AUTO;

		buildConstraint(current, &constrainted_component_path, &constraint);

		// Add the constraint to the contraints array.  -1 == append, 1 == one item to add
		GeometryFacadeAddArrayObject((GeometryFacadeArray*)&constraints, -1, 1, &constraint);

		// Increment the constraints to continue parse.
		xmlIn = end + wcslen(end_tag);
	}

	// If no constraint tags were found get out or here.
	if (i == 0) 
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_NOT_FOUND);
	}

	// Prepare to load the constraints array into the component...
	GeometryFacadeAsmCompPath owner_asmcomp_path;
	GeometryFacadeAsmComp constrainted_component;

	GetParentAsmcompPath(constrainted_component_path, &owner_asmcomp_path);

	GetAsmcomp(constrainted_component_path, &constrainted_component);

	// Finally, constrain the damn thing.
	GeometryFacadeSetAsmCompConstraints(&owner_asmcomp_path, &constrainted_component, constraints);

	if (GeometryFacadeGetArraySize(constraints) > 0) 
	{
		GeometryFacadeFreeAsmCompConstraintArray(constraints);
	}
}


// Private functions.
static void buildConstraint(wchar_t *xml, GeometryFacadeAsmCompPath *asmCompPath, GeometryFacadeAsmCompConstraint *asmCompConstraint) 
{
	try
	{
		wchar_t type[25];
		wchar_t idpath_one[255];
		wchar_t reftype_one[255];
		wchar_t idpath_two[255];
		wchar_t reftype_two[255];
		wchar_t offset_value_string[255];
		wchar_t refname_one[255];
		wchar_t refname_two[255];

		wchar_t* offset_end_ptr=NULL;
		double offset_value;

		GeometryFacadeAsmCompConstraintType constraint_type;
		GeometryFacadeType constraint1_type, constraint2_type;	

		getXMLAttributeValue(xml, L"type", type);
		getXMLAttributeValue(xml, L"path1", idpath_one);
		getXMLAttributeValue(xml, L"ref1", reftype_one);
		getXMLAttributeValue(xml, L"name1", refname_one);
		getXMLAttributeValue(xml, L"path2", idpath_two);
		getXMLAttributeValue(xml, L"ref2", reftype_two);
		getXMLAttributeValue(xml, L"name2", refname_two);
		getXMLValue(xml, offset_value_string);

		GeometryFacadeAsmCompPath part_1_path, part_2_path;
		GeometryFacadeMdl mdl_1, mdl_2;
		GeometryFacadeName part_1_ref_name_w, part_2_ref_name_w;
		GeometryFacadeModelItem datum_1, datum_2;
		GeometryFacadeModelItem model_item_1, model_item_2;

		GetAsmcompPath(idpath_one, &part_1_path);
		GetAsmcompPath(idpath_two, &part_2_path);
		GetAsmcompPath(idpath_one, asmCompPath);

		GeometryFacadeGetAsmCompPathMdl(&part_1_path, &mdl_1);
		GeometryFacadeGetAsmCompPathMdl(&part_2_path, &mdl_2);

		std::wstring sRefNm = refname_one;
		std::string::size_type pos = sRefNm.find(L",");
		if(pos != std::string::npos)
		{ 
			//We have got static assembly feature process it and change comp path and handle accordingly.
			std::wstring smdlIds;
			InitHandleOfStaticAssemblyFeature(sRefNm,mdl_1,idpath_one,refname_one,smdlIds);		
			LOG << "Model ID string for static assembly is : " << smdlIds << endl;
			GetAsmcompPath(smdlIds, &part_1_path);	
			GeometryFacadeGetAsmCompPathMdl(&part_1_path, &mdl_1);
		}

		sRefNm = refname_two;
		pos = sRefNm.find(L","); 
		if(pos != std::string::npos)
		{ 
			//We have got static assembly feature process it and change comp path and handle accordingly.
			std::wstring smdlIds;
			InitHandleOfStaticAssemblyFeature(sRefNm,mdl_2,idpath_two,refname_two,smdlIds);		
			LOG << "Model ID string for static assembly is : " << smdlIds << endl;
			GetAsmcompPath(smdlIds, &part_2_path);	
			GeometryFacadeGetAsmCompPathMdl(&part_2_path, &mdl_2);
		}

		ProCharLine refOne, refTwo, charType;
		GeometryFacadeWideStringToString(refOne, reftype_one);
		GeometryFacadeWideStringToString(refTwo, reftype_two);
		GeometryFacadeWideStringToString(charType, type);

		constraint1_type = getProReferenceType(refOne);
		constraint2_type = getProReferenceType(refTwo);

		GeometryFacadeInitModelItemByName(mdl_1, constraint1_type, refname_one, &datum_1);
		GeometryFacadeMdlToModelItem(mdl_1, &model_item_1);

		GeometryFacadeSelection selection_1 = GeometryFacadeAllocateSelection(&part_1_path, &datum_1);

		try
		{
			GeometryFacadeInitModelItemByName(mdl_2, constraint2_type, refname_two, &datum_2);
		}
		catch (ProeException ex)
		{
			// If the error was GEOMETRY_FACADE_NOT_FOUND,
			// trick the code into thinking no error occured.
			// TODO: Investigate if this is the right thing to do.
			if (ex.GetResult() == GEOMETRY_FACADE_NOT_FOUND)
			{	
				return;
			}
			else
			{
				throw;
			}
		}

		GeometryFacadeMdlToModelItem(mdl_2, &model_item_2);
		GeometryFacadeSelection selection_2 = GeometryFacadeAllocateSelection(&part_2_path, &datum_2);

		// Allocate and fill the constraint.

		constraint_type = getProConstraintType(charType, refOne, refTwo);
		GeometryFacadeSetAsmCompConstraintType(*asmCompConstraint, constraint_type);

		GeometryFacadeSetAsmCompConstraintCompReference(*asmCompConstraint, selection_1, GEOMETRY_FACADE_DATUM_SIDE_YELLOW);
		GeometryFacadeSetAsmCompConstraintAsmReference(*asmCompConstraint, selection_2, GEOMETRY_FACADE_DATUM_SIDE_YELLOW);

		if (constraint_type == GEOMETRY_FACADE_ASM_MATE_OFF || constraint_type == GEOMETRY_FACADE_ASM_ALIGN_OFF || 
			constraint_type == GEOMETRY_FACADE_ASM_ALIGN_ANG_OFF || constraint_type == GEOMETRY_FACADE_ASM_MATE_ANG_OFF ||
			constraint_type == GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE || constraint_type == GEOMETRY_FACADE_ASM_LINE_ANGLE ||
			constraint_type == GEOMETRY_FACADE_ASM_EDGE_ON_SRF_ANG)
		{
			// TODO: There is a possible rounding error in the strtod function.
			offset_value = wcstod(offset_value_string, &offset_end_ptr);

			// TODO: offset_value must be given a number in the XML!
			GeometryFacadeSetAsmCompConstraintOffset(*asmCompConstraint, offset_value);
		}

		// TODO: Is it required to free the allocated selections?
		//status = ProSelectionFree(&selection_1);
		//status = ProSelectionFree(&selection_2);

	}
	catch(ProeException ex)
	{
		LOG << "BuildConstraint: FAILED to build constraint with inputs as <" << xml  << "> , verify if Geometries to be assembly have selected Datums." << endl;
	}

	LOG << "buildConstraint: End"<< endl;
}

//sRef - Feature path(ASM1-21,ASM2-21,PRT-21,FrontPlane)
//mdl - Top static assembly handle 
//idpath - Static assembly IDPath
//refname - Name of the reference(FrontPlane)
//smdlIds - List of ID's of to reach feature(46,56,23)
void InitHandleOfStaticAssemblyFeature(std::wstring sRef,GeometryFacadeMdl mdl,wchar_t idpath[255],wchar_t refname[255],std::wstring &smdlIds)
{
	std::vector<std::wstring> vPrtNames;		
	std::wstring sFeatName = sRef.substr(sRef.find_last_of(L",") + 1);
	std::wstring sPartName =  sRef.substr(0,sRef.find_last_of(L","));
	wcscpy(refname,sFeatName.c_str());

	//This function here processes sPartName string and fills vector vPrtNames with name of each part
	//to reach feature sFeatName.
	ProcessPartNameText(sPartName,L",",vPrtNames);
	//Remove Top assembly name as we already have its ID in idpath.
	vPrtNames.erase(vPrtNames.begin() + 0);

	smdlIds = idpath;		
	GetModelIDString(mdl,vPrtNames,smdlIds);
}

//pContainerAsm - Handle of Static assembly which holds component whose reference is used in constrain
//vPrtNames - Vector constaining list of components/sub-assemblies
//smdlIds - List of ID's of to reach feature(46,56,23)
void GetModelIDString(GeometryFacadeMdl pContainerAsm,std::vector<std::wstring> vPrtNames,std::wstring &smdlIds)
{
	int *iFeatIDs = NULL,iNoFeat;
	ProFeatStatus* p_status_array = NULL;
	GeometryFacadeFeature lFeature;
	GeometryFacadeFeatureType lFeattype;
	GeometryFacadeMdl lFeatureMdl;
	GeometryFacadeMdlData mdlData;
	char cMdlId[20];
	wchar_t wcMdlId[40];
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	char sStcComp[260],sCompType[20];
	std::vector<std::string>::iterator PrtNmItr;
	int iMdlID;	

	iFeatIDs = (int *)GeometryFacadeAllocateArray(0,sizeof(int),1); //size of int should be used instead of int* I-03004	
	p_status_array = (ProFeatStatus *)GeometryFacadeAllocateArray(0 , sizeof(ProFeatStatus) , 1);
	result = ProSolidFeatstatusGet((GeometryFacadeSolid)pContainerAsm,&iFeatIDs,&p_status_array,&iNoFeat);

	for (int lIndex = 0; lIndex < iNoFeat; lIndex++)
	{		
		if (ProFeatureInit((ProSolid)pContainerAsm, iFeatIDs[lIndex] , &lFeature) != PRO_TK_NO_ERROR)
			continue;

		ProFeatureTypeGet(&lFeature, &lFeattype);      
		if (lFeattype == PRO_FEAT_COMPONENT)
		{         			
			LOG << "GetModelIDString: Initialize Component at Index <" << lIndex << "> with Id <" <<  iFeatIDs[lIndex] << ">." << endl;
			bool bIsCompExist = false;
			result = ProAsmcompMdlGet((ProAsmcomp*)&lFeature, &lFeatureMdl);
			GeometryFacadeGetMdlData(lFeatureMdl,&mdlData); 

			ProWstringToString(sStcComp,mdlData.name);
			ProWstringToString(sCompType,mdlData.type);
			for(int i = 0 ;i<(int)vPrtNames.size();i++)
			{
				ProCharLine name;
				GeometryFacadeWideStringToString(name, vPrtNames[i].c_str());
				int iStrCmp = strcmp(sStcComp,name);
				if(iStrCmp == 0)
				{
					LOG << "GetModelIDString: Component Found as <" << sStcComp << "> at Index <" << lIndex << "> with Feature Id as <" << lFeature.id << ">." << endl;
					bIsCompExist = true;
					vPrtNames.erase(vPrtNames.begin()+i);
				}
			}

			if(bIsCompExist)
			{
				iMdlID = lFeature.id;
				_itoa(iMdlID,cMdlId,10);
				smdlIds.append(L",");
				GeometryFacadeStringToWideString(wcMdlId, cMdlId);
				smdlIds.append(wcMdlId);				
			}

			if(vPrtNames.size() >= 1 && (strncmp(sCompType,"ASM",3) == 0) && bIsCompExist)
			{
				GetModelIDString(lFeatureMdl,vPrtNames,smdlIds);
			}
		}
	}

	if(iFeatIDs != NULL)
		GeometryFacadeFreeArray((ProArray *)&iFeatIDs);

	if(p_status_array != NULL)
		GeometryFacadeFreeArray((ProArray*)&p_status_array);
}


static void fixPosition_wrapper(std::string idPath, double x, double y, double z) 
{
	GeometryFacadeAsmCompPath path;
	GeometryFacadeAsmComp asmcomp;
	GeometryFacadeMatrix pos_matrix;
	GeometryFacadeMatrix translation_matrix = {{1.0, 0.0, 0.0, 0.0 }, 
									{0.0, 1.0, 0.0, 0.0}, 
									{0.0, 0.0, 1.0, 0.0}, 
									{0.0, 0.0, 0.0, 1.0}};

	GetAsmcompPath(idPath, &path);
	GetAsmcomp(path, &asmcomp);

	GeometryFacadeGetAsmCompPosition(&asmcomp, pos_matrix);

	// Remove all pre-existing constraints.
	GeometryFacadeRemoveAsmCompConstraint(&asmcomp, -1);

	GeometryFacadeSetAsmCompPosition(NULL, &asmcomp, translation_matrix);

	GeometryFacadeRegenerateAsmComp(&asmcomp, GEOMETRY_FACADE_B_TRUE);
	GeometryFacadeRepaintWindow(GEOMETRY_FACADE_VALUE_UNUSED);
	GeometryFacadeClearWindow(GEOMETRY_FACADE_VALUE_UNUSED);
	GeometryFacadeRefreshWindow(GEOMETRY_FACADE_VALUE_UNUSED);
	int windowId = GeometryFacadeGetCurrentWindow();
	GeometryFacadeRepaintWindow(windowId);
	GeometryFacadeClearWindow(windowId);
	GeometryFacadeRefreshWindow(windowId);
	GeometryFacadeRegenerateSolid( (GeometryFacadeSolid)asmcomp.owner, GEOMETRY_FACADE_REGEN_NO_FLAGS );
}


// <constraint type="Align" 
//         idpath_one="39,9,9,10" reftype_one="Plane" refname_one="TOP"
//         idpath_two="39,9,9,11" reftype_ two ="Plane" refname_two ="TOP">
//
// </constraint>
static GeometryFacadeAsmCompConstraintType getConstraintTypeFromString(char *typeString) 
{
	char *upper_type_string = typeString;

	StringUpper(typeString, upper_type_string);

	if(!strcmp("MATE", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_MATE;
	}
	else if(!strcmp("MATE OFFSET", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_MATE_OFF;
	}
	else if(!strcmp("ALIGN", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_ALIGN;
	}
	else if(!strcmp("ALIGN OFFSET", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_ALIGN_OFF;
	}
	else if(!strcmp("POINT ON LINE", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_PNT_ON_LINE;
	}
	else if(!strcmp("POINT ON PLANE", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_PNT_ON_SRF;
	}
	else if(!strcmp("ANGLE",typeString))
	{
		return GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE;
	}
	else if(!strcmp("FIX", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_FIX;
	}
	else if(!strcmp("INSERT", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_INSERT;
	}
	else if(!strcmp("ORIENT", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_ORIENT;
	}
	else if(!strcmp("CSYS", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_CSYS;
	}
	else if(!strcmp("TANGENT", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_TANGENT;
	}
	else if(!strcmp("EDGE ON SURFACE", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_EDGE_ON_SRF;
	}
	else if(!strcmp("DEFAULT", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_DEF_PLACEMENT;
	}
	else if(!strcmp("SUBSTITUTE", typeString)) 
	{
		return GEOMETRY_FACADE_ASM_ASM_SUBSTITUTE;
	}

	// Not allowing type = GEOMETRY_FACADE_ASM_AUTO.

	// If none of the above...there was an unrecognized constraint type.
	return (GeometryFacadeAsmCompConstraintType) - 1;
}


static GeometryFacadeAsmCompConstraintType getProConstraintType(char *typeString, char *reference1Type, char *reference2Type) 
{
	GeometryFacadeAsmCompConstraintType result;
	GeometryFacadeType ref1, ref2;

	result = getConstraintTypeFromString(typeString);
	ref1 = getProReferenceType(reference1Type);
	ref2 = getProReferenceType(reference2Type);

	if(ref1 == GEOMETRY_FACADE_SURFACE && ref2 == GEOMETRY_FACADE_SURFACE) 
	{
		// ALWAYS force align and mate to use an offset value.
		if (result == GEOMETRY_FACADE_ASM_ALIGN) 
		{
			result = GEOMETRY_FACADE_ASM_ALIGN_OFF;
		}
		else if (result == GEOMETRY_FACADE_ASM_MATE) 
		{
			result = GEOMETRY_FACADE_ASM_MATE_OFF;
		}
		else if(result = GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE)
		{
			result = GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE;
		}
	}
	else if ( (ref1 == GEOMETRY_FACADE_POINT && ref2 == GEOMETRY_FACADE_AXIS) || (ref1 == GEOMETRY_FACADE_AXIS && ref2 == GEOMETRY_FACADE_POINT) )
	{
		result = GEOMETRY_FACADE_ASM_PNT_ON_LINE;
	}
	else if ( (ref1 == GEOMETRY_FACADE_POINT && ref2 == GEOMETRY_FACADE_SURFACE) || (ref1 == GEOMETRY_FACADE_SURFACE && ref2 == GEOMETRY_FACADE_POINT) )
	{
		result = GEOMETRY_FACADE_ASM_PNT_ON_SRF;
	}
	else if ( (ref1 == GEOMETRY_FACADE_AXIS && ref2 == GEOMETRY_FACADE_AXIS) || (ref1 == GEOMETRY_FACADE_POINT && ref2 == GEOMETRY_FACADE_POINT) )
	{		
		if(result == GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE && (ref1 == GEOMETRY_FACADE_AXIS && ref2 == GEOMETRY_FACADE_AXIS))
		{
			result = GEOMETRY_FACADE_ASM_LINE_ANGLE;
		}
		else
		{
			result = GEOMETRY_FACADE_ASM_ALIGN;
		}
	}
	else if((ref1 == GEOMETRY_FACADE_AXIS && ref2 == GEOMETRY_FACADE_SURFACE) || (ref1 == GEOMETRY_FACADE_SURFACE && ref2 == GEOMETRY_FACADE_AXIS) )
	{
		if(result == GEOMETRY_FACADE_ASM_ALIGN_NODEP_ANGLE)
		{
			result = GEOMETRY_FACADE_ASM_EDGE_ON_SRF_ANG;
		}
	}
	else if (ref1 == GEOMETRY_FACADE_CSYS && ref2 == GEOMETRY_FACADE_CSYS)
	{
		result = GEOMETRY_FACADE_ASM_CSYS;
	}

	return result;
}


static GeometryFacadeType getProReferenceType(char *type) 
{
	GeometryFacadeType result = GEOMETRY_FACADE_TYPE_INVALID;

	if ( (UtilStrcmp(type, "PLANE") == 0 ) || UtilStrcmp(type, "DTMPLN") == 0 )
	{
		result = GEOMETRY_FACADE_SURFACE;
	}
	else if ( (UtilStrcmp(type, "AXIS") == 0 )  || UtilStrcmp(type, "DTMLINE" ) == 0 )	
	{
		result = GEOMETRY_FACADE_AXIS;
	}
	else if ( (UtilStrcmp(type, "COORD SYS" ) == 0) || UtilStrcmp(type, "CSYS") == 0 )
	{
		result = GEOMETRY_FACADE_CSYS;
	}
	else if ( (UtilStrcmp(type, "POINT") == 0 ) || UtilStrcmp(type, "DTMPNT") == 0 )
	{
		result = GEOMETRY_FACADE_POINT;
	}

	return result;
}

//commented line from VS 2003 modified for VS 2008
//static void getXMLAttributeValue(const char *xml, char *attribute, char *value) 
void getXMLAttributeValue(char *xml, char *attribute, char *value) 
{
	char *start = NULL;
	char *val_start = NULL;
	char *val_end=NULL;

	// Find the_attribute within the_string.
	start = strstr(xml, attribute);

	// Find the starting quote after the_attribute.
	val_start = strstr(start, "\"");

	// Find the ending quote after the_attribute.
	val_end = strstr(val_start + 1, "\"");

	// Copy the string that is between the quotes.
	strncpy(value, val_start + 1, val_end - val_start - 1);

	// NULL terminate value.
	value[val_end - val_start - 1] = '\0';
}

void getXMLAttributeValue(wchar_t *xml, wchar_t *attribute, wchar_t *value)
{
	wchar_t *start = NULL;
	wchar_t *val_start = NULL;
	wchar_t *val_end=NULL;

	try
	{
		// Find the_attribute within the_string.
		start = wcsstr(xml, attribute);

		// Find the starting quote after the_attribute.
		val_start = wcsstr(start, L"\"");

		// Find the ending quote after the_attribute.
		val_end = wcsstr(val_start + 1, L"\"");

		// Copy the string that is between the quotes.
		wcsncpy(value, val_start + 1, wcslen(val_start) - wcslen(val_end));

		// NULL terminate value.
		value[val_end - val_start - 1] = L'\0';
	}
	catch (const std::exception &ex)
	{
		LOG << "Exception occurred in getXMLAttributeValue:" << ex.what() <<endl;
		throw ex;
	}
}

//
//	<constraint type = "Align" 
//			path1 ="39,9,9,10" ref1="Plane" name1="TOP"
//			path2= "39,9,9,11" ref2="Plane" name2="TOP">
//	</constraint>
//commented line from VS 2003 modified for VS 2008
//static void getXMLValue(const char *xml, char *value) 
void getXMLValue(char *xml, char *value) 
{
	try
	{
		// Find the string between  '>' and '<' ignoring ws.
		char *val_start = NULL;
		char *val_end = NULL;

		// Find the first '>'.
		val_start = strstr(xml, ">");

		// Find the first occurence of '<' after the first '>'.
		val_end = strstr(val_start + 1, "<");

		// Copy the string between '>' and '<'.
		strncpy(value, val_start + 1, val_end - val_start - 1);

		// NULL terminate value.
		value[val_end - val_start - 1] = '\0';
	}
	catch (const std::exception &ex)
	{
		LOG << "Exception occurred in getXMLValue:" << ex.what() <<endl;
		throw ex;
	}
}

void getXMLValue(wchar_t *xml, wchar_t *value) 
{
	try
	{
		// Find the string between  '>' and '<' ignoring ws.
		wchar_t *val_start = NULL;
		wchar_t *val_end = NULL;

		// Find the first '>'.
		val_start = wcsstr(xml, L">");

		// Find the first occurence of '<' after the first '>'.
		val_end = wcsstr(val_start + 1, L"<");

		// Copy the string between '>' and '<'.
		wcsncpy(value, val_start + 1, val_end - val_start - 1);

		// NULL terminate value.
		value[val_end - val_start - 1] = '\0';
	}
	catch (const std::exception &ex)
	{
		LOG << "Exception occurred in getXMLValue:" << ex.what() <<endl;
		throw ex;
	}
}


static void showConstraints_wrapper(std::string idPath) 
{
	GeometryFacadeAsmCompPath path;
	GetAsmcompPath(idPath, &path);

	GeometryFacadeAsmComp comp;
	GetAsmcomp(path, &comp);

	userAsmcompConstraintsHighlight(&comp);
}


// FUNCTION: userAsmcompConstraintsHighlight
// PURPOSE:  Highlights and labels a component's constraints
static void userAsmcompConstraintsHighlight(GeometryFacadeAsmComp *asmComp)
{
	GeometryFacadeSelection comp_constr, asm_constr;
	GeometryFacadeDatumSide dtmside;
	GeometryFacadeAsmCompConstraint* constr_array;
	int i_count;	
	double offset;
	GeometryFacadeAsmCompConstraintType type;

	// Get the constraints for the component.
	GeometryFacadeGetAsmCompConstraints(asmComp, &constr_array);

	int size = GeometryFacadeGetArraySize(constr_array);

	for (int i = 0; i < size; i++)
	{
		// Highlight the assembly reference geometry.
		GeometryFacadeGetAsmCompConstraintAsmReference(constr_array [i], &asm_constr, &dtmside);

		GeometryFacadeHighlightSelection(asm_constr, GEOMETRY_FACADE_COLOR_ERROR);

		// Highlight the component reference geometry.
		GeometryFacadeGetAsmCompConstraintCompReference(constr_array [i], &comp_constr, &dtmside);

		GeometryFacadeHighlightSelection(comp_constr, GEOMETRY_FACADE_COLOR_WARNING);

		// Prepare and display the message text.
		offset = GeometryFacadeGetAsmCompConstraintOffset(constr_array [i]);

		type = GeometryFacadeGetAsmCompConstraintType(constr_array [i]);

		i_count = i + 1;
	}

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&constr_array );
}


//This is another copy of ProcessNoteText() 
//Future plan is make single function in Utility.cpp
//Then remove this from here
void ProcessPartNameText(std::wstring sInputText ,std::wstring delimeter, vector<std::wstring> &vNoteStr)
{	
	size_t found;	
	std::wstring sNoteLine =  L"";

	int pos = 0;
	found = sInputText.find_first_of(delimeter);
	if (found == string::npos)
	{
		vNoteStr.push_back(sInputText);
	}

	while (found!=string::npos)
	{		
		sNoteLine = sInputText.substr(pos,found);			
		vNoteStr.push_back(sNoteLine);
		std::wstring noteTemp = sInputText.substr(found+wcslen(delimeter.c_str()));
		sInputText = noteTemp;
		found=noteTemp.find_first_of(delimeter);
		if (found == string::npos)
		{					
			vNoteStr.push_back(sInputText);
		}		
	}
}

//To Convert degree to radian
double degree2radian(double degree) 
{
	return degree * PI / 180;
}