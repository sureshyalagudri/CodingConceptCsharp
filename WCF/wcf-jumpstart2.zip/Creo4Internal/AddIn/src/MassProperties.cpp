// C/C++ header files.
#include <string>


// Application header files.
#include "Log.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "MassProperties.h"


extern std::string result_string;
extern std::wstring result_wstring;


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetMassProperties_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		getMassProperties_wrapper(idPath);
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Get Mass Properties for : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetMassProperty_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	std::wstring property;
	wstring modelID;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		modelID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		property = data.v.w;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,modelID.c_str());

		stringstream ss;
		ss << path;
		ss >> idPath;

		// Declare the output arguments and call the function.
		std::wstring output = getMassProperty_wrapper(idPath, property);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString (arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Mass Property : ";
		AddWStringToMsgString(sFailureMsg, property);
		sFailureMsg.append(" For IDPath : ");
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.
void GetMassPropertiesXML(GeometryFacadeMdl *the_model, std::string &the_mass_props_xml) 
{
	char tag[1000];
	int len = 0;

	GeometryFacadeMassProperty mass_props = GeometryFacadeGetSolidMassProperty( (GeometryFacadeSolid)*the_model, NULL );

	len = sprintf(tag, "\t\t\t<MASS name=\"Volume\">%.7e</MASS>\n", mass_props.volume);
	the_mass_props_xml = the_mass_props_xml + tag;
	len = sprintf(tag, "\t\t\t<MASS name=\"SurfaceArea\">%.7e</MASS>\n", mass_props.surface_area);
	the_mass_props_xml = the_mass_props_xml + tag;
	len = sprintf(tag, "\t\t\t<MASS name=\"Density\">%g</MASS>\n", mass_props.density);
	the_mass_props_xml = the_mass_props_xml + tag;
	len = sprintf(tag, "\t\t\t<MASS name=\"Mass\">%.7e</MASS>\n", mass_props.mass);
	the_mass_props_xml = the_mass_props_xml + tag;

	len = sprintf(tag, "\t\t\t<MASS name=\"CenterOfGravity\">%.7e, %.7e, %.7e</MASS>\n", 
		mass_props.center_of_gravity[0], 
		mass_props.center_of_gravity[1], 
		mass_props.center_of_gravity[2]);
	the_mass_props_xml = the_mass_props_xml + tag;

	len = sprintf(tag, "\t\t\t<MASS name=\"CoorSysInertiaTensor\">[[%.7e, %.7e, %.7e][%.7e, %.7e, %.7e][%.7e, %.7e, %.7e]]</MASS>\n",
		mass_props.coor_sys_inertia_tensor[0][0],
		mass_props.coor_sys_inertia_tensor[0][1],
		mass_props.coor_sys_inertia_tensor[0][2],
		mass_props.coor_sys_inertia_tensor[1][0],
		mass_props.coor_sys_inertia_tensor[1][1],
		mass_props.coor_sys_inertia_tensor[1][2],
		mass_props.coor_sys_inertia_tensor[2][0],
		mass_props.coor_sys_inertia_tensor[2][1],
		mass_props.coor_sys_inertia_tensor[2][2]);
	the_mass_props_xml = the_mass_props_xml + tag;

	len = sprintf(tag, "\t\t\t<MASS name=\"PrincipalMoments\">%.7e, %.7e, %.7e</MASS>\n",
					mass_props.principal_moments[0],
					mass_props.principal_moments[1],
					mass_props.principal_moments[2]);
	the_mass_props_xml = the_mass_props_xml + tag;
	
	len = sprintf(tag, "\t\t\t<MASS name=\"PrincipalAxes\">[[%g, %g, %g][%g, %g, %g][%g, %g, %g]]</MASS>\n",   
					mass_props.principal_axes[0][0], 
					mass_props.principal_axes[0][1], 
					mass_props.principal_axes[0][2],
					mass_props.principal_axes[1][0],
					mass_props.principal_axes[1][1], 
					mass_props.principal_axes[1][2],
					mass_props.principal_axes[2][0],
					mass_props.principal_axes[2][1], 
					mass_props.principal_axes[2][2]);
	the_mass_props_xml = the_mass_props_xml + tag;
}


// Private functions.
static void logMassProperties(GeometryFacadeMassProperty *mass_prop) 
{
	LOG << "Mass Properties" << std::endl;

	LOG << "Volume = " << mass_prop->volume << std::endl;
	LOG << "Surface area = " << mass_prop->surface_area << std::endl;
	LOG << "Density = " << mass_prop->density << std::endl;
	LOG << "Mass = " << mass_prop->mass << std::endl;
	LOG << "Center of gravity with respect to default CSYS" << std::endl;
    LOG << "X Y Z" 
			<< mass_prop->center_of_gravity[0] << " " 
			<< mass_prop->center_of_gravity[1] << " "
			<< mass_prop->center_of_gravity[2] << std::endl;
	LOG << "Inertia at Center of gravity with respect to default CSYS" << std::endl;  
	LOG << "Inertia tensor" << std::endl;
    LOG << "Ixx Ixy Ixz" 
			<< mass_prop->coor_sys_inertia_tensor[0][0] << " "
			<< mass_prop->coor_sys_inertia_tensor[0][1] << " "
			<< mass_prop->coor_sys_inertia_tensor[0][2] << std::endl;
    LOG << "Iyx Iyy Iyz"
			<< mass_prop->coor_sys_inertia_tensor[1][0] << " "
			<< mass_prop->coor_sys_inertia_tensor[1][1] << " "
			<< mass_prop->coor_sys_inertia_tensor[1][2] << std::endl;
    LOG << "Izx Izy Izz"
			<< mass_prop->coor_sys_inertia_tensor[2][0] << " "
			<< mass_prop->coor_sys_inertia_tensor[2][1] << " "
			<< mass_prop->coor_sys_inertia_tensor[2][2] << std::endl;
	LOG << "Principal moments of inertia" << std::endl;
    LOG << "I1  I2  I3" 
			<< mass_prop->principal_moments[0] << " "
			<< mass_prop->principal_moments[1] << " "
			<< mass_prop->principal_moments[2] << std::endl;
	LOG << "Rotation matrix from default orientation to principal axes" 
			<< mass_prop->principal_axes[0][0] << " "
			<< mass_prop->principal_axes[0][1] << " "
			<< mass_prop->principal_axes[0][2] << " "
			<< mass_prop->principal_axes[1][0] << " "
			<< mass_prop->principal_axes[1][1] << " "
			<< mass_prop->principal_axes[1][2] << " "
			<< mass_prop->principal_axes[2][0] << " "
    	    << mass_prop->principal_axes[2][1] << " "
			<< mass_prop->principal_axes[2][2] << std::endl;
}

//Fix added for D-04334 , mass propertis values are noe converted to string considering their scientific notation.
//upto 7 decimal places is hardcoded as Creo currently use it that way.
static wchar_t* getMassProperty_wrapper(std::string the_Id_path, std::wstring the_mass_prop)
{
	GeometryFacadeAsmCompPath comp_path;
	GeometryFacadeAsmComp comp;
	GeometryFacadeMdl model;
	wchar_t buf[256];


	if (strcmp(the_Id_path.c_str(), "0") == 0 || strcmp(the_Id_path.c_str(), "") == 0)
	{
		GeometryFacadeGetCurrentMdl(&model);
	} 
	else 
	{
		GetAsmcompPath(the_Id_path, &comp_path);
		GetAsmcomp(comp_path, &comp);
		GeometryFacadeGetAsmCompMdl(&comp, &model);
	}

	GeometryFacadeMassProperty mass_prop = GeometryFacadeGetSolidMassProperty(GeometryFacadeSolid(model), NULL);

	if (the_mass_prop.compare(L"Volume") == 0)
	{
		swprintf(buf, L"%.7e", mass_prop.volume);
	}
	else if (the_mass_prop.compare(L"SurfaceArea") == 0)
	{
		swprintf(buf, L"%.7e", mass_prop.surface_area);
	}
	else if (the_mass_prop.compare(L"Density") == 0)
	{
		swprintf(buf, L"%g", mass_prop.density);
	}
	else if (the_mass_prop.compare(L"Mass") == 0)
	{
		swprintf(buf, L"%.7e", mass_prop.mass);
	}
	else if (the_mass_prop.compare(L"CenterOfGravity") == 0)
	{
		swprintf(buf, L"%.7e,  %.7e,  %.7e",  mass_prop.center_of_gravity[0], mass_prop.center_of_gravity[1], mass_prop.center_of_gravity[2]);
	}
	else if (the_mass_prop.compare(L"PrincipalMoments") == 0)
	{
		swprintf(buf, L"%.7e,  %.7e,  %.7e", mass_prop.principal_moments[0], mass_prop.principal_moments[1],mass_prop.principal_moments[2]);
	}
	else if (the_mass_prop.compare(L"PrincipalAxes") == 0)
	{
		swprintf(buf, L"[[%g,  %g,  %g][%g,  %g,  %g][%g,  %g,  %g]]",
			mass_prop.principal_axes[0][0], mass_prop.principal_axes[0][1], mass_prop.principal_axes[0][2], 
			mass_prop.principal_axes[1][0], mass_prop.principal_axes[1][1], mass_prop.principal_axes[1][2], 
			mass_prop.principal_axes[2][0], mass_prop.principal_axes[2][1], mass_prop.principal_axes[2][2]);
	}
	else if (the_mass_prop.compare(L"CoorSysInertiaTensor") == 0)
	{
		swprintf(buf, L"[[%.7e,  %.7e,  %e][%.7e,  %.7e,  %.7e][%.7e,  %.7e,  %.7e]]",
			mass_prop.coor_sys_inertia_tensor[0][0], mass_prop.coor_sys_inertia_tensor[0][1], mass_prop.coor_sys_inertia_tensor[0][2], 
			mass_prop.coor_sys_inertia_tensor[1][0], mass_prop.coor_sys_inertia_tensor[1][1], mass_prop.coor_sys_inertia_tensor[1][2], 
			mass_prop.coor_sys_inertia_tensor[2][0], mass_prop.coor_sys_inertia_tensor[2][1], mass_prop.coor_sys_inertia_tensor[2][2]);
	}

	result_wstring = buf;

	return (wchar_t*)result_wstring.c_str();
}


static void getMassProperties_wrapper(std::string the_Id_path) 
{
	GeometryFacadeAsmCompPath comp_path;
	GeometryFacadeAsmComp comp;
	GeometryFacadeMdl model;

	if (the_Id_path == "0" || the_Id_path == "") 
	{
		GeometryFacadeGetCurrentMdl(&model);
	} 
	else 
	{
		GetAsmcompPath(the_Id_path, &comp_path);
		GetAsmcomp(comp_path, &comp);
		GeometryFacadeGetAsmCompMdl(&comp, &model);
	}

	GeometryFacadeMassProperty mass_prop = GeometryFacadeGetSolidMassProperty(GeometryFacadeSolid(model), NULL);

	logMassProperties(&mass_prop);
}

