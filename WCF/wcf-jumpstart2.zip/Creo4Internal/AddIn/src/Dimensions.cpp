// C/C++ header files.
#include <string>


// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Dimensions.h"
#include "Log.h"


extern std::string result_string;
extern std::wstring result_wstring;


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionGetValue_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		// Declare the output arguments and call the function.
		double output = dimensionGetValue_wrapper(idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_DOUBLE;
		arg.value.v.d = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to get Value for Dimension : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionGetValueByIdPath_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		// Declare the output arguments and call the function.
		std::wstring output = dimensionGetValueByIdPath_wrapper(idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to get Value for Dimension : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionSetByName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring name;
	double value;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		name = data.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.d;

		dimensionSetByName_wrapper(name, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Value of Dimension : ";
		AddWStringToMsgString(sFailureMsg, name);
		std::stringstream ss;
		ss << value;
		sFailureMsg.append(" to Value : ");
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionSetValueByIdPath_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	double value;


	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.d;

		DimensionSetValueByIdPath_wrapper(idPath, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to set value of Dimension with : ";
		sFailureMsg.append(idPath);
		std::stringstream ss;
		ss << value;
		sFailureMsg.append(" to Value : ");
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.
void DimensionSetValueByIdPath_wrapper(std::string idPath, double valueIn) 
{
	int table[25];
	int tableSize;
	GeometryFacadeAsmCompPath path;
	GeometryFacadeMdl currentModel;
	GeometryFacadeModelItem modelItem;
	GeometryFacadeMdl owner;
	int dimensionID;
	int iWinID;

	/*GeometryFacadeGetCurrentMdl(&currentModel);*/
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&currentModel); 

	// TODO: Parse theIdPath to fill the table and dimensionID.
	fillPathTable(idPath, table, &tableSize);
	
	// Get path to the owner of dimension.
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)currentModel, table, tableSize - 1, &path );

	// Get the owner object.
	GeometryFacadeGetAsmCompPathMdl(&path, &owner);
	
	// Get the dimension object as the model item.
	dimensionID = table[tableSize - 1];
	GeometryFacadeInitModelItem(owner, dimensionID, GEOMETRY_FACADE_DIMENSION, &modelItem);
	
	// Get the value of the dimension.
	double value = GeometryFacadeGetDimensionValue( (GeometryFacadeDimension*)&modelItem );
	
	// There is no need to change the value to the same value.
	if (value != valueIn) 
	{
		GeometryFacadeSetDimensionValue( (GeometryFacadeDimension*)&modelItem, valueIn );
	}
}


// Private functions.

// This function will get only the value of the dimension for the given IDpath.
static double dimensionGetValue_wrapper(std::string idPath) 
{
	int table[25];
	int table_size;
	GeometryFacadeAsmCompPath path;
	GeometryFacadeMdl current_model;
	GeometryFacadeModelItem model_item;
	GeometryFacadeMdl owner;
	int dim_id;
	int iWinID;

	// Get object from ther_Id_path.
	/*GeometryFacadeGetCurrentMdl(&current_model);*/
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&current_model);

	fillPathTable(idPath, table, &table_size);

	dim_id = table[table_size - 1];

	// Get Path to owner of dimension.
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size - 1, &path );

	// Get the owner object.
	GeometryFacadeGetAsmCompPathMdl(&path, &owner);

	// Get the dimension object as the model_item.
	GeometryFacadeInitModelItem(owner, dim_id, GEOMETRY_FACADE_DIMENSION, &model_item);

	// Get the dimension name.
	//result = GeometryFacadeGetDimensionSymbol((GeometryFacadeDimension*)&model_item, symbol);
	//GeometryFacadeWideStringToString(dim_name, symbol);

	// Get the value of the dimension.
	double value = GeometryFacadeGetDimensionValue( (GeometryFacadeDimension*)&model_item );

	return value;
}


//	Assumption: the_Id_path will be 25 or less integers in a comma delimited 
//				string because the maximum table size defined in ProE is 25.
//
//	Input:		the_Id_path = "31,2,4"
//		where the last number is the dimension id.
//
//	Return Value: "<DIM id="0" name="d0" type="double">0.000000</DIM>"
//				  "GEOMETRY_FACADE_BAD_CONTEXT"
//		          "GEOMETRY_FACADE_BAD_INPUTS"
static wchar_t* dimensionGetValueByIdPath_wrapper(std::string idPath) 
{
	int table[25];
	int table_size;
	GeometryFacadeAsmCompPath path;
	GeometryFacadeMdl current_model;
	GeometryFacadeModelItem model_item;
	GeometryFacadeMdl owner;
	int dim_id;
	GeometryFacadeName symbol;
	wchar_t buf[1000];
	int iWinID;

	// Get object from the_Id_path.
	/*GeometryFacadeGetCurrentMdl(&current_model);*/
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&current_model);

	fillPathTable(idPath, table, &table_size);

	dim_id = table[table_size - 1];

	// Get Path to owner of dimension.
	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)current_model, table, table_size-1, &path );

	// Get the owner object.
	GeometryFacadeGetAsmCompPathMdl(&path, &owner);

	// Get the dimension object as the model_item.
	GeometryFacadeInitModelItem(owner, dim_id, GEOMETRY_FACADE_DIMENSION, &model_item);

	// Get the dimension name.
	GeometryFacadeGetDimensionSymbol( (GeometryFacadeDimension*)&model_item, symbol );

	// Get the value of the dimension.
	double value = GeometryFacadeGetDimensionValue( (GeometryFacadeDimension*)&model_item );
	swprintf(buf, L"<DIM id=\"%d\" name=\"%s\">%f</DIM>", dim_id, symbol, value);

	result_wstring = buf;

	return (wchar_t*)result_wstring.c_str();
}


static void dimensionSetByName_wrapper(std::wstring name, double value) 
{
	GeometryFacadeMdl model;
	GeometryFacadeModelItem dim;
	GeometryFacadeName dim_name;
	DimensionData x;
	int iWinID;
      
	x.name = const_cast<wchar_t*>(name.c_str());
	x.value = value;

	// There is only one current model
	/*GeometryFacadeGetCurrentMdl(&model);*/
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&model);

	// Retrieve the dimensions
	GeometryFacadeVisitSolidDimension( (GeometryFacadeSolid)model, 
									         GEOMETRY_FACADE_B_FALSE, /* Visit ref dims too */ 
									         (GeometryFacadeDimensionVisitAction)dimensionSetVisitAction,
									         (GeometryFacadeDimensionFilterAction)dimensionSetFilterAction, 
									         &x );

	GeometryFacadeVisitSolidDimension( (GeometryFacadeSolid)model, 
									         GEOMETRY_FACADE_B_TRUE, 
									         (GeometryFacadeDimensionVisitAction)dimensionSetVisitAction,
									         (GeometryFacadeDimensionFilterAction)dimensionSetFilterAction, 
									         &x );

	GeometryFacadeStringToWideString(dim_name, "EXTRUSION");
	GeometryFacadeInitModelItemByName(model, GEOMETRY_FACADE_FEATURE, dim_name, &dim);
	GeometryFacadeFeatureType feattype = GeometryFacadeGetFeatureType(&dim);
	GeometryFacadeName feattypename;  
	GeometryFacadeGetFeatureTypeName(&dim, feattypename);

	GeometryFacadeRegenerateSolid( (GeometryFacadeSolid)model, GEOMETRY_FACADE_REGEN_NO_FLAGS );
}


// dimensionSetFilterAction
//
//   This function will only call the visit function for dimensions with names
//   in 'theChanges' strucuture.
static GeometryFacadeError dimensionSetFilterAction(GeometryFacadeDimension *dimension, GeometryFacadeAppData appData) 
{
	GeometryFacadeName dim_name;
	GeometryFacadeName changes_name;

	DimensionData *changes = (DimensionData*)appData;

	GeometryFacadeGetDimensionSymbol(dimension, dim_name);
	
	int result = GeometryFacadeCompareWideString(dim_name, changes->name, GEOMETRY_FACADE_VALUE_UNUSED);

	return (GeometryFacadeError)result; 
}


static GeometryFacadeError dimensionSetVisitAction(GeometryFacadeDimension *dim, GeometryFacadeError filterStatus, GeometryFacadeAppData appData) 
{
	DimensionData *changes = (DimensionData*)appData;
	
	double value = GeometryFacadeGetDimensionValue(dim);
	GeometryFacadeSetDimensionValue(dim, changes->value);
	GeometryFacadeRepaintWindow(GEOMETRY_FACADE_VALUE_UNUSED);

	// When the correct dimension is found return something other 
	// than GEOMETRY_FACADE_NO_ERROR and the visiting of dimensions will stop.
	return GEOMETRY_FACADE_CONTINUE;

	// This function MUST return GEOMETRY_FACADE_NO_ERROR to continue visiting dimensions.
	//return GEOMETRY_FACADE_NO_ERROR;
}




