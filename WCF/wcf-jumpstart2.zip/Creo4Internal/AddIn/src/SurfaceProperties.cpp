// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "SurfaceProperties.h"
#include "Log.h"

extern std::string result_string;
extern std::wstring result_wstring;


// typedef struct GeometryFacadeSurfaceProperties
// {
//         double ambient;
//         double diffuse;
//         double highlite;
//         double shininess;
//         int    threshold;
//         double transparency;
//         double color_rgb[3];
//         double highlight_color[3];
//         double reflection;
//         double decal_intensity;
//         char  *decal;
//         char  *texture_map;
//         char  *bump_map;
//         double bump_height;
//         Projection_type  projection;
//         double local_csys[4][3];
//         int    copies;
//         float  horizontal_offset;
//         float  vertical_offset;
//         float  rotate;
//         float  horizontal_scale;
//         float  vertical_scale;
//         int    flip_horizontal;
//         int    flip_vertical;
//
// } GeometryFacadeSurfaceProperties;
//
//
// The GeometryFacadeSurfaceProperties data structure contains the following fields:
//
//        ambient - Specifies the indirect, scattered light the model receives from its surroundings. The valid range is 0.0 to 1.0.
//        diffuse - Specifies the reflected light that comes from directional, point, or spot lights. The valid range is 0.0 to 1.0.
//        highlite - Specifies the intensity of the light reflected from a highlighted surface area. The valid range is 0.0 to 1.0.
//        shininess - Specifies the properties of a highlighted surface area. A plastic model would have a lower shininess value, while a metallic model would have a higher value. The valid range is 0.0. to 1.0.
//        threshold - Enables you to selectively remove surfaces from view based on this value. Any surface that has a threshold higher than the threshold field will not be displayed. The valid range is 0 to 100.
//        transparency - Specifies the transparency value, which is between 0 (completely opaque) and 1.0 (completely transparent).
//        color_rgb[3] - Specifies the color, in terms of red, green, and blue. The valid range is 0.0. to 1.0.
//        highlight_color - Specifies the highlight color, in terms of red, green, and blue. The valid range is 0.0 to 1.0.
//        reflection - Specifies how reflective the surface is. The valid range is 0 (dull) to 100 (shiny).
//        decal - Specifies the full path to the texture map with the alpha channel (transparency). Otherwise, use NULL.
//        texture_map - Specifies the full path to the texture map.
//        bump_map - Specifies the full path to the bump map. A bump map enables you to create bumps on the surface of the texture map.
//        projection - Specifies the projection type--planar, spherical, or cylindrical.
//        local_csys - Specifies the direction (for planar projection), or the whole coordinate system (which defines the center for the other projection types).
//        horizontal_offset and vertical_offset - Specifies the percentage of horizontal and vertical shift of the texture map on the surface.
//        rotate - Specifies the angle to rotate the texture map on the surface.
//        horizontal_scale and vertical_scale - Specifies the horizontal and vertical scaling of the texture map.


// Basic 16 colors used to color the parts.
//
// None        = -1.0, -1.0, -1.0
// Black       = 0.00, 0.00, 0.00
// White       = 1.00, 1.00, 1.00
// DarkGray    = 0.50, 0.50, 0.50
// LightGray   = 0.75, 0.75, 0.75
// Red         = 1.00, 0.00, 0.00
// DarkRed     = 0.50, 0.00, 0.00
// Yellow      = 1.00, 1.00, 0.00
// DarkYellow  = 0.50, 0.50, 0.00
// Green       = 0.00, 1.00, 0.00
// DarkGreen   = 0.00, 0.50, 0.00
// Cyan        = 0.00, 0.50, 0.50
// Blue        = 0.00, 0.00, 1.00
// DarkBlue    = 0.00, 0.00, 0.50
// Magenta     = 1.00, 0.00, 1.00
// DarkMagenta = 0.50, 0.00, 0.50


// Exported functions.

// Ambient Light functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetAmbientLight_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		// Declare the output arguments and call the function.
		std::wstring output = getAmbientLight_wrapper(idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Get Ambient Light for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetAmbientLight_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	double value;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.d;

		setAmbientLight_wrapper(idPath, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Ambient Light for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Color functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetColor_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		// Declare the output arguments and call the function.
		std::wstring output = getColor_wrapper(idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Color for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetColor_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	std::wstring value;
	wstring target;

	try
	{
		GeometryFacadeValueData data;
				
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		target = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.w;

		char path[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeWideStringToString(path,target.c_str());

		stringstream ss;
		ss << path;
		ss >> idPath;

		setColor_wrapper(idPath, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Color for ID : ";
		sFailureMsg.append(idPath);
		sFailureMsg.append(" For Value : ");
		AddWStringToMsgString(sFailureMsg, value);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Shininess functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetShininess_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string the_Id_path;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		the_Id_path = data.v.s;

		// Declare the output arguments and call the function.
		std::wstring output = getShininess_wrapper(the_Id_path);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Shininess for ID : ";
		sFailureMsg.append(the_Id_path);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetShininess_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	double value;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.d;

		setShininess_wrapper(idPath, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Shininess for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Transparency functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetTransparency_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1",&data);
		idPath = data.v.s;

		// Declare the output arguments and call the function.
		double output = getTransparency_wrapper(idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_DOUBLE;
		arg.value.v.d = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Transparency for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetTransparency_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	double value;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		value = data.v.d;

		setTransparency_wrapper(idPath, value);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Transparency for ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Public functions.

// Color functions.
void GetModelColor(GeometryFacadeMdl model, std::wstring &color) 
{
	GeometryFacadeSurfaceProperties properties;
	GetSurfaceProperties(model, properties);

	wchar_t buf[GEOMETRY_FACADE_LINE_SIZE];
	swprintf(buf, L"%g, %g, %g", properties.color_rgb[0], properties.color_rgb[1], properties.color_rgb[2]);

	color = buf;
}


// Misc. functions.
void GetSurfaceProperties(GeometryFacadeMdl &model, GeometryFacadeSurfaceProperties &properties) 
{
	ProModelitem mdlItem;
	ProMdlToModelitem(model, &mdlItem);
	GeometryFacadeGetSurfaceProperties( &mdlItem, &properties );
}


void GetSurfaceProperties(std::string the_Id_path, GeometryFacadeSurfaceProperties &properties) 
{	
	GeometryFacadeMdl model;
	GetAsmcompMdl(the_Id_path, &model);
	
	GetSurfaceProperties(model, properties);
}


void SetSurfaceProperties(GeometryFacadeMdl &model, GeometryFacadeSurfaceProperties *properties) 
{
	ProModelitem mdlItem;
	ProMdlToModelitem(model, &mdlItem);
	GeometryFacadeSetSurfaceProperties( &mdlItem, properties );
}


void GetSurfacePropertiesXML(GeometryFacadeMdl &model, std::string &xml) 
{
	GeometryFacadeSurfaceProperties properties;
	char value[1000];
	int len = 0;

	GetSurfaceProperties(model, properties);

	len = sprintf(value, "\t\t\t<SURF name=\"AmbientLight\">%g</SURF>\n", properties.ambient);
	xml += value;

	len = sprintf(value, "\t\t\t<SURF name=\"Color\">%g, %g, %g</SURF>\n", properties.color_rgb[0], properties.color_rgb[1], properties.color_rgb[2]);
	xml += value;

	len = sprintf(value, "\t\t\t<SURF name=\"Shininess\">%g</SURF>\n", properties.shininess);
	xml += value;

	len = sprintf(value, "\t\t\t<SURF name=\"Transparency\">%g</SURF>\n", properties.transparency);
	xml += value;
}


// Private functions.

// Ambient Light functions.
static std::wstring getAmbientLight_wrapper(std::string the_Id_path)
{
	GeometryFacadeSurfaceProperties properties;
	wchar_t buf[GEOMETRY_FACADE_LINE_SIZE];
	
	GetSurfaceProperties(the_Id_path, properties);

	swprintf(buf, L"%g", properties.ambient);

	result_wstring = buf;

	return (wchar_t*)result_wstring.c_str();
}


static void setAmbientLight_wrapper(std::string the_Id_path, double ambientLight) 
{
	try
	{
		GeometryFacadeMdl model;
		GeometryFacadeSurfaceProperties properties; 

		GeometryFacadeAsmCompPath path;
		GetAsmcompPath(the_Id_path, &path);

		GeometryFacadeGetCurrentMdl(&model);

		int id = path.comp_id_table[path.table_num-1];

		GeometryFacadeAsmItem asmItem;
		GeometryFacadeAsmcompAsmitemInit(model, id, PRO_PART, L"", &path, &asmItem);

		// Get Appearance of Component. 
		GeometryFacadeGetMdlVisibleAppearanceprops(&asmItem, &properties);

		// Set the desired ambient light.
		properties.ambient = ambientLight;

		UpdateModelAppearance(asmItem, path, id, model, properties);
	}
	catch (ProeException ex)
	{
		throw ProeException(__FILE__, __LINE__,  ex.GetResult());
	}
}


// Color functions.

static std::wstring getColor_wrapper(std::string the_Id_path)
{
	GeometryFacadeSurfaceProperties props;
	double r, g, b;
	wchar_t *buf;
	buf = (wchar_t*)malloc(sizeof(char) * 100);

	GetSurfaceProperties(the_Id_path, props);

	r = props.color_rgb[0];
	g = props.color_rgb[1];
	b = props.color_rgb[2];
	swprintf(buf, L"%f, %f, %f", r, g, b);

	result_wstring = buf;
	free(buf);

	return (wchar_t*)result_wstring.c_str();
}


// SetColor_impl
//
// Args:	the_Id_path = Asmcomp path string "10,9,9"
//			the_color = RGB values in a comma delimited list "1.0,0.0,0.0"
//						or
//						a Hexidecimal color code "0xFF0000"
static void setColor_wrapper(std::string the_Id_path, std::wstring the_color) 
{
	try
	{
		GeometryFacadeColorMap color_map;
		createGeometryFacadeColorMap(the_color, &color_map);

		GeometryFacadeMdl model;
		GeometryFacadeSurfaceProperties properties; 

		GeometryFacadeAsmCompPath path;
		GetAsmcompPath(the_Id_path, &path);

		GeometryFacadeGetCurrentMdl(&model);

		int id = path.comp_id_table[path.table_num-1];

		GeometryFacadeAsmItem asmItem;
		GeometryFacadeAsmcompAsmitemInit(model, id, PRO_PART, L"", &path, &asmItem);

		// Get Appearance of Component. 
		GeometryFacadeGetMdlVisibleAppearanceprops(&asmItem, &properties);

		// Set the desired color.
		properties.color_rgb[0] = color_map.red;
		properties.color_rgb[1] = color_map.green;
		properties.color_rgb[2] = color_map.blue;

		UpdateModelAppearance(asmItem, path, id, model, properties);
	}
	catch (ProeException ex)
	{
		throw ProeException(__FILE__, __LINE__, ex.GetResult());
	}
}

// Updates the model Appearance.
static void UpdateModelAppearance(GeometryFacadeAsmItem &asmItem, GeometryFacadeAsmCompPath path, int id, GeometryFacadeMdl model, GeometryFacadeSurfaceProperties &properties)
{
	ProError result = PRO_TK_NO_ERROR;
	try
	{
		// Set the new properties.
		ProError result = ProMdlVisibleAppearancepropsSet(&asmItem, &properties);
		if(result != PRO_TK_NO_ERROR)
		{
			// If it fails, try passing type as Assembly.
			// There are no API to get model type from assembly comp path.
			GeometryFacadeAsmcompAsmitemInit(model, id, PRO_ASSEMBLY, L"", &path, &asmItem);

			// Set the new properties.
			result = ProMdlVisibleAppearancepropsSet(&asmItem, &properties);
			if(result != PRO_TK_NO_ERROR)
			{
				throw ProeException(__FILE__, __LINE__, result);
			}
		}

		ProWindowRepaint(PRO_VALUE_UNUSED);
	}
	catch (ProeException ex)
	{
		throw ProeException(__FILE__, __LINE__,  ex.GetResult());
	}
}


// Shininess functions.
static std::wstring getShininess_wrapper(std::string the_Id_path)
{
	GeometryFacadeSurfaceProperties properties;
	wchar_t buf[GEOMETRY_FACADE_LINE_SIZE];
	
	GetSurfaceProperties(the_Id_path, properties);

	swprintf(buf, L"%g", properties.shininess);

	result_wstring = buf;

	return (wchar_t*)result_wstring.c_str();
}


static void setShininess_wrapper(std::string the_Id_path, double shininess) 
{
	try
	{
		GeometryFacadeMdl model;
		GeometryFacadeSurfaceProperties properties; 

		GeometryFacadeAsmCompPath path;
		GetAsmcompPath(the_Id_path, &path);

		GeometryFacadeGetCurrentMdl(&model);

		int id = path.comp_id_table[path.table_num-1];

		GeometryFacadeAsmItem asmItem;
		GeometryFacadeAsmcompAsmitemInit(model, id, PRO_PART, L"", &path, &asmItem);

		// Get Appearance of Component. 
		GeometryFacadeGetMdlVisibleAppearanceprops(&asmItem, &properties);

		// Set the desired shininess.
		properties.shininess = shininess;

		UpdateModelAppearance(asmItem, path, id, model, properties);
	}
	catch (ProeException ex)
	{
		throw ProeException(__FILE__, __LINE__,  ex.GetResult());
	}
}


static void createGeometryFacadeColorMap(std::wstring the_color_string, GeometryFacadeColorMap *the_colormap) 
{
	double r, g, b;
	int hex_color;

	r = g = b = -1;

	// Handle a Hexadecimal value in the form 0xFFFFFF to set the color.
	if (the_color_string[0] == L'0' && the_color_string[1] == L'x') 
	{
		// Process the Hexidecimal number.
		hex_color = wcstol(the_color_string.c_str(), NULL, 16);
		r = (double)((hex_color & 0xff0000) >> 16) / 255;
		g = (double)((hex_color & 0x00ff00) >> 8) / 255;
		b = (double)((hex_color & 0x0000ff) >> 0) / 255;
	} 
	else 
	{
		// Process the R, G, B values from a comma delimited string
		
		wchar_t* red = wcstok(const_cast<wchar_t*>(the_color_string.c_str()), L",");
		wchar_t* grn = wcstok(NULL, L",");
		wchar_t* blu = wcstok(NULL, L",");
		if(red != NULL && grn != NULL && blu != NULL) 
		{
			r = _wtof(red);
			g = _wtof(grn);
			b = _wtof(blu);
		}
	}
	
	if ( BETWEEN(0.0, r, 1.0) && BETWEEN(0.0, g, 1.0) && BETWEEN(0.0, b, 1.0) ) 
	{
		the_colormap->red = r;
		the_colormap->green = g;
		the_colormap->blue = b;
	} 
	else 
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
	}
}


// Transparency functions.
static double getTransparency_wrapper(std::string the_Id_path) 
{
	GeometryFacadeSurfaceProperties props; 

	GetSurfaceProperties(the_Id_path, props);

	return props.transparency;
}


static void setTransparency_wrapper(std::string the_Id_path, double the_value) 
{
	try
	{
		GeometryFacadeMdl model;
		GeometryFacadeSurfaceProperties properties; 

		GeometryFacadeAsmCompPath path;
		GetAsmcompPath(the_Id_path, &path);

		GeometryFacadeGetCurrentMdl(&model);

		int id = path.comp_id_table[path.table_num-1];

		GeometryFacadeAsmItem asmItem;
		GeometryFacadeAsmcompAsmitemInit(model, id, PRO_PART, L"", &path, &asmItem);

		// Get Appearance of Component. 
		GeometryFacadeGetMdlVisibleAppearanceprops(&asmItem, &properties);

		// Set the desired transparency.
		properties.transparency = the_value;

		UpdateModelAppearance(asmItem, path, id, model, properties);
	}
	catch (ProeException ex)
	{
		throw ProeException(__FILE__, __LINE__,  ex.GetResult());
	}
}
