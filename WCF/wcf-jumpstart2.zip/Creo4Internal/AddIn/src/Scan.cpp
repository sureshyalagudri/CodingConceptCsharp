// C/C++ header files.
#include <string>
#include <hash_set>
#include <map>
#include <sstream>
#include <fstream>




// Application header files.
#include "Layers.h"
#include "MassProperties.h"
#include "ProcessXML.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "SurfaceProperties.h"
#include "Units.h"
#include "Utility.h"
#include "Scan.h"
#include "Drawings.h"
#include "Log.h"
#include "Models.h"


//Variable to hold part name with UDF which is to be scanned
std::wstring cUDFPart = L"";
wchar_t *cUDFToScan = NULL;
wchar_t *cUDFPath = NULL;

// Exported functions
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring fileName;
	std::wstring file;
	FILE * xmlFile=NULL;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		fileName = data.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		file = data.v.w;

		xmlFile = _wfopen(file.c_str(), L"w");
		LOG << "ScanDrawing_task:Started writing xml file: "<<file.c_str() << endl;

		ProCharLine name;
		GeometryFacadeWideStringToString(name, fileName.c_str());

		//call the scan function.
		scanDrawing_wrapper(name, xmlFile);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataWstring( &arg.value, file.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );

		//Close file
		fclose(xmlFile);
		LOG << "ScanDrawing_task:Finished writing xml file: "<<file.c_str() << endl;
	}
	catch (ProeException ex)
	{
		//Logging exception locally so that input arguments can also be captured.
		LOG << "ERROR:	in Scan Drawing INPUTS: modelHandle-" << fileName <<endl;		
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;
		//Close file
		if (xmlFile != NULL)
		{
			fclose(xmlFile);
		}

		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring fileName;
	std::wstring file;
	FILE * xmlFile=NULL;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		fileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		file = data.v.w;

		ProCharLine name;
		GeometryFacadeWideStringToString(name, fileName.c_str());

		xmlFile = _wfopen(file.c_str(), L"w");
		LOG << "ScanModel_task:Started writing xml file: "<<file.c_str() << endl;

		//call the scan function.
		scanModel_wrapper(name, xmlFile);
		LOG << "scanModel_wrapper returned successfully" << endl;
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		LOG << "Array size allocation completed" << endl;
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataWstring( &arg.value, file.c_str());
		LOG << "GeometryFacadeSetValueDataString completed" << endl;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
		LOG << "Output label assignment completed" << endl;

		//Close file
		fclose(xmlFile);
		LOG << "ScanModel_task:Finished writing xml file: "<<file.c_str() << endl;
	}
	catch (ProeException ex)
	{
		LOG << "ERROR:	in Scan Model INPUTS: modelHandle-" << fileName <<endl;		
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;

		//Close file
		if(xmlFile!=NULL)
		{
			fclose(xmlFile);
		}
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	LOG << "Returning result as " << result << endl;
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanUDF_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring file;
	FILE * xmlFile=NULL;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cUDFPath = data.v.w;		

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		cUDFPart = data.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		file = data.v.w;

		xmlFile = _wfopen(file.c_str(), L"w");
		LOG << "ScanUDF_task:Started Writing xml file: "<<file.c_str() << endl;

		ProCharPath udfPath;
		GeometryFacadeWideStringToString(udfPath, cUDFPath);

		ProCharPath udfPart;
		GeometryFacadeWideStringToString(udfPart, cUDFPart.c_str());

		result = ScanUDF_wrapper(udfPath,udfPart, xmlFile);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataWstring( &arg.value, file.c_str() );		
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );	

		//Close file
		fclose(xmlFile);
		LOG << "ScanUDF_task:Finished writing xml file: "<<file.c_str() << endl;
	}
	catch(ProeException ex)
	{
		LOG << "ERROR:	in Scan UDF INPUTS: UDFPath-" << cUDFPath <<endl;		
		LOG << "FILE:	" << ex.GetFile() << endl;
		LOG << "LINE:	" << ex.GetLine() << endl;
		LOG << "RESULT:	" << ex.GetResult() << endl;
		LOG << "MESSAGE:" << ex.GetMsg() << endl;

		//Close file
		if (xmlFile != NULL)
		{
			fclose(xmlFile);
		}

		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CheckPartsReferencedInDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		wstring fileName = data.v.w;

		ProCharLine name;
		GeometryFacadeWideStringToString(name, fileName.c_str());

		string sDrwSolids = CheckPartsReferencedInDrawing_wrapper(name);

		wchar_t mdlList[4096];
		GeometryFacadeStringToWideString(mdlList, sDrwSolids.c_str());

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataWstring( &arg.value, mdlList);		
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex){}
	return PRO_TK_NO_ERROR;	
}
// Public functions.

GeometryFacadeError ScanUDF_wrapper(char *cUDFPath,const char *cUDFPart, FILE * xmlFile)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeType pPartType = PRO_PART;
	GeometryFacadeSolid pPartHandle = NULL;
	GeometryFacadePath pUDFPath;
	GeometryFacadeUdfdata pUDFData;
	std::string sScanData;

	GeometryFacadeStringToWideString(pUDFPath,cUDFPath);
	GeometryFacadeUdfdataAlloc(&pUDFData);
	GeometryFacadeUdfdataPathSet(pUDFData,pUDFPath);
	
	sScanData = "<rsProE>\n";
	GetUDFXMLTag(cUDFPath,sScanData);	
	GetUDFDimensionXML(pUDFData,sScanData);
	
	//Write to file and clear memory
	fputs(sScanData.c_str(), xmlFile);
	sScanData.clear();

	//GetUDFExternalSymbols(pUDFData,sScanData);
	GetUDFReferenceXML(pUDFData,sScanData);

	//Write to file and clear memory
	fputs(sScanData.c_str(), xmlFile);
	sScanData.clear();

	if(strlen(cUDFPart)!= 0)
	{
		GetUDFFeaturesXML(pUDFData,cUDFPart, xmlFile);
	}
	sScanData += "\t</GPH>\n";
	sScanData += "</rsProE>\n";

	//Write to file and clear memory
	fputs(sScanData.c_str(), xmlFile);
	sScanData.clear();

	return result;
}
static std::string scanDrawing_wrapper(string fileName, FILE * xmlFile)
{
	std::string tmp_sum;
	GeometryFacadeName name;
	char c_name[GEOMETRY_FACADE_LINE_SIZE];
	std::stringstream stmp;
	map<int ,std::string> mViewStr;	
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	//D-05313 removed reinterpret_cast and used Model init
	//Init drawing Handler
	GeometryFacadeStringToWideString(name, fileName.c_str());
	GeometryFacadeDrawing drawing;
	GeometryFacadeMdlInit(name, PRO_MDLFILE_DRAWING, (ProMdl*)&drawing);


	GeometryFacadeGetMdlName( (GeometryFacadeMdl)drawing, name );
	GeometryFacadeWideStringToString(c_name, name);

	//double scale = GeometryFacadeGetDrawingScale(drawing, NULL, -1);	// -1 -> current sheet
	//stmp << scale;

	std::string output = "<rsProE>\n";

	// Get the file information ...
    GeometryFacadeMdlData data;
    GeometryFacadeGetMdlData((GeometryFacadeMdl)drawing, &data);

    std::string pathname,device;
    char dummy[GEOMETRY_FACADE_PATH_SIZE];

    pathname = GeometryFacadeWideStringToString(dummy, data.path);
    device = GeometryFacadeWideStringToString(dummy, data.device);

	output += "\t<DRW name= \"" + std::string(c_name) + "\"" + " type = \"" + "DRW" + "\"" + " path = \"" + pathname + "\"" + " device = \"" + device + "\"" + " PTCVersion = \"" + "Creo Parametric 3.0" "\">\n";
	
	bool bIsTempltSldUsed = false;
	std::string sDrwParts = CheckPartsReferencedInDrawing_wrapper(fileName);
	if(strlen(sDrwParts.c_str()) > 0)
	{
		std::vector <std::string> vPartList;
		ProcessNoteText(sDrwParts,",",vPartList);

		//Add Parts Information to the DRW note...
		std::stringstream sout;
		for(int i = 0;i < (int)vPartList.size();i++)
		{
			sout << "\t\t<SLD name=\"" << vPartList[i] << "\" id=\"" << i << "\">" << "</SLD>\n";
		}

		output += sout.str();
	}
	else
	{
		//Scanning of empty templates.
		LOG << "Given drawing file is empty template , assigning solids in new drawing" << endl;
		bIsTempltSldUsed = GetTemplateDrawing(&drawing , data.name);
		LOG << "New Drawing creation completed" << endl;
	}
	
	//Get data of layers having features in it.
	GetLayerPropertiesXML((GeometryFacadeMdl)drawing, output);
	
	//Write to file and clear memory
	fputs(output.c_str(), xmlFile);
	output.clear();

	drawingViews(drawing, mViewStr , bIsTempltSldUsed);

	//output += "<SHEETS>\n";
	int n_sheets = GeometryFacadeCountDrawingSheets(drawing);
	for(int sheet = 1; sheet <= n_sheets; sheet++)
	{
		// Get sheets.
		drawingSheets(drawing, output,sheet);
		//output = output + tmp_sum;

		//Write to file and clear memory
		fputs(output.c_str(), xmlFile);
		output.clear();

		// Get views.
		//drawingViews(drawing, output);
		//output = output + tmp_sum;

		// Get notes.
		detailNoteInfo(drawing, output,sheet);
		//output = output + tmp_sum;

		// Get symdefs.
		//detailSymbolInfo(drawing, output);
		//output = output + tmp_sum;

		// Get layers.
		//GetLayerPropertiesXML(drawing, output);

		int iNoViews = mViewStr.size();
		if (iNoViews > 0)
		{
			std::string sView = "\t\t\t<VIEWS id = \"1\" name= \"VIEWS\" typename = \"VIEW\">";
			output += sView;
			output += mViewStr[sheet];
			std::string sViewEnd = "\n\t\t\t</VIEWS>";
			output += sViewEnd;
		}		
		
		output += "\t\n</SHEET>\n";

		//Write to file and clear memory
		fputs(output.c_str(), xmlFile);
		output.clear();
	}

	// Get parameters.
	try
	{
		GeometryFacadeModelItem drawingitem;
		//GeometryFacadeParameter *p_parameters;
		GeometryFacadeMdlToModelItem(drawing,&drawingitem);
		//drawingParameters(drawing, output);
		std::string XMLstring_ptr; 
		std::string sPara = "\t\t<PARAMETERS id = \"1\" name= \"PARAMETERS\" typename = \"PARAMETERS\">\n";
		GeometryFacadeVisitParameter(&drawingitem, NULL, (GeometryFacadeParameterAction)scanParameterAction, (GeometryFacadeAppData)&XMLstring_ptr);
		//output += XMLstring_ptr;
		std::string sParac = "\t\t</PARAMETERS>\n";

		output += sPara;
		output += XMLstring_ptr;
		output += sParac; 

	}
	catch (ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
		
	}	



//	output += sDimStr;
	


	// Get syminst.
	////tried uncommenting thrown exception so commented again
	////symbol instances not found error needs to be handled
	//detailSymbolInsts(drawing, tmp_sum);
	//output = output + tmp_sum;

	// Get tables.
	// TODO: Commenting out until we decide how to handle drawing symbols.
	// When a drawing has symbols such as +/-, they end up as binary code
	// inside the XML string which causes the XML loader to crash.
	
	////tried uncommenting thrown exception so commented again
	////symbol instances not found error needs to be handled
	//drawingTables(drawing, tmp_sum);
	//output = output + tmp_sum;


	// End of scan.
	output += "\t\n</DRW>\n";
	output += "</rsProE>\n";

	
	//Write to file and clear memory
	fputs(output.c_str(), xmlFile);
	output.clear();

	if(bIsTempltSldUsed)
	{
		ProMdlEraseAll(drawing);
	}

	return output;
}

string CheckPartsReferencedInDrawing_wrapper(string fileName)
{
	string sDrwSolids;
	try
	{
		GeometryFacadeError result;
		GeometryFacadeSolid *pDrwSlds = NULL;
		int iNoSlds = 0;
		GeometryFacadeDrawing drawing;

		//D-05313 removed reinterpret_cast and used Model init
		//Init drawing Handler
		GeometryFacadeName name;
		GeometryFacadeStringToWideString(name, fileName.c_str());
		GeometryFacadeMdlInit(name, PRO_MDLFILE_DRAWING, (ProMdl*)&drawing);

		result = ProDrawingSolidsCollect((GeometryFacadeDrawing)drawing,&pDrwSlds);
		result = ProArraySizeGet((ProArray*)pDrwSlds,&iNoSlds);

		for(int i = 0;i<iNoSlds;i++)
		{
			ProName wDrwSldNm = {};
			char *cDrwSldNm = new char[sizeof(wDrwSldNm)+1];
			result = ProMdlNameGet((GeometryFacadeMdl)pDrwSlds[i],wDrwSldNm);

			ProMdlType pMdlType;
			result = ProMdlTypeGet((GeometryFacadeMdl)pDrwSlds[i],&pMdlType);
			
			char cExtn[5];
			if(pMdlType == PRO_MDL_ASSEMBLY)
				strcpy(cExtn,".asm");
			else if(pMdlType == PRO_MDL_PART)
				strcpy(cExtn,".prt");	
			
			GeometryFacadeWideStringToString(cDrwSldNm,wDrwSldNm);
			strcat(cDrwSldNm,cExtn);

			if(strlen(sDrwSolids.c_str()) == 0)
			{
				sDrwSolids = cDrwSldNm;
			}
			else
			{
				sDrwSolids.append(",").append(cDrwSldNm);
			}		
			delete []cDrwSldNm;
		}
	}
	catch(ProeException){}
	catch(exception){}
	return sDrwSolids;
}
std::string scanModel_wrapper(string fileName, FILE * xmlFile)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	//D-05313 removed reinterpret_cast and used Model init
	ProMdlfileType  type;
	std::size_t found = fileName.find(".prt");
	if (found!=std::string::npos)
	{
		type = PRO_MDLFILE_PART;
	}
	else
	{
		type = PRO_MDLFILE_ASSEMBLY;
	}

	GeometryFacadeName name;
	GeometryFacadeStringToWideString(name, fileName.c_str());
	
	//Init Model Handler
	GeometryFacadeMdl model;
	GeometryFacadeMdlInit(name, type, &model);

	GeometryFacadeGetMdlName(model, name);
    

	GeometryFacadeSolid solid = (GeometryFacadeSolid)(model);

	GeometryFacadeModelItem modelItem;
	GeometryFacadeMdlToModelItem(model, &modelItem); 

	std::string XMLstring = "<rsProE>\n";
	std::string tag = XMLModelTagGet(model, XMLstring);
	
	// Append the XML string for the units.
	GetUnitSystemXML(&model, XMLstring);
	LOG << "Unit scan finished" << endl;

	// Append the XML string for the mass properties.
	GetMassPropertiesXML(&model, XMLstring);
	LOG << "Mass properties scan finished" << endl;

	// Append the XML string for the surface properties.
	GetSurfacePropertiesXML(model, XMLstring);
	LOG << "Surface properties scan finished" << endl;
	
	//Write to file and clear memory
	fputs(XMLstring.c_str(), xmlFile);
	XMLstring.clear();

	// Append the XML string for the layers.
	if (tag == "ASM")
	GetLayerPropertiesXML(model, XMLstring);
	LOG << "Layer properties scan finished" << endl;

	//Append the XML string for UDF's
	LOG << "Entering UDF scan " << endl;
	GetUDFPropertiesXML(model, XMLstring);
	LOG << "Leaving UDF scan " << endl;
	
	result = ProSolidFamtableCheck((GeometryFacadeSolid)model);
	if(result == GEOMETRY_FACADE_NO_ERROR || result == GEOMETRY_FACADE_EMPTY)
	GetFamilyTableData(model,XMLstring);

	//Write to file and clear memory
	fputs(XMLstring.c_str(), xmlFile);
	XMLstring.clear();

	LOG << "Finished collecting family table data" << endl;

	std::string sPara = "\t\t<PARAMETERS id = \"1\" name= \"PARAMETERS\" typename = \"PARAMETERS\">\n";
	XMLstring += sPara;
	GeometryFacadeVisitParameter(&modelItem, NULL, (GeometryFacadeParameterAction)scanParameterAction, (GeometryFacadeAppData)&XMLstring);
	std::string sParac = "\t\t</PARAMETERS>\n";
	XMLstring += sParac;
	LOG << "Parameter scan finished " << endl;
	// Visit all the root part dimensions & append the appropriate XML strings.

	//Write to file and clear memory
	fputs(XMLstring.c_str(), xmlFile);
	XMLstring.clear();

	// Collect solid id's first to compare dimensions later in this solid before visiting features.
	all_solid_dims_t all_dims;
	all_dims.XMLstring_ptr = &XMLstring;
	all_dims.xmlFile  = xmlFile;

	GeometryFacadeVisitSolidDimension( (GeometryFacadeSolid)model, GEOMETRY_FACADE_B_FALSE, (GeometryFacadeDimensionVisitAction)userCollectAllDimensionsAction, NULL, (GeometryFacadeAppData)&all_dims.dim );
	LOG << "Solid dimension visit finished " << endl;

	try
	{
		GeometryFacadeVisitSolidFeature(solid, (GeometryFacadeFeatureVisitAction)scanFeatVisitAction, NULL, (GeometryFacadeAppData)&all_dims);
	}
	catch (ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
	}
	
	LOG << "Solid feature visit finished " << endl;
	// Close the XML tag.
	XMLstring += "\t</"+ tag + ">" + "\n";
	XMLstring += "</rsProE>\n";
	
	//Write to file and clear memory
	fputs(XMLstring.c_str(), xmlFile);
	XMLstring.clear();
	
	//Free memory
	all_dims.compoScanned.clear();
	all_dims.dim.clear();
	all_dims.XMLstring_ptr->clear();


	LOG << "Scan model string compiled succesfully,now returning" << endl;
	return XMLstring;
}


// Private functions.

void GetUDFXMLTag(char *cUDFPath,std::string &sScanData)
{
	std::string sUDFPath = cUDFPath;
	std::ostringstream sTag;

	int pos1 = sUDFPath.find_last_of("\\");
	int pos2 = sUDFPath.find_last_of(".");
	std::string sVersion = sUDFPath.substr(pos2 + 1);
	std::string sFileTemp = sUDFPath.substr(pos1 + 1,((pos2-pos1) - 1));
	std::string sFileName = sFileTemp.substr(0,sFileTemp.find_last_of("."));
	std::string sFilePath = sUDFPath.substr(0,pos1);
	sTag << "\t<GPH id = \""<<sFileName<< "\" name= \""<<sFileName<< "\" type = \""<<"GPH"<<"\" file = \""<<sFileName<< "\" version = \""<<sVersion << "\" path = \""<<sFilePath << "\" PTCVersion = \""<<"Creo Parametric 3.0"<<"\">"<<"\n";
	sScanData += sTag.str();	
}

void GetUDFDimensionXML(GeometryFacadeUdfdata pUDFData,std::string &sScanData)
{
	GeometryFacadeUdfvardim *pVarDim = NULL;
	GeometryFacadeName pDimName;
	GeometryFacadeLine pDimPrompt;
	GeometryFacadeUdfVardimType pDimType;
	double dDimVal;
	char cTemp[200];
	GeometryFacadeCharName cDimName,cDimType,cDimPrompt;
	int iNoDim = 0;

	GeometryFacadeUdfdataVardimsGet(pUDFData,&pVarDim);
	
	if(pVarDim != NULL)
	iNoDim = GeometryFacadeGetArraySize((GeometryFacadeArray)pVarDim);
	
	sScanData += "\t\t<UVDIMS id = \"1\" name= \"UDFVARIABLE_DIMS\" typename = \"VariableDims\">\n";
		
	for (int i = 0;i<iNoDim;i++)
	{
		GeometryFacadeUdfvardimNameGet(pVarDim[i],pDimName);
		GeometryFacadeUdfvardimPromptGet(pVarDim[i],pDimPrompt);
		GeometryFacadeUdfvardimDefaultvalueGet(pVarDim[i],&pDimType,&dDimVal);

		switch (pDimType)
		{
		case PROUDFVARTYPE_DIM:
			strcpy(cDimType,"Dimension");
			break;
		case PROUDFVARTYPE_IPAR:
			strcpy(cDimType,"Parameter");
			break;
		default:
			break;
		}

		GeometryFacadeWideStringToString(cDimName, pDimName);
		GeometryFacadeWideStringToString(cDimPrompt, pDimPrompt);
		sprintf(cTemp, "\t\t\t<UVDIM id=\"%s\" name=\"%s\" type=\"%s\" dimname=\"%s\">%f</UVDIM>\n",cDimName, cDimPrompt, cDimType,cDimName,dDimVal);
		sScanData += cTemp;
	}
	if(pVarDim != NULL)
	GeometryFacadeUdfvardimProarrayFree(pVarDim);

	sScanData += "\t\t</UVDIMS>\n";

}
void GetUDFExternalSymbols(GeometryFacadeUdfdata pUDFData,std::string &sScanData)
{
	GeometryFacadeUdfextsymbol *pExtSymbl;
	GeometryFacadeUdfdataExternalsymbolsGet(pUDFData,&pExtSymbl);
	int iNo = GeometryFacadeGetArraySize((GeometryFacadeArray)pExtSymbl);
	for (int i = 0;i<iNo;i++)
	{

	}
}

void GetUDFFeaturesXML(GeometryFacadeUdfdata pUDFData,const char *cUDFPart, FILE * xmlFile)
{
	std::string sScanData;
	sScanData += "\t\t<UFETS id = \"1\" name= \"UDF_FEATURES\" typename = \"VariableDims\">\n";
	
	all_solid_dims_t allDims;
	allDims.XMLstring_ptr = &sScanData;
	allDims.xmlFile  = xmlFile;

	GeometryFacadeMdl pUDFPart = NULL;
	pUDFPart = LoadModel_wrapper(cUDFPart);
	if (pUDFPart != NULL)
	{
		try
		{
			GeometryFacadeVisitSolidFeature(GeometryFacadeSolid(pUDFPart), (GeometryFacadeFeatureVisitAction)scanFeatVisitAction, (GeometryFacadeFeatureFilterAction)scanUDFFeatFilterAction, (GeometryFacadeAppData)&allDims);
		}
		catch (ProeException ex)
		{
			if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
			{
				throw;
			}
		}

	}	

	sScanData += "\t\t</UFETS>\n";

	//Write to file and clear memory
	fputs(sScanData.c_str(), xmlFile);
	sScanData.clear();

	//Free memory
	allDims.compoScanned.clear();
	allDims.dim.clear();
	allDims.XMLstring_ptr->clear();
}
void GetUDFReferenceXML(GeometryFacadeUdfdata pUDFData,std::string &sScanData)
{
	GeometryFacadeUdfRequiredRef *pReqdRef;
	wchar_t pPrompt[1000];
	GeometryFacadeType pType;
	GeometryFacadeBoolean bIsAnnotationRef;
	std::ostringstream sRefStr;
	char cRefPrompt[1000];
	//std::string sRefType;

	GeometryFacadeUdfdataRequiredreferencesGet(pUDFData,&pReqdRef);
	int iNoRef = GeometryFacadeGetArraySize((GeometryFacadeArray)pReqdRef);

	for ( int i = 0;i<iNoRef;i++)
	{
		GeometryFacadeUdfrequiredrefPromptGet(pReqdRef[i],pPrompt);
		GeometryFacadeUdfrequiredrefTypeGet(pReqdRef[i],&pType);
		GeometryFacadeUdfrequiredrefIsannotationref(pReqdRef[i],&bIsAnnotationRef);
		GeometryFacadeWideStringToString(cRefPrompt, pPrompt);
//		GeometryFacadeWideStringToString(&sRefType[0], pType);
//		std::remove(sRefType.begin(),sRefType.end(),'PRO_');
		sRefStr << "\t<UREF id = \""<<cRefPrompt<< "\" name= \""<<cRefPrompt<< "\" typename = \""<<"UDFREF"<<"\">""</UREF>"<<"\n";
		//sout << "\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Layer"<<"\">"<<sLayerName<<"</NOTE>"<<"\n";
	}
	sScanData += sRefStr.str();
	GeometryFacadeUdfrequiredrefProarrayFree(pReqdRef);
}
void GetUDFPropertiesXML(GeometryFacadeMdl pModel, std::string &output)
{
	GeometryFacadeError result;
	std::string sGrpStr;
	result = ProSolidGroupVisit((ProSolid)pModel,(ProGroupVisitAction)scanGroupVisitAction,NULL,(ProAppData)&sGrpStr); 	
	if ( result == GEOMETRY_FACADE_NO_ERROR)
	{
		output += sGrpStr.c_str();
	}	
	
}

ProError scanGroupVisitAction(ProGroup* pGroup,ProError result,ProAppData data)
{
	ProName pUDFName,pUDFInstance,cGrpName;	
	char cLocalGrp[PRO_COMMENT_SIZE],cname[PRO_COMMENT_SIZE];	
	ProFeature* pFeats = NULL;	
	std::string *sGrp = (std::string*)data;
	std::string sGrpFeatStr;
	char XMLTag[1000];
	int iNoDims,i;

	result = ProUdfNameGet(pGroup,pUDFName,pUDFInstance);
	GeometryFacadeWideStringToString(cLocalGrp, pUDFName);
	result = ProGroupFeaturesCollect(pGroup,&pFeats);
	ProArraySizeGet((ProArray)pFeats,&iNoDims);
	for (i = 0;i<iNoDims;i++)
	{
		GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(&pFeats[i]);
		if (type == PRO_FEAT_GROUP_HEAD)
		{
			GeometryFacadeGetModelItemName((ProModelitem*)&pFeats[i],cGrpName);
			GeometryFacadeWideStringToString(cname, cGrpName);
			strcat(cname,"_UDF");
		}
	}
	if (strcmp(cLocalGrp,"LOCAL_GROUP") != 0)
	{
		sprintf(XMLTag,"\t\t\t<UDF id=\"%d\" typename=\"UDF\" name=\"%s\">\n",pGroup->id,cname);
		LOG << "Group scanned has ID " << pGroup->id << " & group name is " << cname << endl;
		*sGrp = *sGrp + XMLTag;
		ProGroupFeatureVisit(pGroup,(ProFeatureVisitAction)VisitGroupSubFeatures,NULL,(ProAppData)&sGrpFeatStr);
		*sGrp = *sGrp + sGrpFeatStr;
		*sGrp = *sGrp + "\t\t\t</UDF>\n";	
		LOG << "Feature scan finished for group " << cname << endl;
	}
	
	return GEOMETRY_FACADE_NO_ERROR;
}

ProError VisitGroupSubFeatures(ProFeature* pFeature,ProError result,ProAppData app_data)
{
	ProName featName;
	ProGroup pGroup;
	ProDimension* pGrpDims = NULL;
	int iNoDims;
	ProLine pDimName;
	double dDimVal;
	std::string *sFeatData = (std::string*)app_data;
	char XMLTag[1000];
	GeometryFacadeCharName pDimTypeName;
	GeometryFacadeUnitItem pUnit;
	GeometryFacadeCharName pUnitName;
	char dummy[GEOMETRY_FACADE_PATH_SIZE],cname[GEOMETRY_FACADE_LINE_SIZE],ctypename[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeName wtypename;
	GeometryFacadeCharName cDimName;
	ProFeature pTempFeat;
	GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(pFeature);

	GeometryFacadeGetModelItemName((ProModelitem*)pFeature,featName);
	GeometryFacadeWideStringToString(cname, featName);
	GeometryFacadeGetFeatureTypeName((ProModelitem*)pFeature, wtypename);
	GeometryFacadeWideStringToString(ctypename, wtypename);
	sprintf(dummy, "\t\t\t<FEAT id=\"%d\" name=\"%s\" typename=\"%s\">", pFeature->id, cname, ctypename);
	*sFeatData = *sFeatData + dummy;
	LOG << "Group feature found is " << cname << endl;
	result = ProFeatureGroupGet(pFeature,&pGroup);
	result = ProUdfDimensionsCollect(&pGroup,&pGrpDims);
	ProArraySizeGet((ProArray)pGrpDims,&iNoDims);
	for(int i = 0;i<iNoDims;i++)
	{
		result = ProUdfDimensionNameGet(&pGroup,&pGrpDims[i],pDimName);
		LOG << "Status at ProUdfDimensionNameGet" << result << endl;
		result = ProDimensionValueGet(&pGrpDims[i],&dDimVal);
		GeometryFacadeDimensionType pDimTtype = GeometryFacadeGetDimensionType(&pGrpDims[i]);
		switch (pDimTtype) 
		{
		case GEOMETRY_FACADE_DIMTYPE_LINEAR:

			strcpy(pDimTypeName, "linear");
			break;

		case GEOMETRY_FACADE_DIMTYPE_ANGLE:

			strcpy(pDimTypeName, "angular");
			break;

		case GEOMETRY_FACADE_DIMTYPE_DIAMETER:

			strcpy(pDimTypeName, "diameter");
			break;

		case GEOMETRY_FACADE_DIMTYPE_RADIUS:

			strcpy(pDimTypeName, "radius");
			break;

		case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:

			strcpy(pDimTypeName, "UNKNOWN");
			break;

		default:
			strcpy(pDimTypeName, "XXX");
			break;
		}
		// Get unit of the dimension.
		DimensionUnitGet(&pGrpDims[i], &pUnit);
		GeometryFacadeWideStringToString(pUnitName, pUnit.name);
		GeometryFacadeWideStringToString(cDimName, pDimName);		
		result = ProDimensionFeatureGet(&pGrpDims[i],&pTempFeat);
		if ( pFeature->id == pTempFeat.id)
		{
			sprintf(XMLTag, "\n\t\t\t\t<UDIM id=\"%d\" name=\"%s\" type=\"%s\" units=\"%s\">%f</UDIM>",pGrpDims[i].id, cDimName, pDimTypeName, pUnitName, dDimVal);
			*sFeatData = *sFeatData + XMLTag;
			LOG << "Dimension string created while feature was " << cname << " & dimension ID " << pGrpDims[i].id << " having value " << dDimVal << endl;
		}
	}
	
	*sFeatData = *sFeatData + "\n\t\t\t</FEAT>\n";
	return GEOMETRY_FACADE_NO_ERROR;
}

static void drawingParameters(GeometryFacadeDrawing drawing, std::string &output)
{
	std::ostringstream sout;
	GeometryFacadeModelItem drawingitem;
	GeometryFacadeParameter *p_parameters;
	std::map<std::string, std::string> pmap;

    GeometryFacadeCharName name;
	GeometryFacadeMdlToModelItem(drawing,&drawingitem);

	// Collect all parameters first.
	try
	{
		CollectParameters(&drawingitem, &p_parameters);
	}
	catch (ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
	}

	int n_params = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_parameters );
	for(int i = 0; i < n_params; i++)
	{
		GeometryFacadeParameterValue value;
		GeometryFacadeGetParameterValue(&p_parameters[i], &value);
		std::ostringstream stream_value;
		switch( value.type )
		{
			case GEOMETRY_FACADE_PARAM_DOUBLE:
			
				stream_value << value.value.d_val;
				break;

			case GEOMETRY_FACADE_PARAM_STRING:

				char sval[GEOMETRY_FACADE_LINE_SIZE];
				GeometryFacadeWideStringToString(sval, value.value.s_val);
				stream_value << sval;			
				break;

			case GEOMETRY_FACADE_PARAM_INTEGER:
		
				stream_value << value.value.i_val;
				break;

			case GEOMETRY_FACADE_PARAM_BOOLEAN:
			
				stream_value << value.value.l_val;
				break;

			default:

				break;
		}

		char XMLTag[1000];
		GeometryFacadeWideStringToString(name, (&p_parameters[i])->id);
		sprintf(XMLTag, "\t<PARAM name=\"%s\" type=\"%d\">%s</PARAM>\n", name, value.type, stream_value.str().c_str());
		output = output + XMLTag;
	}

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_parameters );
}


static int drawingSheets(GeometryFacadeDrawing drawing, std::string &output,int sheet)
{
    //int sheet;
    GeometryFacadeName wformat;
    GeometryFacadeCharName format;
    GeometryFacadeDrawingSheetInfo info;
    char *unit;
	std::stringstream sout;
	

	//sout << "<SHEETS>\n";
	//int n_sheets = GeometryFacadeCountDrawingSheets(drawing);
	//for(sheet = 1; sheet <= n_sheets; sheet++)
	//{
		double scale = GeometryFacadeGetDrawingScale(drawing, NULL, sheet);

		info = GeometryFacadeGetDrawingSheetInfo(drawing, sheet);

		try
		{
			GeometryFacadeGetDrawingFormat(drawing, sheet, wformat);
		}
		catch (ProeException ex)
		{
			strcpy(format, "(NONE)");	
		}

		GeometryFacadeWideStringToString(format, wformat);

		switch (info.units)
		{
			case GEOMETRY_FACADE_UNIT_INCH: 
				
				unit = "inches";
				break;

			case GEOMETRY_FACADE_UNIT_FOOT:

				unit = "feet";
				break;

			case GEOMETRY_FACADE_UNIT_MM: 
				
				unit = "mm";
				break;

			case GEOMETRY_FACADE_UNIT_CM: 
				
				unit = "cm";
				break;

			case GEOMETRY_FACADE_UNIT_M: 
				
				unit = "M";
				break;

			case GEOMETRY_FACADE_UNIT_MCM: 
				
				unit = "mcm";
				break;

			default: 
				
				unit = "**unknown";
		}

		/*itoa(sheet,buffer,10);
		
		strcat(sheetName,buffer);*/
		ProName wSheetName;
		char sSheetName[100];
		ProDrawingSheetNameGet(drawing,sheet,wSheetName);
		GeometryFacadeWideStringToString(sSheetName, wSheetName);
		
		sout << "\t\t<SHEET name = \""<<sSheetName<<"\" id= \""<<sheet<<"\" scale= \""<<scale<<"\" Width=\"" << info.width << "\" Height=\"" << info.height << "\" unit = \"" << unit <<"\" Format=\"" << format << "\">" << "  " << "\n";
	

	output = output+sout.str();

	return 0;
}


static GeometryFacadeError userCollectAllDimensionsAction(GeometryFacadeDimension *dimension, GeometryFacadeError status, GeometryFacadeAppData data) 
{
	stdext::hash_set<int> * p_dim = (stdext::hash_set<int>*)data;

	p_dim->insert(dimension->id);

	return GEOMETRY_FACADE_NO_ERROR;
}
							

// GeometryFacadeDimension *the_dimension (In) The dimension being visited. 
// GeometryFacadeError status (In) Error status from the filter function.
// GeometryFacadeAppData data (In) Caller supplied data.
static GeometryFacadeError scanDimensionVisitAction(GeometryFacadeDimension *the_dimension, GeometryFacadeError status, GeometryFacadeAppData data) 
{
	GeometryFacadeName symbol;
    GeometryFacadeCharName dimension_name;
    GeometryFacadeName oname;
    GeometryFacadeCharName owner_name;
    int window_id = 0;
    GeometryFacadeAsmCompPath path;
    GeometryFacadeMdl owner = the_dimension->owner;
	int dim_id = the_dimension->id;
	GeometryFacadeType dimension_type = the_dimension->type;
	GeometryFacadeUnitItem unit;
	GeometryFacadeCharName unit_name;
	GeometryFacadeCharName dim_typename;

	std::string *XMLstring_ptr = (std::string*)data; 

	GeometryFacadeGetMdlName(owner, oname);
	GeometryFacadeWideStringToString(owner_name, oname);
	int owner_id = GeometryFacadeGetMdlId(owner);

	GeometryFacadeInitAsmCompPath( (GeometryFacadeSolid)owner, NULL, 0, &path );

	GeometryFacadeGetDimensionSymbol(the_dimension, symbol);
	double value = GeometryFacadeGetDimensionValue(the_dimension);
	GeometryFacadeWideStringToString(dimension_name, symbol);

	// Get the type of the dimension.
	GeometryFacadeDimensionType dim_type = GeometryFacadeGetDimensionType(the_dimension);

   	switch (dim_type) 
	{
		case GEOMETRY_FACADE_DIMTYPE_LINEAR:

			strcpy(dim_typename, "linear");
			break;

		case GEOMETRY_FACADE_DIMTYPE_ANGLE:

			strcpy(dim_typename, "angular");
			break;

		case GEOMETRY_FACADE_DIMTYPE_DIAMETER:

			strcpy(dim_typename, "diameter");
			break;

		case GEOMETRY_FACADE_DIMTYPE_RADIUS:

			strcpy(dim_typename, "radius");
			break;

		case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:

			strcpy(dim_typename, "UNKNOWN");
			break;

		default:

			strcpy(dim_typename, "XXX");
			break;
	}

	// Get unit of the dimension.
	DimensionUnitGet(the_dimension, &unit);
	GeometryFacadeWideStringToString(unit_name, unit.name);

	char XMLTag[1000];
	sprintf(XMLTag, "<DIM id=\"%d\" name=\"%s\" type=\"%s\" units=\"%s\">%f</DIM>\n", 
					dim_id, dimension_name, dim_typename, unit_name, value);
	*XMLstring_ptr = *XMLstring_ptr + XMLTag;

	return GEOMETRY_FACADE_NO_ERROR;
}

static GeometryFacadeError scanUDFFeatFilterAction(GeometryFacadeFeature *feature,GeometryFacadeAppData appData)
{
	GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(feature);

	if(type != PRO_FEAT_GROUP_HEAD)
	return GEOMETRY_FACADE_CONTINUE;
	return GEOMETRY_FACADE_NO_ERROR;
}
//Feature status for each component is checked ,if component is suppressed 
//then resume it ,scan all the information & the restore back to its original state.
//Feat status is passed to XMLFeatureTagGet(). 
static GeometryFacadeError scanFeatVisitAction(GeometryFacadeFeature *theFeature_ptr, GeometryFacadeError status, GeometryFacadeAppData app_data) 
{
	// Either a feature is a component or a regular feature.
	all_solid_dims_t *p_all_dims = (all_solid_dims_t *)app_data;
	std::string *XMLstring_ptr = p_all_dims->XMLstring_ptr;
	GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(theFeature_ptr);
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	
	// Visit the assembly and parts.
	if (GEOMETRY_FACADE_FEAT_COMPONENT == type)
	{
		GeometryFacadeMdl model;
		GeometryFacadeMdlData model_data;
		std::string tag;
		std::string XMLTag;
		std::string sSuppressed = "No";

		try 
		{
			GeometryFacadeFeatureStatus feat_status = GeometryFacadeGetFeatureStatus(theFeature_ptr);

			if (feat_status == GEOMETRY_FACADE_FEAT_SUPPRESSED)
			{
				GeometryFacadeFeatureResumeOptions options = GEOMETRY_FACADE_FEAT_RESUME_INCLUDE_PARENTS;
				int num_opts = 1;
				GeometryFacadeResumeFeature( (GeometryFacadeSolid)theFeature_ptr->owner, &theFeature_ptr->id, 1, &options, num_opts );
				sSuppressed = "Yes";
			}
			GeometryFacadeGetAsmCompMdl(theFeature_ptr,&model);

			tag = XMLFeatureTagGet(theFeature_ptr, sSuppressed, XMLTag);
			*XMLstring_ptr = *XMLstring_ptr + XMLTag;

			GeometryFacadeModelItem model_item_p;
			GeometryFacadeMdlToModelItem(model, &model_item_p);
			GeometryFacadeGetMdlData(model, &model_data);

			//B-05921-TK-14965: If file is scanned once then
			//do not scan it again
			GeometryFacadeName mdlName;
			GeometryFacadeGetMdlName(model, mdlName);

			GeometryFacadeCharPath name;
			GeometryFacadeWideStringToString(name, mdlName);

			if(model_item_p.type==PRO_PART)
			{
				strcat(name,".prt");
			}
			else if(model_item_p.type==PRO_ASSEMBLY)
			{
				strcat(name,".asm");
			}
			
			//Check is already scanned, if yes write close tag to xml file and return 
			if(std::find(p_all_dims->compoScanned.begin(), p_all_dims->compoScanned.end(), name) != p_all_dims->compoScanned.end())
			{
				// Close the XML tag.
				*XMLstring_ptr += "\t\t</"+ tag + ">" + "\n";

				//Write to file and clear
				fputs(XMLstring_ptr->c_str(),p_all_dims->xmlFile);
				XMLstring_ptr->clear();
				p_all_dims->XMLstring_ptr->clear();

				return GEOMETRY_FACADE_NO_ERROR;
			}
			else
			{
				p_all_dims->compoScanned.push_back(name);
			}

			// Append the XML string for the units.
			GetUnitSystemXML(&model, *XMLstring_ptr);

			// Append the XML string for the mass properties.
			GetMassPropertiesXML(&model, *XMLstring_ptr);

			// Append the XML string for the surface properties.
			GetSurfacePropertiesXML(model, *XMLstring_ptr);

			// Append the XML string for the layers.
			//<Milind> We dont need model layers right now as we are 
			//targeted suppress/unsppress by layer for assemblies only.
			if (tag == "ASM")
			GetLayerPropertiesXML(model, *XMLstring_ptr); 
			
			//Append the XML string for UDF
			GetUDFPropertiesXML(model, *XMLstring_ptr);

			//Append Family Table properties.
			result = ProSolidFamtableCheck((GeometryFacadeSolid)model);
			if(result == GEOMETRY_FACADE_NO_ERROR || result == GEOMETRY_FACADE_EMPTY)
			GetFamilyTableData(model,*XMLstring_ptr);

			std::string sPara = "\t\t<PARAMETERS id = \"1\" name= \"PARAMETERS\" typename = \"PARAMETERS\">\n";
			*XMLstring_ptr += sPara;
			GeometryFacadeVisitParameter(&model_item_p, NULL, (GeometryFacadeParameterAction)scanParameterAction, (GeometryFacadeAppData)XMLstring_ptr);
			std::string sParac = "\t\t</PARAMETERS>\n";
			*XMLstring_ptr += sParac;

			// Collect solid ids first to compare later.
			all_solid_dims_t all_dims;   // This is a new container that contains the old string but new set of dim ids.
			all_dims.XMLstring_ptr = XMLstring_ptr;
			all_dims.xmlFile = p_all_dims->xmlFile;

			GeometryFacadeVisitSolidDimension( (GeometryFacadeSolid)model, GEOMETRY_FACADE_B_FALSE, (GeometryFacadeDimensionVisitAction)userCollectAllDimensionsAction, NULL, (GeometryFacadeAppData)&all_dims.dim );

			try
			{
				GeometryFacadeVisitSolidFeature( (GeometryFacadeSolid)model, (GeometryFacadeFeatureVisitAction)scanFeatVisitAction, NULL, (GeometryFacadeAppData)&all_dims);
			}
			catch (ProeException ex)
			{
				if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
				{
					throw;
				}
			}

			// Close the XML tag.
			*XMLstring_ptr += "\t\t</"+ tag + ">" + "\n";
			if (feat_status == GEOMETRY_FACADE_FEAT_SUPPRESSED)
			{
				GeometryFacadeFeatureDeleteOptions supoptions = GEOMETRY_FACADE_FEAT_DELETE_CLIP;
				GeometryFacadeSuppressFeature((GeometryFacadeSolid)theFeature_ptr->owner, &theFeature_ptr->id, 1, &supoptions, 1);
			}

		}
		catch (ProeException ex) 
		{
			LOG << ex.GetResult() << " " << ex.GetLine() << endl;

		}
	}
	else if((type == PRO_FEAT_GROUP_HEAD) && (wcslen(cUDFPart.c_str()) != 0))
	{
		ProFeature *feats = NULL;
		int iNoFeats;
		GeometryFacadeName pUDFName,pInstance;
		ProCharPath uPath;
		GeometryFacadeWideStringToString(uPath, cUDFPath);

		std::string sUDFPart = uPath;
		ProUdfNameGet(theFeature_ptr,pUDFName,pInstance);
		
		string temp = sUDFPart.substr(sUDFPart.find_last_of("\\")+1);
		std::string sUdFNmInPath = temp.substr(0,temp.find_first_of("."));
		
		ProName fileName;
		GeometryFacadeStringToWideString(fileName, sUdFNmInPath.c_str());
		int res =  _wcsicmp(fileName, pUDFName);

		if(res == 0)
		{
			ProGroupFeaturesCollect(theFeature_ptr,&feats);
			ProArraySizeGet(feats,&iNoFeats);

			for(int i = 0;i<iNoFeats;i++)
			{
				char dummy[GEOMETRY_FACADE_PATH_SIZE],cname[GEOMETRY_FACADE_LINE_SIZE],ctypename[GEOMETRY_FACADE_LINE_SIZE];
				GeometryFacadeName wname,wtypename;

				GeometryFacadeGetModelItemName(&feats[i], wname);			

				GeometryFacadeWideStringToString(cname, wname);
				GeometryFacadeGetFeatureTypeName(&feats[i], wtypename);
				GeometryFacadeWideStringToString(ctypename, wtypename);

				sprintf(dummy, "\t\t\t<FEAT id=\"%s\" name=\"%s\" typename=\"UDFFEAT\">", cname, cname);
				*XMLstring_ptr = *XMLstring_ptr + dummy;
				*XMLstring_ptr = *XMLstring_ptr +"\n\t\t\t</FEAT>\n";				
			}
		}
		
	}
	else
	{
		ProGroupStatus pGrpStatus;	
		status = ProFeatureGroupStatusGet(theFeature_ptr,&pGrpStatus);
		LOG << "Got status of " << theFeature_ptr->id << " as " << pGrpStatus << endl; 
		// Visit dimensions.
		char dummy[GEOMETRY_FACADE_PATH_SIZE],
			cname[GEOMETRY_FACADE_LINE_SIZE],
			ctypename[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeName wname,wtypename;

		GeometryFacadeGetModelItemName(theFeature_ptr, wname);			

		GeometryFacadeWideStringToString(cname, wname);
		LOG << "Model item NAME is " << cname << endl;
		GeometryFacadeGetFeatureTypeName(theFeature_ptr, wtypename);
		GeometryFacadeWideStringToString(ctypename, wtypename);
		LOG << "Model item TYPE is " << ctypename << endl;
		if (pGrpStatus == PRO_GROUP_MEMBER)
		{				
			pGrpStatus = CheckIsFeatureGroupMember(theFeature_ptr);	
			LOG << "Group status for feature " << cname << " is " << pGrpStatus << endl;
		}
		if (pGrpStatus != PRO_GROUP_MEMBER)
		{
			LOG << "Final group status is " << pGrpStatus << endl;
			sprintf(dummy, "\t\t\t<FEAT id=\"%d\" name=\"%s\" typename=\"%s\">", theFeature_ptr->id, cname, ctypename);
			LOG << "XML string for feature : " << cname << "  " << dummy << endl;
			*XMLstring_ptr = *XMLstring_ptr + dummy;

			//Write to file and clear memory
			fputs(XMLstring_ptr->c_str(),p_all_dims->xmlFile);
			XMLstring_ptr->clear();
			p_all_dims->XMLstring_ptr->clear();

			LOG << "Going to visit feature dimension " << endl;
			GeometryFacadeVisitFeatureDimension(theFeature_ptr, (GeometryFacadeDimensionVisitAction)userDimensionVisitAction, NULL, (GeometryFacadeAppData)app_data);
			LOG << "Feature dimension visit completed for feature " << cname << endl;
			std::string sTextTag;
			LOG << "Checking sketch text " << endl;
			CheckSketchText(theFeature_ptr,sTextTag);
			LOG << "Checking sketch text completed output is " << sTextTag << endl;
			if (sTextTag.length() != 0)
			{
				*XMLstring_ptr = *XMLstring_ptr + sTextTag;		
			}
			LOG << "Feature string created for feature " << cname << endl;
			*XMLstring_ptr = *XMLstring_ptr +"\n\t\t\t</FEAT>\n"; 
		}
	}

	//Write to file and clear memory
	fputs(XMLstring_ptr->c_str(),p_all_dims->xmlFile);
	XMLstring_ptr->clear();
	p_all_dims->XMLstring_ptr->clear();

	return GEOMETRY_FACADE_NO_ERROR;
}

//This function checks is called as input function group status is PRO_GROUP_MEMBER
//So here Group will be initialized for this feature & name will be checked
//if it is "Local_Group then these feature is not part of UDF library feature.
ProGroupStatus CheckIsFeatureGroupMember(ProFeature* theFeature_ptr)
{
	ProGroup pGroup;
	
	GeometryFacadeError status;
	ProGroupStatus pGrpStatus = PRO_GROUP_MEMBER;
	ProName pUDFName,pUDFInstance;
	char cLocalGrp[PRO_COMMENT_SIZE];
	status = ProFeatureGroupGet(theFeature_ptr,&pGroup);
	ProUdfNameGet(&pGroup,pUDFName,pUDFInstance);
	GeometryFacadeWideStringToString(cLocalGrp, pUDFName);
	
	if (status == PRO_TK_NO_ERROR)
	{
		if (strcmp(cLocalGrp,"LOCAL_GROUP") == 0)
		{
			pGrpStatus = PRO_GROUP_NONE;
		}
		else
		{
			pGrpStatus = PRO_GROUP_MEMBER;
		}
	}

	return pGrpStatus;
}

void CheckSketchText(GeometryFacadeFeature *theFeature_ptr,std::string &sTextTag)
{
	ProError result;
	ProFeatureElemtreeExtractOptions opts =  PRO_FEAT_EXTRACT_NO_OPTS;
	ProElement pElement;
	ProSection pSection;
	ProIntlist pSectIDList;
	Pro2dEntdef* pEntity;
	Pro2dTextdef *pTextStr;
	ProName pSectName;
	int iNoOfSect,iNoOfSectID;
	char cTextStr[PRO_COMMENT_SIZE];
	char sSectName[PRO_LINE_SIZE];
	std::ostringstream sOut;
	LOG << "Entered to check if feature " << theFeature_ptr->id << " has sketch text " << endl;
	result = ProFeatureElemtreeExtract(theFeature_ptr,NULL,opts,&pElement);

	if (result == GEOMETRY_FACADE_NO_ERROR)
	{
		result = ProFeatureNumSectionsGet(theFeature_ptr,&iNoOfSect);

		for (int i = 0;i<iNoOfSect;i++)
		{
			if((result = ProFeatureSectionCopy(theFeature_ptr,i,&pSection)) != GEOMETRY_FACADE_NO_ERROR)
			{
				return;
			}

			result = ProSectionEntityIdsGet(pSection,&pSectIDList,&iNoOfSectID);
			LOG << "Result for EntityIdsGet " << result << " no of ID's " << iNoOfSectID << endl;

			if ( result == GEOMETRY_FACADE_NO_ERROR)
			{
				for (int j = 0; j<iNoOfSectID;j++)
				{
					result = ProSectionEntityGet(pSection,pSectIDList[j],&pEntity);
					LOG << "Result of Entity get for section ID " << j << endl;
					if ( result == GEOMETRY_FACADE_NO_ERROR)
					{
						if (pEntity->type == PRO_2D_TEXT)
						{
							ProSectionNameGet(pSection,pSectName);
							pTextStr = (Pro2dTextdef *)pEntity;
							ProWstringToString (cTextStr, pTextStr->string);
							ProWstringToString (sSectName, pSectName);

							char XMLTag[1000];
							char ID[100];
							_itoa(theFeature_ptr->id,ID,10);
							//strcat(ID,(char *)theFeature_ptr->id);
							strcat(ID,"-");
							char buffer[10];
							_itoa(pSectIDList[j],buffer,10);
							strcat(ID,buffer);
							sprintf(XMLTag, "\n\t\t\t\t<STXT id=\"%s\" name=\"%s\" type=\"SKETCHTEXT\">%s</STXT>",ID, sSectName, cTextStr);				
							LOG << "Sketch text XML created as " << XMLTag << endl;
							sTextTag =  sTextTag + XMLTag;
						}
					}
				}
			}
		}
	}

	LOG << "Exiting sketch text check " << endl;

	return ;
}

static GeometryFacadeError ScanParameterFilter(GeometryFacadeParameter *theParameter, char **XML_ptr) 
{
   GeometryFacadeParameterValue value; 

   GeometryFacadeGetParameterValue(theParameter, &value);

   return GEOMETRY_FACADE_NO_ERROR;
}


static GeometryFacadeError scanParameterAction(GeometryFacadeParameter *theParameter, GeometryFacadeError status, GeometryFacadeAppData data) 
{
    GeometryFacadeCharName name;
    GeometryFacadeWideStringToString(name, theParameter->id);

    GeometryFacadeParameterValue value; 

    GeometryFacadeGetParameterValue(theParameter, &value);
	std::string * XMLstring_ptr = (std::string *) data;
	std::ostringstream stream_value;
	char sval[GEOMETRY_FACADE_LINE_SIZE];
	char XMLTag[1000];
 
	//Get Parameter status D-05144 
	ProError result;
	ProLockstatus lockStatus; 
	ProCharLine paramStatus;
	result = ProParameterLockstatusGet(theParameter, &lockStatus);
	if(result==PRO_TK_NO_ERROR)
	{
		if(lockStatus==PRO_PARAMLOCKSTATUS_UNLOCKED)
		{
			strcpy(paramStatus, "Full");
		}
		else if(lockStatus==PRO_PARAMLOCKSTATUS_LIMITED)
		{
			strcpy(paramStatus, "Limited");
		}
		else if(lockStatus==PRO_PARAMLOCKSTATUS_LOCKED)
		{
			strcpy(paramStatus, "Locked");
		}
	}
	else
	{
		strcpy(paramStatus, "none");
	}

	switch (value.type)
	{
		case GEOMETRY_FACADE_PARAM_DOUBLE:
 			stream_value << value.value.d_val;
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"DOUBLE\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus,stream_value.str().c_str());
            break;

        case GEOMETRY_FACADE_PARAM_STRING:					
			GeometryFacadeWideStringToString(sval, value.value.s_val);						
			stream_value << GetValidStringValue(sval);			
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"STRING\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus, stream_value.str().c_str());
            break;

        case GEOMETRY_FACADE_PARAM_INTEGER:
			stream_value << value.value.i_val;
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"INTEGER\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus,stream_value.str().c_str());
			break;

        case GEOMETRY_FACADE_PARAM_BOOLEAN:			
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"BOOLEAN\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus,( (value.value.l_val == 1) ? "TRUE" : "FALSE" ));
            break;

		case GEOMETRY_FACADE_PARAM_NOTE_ID:			
			stream_value << value.value.i_val;
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"INTEGER\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus,stream_value.str().c_str());
			break;

		case GEOMETRY_FACADE_PARAM_VOID:			
			GeometryFacadeWideStringToString(sval, value.value.s_val);
			stream_value << sval;			
			sprintf(XMLTag,"\t\t\t<PARA id=\"%s\" type=\"STRING\" name=\"%s\" state=\"%s\">%s</PARA>\n",name,name,paramStatus,stream_value.str().c_str()); 
			break;

		default:
			break;
	}

	*XMLstring_ptr = *XMLstring_ptr+ XMLTag;

    return GEOMETRY_FACADE_NO_ERROR;
}


static GeometryFacadeError userDimensionVisitAction(GeometryFacadeDimension *the_dimension, GeometryFacadeError status, GeometryFacadeAppData data)
{
	GeometryFacadeName symbol;
    GeometryFacadeCharName dimension_name;
    int window_id = 0;
    GeometryFacadeMdl owner = the_dimension->owner;
	int dim_id = the_dimension->id;
	GeometryFacadeType dimension_type = the_dimension->type;
	GeometryFacadeUnitItem unit;
	GeometryFacadeCharName unit_name;
	GeometryFacadeCharName dim_typename;
	LOG << "Here to scan feature dimension  " << the_dimension ->id << " for owner " << int(the_dimension->owner) << endl;
	all_solid_dims_t *all_dims = (all_solid_dims_t*)data;
	std::string * XMLstring_ptr = all_dims ->XMLstring_ptr; 

	// Check if this dimension is in the solid dimensions already collected for this solid.
	stdext::hash_set <int> :: const_iterator dim_RcIter;
	dim_RcIter = all_dims->dim.find( the_dimension->id);
	if ( dim_RcIter == all_dims->dim.end( ) )
	{
		LOG << "Dimension : " << the_dimension->id << " alredy scanned in solid dimension which is not modiafiable" << endl;
		return GEOMETRY_FACADE_NO_ERROR; // This dimension is not modifiable, just get out of here.
	}

	GeometryFacadeGetDimensionSymbol(the_dimension, symbol);
	double value = GeometryFacadeGetDimensionValue(the_dimension);
	GeometryFacadeWideStringToString(dimension_name, symbol);
	LOG << "This dimension is modifiable now will create XML string " << endl;
	// Get the type of the dimension.
	GeometryFacadeDimensionType dim_type = GeometryFacadeGetDimensionType(the_dimension);
   	switch (dim_type) 
	{
		case GEOMETRY_FACADE_DIMTYPE_LINEAR:

			strcpy(dim_typename,"linear");
			break;

		case GEOMETRY_FACADE_DIMTYPE_ANGLE:

			strcpy(dim_typename, "angular");
			break;

		case GEOMETRY_FACADE_DIMTYPE_DIAMETER:

			strcpy(dim_typename, "diameter");
			break;

		case GEOMETRY_FACADE_DIMTYPE_RADIUS:

			strcpy(dim_typename, "radius");
			break;

		case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:

			strcpy(dim_typename, "UNKNOWN");
			break;

		default:

			strcpy(dim_typename, "XXX");
			break;
	}
	LOG << "Dimension type is received now get UNIT " << endl;
	// Get unit of the dimension.
	DimensionUnitGet(the_dimension, &unit);
	GeometryFacadeWideStringToString(unit_name, unit.name);
	LOG << "Now going to create XML string for dimension " << endl;

	ProBoolean bIsRelDriven = PRO_B_FALSE;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string sRelDrivn = "False";
	result = ProDimensionIsReldriven(the_dimension,&bIsRelDriven);
	
	if(bIsRelDriven)
	{
		sRelDrivn = "True";
	}

	char XMLTag[1000];
	sprintf(XMLTag, "\n\t\t\t\t<DIM id=\"%d\" name=\"%s\" type=\"%s\" units=\"%s\" RelationDriven=\"%s\">%f</DIM>", 
					dim_id, dimension_name, dim_typename, unit_name, sRelDrivn.c_str(),value);
	LOG << "Dimension string is " << XMLTag << " now append it " << endl;
	*XMLstring_ptr = *XMLstring_ptr + XMLTag;
	LOG << "Append completed return to feature scan " << endl;

	//Write to file and clear
	fputs(XMLstring_ptr->c_str(),all_dims->xmlFile);
	XMLstring_ptr->clear();
	all_dims->XMLstring_ptr->clear();

	return GEOMETRY_FACADE_NO_ERROR;
}
