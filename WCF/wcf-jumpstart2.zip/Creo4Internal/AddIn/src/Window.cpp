// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Window.h"


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError WindowCurrentClose_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		// Call the wrapper method.
		windowCurrentClose_wrapper();
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


// Private functions.
static void windowCurrentClose_wrapper() 
{
	GeometryFacadeCloseCurrentWindow();
}