// C/C++ header files.
#include <string>


// Application header files.
#include "Models.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Components.h"

//Globals
//This variable will hold new model name.
std::string sMdlNameStrd;
int iFeatNumberVar = -1;

// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CheckModifyingEntityExistInPart_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t *cPartEntityType = NULL;
	wchar_t *cPartEntityName = NULL;
	char cIdPath[GEOMETRY_FACADE_PATH_SIZE];
	wstring idPath;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cPartEntityType = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		cPartEntityName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		idPath = data.v.w;

		GeometryFacadeWideStringToString(cIdPath,idPath.c_str());

		int iReturn = -1;
		iReturn = CheckModifyingEntityExistInPart_wrapper(cPartEntityType ,cPartEntityName ,  cIdPath);

		//iReturn = 1 = Entity Does not exist
		//iReturn = 0 = Entity exist

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = iReturn;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Check modifying entity: ";
		AddWStringToMsgString(sFailureMsg, cPartEntityType);
		sFailureMsg.append(" of name : ");
		AddWStringToMsgString(sFailureMsg, cPartEntityName);
		sFailureMsg.append(" at id Path : ");
		sFailureMsg.append(cIdPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string filePath;
	std::string ownerIDPath;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		filePath = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		ownerIDPath = data.v.s;

		// Declare the output arguments and call the function.
		int output = AddComponent_wrapper(filePath, ownerIDPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Add Component : ";
		sFailureMsg.append(filePath);
		sFailureMsg.append(" to the Owner : ");
		sFailureMsg.append(ownerIDPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddComponentWithSuffix_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring modelName;
	std::wstring suffix;
	std::wstring ownerIDPath;

	ProCharLine name, suffixNew, ownerID;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		modelName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		suffix = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		ownerIDPath = data.v.w;

		GeometryFacadeWideStringToString(name, modelName.c_str());
		GeometryFacadeWideStringToString(suffixNew, suffix.c_str());
		GeometryFacadeWideStringToString(ownerID, ownerIDPath.c_str());

		// Declare the output arguments and call the function.
		int output = addComponentWithSuffix_wrapper(name, suffixNew, ownerID);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Add Component : ";
		sFailureMsg.append(name);
		sFailureMsg.append(" With Suffix : ");
		sFailureMsg.append(suffixNew);
		sFailureMsg.append(" to the Owner : ");
		sFailureMsg.append(ownerID);
		ex.m_message = sFailureMsg;  
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddSuffix_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string modelName;
	std::string suffix;
	
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		modelName = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		suffix = data.v.s;

		// Declare the output arguments and call the function.
		int output = AddSuffix_wrapper(modelName, suffix);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{		
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DeleteComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::string idPath;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.s;

		DeleteComponent_wrapper(idPath);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Delete Component with ID : ";
		sFailureMsg.append(idPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ReplaceProEPartFile_task(GeometryFacadeArgument *inputArguments,GeometryFacadeArgument **outputArguments)
{
	std::wstring sCrntFleID,sNewFleNm,sIDath;
	ProCharPath crntFleID, newFleNm, idPath;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	try
	{
		GeometryFacadeValueData pData;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&pData);
		sCrntFleID = pData.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&pData);
		sNewFleNm = pData.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG3",&pData);
		sIDath = pData.v.w;

		GeometryFacadeWideStringToString(crntFleID, sCrntFleID.c_str());
		GeometryFacadeWideStringToString(newFleNm, sNewFleNm.c_str());
		GeometryFacadeWideStringToString(idPath, sIDath.c_str());

		int iNewFleID = ReplaceProEPartFile_wrapper(crntFleID,newFleNm,idPath);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = iNewFleID;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Add ProE part file : ";
		sFailureMsg.append(newFleNm).append(" in assembly ID : ").append(idPath).append(" and current file ID was : ").append(crntFleID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

int CheckModifyingEntityExistInPart_wrapper(wchar_t *cPartEntityType , wchar_t *cPartEntityName , char *cIdPath)
{
	int iReturn = -1;

	if(_wcsicmp(cPartEntityType , L"LAYER") == 0)
		iReturn = CheckLayerExist(cIdPath);
	else if(_wcsicmp(cPartEntityType , L"PARAMETER") == 0)
		iReturn = CheckParameterExist(cPartEntityName , cIdPath);
	else if(_wcsicmp(cPartEntityType , L"FTINSTANCE") == 0)
		iReturn = CheckFamilyTableInstanceExist(cPartEntityName , cIdPath);
	else if(_wcsicmp(cPartEntityType , L"SKETCHTEXT") == 0)
		iReturn = CheckSketchTextExist(cIdPath);
	else if(_wcsicmp(cPartEntityType , L"DIMENSION") == 0)
		iReturn = CheckDimensionExist(cIdPath);

	return iReturn;
}

int CheckLayerExist(char *cIdPath)
{
	return CheckPartEntityExist_ForCommon(cIdPath , GEOMETRY_FACADE_LAYER);
}

//iReturn = 1 = Entity Does not exist
//iReturn = 0 = Entity exist
int CheckParameterExist(wchar_t *cPartEntityName , char *cIdPath)
{
	int iReturn = 1;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl model = NULL;
	GeometryFacadeModelItem modelitem;
	GeometryFacadeParameter parameter;

	GetAsmcompMdl(cIdPath,&model);
	GeometryFacadeMdlToModelItem(model, &modelitem);

	if((result = ProParameterInit(&modelitem , cPartEntityName, &parameter)) == GEOMETRY_FACADE_NO_ERROR)
	{
		iReturn = 0;
	}

	return iReturn;
}

//iReturn = 1 = Entity Does not exist
//iReturn = 0 = Entity exist
int CheckFamilyTableInstanceExist(wchar_t *cPartEntityName , char *cIdPath)
{
	int iReturn = 1;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl model = NULL;
	ProFamtable pFmTbl;
	ProFaminstance pFmInst;

	GetAsmcompMdl(cIdPath,&model);
	result = ProSolidFamtableCheck((GeometryFacadeSolid)model);

	if(result == GEOMETRY_FACADE_EMPTY) //model is a family table instance 
	{
		GeometryFacadeMdl pGenrcMDl;
		result = ProFaminstanceGenericGet(model,true,&pGenrcMDl);
		model = pGenrcMDl;
	}

	result = ProFamtableInit(model,&pFmTbl);
	if(result == GEOMETRY_FACADE_NO_ERROR)
	{
		result = ProFaminstanceInit(cPartEntityName,&pFmTbl,&pFmInst);
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			ProFaminstanceVerifyStatus pInstVerified;
			if((result = ProFaminstanceIsVerified(&pFmInst,&pInstVerified)) == GEOMETRY_FACADE_NO_ERROR)
			{
				iReturn = 0;
			}
		}
	}
	return iReturn;
}

//iReturn = 1 = Entity Does not exist
//iReturn = 0 = Entity exist
int CheckSketchTextExist(char *cIdPath)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iFeatId , iTable[25] , iTableSize , iReturn = 1;
	GeometryFacadeMdl pCurrentMdl = NULL , pOwnerMdl = NULL;
	GeometryFacadeAsmCompPath pOwnerPath;
	GeometryFacadeFeature pFeature;

	// Filling a path table allows easy access to the feature id 
	//  and parent component path.
	fillPathTable(cIdPath, iTable, &iTableSize);
	iFeatId = iTable[iTableSize-1];

	// Get Root model.
	GeometryFacadeGetCurrentMdl(&pCurrentMdl);
	GeometryFacadeInitAsmCompPath((GeometryFacadeSolid)pCurrentMdl, iTable, iTableSize-1, &pOwnerPath);
	GeometryFacadeGetAsmCompPathMdl(&pOwnerPath, &pOwnerMdl);
	if((result = ProFeatureInit((GeometryFacadeSolid)pOwnerMdl,iFeatId,&pFeature)) == GEOMETRY_FACADE_NO_ERROR)
	{
		iReturn = 0;
	}
	return iReturn;
}


//iReturn = 1 = Entity Does not exist
//iReturn = 0 = Entity exist
int CheckDimensionExist(char *cIdPath)
{
	return CheckPartEntityExist_ForCommon(cIdPath , GEOMETRY_FACADE_DIMENSION);
}

//To be called where entities are retreived using Model Item...
int CheckPartEntityExist_ForCommon(char *cIdPath , GeometryFacadeType pEntityType)
{
	int table[25] , tableSize , featId , iReturn = 1;
	GeometryFacadeAsmCompPath pOwnerPath;
	GeometryFacadeMdl pCurrentMdl = NULL , pOwnerMdl = NULL;
	GeometryFacadeModelItem modelItem;	
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	fillPathTable(cIdPath, table, &tableSize);
	featId = table[tableSize-1];
	GeometryFacadeGetCurrentMdl(&pCurrentMdl);
	GeometryFacadeInitAsmCompPath((GeometryFacadeSolid)pCurrentMdl, table, tableSize-1, &pOwnerPath);
	GeometryFacadeGetAsmCompPathMdl(&pOwnerPath, &pOwnerMdl);

	if((result = ProModelitemInit(pOwnerMdl, featId, pEntityType, &modelItem)) == GEOMETRY_FACADE_NO_ERROR)
	{
		iReturn = 0;
	}

	return iReturn;
}

int ReplaceProEPartFile_wrapper(std::string sCrntFleID,std::string sNewFleNm,std::string sIDath)
{
	GeometryFacadeError result;
	int iCompID = 0;
	int iTemp = 0;

	LOG << "Replace ProE part file with ID : " << sCrntFleID << " with new model : " << sNewFleNm << " at assembly path : " << sIDath << endl;
	GeometryFacadeMdl pOwnerAsm;
	GetAsmcompMdl(sIDath, &pOwnerAsm); //get asm handle here.
	GeometryFacadeMdl pCrntMdl; 
	GetAsmcompMdl(sCrntFleID,&pCrntMdl); //Handle of model to be replaced.
	LOG << "Retrieved Current model handle and assembly handle" << endl;

	ProName wmdlName;
	std::string mdlType,modelName;
	GeometryFacadeMdlType pCrntMdlType;
	GetMdlNameTypeFromString_wrapper(sNewFleNm, modelName, mdlType);
	result = ProMdlNameGet(pCrntMdl,wmdlName);
	result = ProMdlTypeGet(pCrntMdl , &pCrntMdlType);

	ProName fileName;
	GeometryFacadeStringToWideString(fileName, sNewFleNm.c_str());
	int iCmprRslt = _wcsicmp(fileName, wmdlName);

	if(iCmprRslt != 0)
	{
		//Initialize  assembly comp to Remove constrain
		GeometryFacadeAsmComp pAsmComp;
		int table[25];
		int table_size;
		GeometryFacadeAsmCompPath pAsmCompPath;
		fillPathTable(sCrntFleID, table, &table_size);
		result = ProAsmcomppathInit((ProSolid)pOwnerAsm,table,table_size,&pAsmCompPath); 
		GetAsmcomp(pAsmCompPath,&pAsmComp);
		ProAsmcompconstraint *pAsmConstr;
		result = ProArrayAlloc(0,sizeof(ProAsmcompconstraint),1,(ProArray*)&pAsmConstr);
		//If Current component has constrains remove it.
		if(ProAsmcompConstraintsGet(&pAsmComp,&pAsmConstr) == GEOMETRY_FACADE_NO_ERROR)
		{
			result = ProAsmcompConstrRemove(&pAsmComp,-1);
		}
		LOG << "Assembly component initialization completed and all constraisn were removed" << endl;

		//Initialize new model handle	
		GeometryFacadeMdl pNewMdl;
		retrieveComponent_wrapper(sNewFleNm,&pNewMdl);
		LOG << "New model retreived " << endl;

		if(sCrntFleID.find(",") != string::npos)
		{
			//If part to be replaced is at below sub-assembly then sCrntFleID will be (ownerID,compID).
			//So here we will extract compID out of full comp. path ID.
			sCrntFleID = sCrntFleID.substr(sCrntFleID.find_last_of(",")+1);
		}

		sscanf(sCrntFleID.c_str(),"%d",&iTemp);	
		
		//Get feature number for the assembly component...
		int iFeatNumber = -1;
		GeometryFacadeFeature pFeature;
		result = ProFeatureInit((GeometryFacadeSolid)pOwnerAsm , iTemp , &pFeature);
		result = ProFeatureNumberGet(&pFeature , &iFeatNumber);
		LOG << "Component with Id : " << sCrntFleID << " has feature number " << iFeatNumber << " in the assembly file " << endl;

		ProArray pCompIds;
		pCompIds = GeometryFacadeAllocateArray(0,sizeof(int),1);
		GeometryFacadeAddArrayObject(&pCompIds,-1,1,&iTemp);
		//wchar_t wName;
		//Replace Old model having ID iOldCompID with model of handle pNewMdl in assembly pOwnerAsm.
		LOG << "Now replacing model with ID : " << iTemp << endl;
		/*<Replaced>int iDomain = prodb_interchange_domain((Prohandle)pOwnerAsm,&wName);
		int no = prodb_auto_interchange((Prohandle)pOwnerAsm, 1,iOldCompID, (Prohandle)pNewMdl);</Replaced>*/
		result = ProAssemblyAutointerchange((GeometryFacadeAssembly)pOwnerAsm,(int*)pCompIds,pNewMdl);
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "Model replaced succesfully " << endl;
			GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(pOwnerAsm), GEOMETRY_FACADE_REGEN_NO_FLAGS);
			GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(pNewMdl), GEOMETRY_FACADE_REGEN_NO_FLAGS);			
		}

		//part replacement was succesfull now get ID of new component. API performs part replacment still returns GENERAL_ERROR
		//Such behavior is observed when currently loaded assembly has any regeneration failures. So retreiving new model Id is taken out of condition of NO_ERROR
		iCompID = GetNewPartModelID(pOwnerAsm,modelName , iFeatNumber);

		if(pCompIds != NULL)
		{
			GeometryFacadeFreeArray(&pCompIds);
		}
	}

	
	GeometryFacadeMdl pParentAsm;
	GetAsmcompMdl("", &pParentAsm);
	GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(pParentAsm), GEOMETRY_FACADE_REGEN_NO_FLAGS);

	return iCompID;
}

//There is no direct way to get component id for the newly replaced model.
//So following method will traverse assembly tree , in action method visited component name will be matched with replaced component name.
//Also when there are more than 1 component having same name as replaced component feature number of replaced component will be used as additional
//check. when both things match feature Id will be assigned.
int GetNewPartModelID(GeometryFacadeMdl pOwnerAsm,std::string sNewMdlName , int iFeatNumber)
{
	LOG << "Get ID for model : " << sNewMdlName	<< endl;
	int iMdlID = 0;
	sMdlNameStrd = sNewMdlName;
	iFeatNumberVar = iFeatNumber;
	GeometryFacadeVisitSolidFeature(GeometryFacadeSolid(pOwnerAsm),(GeometryFacadeFeatureVisitAction)NewMdlFeatureVisitAction,NULL,(GeometryFacadeAppData)&iMdlID);
	return iMdlID;
}

GeometryFacadeError NewMdlFeatureVisitAction(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData)
{
	if(feature != NULL)
	{
		GeometryFacadeFeatureType ftype;

		ftype = GeometryFacadeGetFeatureType(feature);	
		if(ftype == GEOMETRY_FACADE_FEAT_COMPONENT)
		{
			GeometryFacadeMdl pMdl;
			GeometryFacadeMdlData pdata;
			char *cTempName = new char[PRO_LINE_SIZE];
			GeometryFacadeGetAsmCompMdl(feature,&pMdl);
			result = ProMdlDataGet(pMdl,&pdata);
			ProWstringToString(cTempName,pdata.name);

			ProName name;
			GeometryFacadeStringToWideString(name, sMdlNameStrd.c_str());

			int iCmp = _wcsicmp(name,pdata.name);
			if(iCmp == 0)
			{
				int iFeatNo = -1;
				result = ProFeatureNumberGet(feature , &iFeatNo);
				if(iFeatNo == iFeatNumberVar)
				{
					LOG << "New Model name is : " << sMdlNameStrd << " and assembly component matched is : " << cTempName << " having ID is : " << feature->id << " and Feature Number : " << iFeatNo << endl;
					int *ImdlID = (int*)appData;
					*ImdlID = feature->id;
				}
			}
			delete[] cTempName;
		}
	}
	return GEOMETRY_FACADE_NO_ERROR;
}

// Public functions.

//
// Add Component
//
// API function to open file and add as component geometry
//
// Input:	theFilePath - includes extension
//			theOwnerIDPath
//
//	Output:	FeatureID with respect to the root model part. (asmCompPath)

int AddComponent_wrapper(std::string filePath, std::string ownerIdPath) 
{
	GeometryFacadeMdl component;
	retrieveComponent_wrapper(filePath, &component);

	GeometryFacadeMatrix identity_matrix = {{1.0, 0.0, 0.0, 0.0}, 
								 {0.0, 1.0, 0.0, 0.0}, 
								 {0.0, 0.0, 1.0, 0.0}, 
								 {0.0, 0.0, 0.0, 1.0}};
	GeometryFacadeAsmComp assembly_component;
	GeometryFacadeMdl owner;
	int new_id;

	GetAsmcompMdl(ownerIdPath, &owner);

	GeometryFacadeAssembleAsmComp( (GeometryFacadeAssembly)owner, (GeometryFacadeSolid)component, identity_matrix, &assembly_component );

	new_id = assembly_component.id;

	return new_id;
}


void DeleteComponent_wrapper(std::string idPath) 
{
	GeometryFacadeAsmCompPath path;
	GeometryFacadeMdl owner;    	
	GeometryFacadeMdl pModel = NULL;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	int feat_id[1];
	LOG << "DeleteComponent: Started for component at  :  " << idPath << endl;
	// get the component path from the IdPath string
	GetAsmcompPath(idPath, &path);

	// BUG confirmed by PTC support 20060131
	//status = GeometryFacadeAsmCompRmvUniqueSubasm (&path);

	// Since there is a bug with this function PTC tech support
	// suggested using ProFeatureDelete() as a work around. -rpm

	// The feature is the last entry in the component path table
	feat_id[0] = path.comp_id_table[path.table_num-1];

	// The feature owner is the component path without the last id
	path.table_num = path.table_num - 1;

	//<Milind> Here GeometryFacadeGetAsmCompPathMdl() returns GEOMETRY_FACADE_GENERAL_ERROR if required path is missing
	//this case arises when parent item gets deleted before deleting child.
	//Child component gets deleted along with parent so no need to worry about child deletion. 
	try
	{
		LOG << "DeleteComponent: Deleting component... "  << endl;
		// get the owner of the feature
		GeometryFacadeGetAsmCompPathMdl(&path, &owner);
		bool IsUDF = CheckComponentForUDF(owner,feat_id[0],idPath , &pModel);

		if(pModel != NULL || IsUDF)
		{
			GeometryFacadeDeleteFeature( (GeometryFacadeSolid)owner, feat_id, 1, NULL, 0 );
			LOG << "DeleteComponent: Component deleted successfully "  << endl;
		}
		else
			LOG << "DeleteComponent: Component doesn't exist at given path , so can't delete."  << endl;
	}
	catch (ProeException ex)
	{
		LOG << "DeleteComponent: Exception thrown while deleting compoenet." <<  endl;
		if (ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
		{
			throw;
		}		
	}

	//Erase geometry from Current ProE session..
	if(pModel != NULL)
		ProMdlErase(pModel);

	//Erase not displayed items, Added for Dynamic Occurrence Item
	ProMdlEraseNotDisplayed();

	LOG << "DeleteComponent: Completed. "  << endl;
}

bool CheckComponentForUDF(ProMdl owner,int feat_id,std::string idPath , GeometryFacadeMdl *pModel)
{	
	bool IsUDF = false;
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeFeature pFeature;
		result = ProFeatureInit( (GeometryFacadeSolid)owner,feat_id,&pFeature);
		GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(&pFeature);
		if (GEOMETRY_FACADE_FEAT_COMPONENT == type)
		{
			GetAsmcompMdl(idPath,pModel);
		}
		else if(PRO_FEAT_GROUP_HEAD == type)
			IsUDF = true;
	}
	catch(ProeException ex)
	{
	}
	return IsUDF;
}

// Private functions.

// Retrieve Component
//
// Create the geometry from disc file.
//
// Input:	Filename
//
// Output:	pointer to component
static int addComponentWithSuffix_wrapper(std::string modelWithExtension, std::string suffix, std::string ownerIdPath)
{
	std::string modelName, 
		modelType, 
		newModelName;

	GetMdlNameTypeFromString_wrapper(modelWithExtension, modelName, modelType);
	if(suffix.length() != 0)
	{
		newModelName = modelName + suffix + modelType;
	}
	else
	{
		newModelName = modelName + modelType;
	}

	// TODO: The below line seems incorrect.  Why are
	// we trying to load the template file?
	//int output = AddSuffix_wrapper(modelWithExtension, suffix);

	GeometryFacadeMdl owner;

	GetAsmcompMdl(ownerIdPath , &owner);

	//get owner type , it has to be a Assembly so that Add operation doesn't fail.
	GeometryFacadeMdlType ownerType = GeometryFacadeGetMdlType(owner);

	if(ownerType == GEOMETRY_FACADE_MDL_ASSEMBLY)
	{
		return AddComponent_wrapper(newModelName, ownerIdPath);
	}
	else
	{
		LOG << "FAILED: To Add " << modelWithExtension << " to Parent part at " << ownerIdPath << ". Owner geometry is not a valid Assembly file." << endl;
		return 0;
	}
}


static void retrieveComponent_wrapper(std::string path, GeometryFacadeMdl *model) 
{
	GeometryFacadePath path_w;

	GeometryFacadeStringToWideString( path_w, const_cast<char*>( path.c_str() ) );
	GeometryFacadeLoadMdl(path_w, (GeometryFacadeMdlType)GEOMETRY_FACADE_VALUE_UNUSED, GEOMETRY_FACADE_B_FALSE, model);
}

