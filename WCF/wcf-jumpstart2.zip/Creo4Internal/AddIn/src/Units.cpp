// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"
#include "Units.h"


// Public functions.
void GetUnitSystemXML(GeometryFacadeMdl *the_model, std::string &XMLString_prt) 
{
	GeometryFacadeUnitSystem unitSystem;	
	GeometryFacadeCharName type_name;

	GeometryFacadeUnitItem unit;
	GeometryFacadeUnitItem mass_unit;
	GeometryFacadeUnitItem force_unit;
	GeometryFacadeUnitItem length_unit;
	GeometryFacadeUnitItem time_unit;
	GeometryFacadeUnitItem temp_unit;
	GeometryFacadeUnitItem angle_unit;

	GeometryFacadePart part = (GeometryFacadePart)the_model;

	// Unit system of the dimension owner
	GeometryFacadeGetMdlPrincipalUnitSystem(*the_model, &unitSystem);

	GeometryFacadeUnitSystemType type = GeometryFacadeGetUnitSystemType(&unitSystem);
	sprintf(type_name, "%d", type);

	if (type == GEOMETRY_FACADE_UNITSYSTEM_MLT)
	{
		// Type MLT doesn't contain FORCE.
		GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_MASS, &mass_unit);
	}
	else if (type == GEOMETRY_FACADE_UNITSYSTEM_FLT)
	{
		// Type FLT doesn't contain MASS.
		GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_FORCE, &force_unit);
	}

	GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_LENGTH, &length_unit);
	GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_TIME, &time_unit);
	GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_TEMPERATURE, &temp_unit);
	GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_ANGLE, &angle_unit);

	char dummy[GEOMETRY_FACADE_PATH_SIZE];

	XMLString_prt = XMLString_prt + "\t\t\t<UNITS type=\"" + type_name + "\" " + "name=\"" + GeometryFacadeWideStringToString(dummy, unitSystem.name)+ "\">" + "\n";

	GeometryFacadeCharName unit_name;
	GeometryFacadeUnitType unit_types[6] = {GEOMETRY_FACADE_UNITTYPE_LENGTH, GEOMETRY_FACADE_UNITTYPE_MASS, GEOMETRY_FACADE_UNITTYPE_FORCE,
								 GEOMETRY_FACADE_UNITTYPE_TIME, GEOMETRY_FACADE_UNITTYPE_TEMPERATURE, GEOMETRY_FACADE_UNITTYPE_ANGLE};
	GeometryFacadeCharName type_names[6] = {"length", "mass", "force", "time", "temp", "angle"};

	for (int i = 0; i < 6; ++i) 
	{
		if ( (type == GEOMETRY_FACADE_UNITSYSTEM_MLT && unit_types[i] == GEOMETRY_FACADE_UNITTYPE_FORCE ) ||
             (type == GEOMETRY_FACADE_UNITSYSTEM_FLT && unit_types[i] == GEOMETRY_FACADE_UNITTYPE_MASS) )
		{
			// If type is MLT & unit is FORCE or type is FLT & unit is MASS, skip.
			continue;
		}

		GeometryFacadeGetUnitSystemUnit(&unitSystem, unit_types[i], &unit);
		GeometryFacadeWideStringToString(unit_name, unit.name);
		XMLString_prt = XMLString_prt + "\t\t\t\t<UNIT type=\""+ type_names[i]+"\">"+ unit_name+ "</UNIT>"+ "\n";
	}

	XMLString_prt = XMLString_prt + "\t\t\t</UNITS>\n";
}


// typedef enum GEOMETRY_FACADE_DIMENSIONtype 
// {
//     GEOMETRY_FACADE_DIMTYPE_UNKNOWN   = -1, // ((== DIM_TYPE_UNKNOWN)) 
//	   GEOMETRY_FACADE_DIMTYPE_LINEAR    =  9, // ((== DIM_LINEAR      )) 
//	   GEOMETRY_FACADE_DIMTYPE_RADIUS    =  3, // ((== DIM_RAD         )) 
//	   GEOMETRY_FACADE_DIMTYPE_DIAMETER  =  4, // ((== DIM_DIA         ))
//	   GEOMETRY_FACADE_DIMTYPE_ANGLE     = 21  // ((== DIM_ANGULAR     ))
// } GeometryFacadeDimensionType;
//
// Unit types can have any of the following values:
//	GEOMETRY_FACADE_UNITTYPE_LENGTH
//	GEOMETRY_FACADE_UNITTYPE_MASS
//	GEOMETRY_FACADE_UNITTYPE_FORCE
//	GEOMETRY_FACADE_UNITTYPE_TIME
//	GEOMETRY_FACADE_UNITTYPE_TEMPERATURE
//	GEOMETRY_FACADE_UNITTYPE_ANGLE
void DimensionUnitGet(GeometryFacadeDimension *the_dim, GeometryFacadeUnitItem *the_unit) 
{
	GeometryFacadePart part;
	GeometryFacadeMdl model;
	GeometryFacadeUnitSystem unitSystem;

	GeometryFacadeDimensionType dim_type = GeometryFacadeGetDimensionType(the_dim);
	model = the_dim->owner;
	part = (GeometryFacadePart)model;

	// Extract system of units.

	// Unit system of the dimension owner.
	GeometryFacadeGetMdlPrincipalUnitSystem(part, &unitSystem);
	
   	switch (dim_type) 
	{
		case GEOMETRY_FACADE_DIMTYPE_LINEAR:

			GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_LENGTH, the_unit);
			break;

		case GEOMETRY_FACADE_DIMTYPE_ANGLE:

			GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_ANGLE, the_unit);
			break;

		case GEOMETRY_FACADE_DIMTYPE_DIAMETER:

			GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_LENGTH, the_unit);
			break;

		case GEOMETRY_FACADE_DIMTYPE_RADIUS:

			GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_LENGTH, the_unit);
			break;

		case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:

			GeometryFacadeGetUnitSystemUnit(&unitSystem, GEOMETRY_FACADE_UNITTYPE_LENGTH, the_unit);
			break;

		default:

			// TODO: figure out what to do if the type is unknown ...
			break;
   }
}
