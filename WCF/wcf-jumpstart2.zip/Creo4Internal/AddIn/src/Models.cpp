// C/C++ header files.
#include <string>
#include <set>
#include <vector>

#include <cstdio>
#include <typeinfo.h>
#include <cstdarg>
#include <io.h>
#include <iostream>
#include "tchar.h"
#include <string>




// Application header files.
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Scan.h"
#include "Utility.h"
#include "Models.h"
#include "ProPrint.h"


using namespace std;

//It will store the components in an assembly.suffix parameters needs to be passed in featurevisitaction function.
vector<char*> compList;
vector<char*> vGnrcMdlList;
std::string suffix;
std::string workingFolder;
vector<std::string> vStringValContainer;//general purpose container will be used to store string type values.<TODO>Check if earlier vectors can be used.

typedef struct rename_data
{
	std::string suff;
	std::set<GeometryFacadeMdl> component;
} rename_data_t;


// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetListOfModelsInSession_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	try
	{
		std::string sAllMdlList = GetListOfModelsInSession_wrapper();

		wchar_t mdlList[4096];
		GeometryFacadeStringToWideString(mdlList, sAllMdlList.c_str());

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		GeometryFacadeSetValueDataWstring( &arg.value, mdlList);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		LOG << "GetListOfModelsInSession_task: Caught Outer exception while retreiving list of models in current session." <<  endl;
	}
	return GEOMETRY_FACADE_NO_ERROR;
}



GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError LoadModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring fileName;
	ProCharPath name;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		fileName = data.v.w;

		GeometryFacadeWideStringToString(name, fileName.c_str());

		// Declare the output arguments and call the function.
		GeometryFacadeMdl output = LoadModel_wrapper(name);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;

		// The Pro/TOOLKIT docs say not to use type PRO_VALUE_TYPE_POINTER when
		// passing arguments between applications, so we use an int.  This could
		// be problematic on 64-bit machines if the underlying PRO_VALUE_TYPE_INT
		// turns out to be 32-bits because then we would be casting a 64-bit void* 
		// to a 32-bit int.  Hopefully, this will not be the case.  If it is, perhaps
		// we could use PRO_VALUE_TYPE_STRING instead.

		// These casts are to here simply to remove the warnings on 64-bit machines.
		//D-05337 Remove reinterpret_cast and return 0
		arg.value.v.i = 0;

		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Load Model : ";
		sFailureMsg.append(name);
		ex.m_message = sFailureMsg;
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameAssemblyComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;	
	GeometryFacadeMdl mdlHandle = NULL;
	int iIsRSStandard = -1;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		suffix = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		workingFolder = data.v.s;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG3",&data);
		iIsRSStandard = data.v.i;

		int iWinID;
		ProWindowCurrentGet(&iWinID);
		ProWindowMdlGet(iWinID,&mdlHandle); 
		//GeometryFacadeGetCurrentMdl(&mdlHandle);

		//iIsRSStandard = 0 = False
		//iIsRSStandard = 1 = True
		result = RenameAssemblyComponent_wrapper(mdlHandle , iIsRSStandard);

		clearComplist();

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;

		arg.value.v.i = static_cast<int>(result);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );

	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Process Sttaic Assembly : ";
		sFailureMsg.append(suffix);
		sFailureMsg.append(" and Working Folder : ");
		sFailureMsg.append(workingFolder);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	if(result != GEOMETRY_FACADE_NO_ERROR && mdlHandle != NULL)
		ProMdlEraseAll(mdlHandle);

	return result;
}

void clearComplist()
{
	int i;
	char* temp = NULL;
	for(i = 1;i<= (int)compList.size();i++)
	{
		temp = compList[i-1];
		delete temp;
	}

	for(i = 1;i<= (int)vGnrcMdlList.size();i++)
	{
		temp = vGnrcMdlList[i-1];
		delete temp;
	}

	compList.clear();
	compList.empty();
	vGnrcMdlList.clear();
	vGnrcMdlList.empty();
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ClearProeWindow_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iAsmRemoveFlag;
	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iAsmRemoveFlag = data.v.i;

		GeometryFacadeMdl mdlHandle = NULL;
		GeometryFacadeGetCurrentMdl(&mdlHandle);

		//Get file Name
		ProName name;
		GeometryFacadeGetMdlName(mdlHandle, name);

		ProCharLine charName; 
		ProWstringToString(charName, name);

		//Get file type
		ProMdlfileType  type;
		type = GeometryFacadeGetMdlFileType(mdlHandle);
		if (type==PRO_MDLFILE_PART)
		{
			strcat(charName, ".prt");
		}
		else if(type == PRO_MDLFILE_ASSEMBLY)
		{
			strcat(charName, ".asm");
		}

		GeometryFacadeClearWindow(GEOMETRY_FACADE_VALUE_UNUSED);
		if(mdlHandle != NULL && iAsmRemoveFlag == 0)
		{
			//Creo is Crashing while saving and closing drawing file. To avoid such crash 
			//erase not displayed files before save and close.
			ProMdlEraseNotDisplayed();

			ProMdlSave(mdlHandle);
			ProMdlEraseAll(mdlHandle);
			ProMdlEraseNotDisplayed();
			LOG << "ClearProeWindow_task: Top level assembly is saved and removed from current Creo session." << endl;
		}

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
		ProLine nameToReturn; 
		GeometryFacadeStringToWideString(nameToReturn, charName);
		GeometryFacadeSetValueDataWstring( &arg.value, nameToReturn);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );


	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Clear ProE Window";
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RegenerateAssemblyFile_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wstring model;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		model = data.v.w;

		ProCharLine modelName;
		GeometryFacadeWideStringToString( modelName, model.c_str());
		string modelHandle = modelName;

		//D-05337 removed reinterpret_cast and used Model init
		ProMdlfileType  type;
		std::size_t found = modelHandle.find(".prt");
		if (found!=std::string::npos)
		{
			type = PRO_MDLFILE_PART;
		}
		else
		{
			type = PRO_MDLFILE_ASSEMBLY;
		}

		GeometryFacadeName name;
		GeometryFacadeStringToWideString(name, modelHandle.c_str());

		//Init Model Handler
		GeometryFacadeMdl model;
		GeometryFacadeMdlInit(name, type, &model);


		GeometryFacadeDisplayMdl(model);

		GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(model), GEOMETRY_FACADE_REGEN_NO_FLAGS);

		// Get the current window id.
		int windowId = GeometryFacadeGetCurrentWindow();	

		// Activate the window.
		GeometryFacadeActivateWindow(windowId);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;

		arg.value.v.i = static_cast<int>(result);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );


	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Regenerate Assembly File";		
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;


}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError EraseModelByName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wstring wchrName;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		wchrName = data.v.w;

		ProCharLine modelName;
		GeometryFacadeWideStringToString( modelName, wchrName.c_str());
		string modelHandle = modelName;

		ProMdlfileType  type;
		std::size_t found = modelHandle.find(".prt");
		if (found!=std::string::npos)
		{
			type = PRO_MDLFILE_PART;
		}
		else
		{
			type = PRO_MDLFILE_ASSEMBLY;
		}

		GeometryFacadeName name;
		GeometryFacadeStringToWideString(name, modelHandle.c_str());

		// Init Model Handler.
		GeometryFacadeMdl model;
		GeometryFacadeMdlInit(name, type, &model);

		GeometryFacadeEraseMdl(model);


		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;

		arg.value.v.i = static_cast<int>(result);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to erase model";		
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


//GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RetrieveModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
//{
//	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
//
//	try
//	{
//		GeometryFacadeValueData data;
//		
//		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
//		std::string partName = data.v.s;
//
//		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
//		int display = data.v.i;
//
//		// Declare the output arguments and call the function.
//		GeometryFacadeMdl output = retrieveModel_wrapper(partName, display);
//
//		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
//
//		GeometryFacadeArgument arg;
//		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
//		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
//		arg.value.v.i = output;
//		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
//	}
//	catch (ProeException ex)
//	{
//		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
//		// allow passing exceptions, so save the error information.
//		SaveErrorInfo(ex);
//		result = (GeometryFacadeError)ex.GetResult();
//	}
//
//	return result;	
//}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError EraseCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		eraseCurrentModel_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Erase Current Model";		
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SaveModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		saveModel_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Save Model";
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BackupModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring sReleaseFolderPath, sGeometryFileName, sGeomReleaseFileName, sDrwFileName, sDrwReleaseFileName, sAsmChildId, sAsmChildRelName;
	char releaseFolderPath[2000]; 
	ProCharLine geometryFileName, geomReleaseFileName, drwFileName, drwReleaseFileName, asmChildId, asmChildRelName;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sReleaseFolderPath = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sGeometryFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sGeomReleaseFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		sDrwFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG5", &data);
		sDrwReleaseFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG6", &data);
		sAsmChildId = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG7", &data);
		sAsmChildRelName = data.v.w;

		GeometryFacadeWideStringToString(releaseFolderPath, sReleaseFolderPath.c_str());
		GeometryFacadeWideStringToString(geometryFileName, sGeometryFileName.c_str());
		GeometryFacadeWideStringToString(geomReleaseFileName, sGeomReleaseFileName.c_str());
		GeometryFacadeWideStringToString(drwFileName, sDrwFileName.c_str());
		GeometryFacadeWideStringToString(drwReleaseFileName, sDrwReleaseFileName.c_str());
		GeometryFacadeWideStringToString(asmChildId, sAsmChildId.c_str());
		GeometryFacadeWideStringToString(asmChildRelName, sAsmChildRelName.c_str());


		backupModel_wrapper(releaseFolderPath , geometryFileName , geomReleaseFileName , drwFileName , drwReleaseFileName , asmChildId , asmChildRelName);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Backup Model at Path : ";
		sFailureMsg.append(releaseFolderPath);
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BackupModelToWIP_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring sWIPFolderPath, sGeomRelFileName, sGeomWIPFileName, sDrwFileName, sDrwReleaseFileName, sAsmChildId, sAsmChildWrkngName;
	char wipFolderPath[2000];
	ProCharLine geomRelFileName, geomWIPFileName, drwFileName, drwReleaseFileName, asmChildId, asmChildWrkngName;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sWIPFolderPath = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sGeomRelFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sGeomWIPFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		sDrwFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG5", &data);
		sDrwReleaseFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG6", &data);
		sAsmChildId = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG7", &data);
		sAsmChildWrkngName = data.v.w;

		GeometryFacadeWideStringToString(wipFolderPath, sWIPFolderPath.c_str());
		GeometryFacadeWideStringToString(geomRelFileName, sGeomRelFileName.c_str());
		GeometryFacadeWideStringToString(geomWIPFileName, sGeomWIPFileName.c_str());
		GeometryFacadeWideStringToString(drwFileName, sDrwFileName.c_str());
		GeometryFacadeWideStringToString(drwReleaseFileName, sDrwReleaseFileName.c_str());
		GeometryFacadeWideStringToString(asmChildId, sAsmChildId.c_str());
		GeometryFacadeWideStringToString(asmChildWrkngName, sAsmChildWrkngName.c_str());



		BackupModelToWIP_wrapper(wipFolderPath , geomRelFileName, geomWIPFileName, drwFileName, drwReleaseFileName, asmChildId, asmChildWrkngName);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed while Model Backup to WIP folder : ";
		sFailureMsg.append(wipFolderPath);
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		GeometryFacadeValueData data;

		std::wstring idPath;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.w;

		std::wstring newName;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		newName = data.v.w;

		ProCharLine path, name;
		GeometryFacadeWideStringToString(path, idPath.c_str());
		GeometryFacadeWideStringToString(name, newName.c_str());

		renameModel_wrapper(path, name);
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}	
	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RepaintCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		repaintCurrentModel_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Repaint Current Model";
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RegenerateCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		RegenerateCurrentModel_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Regenerate Current Model";
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ZoomAllCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		ZoomAllCurrentModel_wrapper();
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddUDF_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t *sXMLRef=NULL;
	wchar_t * sUDFFile=NULL;
	try
	{
		GeometryFacadeValueData data;		

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sXMLRef = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sUDFFile = data.v.w;

		int iUDFId = AddUDF_wrapper(sXMLRef, sUDFFile);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;		

		arg.value.v.i = iUDFId;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Add UDF : ";
		wstring xml1=sXMLRef;
		std::string udf(xml1.begin(), xml1.end());
		sFailureMsg.append(udf);
		sFailureMsg.append( " With XML Ref : ");
		wstring ref1=sXMLRef;
		std::string ref(ref1.begin(), ref1.end());
		sFailureMsg.append(ref);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError UDFDimensionValueSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wstring cID, cDimName;
	double dDimValue;
	ProCharPath id, DimName;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		cDimName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		dDimValue = data.v.d;

		GeometryFacadeWideStringToString(id, cID.c_str());
		GeometryFacadeWideStringToString(DimName, cDimName.c_str());

		UDFDimensionValueSet_wrapper(id,DimName,dDimValue);		

	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Dimension : ";
		sFailureMsg.append(DimName);
		sFailureMsg.append(" With ID : ");
		sFailureMsg.append(id);
		sFailureMsg.append(" having value : ");
		char ss[20];
		sprintf(ss,"%g",dDimValue);
		sFailureMsg.append(ss);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}
//First call to the Export File Task.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ExportFileTypes_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wstring  cDrwExptType, cMdlExptType, cReleaseDirPath, cDrwFile, cMdlFile, cExportFileName, exportFactOne, exportFactTwo, exportFactThree;
	char releaseDirPath[2000], drwFile[2000], mdlFile[2000], exportFileName[2000]; 
	ProCharLine drwExptType, mdlExptType, expFactOne, expFactTwo, expFactThree;

	//This variable will hold Format types which can't be exported.
	//It will be then returned and notified to USER.
	std::string cTypeNotExported;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		cDrwExptType = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		cMdlExptType = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG3",&data);
		cReleaseDirPath = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG4",&data);
		cDrwFile = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG5",&data);
		cMdlFile = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG6",&data);
		cExportFileName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG7",&data);
		exportFactOne = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG8",&data);
		exportFactTwo = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG9",&data);
		exportFactThree = data.v.w;

		GeometryFacadeWideStringToString(drwFile, cDrwFile.c_str());
		GeometryFacadeWideStringToString(drwExptType, cDrwExptType.c_str());
		GeometryFacadeWideStringToString(mdlFile, cMdlFile.c_str());
		GeometryFacadeWideStringToString(mdlExptType, cMdlExptType.c_str());
		GeometryFacadeWideStringToString(releaseDirPath, cReleaseDirPath.c_str());
		GeometryFacadeWideStringToString(exportFileName, cExportFileName.c_str());
		GeometryFacadeWideStringToString(expFactOne, exportFactOne.c_str());
		GeometryFacadeWideStringToString(expFactTwo, exportFactTwo.c_str());
		GeometryFacadeWideStringToString(expFactThree, exportFactThree.c_str());


		ExportFileTypes_Wrapper(drwFile, drwExptType, mdlFile, mdlExptType, releaseDirPath, exportFileName, expFactOne, expFactTwo, expFactThree, cTypeNotExported);

		ProPath typeNotExported;
		GeometryFacadeStringToWideString(typeNotExported, cTypeNotExported.c_str());

		LOG << "Exporting finished with file types not support as : " << cTypeNotExported << endl;
		//Exporting is finished now return file type not exported.
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;			
		GeometryFacadeSetValueDataWstring( &arg.value, typeNotExported);
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed While Exporting Model File Types : ";
		sFailureMsg.append(mdlExptType).append(" For Model File : ").append(mdlFile);
		sFailureMsg.append( " and Drawing File Types : ").append(drwExptType).append(" For Drawing File : ").append(drwFile).append(" at Release Directory : ").append(releaseDirPath);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();	
	}
	return result;

}
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessFamilyTableInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{

	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring idPath, instanceName;
	ProCharPath idPathNew, instanceNameNew;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		instanceName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		idPath = data.v.w;

		GeometryFacadeWideStringToString(instanceNameNew, instanceName.c_str());
		GeometryFacadeWideStringToString(idPathNew, idPath.c_str());

		//This variable will have status for Instance Processing
		//iInstResult = 0 , PRO_TK_NO_ERROR Processig succeded.
		//iInstResult < 0 , Processing failed.
		//iInstResult = 2 , processing modified Model ID Path.
		int iInstResult = ProcessFamilyTableInstance_wrapper(instanceNameNew,idPathNew);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;		

		arg.value.v.i = iInstResult;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed While Processing Family Instance : ";
		sFailureMsg.append(instanceNameNew).append(" for part/assembly having ID path : ").append(idPathNew);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessDocumentNameForStaticAsmComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	wstring sStaticAsmId , sComponentId, cDocumentName;
	ProCharPath staticAsmID, componentId, documentName;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		sStaticAsmId = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		sComponentId = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG3",&data);
		cDocumentName = data.v.w;

		GeometryFacadeWideStringToString(staticAsmID, sStaticAsmId.c_str());
		GeometryFacadeWideStringToString(componentId, sComponentId.c_str());
		GeometryFacadeWideStringToString(documentName, cDocumentName.c_str());

		LOG << "ProcessDocumentNameForStaticAsmComponent_task: For Static assembly at <" << sStaticAsmId << "> for Component at <" << sComponentId << "> new name is <" << cDocumentName << ">." << endl;
		int iOut = ProcessDocumentNameForStaticAsmComponent_wrapper(staticAsmID , componentId , documentName);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;		
		arg.value.v.i = iOut;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "ProcessDocumentNameForStaticAsmComponent_task: Failed While Performing Static Assembly Component renaming for component at ";
		sFailureMsg.append(componentId).append(" to New Name ").append(documentName).append(" In static assembly ").append(staticAsmID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}	
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessDocumentName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	wstring sOwnerId, documentName;
	ProCharPath ownerID;
	ProCharLine name;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		sOwnerId = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		documentName = data.v.w;

		GeometryFacadeWideStringToString(ownerID, sOwnerId.c_str());
		GeometryFacadeWideStringToString(name, documentName.c_str());

		int iOut = ProcessDocumentName_wrapper(ownerID,name);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;		
		arg.value.v.i = iOut;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed While Processing Document Name for Owner at Path: ";
		sFailureMsg.append(ownerID).append(" with Document Name : ").append(name);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}	
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameFamilyTableInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProCharPath cInstCrntNm, cInstNewNm, cGnrcPath;

	try
	{
		wstring instName, instNewName, path;
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG1",&data);
		instName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG2",&data);
		instNewName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments,L"ARG3",&data);
		path = data.v.w;

		GeometryFacadeWideStringToString(cInstCrntNm, instName.c_str());
		GeometryFacadeWideStringToString(cInstNewNm, instNewName.c_str());
		GeometryFacadeWideStringToString(cGnrcPath, path.c_str());

		RenameFamilyTableInstance_wrapper(cInstCrntNm,cInstNewNm,cGnrcPath);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed While Renaming Family Table Instance for Owner at Path: ";
		sFailureMsg.append(cGnrcPath).append(" for Instance : ").append(cInstCrntNm).append(" new name to apply was : ").append(cInstNewNm);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetModelNameByID_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring idPath;
	ProCharPath id;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.w;

		GeometryFacadeWideStringToString(id, idPath.c_str());

		std::wstring output = GetModelNameByID_wrapper(id);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, output.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Get Model Name for ID : ";
		sFailureMsg.append(id);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SaveModelByID_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring idPath;
	ProCharPath id;
	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		idPath = data.v.w;

		GeometryFacadeWideStringToString(id, idPath.c_str());

		SaveModelByID_wrapper(id);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);
		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, L"");
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Save Model Name for ID : ";
		sFailureMsg.append(id);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

// Save the model for given id. 
static void SaveModelByID_wrapper(std::string idPath)
{
	try
	{
		GeometryFacadeMdl model = NULL;
		GetAsmcompMdl(idPath, &model);

		GeometryFacadeSaveMdl(model);
	}
	catch(ProeException ex)
	{
		LOG << "SaveModelByID_wrapper: Model is not found with ID: " << idPath <<endl;
	}
}

// Returns model name for given id.
static std::wstring GetModelNameByID_wrapper(std::string idPath)
{
	ProName mdlName;
	mdlName[0]='\0';
	
	try
	{
		// Get the model id path.
		GeometryFacadeMdl model = NULL;
		GetAsmcompMdl(idPath, &model);

		// Get model name and add extension.
		ProError status = ProMdlNameGet(model,mdlName);
		if(status==PRO_TK_NO_ERROR)
		{
			ProMdlType mdlType;
			mdlType = GeometryFacadeGetMdlType(model);
			if(mdlType==PRO_MDL_PART)
			{
				wcscat( mdlName, L".prt");
			}
			if(mdlType==PRO_MDL_ASSEMBLY)
			{
				wcscat( mdlName, L".asm");
			}
		}
	}
	catch(ProeException ex)
	{
		LOG << "GetModelNameByID_wrapper: Model is not found with ID: " << idPath <<endl;
	}

	return mdlName;
}

// Public functions.
static std::string GetListOfModelsInSession_wrapper()
{
	std::string sAllMdlLst;

	//1st get all assemblies list
	std::string sLst = GetListOfModel(GEOMETRY_FACADE_MDL_ASSEMBLY);

	if(strlen(sLst.c_str()) != 0)
		sAllMdlLst = sLst;

	//Now get all parts list
	sLst = GetListOfModel(GEOMETRY_FACADE_MDL_PART);

	if(strlen(sAllMdlLst.c_str()) == 0 && (strlen(sLst.c_str()) != 0))
		sAllMdlLst = sLst;
	else if(strlen(sLst.c_str()) != 0)
	{
		sAllMdlLst.append(",").append(sLst);
	}

	LOG << "GetListOfModelsInSession_wrapper: Returning final list " <<  sAllMdlLst << endl;
	return sAllMdlLst;
}

std::string GetListOfModel(GeometryFacadeMdlType pMdlType)
{
	std::string sAllMdlList;
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl *pSessionMdlLst = NULL;
		int iNoMdl = 0;

		result = ProSessionMdlList(pMdlType  , &pSessionMdlLst , &iNoMdl);
		LOG << "GetListOfModel: Models in session <" << iNoMdl << "> of Type <" <<  pMdlType << ">." << endl;
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			for(int i = 0 ; i<iNoMdl ; i++)
			{
				GeometryFacadeName wMdlNm = {};				
				char cMdlName[GEOMETRY_FACADE_LINE_SIZE];
				std::string sMdlFullName;
				GeometryFacadeGetMdlName(pSessionMdlLst[i] , wMdlNm);
				GeometryFacadeWideStringToString(cMdlName , wMdlNm);
				sMdlFullName = cMdlName;

				GeometryFacadeMdlType pMdlType = GeometryFacadeGetMdlType(pSessionMdlLst[i]);
				if(pMdlType == GEOMETRY_FACADE_MDL_PART)
					sMdlFullName.append(".PRT");
				else if(pMdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
					sMdlFullName.append(".ASM");

				if(strlen(sAllMdlList.c_str()) == 0)
					sAllMdlList = sMdlFullName;
				else
				{
					sAllMdlList.append(",").append(sMdlFullName);
				}				
			}
		}

		if(pSessionMdlLst != NULL)
			ProArrayFree((ProArray*)&pSessionMdlLst);
	}
	catch(ProeException ex)
	{
		LOG << "Addin: GetListOfModel: FAILED: While retreiving session model list" << endl;
	}
	return sAllMdlList;
}

//Performs renaming of instances from family table.
//cInstCrntNm = Name of current Instance 
//cInstNewNm = New instance name.
//cGnrcPath = ID Path of the geometry with Family table.
void RenameFamilyTableInstance_wrapper(char *cInstCrntNm,char *cInstNewNm,char *cGnrcPath)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl cCrntMdl = NULL,cGnrcMdl = NULL;
	GeometryFacadeModelItem pMdlItem; 
	int iCmp = 0;

	std::string sPrmName = GetValidParameterName(cInstCrntNm);
	LOG << "Valid Parameter Name processed as : " << sPrmName << " Earlier name was : " << cInstCrntNm << endl;

	//Get current model handle.
	GetAsmcompMdl(cGnrcPath,&cCrntMdl);  

	//check if current part is generic or instnace , if instance change it to generic and the process.
	result = ProSolidFamtableCheck((GeometryFacadeSolid)cCrntMdl);

	if(result == GEOMETRY_FACADE_EMPTY)
		ProFaminstanceGenericGet(cCrntMdl,PRO_B_TRUE,&cGnrcMdl);
	else
		cGnrcMdl = cCrntMdl;

	GeometryFacadeMdlToModelItem(cGnrcMdl,&pMdlItem);

	//Check processing paramter and retreive value stored earlier.
	bool bIsPrmExist = CheckParameterExist(pMdlItem,sPrmName.c_str(),cInstCrntNm,cInstNewNm);
	LOG << "Current instance name : " << cInstCrntNm << endl;

	//If paramter doesn't exist create it and assign value.
	if(!bIsPrmExist)
	{
		ProParamvalue Pvalue;
		GeometryFacadeLine wParmVal;
		GeometryFacadeStringToWideString(wParmVal,cInstNewNm);
		ProParamvalueSet(&Pvalue,&wParmVal,PRO_PARAM_STRING);

		//Assign Name to Parameter.
		GeometryFacadeName wParmName = {};
		GeometryFacadeStringToWideString(wParmName,&sPrmName[0]);

		//Create Parameter for Instance.
		GeometryFacadeParameter pParameter;
		GeometryFacadeCreateParameter(&pMdlItem,wParmName,&Pvalue,&pParameter);
	}

	//Check if instance is already renamed.
	iCmp = _stricmp(cInstCrntNm,cInstNewNm);

	if(iCmp != 0)
	{
		ProFamtable pFmTbl;
		GeometryFacadeName pInstNm;			
		ProFaminstance pFmInst;
		GeometryFacadeStringToWideString(pInstNm,cInstCrntNm);
		result = ProFamtableInit(cGnrcMdl,&pFmTbl);
		result = ProFaminstanceInit(pInstNm,&pFmTbl,&pFmInst);
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "Instance initialization completed , get model out of it." << endl;
			GeometryFacadeMdl pInstModel = NULL;
			result = ProFaminstanceCreate(&pFmInst,&pInstModel);
			GeometryFacadeStringToWideString(pInstNm,cInstNewNm);			
			LOG << "Model created with result : " <<  result << "Renaming instance at : " << cGnrcPath << " as : " << cInstNewNm << endl;
			GeometryFacadeRenameMdl(pInstModel,pInstNm);
			GeometryFacadeSaveMdl(cGnrcMdl);
			GeometryFacadeEraseMdl(pInstModel);
			LOG << "Instance at : " << cGnrcPath << " is renamed to : " << cInstNewNm << endl;
		}
		else
			LOG << "Instance initialization failed with result as : " << result << " for instance having current name : " << cInstCrntNm << endl;
	}
	else
		LOG << "Instance name at path : " << cGnrcPath << " already modified" << endl;
}

//ProE accepts parameter name which does not starts with a digit and does not has any special
//character.Following method will find such characters in cInstCrntNm and replace it with "R".
std::string GetValidParameterName(std::string cInstCrntNm)
{
	std::string sTemp = cInstCrntNm;
	for(int i = 0;i<(int)sTemp.length();i++)
	{
		char c = sTemp[i];
		int alNum;

		if(i == 0)
			alNum = isdigit(c); //First character should not be digit.
		else
			alNum = isalnum(c);

		if((alNum != 0 && i == 0) || alNum == 0)
		{
			sTemp.replace(i,1,"R");
		}
	}
	return sTemp;
}

bool CheckParameterExist(GeometryFacadeModelItem pInstMdlItm,const char *CParmName,char *cInstName,char *cInstNewNm)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeName pParamNm;
	GeometryFacadeParameter pParamObj;
	GeometryFacadeParameterValue pParamVal;
	GeometryFacadeStringToWideString(pParamNm,CParmName);
	result = ProParameterInit(&pInstMdlItm,pParamNm,&pParamObj);

	if(result != GEOMETRY_FACADE_NO_ERROR)	
		return false;

	LOG << "Parameter already exist , now check there value and modify if required" << endl;
	char *cCrntPrmVal = new char[sizeof(GeometryFacadeName)+1];
	result = ProParameterValueGet(&pParamObj,&pParamVal);
	GeometryFacadeWideStringToString(cCrntPrmVal,pParamVal.value.s_val);
	int iCmpRslt = _stricmp(cCrntPrmVal,cInstNewNm);
	if(iCmpRslt != 0)
	{
		SetNewValueForParamater(pParamObj,&pParamVal,cInstNewNm);
		LOG << "Set new value as : " << cInstNewNm << " for parameter : " << cInstName << endl;
	}

	strcpy(cInstName,cCrntPrmVal);

	delete []cCrntPrmVal;
	return true;
}

void SetNewValueForParamater(GeometryFacadeParameter pParamObj,GeometryFacadeParameterValue *pParamVal,char *cParamVal)
{
	GeometryFacadeLine wParmVal;
	GeometryFacadeStringToWideString(wParmVal,cParamVal);
	ProParamvalueSet(pParamVal,&wParmVal,PRO_PARAM_STRING);
	ProParameterValueSet(&pParamObj,pParamVal);
}

//method to process component renaming for static assembly components.
int ProcessDocumentNameForStaticAsmComponent_wrapper(std::string sStaticAsmId , std::string sComponentId , char* cDocumentName)
{
	LOG << "RenameStaticAssemblyCompnent: Started..." << endl;

	std::string sCompAsmId;
	int compId = 0;
	GeometryFacadeMdl pStaticAsm = NULL , pContainerAsm = NULL , pCompToRename = NULL;		

	LOG << "RenameStaticAssemblyCompnent: Get Static Assembly handle at Id <" << sStaticAsmId << ">." << endl;
	GetAsmcompMdl(sStaticAsmId , &pStaticAsm);		//Get Parent Static Asm Handle

	//now get handle of component to rename
	std::string sCompCompletePath;
	sCompCompletePath = sCompCompletePath.append(sStaticAsmId).append(",").append(sComponentId);	
	LOG << "RenameStaticAssemblyCompnent: Get Handle of Component to Rename at Id <" << sCompCompletePath << ">." << endl;
	GetAsmcompMdl(sCompCompletePath , &pCompToRename);

	//now get handle of container assembly , which actually contains the component to rename.
	std::size_t nPos = sComponentId.find_last_of(",");
	if(nPos == string::npos)
		sCompAsmId = ""; //static assembly is TL Asm
	else
		sCompAsmId = sComponentId.substr(0 , nPos);

	if(strlen(sStaticAsmId.c_str()) != 0)
	{
		std::string sTemp = sStaticAsmId;
		sCompAsmId =  sTemp.append(",").append(sCompAsmId);
	}

	LOG << "RenameStaticAssemblyCompnent: Get Handle of Assembly containing the rename component at Id <" << sCompAsmId << ">." << endl;
	GetAsmcompMdl(sCompAsmId , &pContainerAsm);

	//get current name of model to rename..
	GeometryFacadeName wStcCompName;
	GeometryFacadeMdlType pCompType;

	GeometryFacadeGetMdlName(pCompToRename , wStcCompName);
	char cCompCrntName[GEOMETRY_FACADE_FILE_NAME_SIZE];
	ProWstringToString(cCompCrntName , wStcCompName);

	//check component current name with new name , if not-equal then only renaming is required..
	ProName fileName;
	GeometryFacadeStringToWideString(fileName, cDocumentName);
	int iCmp =  _wcsicmp(fileName, wStcCompName);

	if(iCmp != 0)
	{
		//as new name to be applied is different , lets continue with renaming..
		LOG << "RenameStaticAssemblyCompnent: Component current name and new name are different , renaming continues.." << endl;
		//append valid extension to form complete name..
		pCompType = GeometryFacadeGetMdlType(pCompToRename);	
		if(pCompType == GEOMETRY_FACADE_MDL_PART)
			strcat(cCompCrntName , ".PRT");
		else if(pCompType == GEOMETRY_FACADE_MDL_ASSEMBLY)
			strcat(cCompCrntName , ".ASM");

		//Collect All components from the parent static assembly , excluding the component to be renamed.		
		LOG << "RenameStaticAssemblyCompnent: Retreive all component names al ALL level from parent static assembly." << endl;
		vStringValContainer.clear();
		GetAllComponentNameOfStaticAssembly(pStaticAsm , sCompCompletePath , true);
		vector<std::string> vAllStcAsmComps = vStringValContainer;	

		//now Collect ONLY components at same level of components to rename , exclude component to rename
		LOG << "RenameStaticAssemblyCompnent: Retreive all component names at level of container assembly" << endl;
		vStringValContainer.clear();
		GetAllComponentNameOfStaticAssembly(pContainerAsm , sCompCompletePath , false);
		std::vector<std::string> vCompsAtSameLevel = vStringValContainer;		

		//now both lists will be processed in which if container asm contains more than one instance of component to be renamed
		//it will be removed..
		//<TODO> Improve it by using vector iterator
		for(int i = 0; i < (int)vAllStcAsmComps.size() ; i++)
		{
			if(stricmp(vAllStcAsmComps[i].c_str() , vCompsAtSameLevel[0].c_str()) == 0)//match top static assembly with assembly containing part to rename.
			{	
				LOG << "RenameStaticAssemblyCompnent: Container assembly found in parent assembly at Index <" <<  i << ">." << endl;
				for(int j = 0; j<(int)vCompsAtSameLevel.size() ; j++)
				{
					int iCount = i+j;						
					char *cCompName = const_cast<char*>(vAllStcAsmComps[iCount].c_str());
					LOG << "RenameStaticAssemblyCompnent: Component at index <" << iCount << "> is <" << cCompName << ">." << endl;
					if((stricmp(cCompName , cCompCrntName) == 0) && i != 0)
					{
						vAllStcAsmComps.erase(vAllStcAsmComps.begin() + (iCount)); //it will remove instance of component from all component list. it will be useful in next comp. check..
						j -= 1; //after erase operation vector elements will be moved up , it will change position of component. So this adjustment is done.
						LOG << "RenameStaticAssemblyCompnent: Component instance <" << vAllStcAsmComps[iCount] << "> found in parent assembly at Index  <" <<  i << "> , removed from parent assembly component list" << endl;
					}
				}			
				break;
			}
		}

		//now check if there are instances of component to rename at any level of assembly.		
		//<TODO>Use std::find instead of loop.
		bool bCompInstExist = false;
		for(int i = 0; (int)i < vAllStcAsmComps.size() ; i++)
		{			
			if(stricmp(vAllStcAsmComps[i].c_str() , cCompCrntName) == 0)
			{
				LOG << "RenameStaticAssemblyCompnent: Current Component <" << cCompCrntName << "> Instance exist in parent static assembly at Index <" << i << ">" << endl; 
				bCompInstExist = true;
			}
		}

		//if , it has then we will have to go for Component Replace..
		if(bCompInstExist)
		{
			LOG << "RenameStaticAssemblyCompnent: There are instances of component <" << cCompCrntName << "> exist in static assembly , so performing rename replacement for this particular component" << endl; 
			//current component has instances at different level of static assembly. we can't perform geometry rename as it will rename other instances.
			//in this case we will copy current component with new name.
			//and replace copied component with new component.
			GeometryFacadeMdl pPartToReplace = NULL;
			pPartToReplace = GetPartToReplace(pCompToRename , cDocumentName);
			LOG << "RenameStaticAssemblyCompnent: Part to replace is retreived" << endl; 

			//Now perform actual component replacement..
			//this replacement will modify id of component , this need to be returned and respective MasterDoc will need to update with it.
			compId = PerformComponentReplacement(pContainerAsm , pPartToReplace , sCompCompletePath , sStaticAsmId , cDocumentName);

			if(std::find(vCompsAtSameLevel.begin() , vCompsAtSameLevel.end() , cCompCrntName) != vCompsAtSameLevel.end())
			{				 				 
				vStringValContainer.clear();
				CollectAllInstanceId(pContainerAsm , cCompCrntName);
				for(int i = 0; i<(int)vStringValContainer.size(); i++)
				{					 
					std::string sInstIdPath = sCompAsmId;
					sInstIdPath = sInstIdPath.append(",").append(vStringValContainer[i]);	 
					PerformComponentReplacement(pContainerAsm , pPartToReplace , sInstIdPath , sStaticAsmId ,  cDocumentName);//no need to update instance comp id.
				}
			}
		}
		else
		{
			//So far There are no seperate instances of Component to rename exist in assembly 
			//but before rename we must check if there are any components with this name already exist in parent static assembly.
			//for such parts only rename will not work , they will have to be replaced with existing part.
			std::string sPartWidNewDocName = cDocumentName;
			if(pCompType == GEOMETRY_FACADE_MDL_PART)
				sPartWidNewDocName.append(".PRT");
			else if(pCompType == GEOMETRY_FACADE_MDL_ASSEMBLY)
				sPartWidNewDocName.append(".ASM");

			std::transform(sPartWidNewDocName.begin(), sPartWidNewDocName.end(), sPartWidNewDocName.begin(), toupper);
			LOG << "New Name would be : " <<  sPartWidNewDocName << endl;
			if(std::find(vAllStcAsmComps.begin() , vAllStcAsmComps.end() , sPartWidNewDocName) != vAllStcAsmComps.end())
			{
				LOG << "RenameStaticAssemblyCompnent: Static assembly already contains component with new name <" << sPartWidNewDocName  << "> , this component will be used for replacement." << endl;

				GeometryFacadeMdl pPartToReplace = NULL;
				pPartToReplace = GetPartToReplace(pCompToRename , cDocumentName);
				LOG << "RenameStaticAssemblyCompnent: Part to replace is retreived" << endl;

				//Now perform actual component replacement..
				//this replacement will modify id of component , this need to be returned and respective MasterDoc will need to update with it.
				compId = PerformComponentReplacement(pContainerAsm , pPartToReplace , sCompCompletePath , sStaticAsmId , cDocumentName);
				if(std::find(vCompsAtSameLevel.begin() , vCompsAtSameLevel.end() , cCompCrntName) != vCompsAtSameLevel.end())
				{				 				 
					vStringValContainer.clear();
					CollectAllInstanceId(pContainerAsm , cCompCrntName);
					for(int i = 0; i<(int)vStringValContainer.size(); i++)
					{					 
						std::string sInstIdPath = sCompAsmId;
						sInstIdPath = sInstIdPath.append(",").append(vStringValContainer[i]);	 
						PerformComponentReplacement(pContainerAsm , pPartToReplace , sInstIdPath , sStaticAsmId ,  cDocumentName);//no need to update instance comp id.
					}
				}
			}
			else
			{
				//Component with new name does not exist , rename component.
				LOG << "RenameStaticAssemblyCompnent: There are no component/instance with new name , so performing rename operation" << endl; 
				GeometryFacadeName wDocName;
				GeometryFacadeStringToWideString(wDocName , cDocumentName);
				GeometryFacadeRenameMdl(pCompToRename ,wDocName);
			}
		}		
		GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(pStaticAsm), GEOMETRY_FACADE_REGEN_NO_FLAGS);
	}	
	return compId;
}

void CollectAllInstanceId(GeometryFacadeMdl pContainerAsm , char* CompCrntName)
{
	GeometryFacadeVisitSolidFeature((GeometryFacadeSolid)pContainerAsm , (GeometryFacadeFeatureVisitAction)CollectComponentInstanceId , (GeometryFacadeFeatureFilterAction)FeatureFilterAction , (GeometryFacadeAppData)&CompCrntName);
}

GeometryFacadeError CollectComponentInstanceId(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData)
{
	try
	{
		if(feature != NULL)
		{		
			char **cCompToRename = (char **)appData;	

			GeometryFacadeMdl featMdl;
			GeometryFacadeMdlData featMdlData;
			GeometryFacadeAsmCompMdl(feature,&featMdl);

			//instance current name..
			GeometryFacadeGetMdlData(featMdl , &featMdlData);
			GeometryFacadeMdlType mdlType = GeometryFacadeGetMdlType(featMdl);

			std::stringstream cFileName;
			char cFile[GEOMETRY_FACADE_LINE_SIZE];

			GeometryFacadeWideStringToString(cFile , featMdlData.name);		

			//now form the name..
			cFileName << cFile;
			if(mdlType == GEOMETRY_FACADE_MDL_PART)
				cFileName << ".PRT";
			else if(mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
				cFileName << ".ASM";

			if(featMdl != NULL && _stricmp(cFileName.str().c_str() , *cCompToRename) == 0)
			{
				//it is a instance component , store its id..
				char sId[10];
				itoa(feature->id , sId , 10);
				vStringValContainer.push_back(sId);
			}		
		}
	}
	catch(ProeException ex)
	{
		LOG << "CollectComponentInstanceId: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl; 		
	}

	return GEOMETRY_FACADE_NO_ERROR;
}

int PerformComponentReplacement(GeometryFacadeMdl pContainerAsm , GeometryFacadeMdl pPartToReplace , std::string sCompCompletePath , std::string sStaticId , char *NewComponentName)
{
	int iCompId = 0;

	try
	{
		LOG << "PerformComponentReplacement: In Static Assembly <" << sStaticId << "> with New Component Name <" <<  NewComponentName << "> at Id Path <" << sCompCompletePath  << ">." << endl;

		//get actual Id of Model..
		std::size_t pos = sCompCompletePath.find_last_of(",");
		std::string sCompId;


		if(pos == string::npos)
			sCompId = sCompCompletePath;
		else
			sCompId = sCompCompletePath.substr(pos+1);

		//Perform constrain operation..
		GeometryFacadeAsmComp pAsmComp;
		int table[25];
		int table_size;
		GeometryFacadeAsmCompPath pAsmCompPath;
		fillPathTable(sCompCompletePath, table, &table_size);
		GeometryFacadeError result = ProAsmcomppathInit((ProSolid)pContainerAsm,table,table_size,&pAsmCompPath); 
		GetAsmcomp(pAsmCompPath,&pAsmComp);
		GeometryFacadeAsmCompConstraint *pAsmConstr;
		result = ProArrayAlloc(0,sizeof(ProAsmcompconstraint),1,(ProArray*)&pAsmConstr);
		//If Current component has constrains remove it.
		if(ProAsmcompConstraintsGet(&pAsmComp,&pAsmConstr) == GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "PerformComponentReplacement: Static assembly component is constrained , removing them from current component" << endl;
			result = ProAsmcompConstrRemove(&pAsmComp,-1);
		}

		int iMdlId = 0;
		sscanf(sCompId.c_str(),"%d",&iMdlId);	

		//Get feature number for the assembly component...
		int iFeatNumber = -1;
		GeometryFacadeFeature pFeature;
		result = ProFeatureInit((GeometryFacadeSolid)pContainerAsm , iMdlId , &pFeature);
		result = ProFeatureNumberGet(&pFeature , &iFeatNumber);
		LOG << "Component with Id : " << sCompCompletePath << " has feature number " << iFeatNumber << " in the assembly file " << endl;

		GeometryFacadeArray pCompIds;
		pCompIds = GeometryFacadeAllocateArray(0,sizeof(int),1);
		GeometryFacadeAddArrayObject(&pCompIds,-1,1,&iMdlId);

		result = ProAssemblyAutointerchange((GeometryFacadeAssembly)pContainerAsm,(int*)pCompIds,pPartToReplace);
		LOG << "PerformComponentReplacement: Component interchange completed with result <" << result << ">." << endl;

		//Add calls to regenerate assembly
		char cNewId[10];
		iCompId = GetNewPartModelID(pContainerAsm , NewComponentName , iFeatNumber);
		itoa(iCompId , cNewId , 10);
		sCompCompletePath.replace(pos+1 , strlen(sCompId.c_str()) + 1 , cNewId);		//replace old comp id in path with new Id , so that complete path to reach component can be formed.
		LOG << "PerformComponentReplacement: Component Replacement Succeded , now Re-Constrain new component at new Id Path <<" << sCompCompletePath << endl;

		ReConstrainReplacedComponent(pContainerAsm , sCompCompletePath ,  sStaticId ,  pAsmConstr);

		if(pCompIds != NULL)
			GeometryFacadeFreeArray(&pCompIds);

		GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(pContainerAsm), GEOMETRY_FACADE_REGEN_NO_FLAGS);
		LOG << "PerformComponentReplacement: Component Replacement and Re-Constraining completed now returing new component Id as <" << iCompId << ">." << endl;
	}
	catch(ProeException ex)
	{
		LOG << "PerformComponentReplacement: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl;
		LOG << "PerformComponentReplacement: Failed to replace component at <" << sCompCompletePath << "> with new component <" << NewComponentName << ">." << endl;
	}

	return iCompId;//return Id of replaced component.
}

void ReConstrainReplacedComponent(GeometryFacadeMdl pContainerAsm , std::string sCompCompletePath , std::string sStaticId , GeometryFacadeAsmCompConstraint *pAsmConstr)
{	
	try
	{
		int iNoCon = -1;
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		iNoCon = GeometryFacadeGetArraySize((GeometryFacadeArray)pAsmConstr);	

		LOG << "ReConstrainReplacedComponent: In Static Assembly <<"  << sStaticId << "> at Id Path <" << sCompCompletePath << ", Total Constrain count <" << iNoCon << ">." << endl;

		for(int i = 0 ; i< iNoCon ; i++)
		{
			GeometryFacadeSelection pAsmSel;
			GeometryFacadeDatumSide pAsmDatumSide;
			GeometryFacadeModelItem pAsmMdlItem;
			GeometryFacadeAsmCompPath pAsmCompPath;
			GeometryFacadeName wReferenceName;
			char cRefName[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeModelItem datum_1, datum_2;
			GeometryFacadeAsmCompPath part_1_path, part_2_path;
			GeometryFacadeMdl mdl1 , mdl2;	

			//Get AsmCompPath for Assembly reference		
			result = ProAsmcompconstraintAsmreferenceGet(pAsmConstr[i] , &pAsmSel , &pAsmDatumSide);
			result = ProSelectionAsmcomppathGet(pAsmSel , &pAsmCompPath);
			std::string sAsmCrntIdPath = GetCompCurrentIdPath(pAsmCompPath , sStaticId); //at 0th index AsmCompPath is stored
			GetAsmcompPath(sAsmCrntIdPath , &part_2_path);

			//Retreive Assembly Reference..		
			result = ProSelectionModelitemGet(pAsmSel , &pAsmMdlItem);
			result = ProModelitemNameGet(&pAsmMdlItem , wReferenceName);
			ProWstringToString(cRefName , wReferenceName);
			//using datum name initialize datum with new Assembly with replaced component				 
			GeometryFacadeGetAsmCompPathMdl(&part_2_path, &mdl2);		
			ProModelitemByNameInit(mdl2, pAsmMdlItem.type, wReferenceName, &datum_2);

			//Get AsmCompPath for Component reference				
			GetAsmcompPath(sCompCompletePath , &part_1_path);

			//Retreive Component Items
			result = ProAsmcompconstraintCompreferenceGet(pAsmConstr[i] , &pAsmSel , &pAsmDatumSide);
			result = ProSelectionModelitemGet(pAsmSel , &pAsmMdlItem);
			result = ProModelitemNameGet(&pAsmMdlItem , wReferenceName);		
			GeometryFacadeGetAsmCompPathMdl(&part_1_path, &mdl1);		
			ProModelitemByNameInit(mdl1, pAsmMdlItem.type, wReferenceName , &datum_1);//at 1th index Comp Model Item is stored

			GeometryFacadeSelection selection_1 = GeometryFacadeAllocateSelection(&part_1_path, &datum_1);
			GeometryFacadeSelection selection_2 = GeometryFacadeAllocateSelection(&part_2_path, &datum_2);

			//Set Constraint type..
			GeometryFacadeAsmCompConstraintType pconType;
			result = ProAsmcompconstraintTypeGet(pAsmConstr[i] , &pconType);
			GeometryFacadeSetAsmCompConstraintType(pAsmConstr[i], pconType);

			//Now set references..
			GeometryFacadeSetAsmCompConstraintCompReference(pAsmConstr[i], selection_1, GEOMETRY_FACADE_DATUM_SIDE_YELLOW);
			GeometryFacadeSetAsmCompConstraintAsmReference(pAsmConstr[i], selection_2, GEOMETRY_FACADE_DATUM_SIDE_YELLOW);

			//now store common items
			double dOffsetVal = 0;
			result = ProAsmcompconstraintOffsetGet(pAsmConstr[i] , &dOffsetVal);

			if(dOffsetVal != 0)
			{
				GeometryFacadeSetAsmCompConstraintOffset(pAsmConstr[i], dOffsetVal);
			}
		}

		////Re-constrain loaded component..
		GeometryFacadeAsmCompPath pReplacdCompPath;
		GetAsmcompPath(sCompCompletePath , &pReplacdCompPath);

		GeometryFacadeAsmCompPath owner_asmcomp_path;
		GeometryFacadeAsmComp constrainted_component;

		GetParentAsmcompPath(pReplacdCompPath , &owner_asmcomp_path);
		GetAsmcomp(pReplacdCompPath, &constrainted_component);

		// Finally, constrain the damn thing.
		GeometryFacadeSetAsmCompConstraints(&owner_asmcomp_path, &constrainted_component, pAsmConstr);
	}
	catch(ProeException ex)
	{
		LOG << "ReConstrainReplacedComponent: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl;
		LOG << "ReConstrainReplacedComponent: Failed to Re-Constrain component at <" <<  sCompCompletePath << ">" << endl;
	}	

	if (GeometryFacadeGetArraySize(pAsmConstr) > 0) 
	{
		GeometryFacadeFreeAsmCompConstraintArray(pAsmConstr);
	}

	LOG << "ReConstrainReplacedComponent: Completed" << endl;
}

std::string GetCompCurrentIdPath(GeometryFacadeAsmCompPath pAsmCompPath , std::string sStaticId)
{
	std::string sFinalStr;

	try
	{
		std::string idPath;
		for(int i = 0;i<pAsmCompPath.table_num;i++)
		{
			int iNo;
			iNo = pAsmCompPath.comp_id_table[i];
			char cTemp[10];
			itoa(iNo , cTemp , 10);
			if(strlen(idPath.c_str()) == 0)
			{			
				idPath = cTemp;
			}
			else
			{
				idPath.append(",").append(cTemp);			
			}
		}

		sFinalStr = sStaticId;
		sFinalStr = sFinalStr.append(",").append(idPath);

	}
	catch(ProeException ex)
	{
		LOG << "GetCompCurrentIdPath: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl; 
	}	
	return sFinalStr;
}

GeometryFacadeMdl GetPartToReplace(GeometryFacadeMdl pCompToRename , char *cDocumentName)
{
	GeometryFacadeMdl pPartToReplace = NULL;

	try
	{
		GeometryFacadeMdlType pMdlType;

		pMdlType = GeometryFacadeGetMdlType(pCompToRename);
		GeometryFacadeName wDocName;
		ProStringToWstring(wDocName , cDocumentName);

		if(ProMdlInit(wDocName , pMdlType , &pPartToReplace) == GEOMETRY_FACADE_NO_ERROR)
		{
			//part with same new name already exist in current session , it is initialized use this for replacement.
			if(pPartToReplace != NULL)
			{
				return pPartToReplace;
			}
		}

		//Part with New DocumentName does not exist create a copy of CompToRename with new name and use it for replacement..
		GeometryFacadeError result = ProMdlCopy(pCompToRename , wDocName , &pPartToReplace);
		if(result == GEOMETRY_FACADE_NO_ERROR && pPartToReplace != NULL)
		{
			return pPartToReplace;
		}
	}
	catch(ProeException ex)
	{
		LOG << "GetPartToReplace: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl;
		LOG << "GetPartToReplace: Failed to get part for <" << cDocumentName << ">" << endl;
	}	

	return pPartToReplace;
}

void GetAllComponentNameOfStaticAssembly(GeometryFacadeMdl pStaticAsm , std::string sCompToRename , bool bIncludeSubAsm)
{	
	try
	{
		//1st insert container assembly name..
		GeometryFacadeMdlData mdlData;
		GeometryFacadeMdlType mdlType;
		GeometryFacadeGetMdlData(pStaticAsm , &mdlData);
		mdlType = GeometryFacadeGetMdlType(pStaticAsm);

		std::stringstream cFileName;
		char cFile[GEOMETRY_FACADE_LINE_SIZE];

		GeometryFacadeWideStringToString(cFile , mdlData.name);		

		//now form the name..
		cFileName << cFile;
		if(mdlType == GEOMETRY_FACADE_MDL_PART)
			cFileName << ".PRT";
		else if(mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
			cFileName << ".ASM";

		vStringValContainer.push_back(cFileName.str());
		LOG << "GetAllComponentNameOfStaticAssembly: Insert Assembly <" << cFileName.str() << ">." << endl;

		if(bIncludeSubAsm)
		{
			GeometryFacadeVisitSolidFeature((GeometryFacadeSolid)pStaticAsm , (GeometryFacadeFeatureVisitAction)CollectAllAsmCompName , (GeometryFacadeFeatureFilterAction)FeatureFilterAction , (GeometryFacadeAppData)&sCompToRename);
		}
		else
		{
			GeometryFacadeVisitSolidFeature((GeometryFacadeSolid)pStaticAsm , (GeometryFacadeFeatureVisitAction)CollectSingleLevelCompName , (GeometryFacadeFeatureFilterAction)FeatureFilterAction , (GeometryFacadeAppData)&sCompToRename);
		}

	}
	catch(ProeException ex)
	{
		LOG << "GetAllComponentNameOfStaticAssembly: Caught Outer exception <" << ex.GetMsg() << "> @ <"  << ex.GetLine() << ">" << endl;
	}
}

GeometryFacadeError CollectAllAsmCompName(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData)
{
	if(feature != NULL)
	{				
		std::string *sCompToRename = (std::string*)appData;
		AddComponentInstanceIntoList(feature , sCompToRename , true);		
	}
	return GEOMETRY_FACADE_NO_ERROR;//always return NO error so that visiting can be continued
}

GeometryFacadeError CollectSingleLevelCompName(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData)
{
	if(feature != NULL)
	{		
		std::string *sCompToRename = (std::string*)appData;		
		AddComponentInstanceIntoList(feature , sCompToRename , false);//Do not include sub-assembly components.
	}
	return GEOMETRY_FACADE_NO_ERROR;
}

void AddComponentInstanceIntoList(GeometryFacadeFeature *feature , std::string *sCompToRename , bool bIncludeSubAsm)
{
	try
	{
		//1st collect info about part to rename		
		GeometryFacadeMdl pCompToRename;		
		GetAsmcompMdl(sCompToRename->c_str() , &pCompToRename);

		//GetId of it..
		std::size_t iPos = sCompToRename->find_last_of(",");
		std::string sId;
		if(iPos == string::npos)
			sId = sCompToRename->c_str();
		else
			sId = sCompToRename->substr(iPos+1);

		int Id = atoi(sId.c_str());

		//now collect info about currently visited feature
		GeometryFacadeMdl mdl;
		GeometryFacadeMdlData mdlData;
		GeometryFacadeMdlType mdlType;
		GeometryFacadeAsmCompMdl(feature,&mdl);
		GeometryFacadeGetMdlData(mdl , &mdlData);
		mdlType = GeometryFacadeGetMdlType(mdl);

		std::stringstream cFileName;
		char cFile[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(cFile , mdlData.name);		

		//now form the name..
		cFileName << cFile;
		if(mdlType == GEOMETRY_FACADE_MDL_PART)
			cFileName << ".PRT";
		else if(mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
			cFileName << ".ASM";

		//if current part is sub-assembly get its component..
		if(mdlType == GEOMETRY_FACADE_MDL_ASSEMBLY && bIncludeSubAsm && (pCompToRename != mdl || (Id != feature->id)))
		{
			GetAllComponentNameOfStaticAssembly(mdl , sCompToRename->c_str() , bIncludeSubAsm);
		}
		else 	if(pCompToRename != mdl || (Id != feature->id))
		{				
			vStringValContainer.push_back(cFileName.str()); //insert into global list
			LOG << "GetAllComponentNameOfStaticAssembly: Insert Component <" << cFileName.str() << ">." << endl;
		}

	}
	catch(ProeException ex)
	{
		LOG << "AddComponentInstanceIntoList: Caught Outer exception <" << ex.GetMsg() << "> @ <" << ex.GetLine() << ">." << endl;
		LOG << "AddComponentInstanceIntoList: Failed to Add Instance information for Component <" << feature->id << ">." << endl;
	}	

}

//sOwnerId = Id Path of the model.
//cDocumentName = Name of the document.
int ProcessDocumentName_wrapper(string sOwnerId,char *cDocumentName)
{
	GeometryFacadeMdl pOwnerHndl = NULL;
	GeometryFacadeName wDocName,wmdlName;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	int i = _stricmp("DRW",sOwnerId.c_str());
	if(i == 0)
	{
		//Get Handle of Drawing
		//GeometryFacadeGetCurrentMdl(&pOwnerHndl);
		int iWinID;
		ProWindowCurrentGet(&iWinID);
		ProWindowMdlGet(iWinID,&pOwnerHndl);
	}
	else
	{
		//Get Handle of component
		GetAsmcompMdl(sOwnerId, &pOwnerHndl);
	}

	//Applying document names to Family Table Instances is not supported..
	//In error situations Addin may receive calls to rename such instances.So check is must here.
	//So following API will check if OwnerHandle has any generic info with it , if it is FOUND it proves OwnerHandle is an family table instance
	//API will return GEOMETRY_FACADE_NO_ERROR if it has any generic model information.
	GeometryFacadeName wGnrcName;
	GeometryFacadeMdlType pGnrcType;
	result = ProFaminstanceImmediategenericinfoGet(pOwnerHndl , wGnrcName ,&pGnrcType);
	LOG << "ProcessDocumentName_wrapper: Family table instance check returned <" << result << ">." << endl;

	if(result != GEOMETRY_FACADE_NO_ERROR)
	{
		result = ProMdlNameGet(pOwnerHndl,wmdlName);

		ProName fileName;
		GeometryFacadeStringToWideString(fileName, cDocumentName);
		int iCmprRslt =  _wcsicmp(fileName, wmdlName);

		if(iCmprRslt != 0)
		{

			//Erase not displayed part.This will remove parts having name same as document name.
			GeometryFacadeMdlType pMdlTp;
			pMdlTp = GeometryFacadeGetMdlType(pOwnerHndl);
			EarseModelInSession(cDocumentName,pMdlTp);

			GeometryFacadeStringToWideString(wDocName,cDocumentName);
			GeometryFacadeRenameMdl(pOwnerHndl,wDocName);
			LOG << "ProcessDocumentName_wrapper: Geometry at <" << sOwnerId << "> is succesfully renamed to <" << cDocumentName << ">." << endl;
		}
	}
	else
		LOG << "ProcessDocumentName_wrapper: Geometry at : " << sOwnerId << " is a family table instance , so Document Name <" << cDocumentName << "< is not applied , Result : " << result << endl;

	return 0;
}

//It is responsible to find model with same as new doc name in session.
//if found it will erase so that further renaming works fine.
void EarseModelInSession(char *cDocumentName,GeometryFacadeMdlType pMdlTp)
{
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl *pSessionMdlLst = NULL;
		int iNoMdl = 0;

		result = ProSessionMdlList(pMdlTp,&pSessionMdlLst,&iNoMdl);
		LOG << "Models in session : " << iNoMdl << " while Model Type is : " << int(pMdlTp) << endl;
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			for(int i = 0;i<iNoMdl;i++)
			{
				ProName wMdlNm = {};
				std::string sTemp;
				result = ProMdlNameGet(pSessionMdlLst[i],wMdlNm);
				
				ProName fileName;
				GeometryFacadeStringToWideString(fileName, cDocumentName);
				int iCmp = _wcsicmp(fileName, wMdlNm);
				if(iCmp == 0)
				{					
					result = ProMdlErase(pSessionMdlLst[i]);
					LOG << "ProE session already has : " << cDocumentName << " so erasing it.. with result : " << result << endl;
				}
			}
		}

		if(pSessionMdlLst != NULL)
			ProArrayFree((ProArray*)&pSessionMdlLst);
	}
	catch(ProeException)
	{
		//No need to throw this as it is subprocess and just performs a session cleanup.
		LOG << "Absorbed exception while trying to erase model from session list" << endl;
	}
	catch(exception)
	{
		LOG << "Absorbed exception while trying to erase model from session list" << endl;
	}
}

int ProcessFamilyTableInstance_wrapper(char *cInstanceName,std::string sIDPath)
{
	int iProRslt = 0;
	GeometryFacadeMdl pOwnerAssembly = NULL,pInstanceMdl = NULL;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	//Get Handle of component having family table
	GetAsmcompMdl(sIDPath, &pInstanceMdl);

	int iChk = CheckInstanceWithCurrentPart(pInstanceMdl,cInstanceName);		
	if(iChk == 0)
		return 1;

	//This condition is true when we have to process family table instance of root assembly/part.
	//In this situation interchange will not work so create instance and display it.
	if(strlen(sIDPath.c_str()) == 0) 
	{								
		LOG << "Processing family table instance : " << cInstanceName << " for root model" << endl;
		iProRslt = ProcessFamilyTableInstanceOfRoot(cInstanceName,pInstanceMdl);
		return iProRslt;
	}

	//Get assembly handle having instance.
	std::string sOwnerAsmPath;
	std::string sMdlID; //This will be value of generic model ID only.
	int iMdlId;
	if(sIDPath.find(",") != string::npos)
	{
		sOwnerAsmPath = sIDPath.substr(0,sIDPath.find_last_of(","));
		sMdlID = sIDPath.substr(sIDPath.find_last_of(",")+1);
		iMdlId = atoi(sMdlID.c_str());
	}
	else
	{
		sOwnerAsmPath = ""; //Owner is an top level  
		iMdlId = atoi(sIDPath.c_str());
	}
	GetAsmcompMdl(sOwnerAsmPath, &pOwnerAssembly);

	//Assign model ID.			
	ProArray pCompIds;
	pCompIds = GeometryFacadeAllocateArray(0,sizeof(int),1);
	GeometryFacadeAddArrayObject(&pCompIds,-1,1,&iMdlId);

	//Check for family table in initiazed instance handle.
	result = ProSolidFamtableCheck((GeometryFacadeSolid)pInstanceMdl);
	if(result == GEOMETRY_FACADE_NO_ERROR) //pInstanceMdl is a generic component 
	{
		iProRslt = ProcessFamilyTableInstance(cInstanceName,(int*)pCompIds,pInstanceMdl,pOwnerAssembly);		
	}
	else if(result == GEOMETRY_FACADE_EMPTY) //pInstanceMdl is a family table instance 
	{
		//get Generic model of the instance
		GeometryFacadeMdl pGenrcMDl;
		result = ProFaminstanceGenericGet(pInstanceMdl,true,&pGenrcMDl);
		LOG << "Status of Generic of Instance Get : " << result << endl;

		if(CheckInstanceForGeneric(pGenrcMDl,cInstanceName) == 0)
		{
			//<Replaced>iProRslt = prodb_auto_interchange((Prohandle)pOwnerAssembly, 1,iGenMdlID, (Prohandle)pGenrcMDl);
			iProRslt = ProAssemblyAutointerchange((GeometryFacadeAssembly)pOwnerAssembly,(int*)pCompIds,pGenrcMDl);
			LOG << "Interchange result for generic instance: " << iProRslt << endl;
		}
		else
		{
			iProRslt = ProcessFamilyTableInstance(cInstanceName,(int*)pCompIds,pGenrcMDl,pOwnerAssembly);
		}
	}

	//This extra processing is needed to verify has family table processing modified Model ID
	//This situation comes when user adds multiple files having family atble and assigns same FT instance.
	//In this situation ProE increases model ID of next model by 1.
	//SO we will return process result as 2 for this situation.
	if(iProRslt == 0)
	{
		try
		{
			GetAsmcompMdl(sIDPath, &pInstanceMdl);
		}
		catch(ProeException ex)
		{
			if(ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
			{
				throw ex;
			}
			iProRslt = 2;
			LOG << "Family Table Processing succeded ,but it has caused change in model ID so returning process result as : 2" << endl;
		}
	}

	if(pCompIds != NULL)
	{
		GeometryFacadeFreeArray(&pCompIds);
	}
	return iProRslt;
}

int ProcessFamilyTableInstanceOfRoot(char *cInstanceName,GeometryFacadeMdl pRootMdl)
{ 
	int iResult = 0;
	GeometryFacadeMdl instModel = NULL;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProFamtable p_famtab;
	ProName inst_name;
	ProFaminstance p_inst;

	result = ProSolidFamtableCheck((GeometryFacadeSolid)pRootMdl);

	if(result == GEOMETRY_FACADE_EMPTY) //pRootMdl is a family table instance 
	{
		//get Generic model of the instance
		GeometryFacadeMdl pGenrcMDl;
		result = ProFaminstanceGenericGet(pRootMdl,true,&pGenrcMDl);
		LOG << "Status of Generic of Instance Get : " << result << endl;
		pRootMdl = pGenrcMDl;
	}

	if(CheckInstanceForGeneric(pRootMdl,cInstanceName) != 0)
	{
		// If same name family table instance item is present in session 
		// then we are facing issue of invalid reference. To avoid this
		// erase not displayed family table instance.
		ProMdlType type;
		ProMdlTypeGet(pRootMdl, &type);
		EarseModelInSession(cInstanceName, type);

		GeometryFacadeStringToWideString(inst_name, cInstanceName);
		result = ProFamtableInit(pRootMdl,&p_famtab);
		if (result != GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "Fails to init model: " << result << endl;
			throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
		}

		result = ProFaminstanceInit(inst_name, &p_famtab, &p_inst);
		if (result != GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "Fails to init Family table instance: " << result << endl;
			throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
		}

		result = ProFaminstanceCreate(&p_inst, &instModel);
		if (result != GEOMETRY_FACADE_NO_ERROR)
		{
			LOG << "Fails to create family table instance: " << result << endl;
			throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
		}
	}
	else
	{
		instModel = pRootMdl; // This assigning is to display generic , as user has selected Generic instance to load.
	}
	GeometryFacadeDisplayMdl(instModel);
	int windowId = GeometryFacadeGetCurrentWindow();
	GeometryFacadeActivateWindow(windowId);

	return (int)result+1; // we have 1 for success of processing family table instance, so adding one to make NO_ERROR(0) to return 1.
}

//We may be situation where user wants to load 
//generic/default instance of a part/assembly , so check it here 
//result = 0 , New instance is found to be generic part.
//result = 1 , New instance is not a generic part move to further processing.
int CheckInstanceForGeneric(GeometryFacadeMdl pModel,char *cInstanceName)
{
	int result = 0;
	ProMdldata pMdlData;
	char cMdlName[GEOMETRY_FACADE_LINE_SIZE];

	result = ProMdlDataGet(pModel,&pMdlData);
	ProWstringToString(cMdlName,pMdlData.name);
	//If it is instance it might have suffix added check it , if it is remove 
	//to have correct comparison
	std::string sTemp = cMdlName;
	if(sTemp.find("-"))
	{
		sTemp = sTemp.substr(0,sTemp.find_last_of("-"));
		strcpy(cMdlName,sTemp.c_str());
	}
	
	ProLine fileName, instName;
	GeometryFacadeStringToWideString(fileName, cMdlName);
	GeometryFacadeStringToWideString(instName, cInstanceName);
	result =  _wcsicmp(fileName, instName);

	LOG << "Result for Instance Check to generic : " << result << endl;
	return result;
}

// we might get instance which is alreday loaded in ProE 
//So just check it here if found true return without any modification.
int CheckInstanceWithCurrentPart(GeometryFacadeMdl pModel,char *cInstanceName)
{
	int result = 0;
	ProMdldata pMdlData;
	char cMdlName[GEOMETRY_FACADE_LINE_SIZE];

	result = ProMdlDataGet(pModel,&pMdlData);
	ProWstringToString(cMdlName,pMdlData.name);
	//If it is instance it might have suffix added check it , if it is remove 
	//to have correct comparison
	std::string sTemp = cMdlName;
	if(sTemp.find("-"))
	{
		sTemp = sTemp.substr(0,sTemp.find_last_of("-"));
		strcpy(cMdlName,sTemp.c_str());
	}

	ProLine fileName, instName;
	GeometryFacadeStringToWideString(fileName, cMdlName);
	GeometryFacadeStringToWideString(instName, cInstanceName);
	result =  _wcsicmp(fileName, instName);

	return result;
}

int ProcessFamilyTableInstance(char *cInstanceName,int *iMdlId,GeometryFacadeMdl pGnrcMdl,GeometryFacadeMdl pOwnerAsm)
{
	ProName wInstName;
	ProFamtable famTable;
	ProFaminstance ftInst;
	GeometryFacadeMdl pInstance = NULL;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProFaminstanceVerifyStatus pInstVerified;

	// If same name family table instance item is present in session 
	// then we are facing issue of invalid reference. To avoid this
	// erase not displayed family table instance.
	ProMdlType type;
	ProMdlTypeGet(pGnrcMdl, &type);
	EarseModelInSession(cInstanceName, type);

	ProName modelName;
	ProMdlNameGet(pGnrcMdl, modelName);

	result = ProFamtableInit(pGnrcMdl, &famTable);
	LOG << "Result of FT Init : " << result << endl;

	GeometryFacadeStringToWideString(wInstName,cInstanceName);
	result = ProFaminstanceInit(wInstName,&famTable,&ftInst);
	LOG << "Result of instance initialization : " << cInstanceName << " is " << result << endl;
	if (result != GEOMETRY_FACADE_NO_ERROR)
	{
		LOG << "Fail to initialize instance: " << cInstanceName << ". Error is " << result << endl;
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}

	//Verify Family Table Instance 
	result = ProFaminstanceIsVerified(&ftInst,&pInstVerified);	

	//If family table instance is not found possibility is RS instance name does not matches with ProE instance.
	//This situaion comes when instance name in FT changes with change/rename in part/assembly conatining it.
	//Assembly reference assigns suffixes to the component and parent assembly so same suffix gets appended in
	//instance name also so following code will identify suffix and will append it to instance name.
	if ( result == GEOMETRY_FACADE_NOT_FOUND)
	{
		ProMdldata pMdlData;
		ProMdlDataGet(pGnrcMdl,&pMdlData);
		char cTemp[GEOMETRY_FACADE_LINE_SIZE];
		ProWstringToString(cTemp,pMdlData.name);
		std::string sPartFile = cTemp;
		std::string sSuffix = sPartFile.substr(sPartFile.find_last_of("-"),sPartFile.find_first_of(".")-1);
		//sSuffix = sSuffix.erase(sSuffix.find_first_of("."));
		strcat(cInstanceName,sSuffix.c_str());
		GeometryFacadeStringToWideString(wInstName,cInstanceName);
		LOG << "New Instance Name : " << cInstanceName << endl;
		result = ProFaminstanceInit(wInstName,&famTable,&ftInst);			
	}

	result = ProFaminstanceCreate(&ftInst,&pInstance);
	LOG << "Result of FT instance create : " << result << endl;
	if (result != GEOMETRY_FACADE_NO_ERROR)
	{
		LOG << "Fail to create instance: " << cInstanceName << ". Error is " << result << endl;
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}

	ProMdl genModel;
	result = ProFaminstanceGenericGet(pInstance, 0, &genModel);
	if (result == GEOMETRY_FACADE_NO_ERROR)
	{
		ProName genMdlName;
		ProMdlNameGet(genModel, genMdlName);
		char name1[PRO_LINE_SIZE];
		char name2[PRO_LINE_SIZE];
		GeometryFacadeWideStringToString(name1, modelName);
		GeometryFacadeWideStringToString(name2, genMdlName);

		if (strcmpi(name1, name2) != 0)
		{
			// Convert name to lower case to avoid failure in model init
			// ProMdlInit fails if we pass model name in capital letters
			char c;
			int i = 0;
			while (cInstanceName[i])
			{
				c = cInstanceName[i];
				cInstanceName[i] = tolower(c);
				i++;
			}

			// Check is there same name file exist in Creo 
			ProMdl sameModel;
			ProName nameTemp;
			ProStringToWstring(nameTemp, cInstanceName);
			result = ProMdlInit(nameTemp, type, &sameModel);
			if (result == PRO_TK_NO_ERROR)
			{
				LOG << "Same name Instance is already present in Creo: " << result << endl;
				// Error -200 is returned from AddIn to show that there is same name instance available in Creo
				return -200;
			}
		}
	}

	//<Replaced>int no = prodb_auto_interchange((Prohandle)pOwnerAsm, 1,iMdlId, (Prohandle)pInstance);
	result = ProAssemblyAutointerchange((GeometryFacadeAssembly)pOwnerAsm,iMdlId,pInstance);
	LOG << "Interchange result for family table instance: " << result << endl;

	return result;
}

void ExportFileTypes_Wrapper(char *cDrwFile,char *cDrwExptType,char *cMdlFile,char *cMdlExptType,char *cRelaseDirPath,char *cExportFileName, char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported)
{	
	try
	{
		std::vector<std::string> vDrwExptTp;
		std::vector<std::string> vMdlExptTp;
		if(strlen(cDrwExptType) > 0)
		{
			ProcessNoteText(cDrwExptType,",",vDrwExptTp);
		}
		if(strlen(cMdlExptType) > 0)
		{
			ProcessNoteText(cMdlExptType,",",vMdlExptTp);
		}

		if(vMdlExptTp.size() > 0)
		{
			LOG << "ExportFileTypes_Wrapper: Loading Geometry file <" << cMdlFile << ">." << endl; 
			LoadModel_wrapper(cMdlFile);
			ExportModelFile(vMdlExptTp,cRelaseDirPath,cExportFileName,exportFactOne, exportFactTwo, exportFactThree, cTypeNotExported);
			LOG << "ExportFileTypes_Wrapper: Finished Exporting Model File Type" << endl;
		}
		if(vDrwExptTp.size() > 0)
		{
			LOG << "ExportFileTypes_Wrapper: Loading Drawing file <" << cMdlFile << ">." << endl;
			LoadModel_wrapper(cDrwFile);			
			ExportDrawingFile(vDrwExptTp,cRelaseDirPath,cExportFileName,exportFactOne, exportFactTwo, exportFactThree, cTypeNotExported);
			LOG << "ExportFileTypes_Wrapper: Finished Exporting Drawing File Type" << endl;
		}
	}
	catch (ProeException ex)
	{
		LOG << "ExportFileTypes_Wrapper: Caught Outer exception" << endl;
		throw ex;
	}
}

void ExportModelFile(std::vector<std::string> vMdlExptTp,char *cRelaseDirPath,char *cExportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported)
{
	try
	{
		GeometryFacadeMdl mdlHandle = NULL;
		GeometryFacadeMdlData mdlData;
		int iWinID;
		ProWindowCurrentGet(&iWinID);
		ProWindowMdlGet(iWinID,&mdlHandle);
		GeometryFacadeGetMdlData(mdlHandle,&mdlData);
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

		LOG << "ExportModelFile: Started Geometry file export" << endl;

		for(int i =0;i<(int)vMdlExptTp.size();i++)
		{

			ProIntf3DExportType MexptType = Get3DExportType(vMdlExptTp[i].c_str());		
			LOG << "ExportModelFile: File format to be exported to <" << vMdlExptTp[i] << endl;
			if(MexptType != 0)
			{
				ProOutputAssemblyConfiguration pConfig = GetConfigurationForExportType(vMdlExptTp[i].c_str());

				//Added for STEP file export B-05821
				if(MexptType==PRO_INTF_EXPORT_STEP && strcmpi(exportFactOne, "Monolithic")==0)
				{
					pConfig = PRO_OUTPUT_ASSEMBLY_SINGLE_FILE;
				}
				else if(MexptType==PRO_INTF_EXPORT_STEP && strcmpi(exportFactOne, "Multiple")==0)
				{
					pConfig = PRO_OUTPUT_ASSEMBLY_MULTI_FILES;
				}
				//Export 3D Model
				ProPath output_file = {};
				ProBoolean bIsConfSupported,bIsbrepSup;			
				ProOutputBrepRepresentation representation;

				if(strlen(cExportFileName) > 0)
				{
					//Generate ExportFileName with full path...
					ProStringToWstring(output_file,cExportFileName);
				}
				else
				{
					ProStringToWstring(output_file,cRelaseDirPath);
					ProWstringConcatenate(mdlData.name,output_file,PRO_VALUE_UNUSED);
					ProWstringConcatenate(mdlData.type,output_file,PRO_VALUE_UNUSED);
				}

				//chk if ASM config. is supported
				result = ProOutputAssemblyConfigurationIsSupported(MexptType,pConfig,&bIsConfSupported);
				//chk if Brep is supported
				result = ProOutputBrepRepresentationAlloc(&representation);
				if(MexptType == PRO_INTF_EXPORT_PARASOLID)
				{
					result = ProOutputBrepRepresentationFlagsSet(representation,PRO_B_FALSE,PRO_B_FALSE,PRO_B_TRUE,PRO_B_TRUE);
				}
				else if(MexptType == PRO_INTF_EXPORT_STEP)
				{
					result = ProOutputBrepRepresentationFlagsSet(representation,PRO_B_FALSE,PRO_B_FALSE,PRO_B_TRUE,PRO_B_FALSE);
				}
				else
				{
					result = ProOutputBrepRepresentationFlagsSet(representation,PRO_B_FALSE,PRO_B_TRUE,PRO_B_FALSE,PRO_B_FALSE);
				}
				result = ProOutputBrepRepresentationIsSupported(MexptType,representation,&bIsbrepSup); 
				//chk for inclusions
				ProOutputInclusion pOpInclsion;
				result = ProOutputInclusionAlloc(&pOpInclsion);
				result = ProOutputInclusionFlagsSet(pOpInclsion,PRO_B_TRUE,PRO_B_TRUE,PRO_B_TRUE);
				//chk layer options
				ProOutputLayerOptions pLyrOptn;
				ProBoolean bLyrOpt = PRO_B_TRUE;
				result = ProOutputLayerOptionsAlloc(&pLyrOptn);
				result = ProOutputLayerOptionsAutoidSet(pLyrOptn,bLyrOpt);
				result = ProIntf3DFileWrite((ProSolid)mdlHandle,MexptType,output_file,pConfig,NULL,representation,pOpInclsion,pLyrOptn);
				if(result == GEOMETRY_FACADE_NO_ERROR)
				{
					LOG << "ExportModelFile: Succesfully exported geometry file to type : " << vMdlExptTp[i] << endl;
				}
				//free all allocations
				ProOutputBrepRepresentationFree(representation);
				ProOutputInclusionFree(pOpInclsion);
				ProOutputLayerOptionsFree(pLyrOptn);
			}
			else
			{
				//Add not supported/invalid file type here.
				cTypeNotExported.append(",");
				cTypeNotExported.append(vMdlExptTp[i]);
			}
		}
	}
	catch (ProeException ex)
	{
		LOG << "ExportModelFile: Caught Outer exception" << endl;
		throw ex;
	}
}

ProOutputAssemblyConfiguration GetConfigurationForExportType(const char *cMdlExptTp)
{
	std::map<std::string,ProOutputAssemblyConfiguration> mAsmConf;
	mAsmConf["stp"] = PRO_OUTPUT_ASSEMBLY_PARTS;
	mAsmConf["set"] = PRO_OUTPUT_ASSEMBLY_MULTI_FILES;
	mAsmConf["vda"] = PRO_OUTPUT_ASSEMBLY_PARTS;
	mAsmConf["igs"] = PRO_OUTPUT_ASSEMBLY_PARTS;
	mAsmConf["ct"]  = PRO_OUTPUT_ASSEMBLY_SINGLE_FILE;
	mAsmConf["neu"] = PRO_OUTPUT_ASSEMBLY_PARTS;
	mAsmConf["x_t"] = PRO_OUTPUT_ASSEMBLY_MULTI_FILES;
	return mAsmConf[cMdlExptTp];
}

ProIntf3DExportType Get3DExportType(const char *cMdlExptTp)
{

	std::map<std::string,ProIntf3DExportType> exptType;
	exptType["stp"] = PRO_INTF_EXPORT_STEP;
	exptType["set"] = PRO_INTF_EXPORT_SET;
	exptType["vda"] = PRO_INTF_EXPORT_VDA;
	exptType["igs"] = PRO_INTF_EXPORT_IGES;
	exptType["ct"]  = PRO_INTF_EXPORT_CATIA;
	exptType["neu"] = PRO_INTF_EXPORT_NEUTRAL;	
	exptType["x_t"] = PRO_INTF_EXPORT_PARASOLID;
	return exptType[cMdlExptTp];
}

void ExportDrawingFile(std::vector<std::string> vDrwExptTp,char *cRelaseDirPath,char *cExportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported)
{
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl mdlHandle = NULL;
		GeometryFacadeMdlData mdlData;
		int iWinID;
		ProWindowCurrentGet(&iWinID);
		ProWindowMdlGet(iWinID,&mdlHandle);
		GeometryFacadeGetMdlData(mdlHandle,&mdlData);

		LOG << "ExportDrawingFile: Started Drawing file export.." << endl;
		for(int i = 0;i<(int)vDrwExptTp.size();i++)
		{
			int iIsPDF = _stricmp(vDrwExptTp[i].c_str(),"PDF");
			int iIsTIFF = _stricmp(vDrwExptTp[i].c_str(),"TIFF");
			int iIsPlotTp = CheckIsPlotType(vDrwExptTp[i].c_str());

			LOG << "ExportDrawingFile: File format to be exported to <" << vDrwExptTp[i] << ">." << endl;
			if(iIsPDF == 0)
			{
				//File type is "PDF" export it here.
				ProPath exptPath = {};
				ProPDFOptions pdfOpt;

				if(strlen(cExportFileName) > 0)
				{
					ProStringToWstring(exptPath,cExportFileName); // Name of Exported output file with path..
				}
				else
				{
					strcat(cRelaseDirPath,"\\");
					ProStringToWstring(exptPath,cRelaseDirPath);
					ProWstringConcatenate(mdlData.name,exptPath,PRO_VALUE_UNUSED);	
					ProWstringConcatenate(mdlData.type,exptPath,PRO_VALUE_UNUSED);
				}

				ProPDFoptionsAlloc(&pdfOpt);
				result = ProPDFoptionsBoolpropertySet(pdfOpt,PRO_PDFOPT_LAUNCH_VIEWER,PRO_B_FALSE);
				result = ProPDFExport(mdlHandle,exptPath,pdfOpt);
				LOG << "ExportDrawingFile: Succesfully Exported Drawing file to type  <" << vDrwExptTp[i] << "> at <" << cExportFileName  << ">." << endl;
				ProPDFoptionsFree(pdfOpt);
			}
			else if (iIsPlotTp == 0)
			{			
				//File type to be exported are PLOT file export it here
				ProProductviewFormat pPrVwFrmt = GetPlotFormat(vDrwExptTp[i].c_str());			
				ProPath exptPath = {};

				ProPath fileName = {};
				ProProductviewExportOptions pdvexptData;			
				ProStringToWstring(exptPath,cRelaseDirPath);			

				if(strlen(cExportFileName) > 0)
				{
					ProStringToWstring(fileName,cExportFileName);
				}
				else
				{
					ProWstringCopy(fileName,mdlData.name,PRO_VALUE_UNUSED);
				}
				ProProductviewexportoptsAlloc(&pdvexptData);
				result = ProProductviewexportoptsFormatSet(pdvexptData,pPrVwFrmt); 
				result = ProProductviewFormattedExport(mdlHandle,exptPath,fileName,pdvexptData);
				if(result == GEOMETRY_FACADE_NO_ERROR)
				{
					LOG << "ExportDrawingFile: Succesfully Exported Drawing file to type <" << vDrwExptTp[i] << "> at <" << cExportFileName  << ">." << endl;
				}
				ProProductviewexportoptsFree(pdvexptData);
				if(result != GEOMETRY_FACADE_NO_ERROR)
				{
					cTypeNotExported.append(",");
					cTypeNotExported.append(vDrwExptTp[i]);
				}
			}
			else if(iIsTIFF == 0)
			{
				//Call method to export TIFF file 
				bool status = ExportTifFile(cRelaseDirPath, cExportFileName, exportFactOne, exportFactTwo, exportFactThree);
				if(status==false)
				{
					//Add failure.
					cTypeNotExported.append(",");
					cTypeNotExported.append(vDrwExptTp[i]);
					LOG << "ExportDrawingFile: Fail to Export <" << vDrwExptTp[i] << ">." << endl;
				}
			}
			else
			{
				//For remaining file type.
				ProImportExportFile exptFormat = GetDrwExportFileType(vDrwExptTp[i].c_str());
				if(exptFormat != 0)
				{
					ProPath exptPath = {};	
					ProName exportExtension = {};

					if(strlen(cExportFileName) > 0)
					{
						char cExtension[5] = ".";
						strcat(cExtension,vDrwExptTp[i].c_str());
						ProStringToWstring(exptPath,cExportFileName); //ExportFileName to be added here...
						ProStringToWstring(exportExtension,cExtension);
						ProWstringConcatenate(exportExtension,exptPath,PRO_VALUE_UNUSED);
					}
					else
					{					
						ProStringToWstring(exptPath,cRelaseDirPath);
					}

					Pro2dExportdata exptData;
					result = Pro2dExportdataAlloc(&exptData);
					result = Pro2dExportdataSheetoptionSet(exptData,PRO2DEXPORT_ALL); 			
					result = Pro2dExport(exptFormat,exptPath,mdlHandle,exptData);
					if(result == GEOMETRY_FACADE_NO_ERROR)
					{
						LOG << "ExportDrawingFile: Succesfully Exported Drawing file to type <" << vDrwExptTp[i] << "> at <" << cExportFileName  << ">." << endl;
					}
					Pro2dExportdataFree(exptData);
				}
				else
				{
					//Add not supported/invalid file type here.
					cTypeNotExported.append(",");
					cTypeNotExported.append(vDrwExptTp[i]);
					LOG << "ExportDrawingFile: Export type not supported <" << vDrwExptTp[i] << ">." << endl;
				}
			}
		}
	}
	catch (ProeException ex)
	{
		LOG << "ExportDrawingFile: Caught Outer exception" << endl;
		throw ex;
	}
}
//To export drawing file to TIFF format B-05842 
// Config values will be set at run time to export quality TIFF file 
//exportFactOne - DPI value 
//exportFactTwo - Compression
//exportFactThree - Tiff type
bool ExportTifFile(char * relaseDirPath,char * exportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree)
{
	ProLine wchrDpiVal;
	wchrDpiVal[0]=NULL;
	ProLine wchrComprVal;
	wchrComprVal[0]=NULL;
	ProLine wchrTypeVal;
	wchrTypeVal[0]=NULL;

	try
	{
		ProError result=PRO_TK_GENERAL_ERROR;
		//Get current drawing 
		ProMdl drawing=NULL;
		result = ProMdlCurrentGet(&drawing);
		if(result != PRO_TK_NO_ERROR)
		{
			return false;
		}
		//Get Wondow id 
		int id;
		ProWindowCurrentGet(&id);

		//Build File Path
		strcat(exportFileName, ".tif");


		//Get Config Options values
		result = ProConfigoptGet(L"raster_plot_dpi" , wchrDpiVal);
		result = ProConfigoptGet(L"tiff_compression" , wchrComprVal);
		result = ProConfigoptGet(L"tiff_type" , wchrTypeVal);

		//Get values into Wchar
		ProName wchrDPI;
		wchrDPI[0]=NULL;
		ProName wchrCompr;
		wchrCompr[0]=NULL;
		ProName wchrType;
		wchrType[0]=NULL;
		ProStringToWstring(wchrDPI, exportFactOne);
		ProStringToWstring(wchrCompr, exportFactTwo);
		ProStringToWstring(wchrType, exportFactThree);

		//Set TIFF Config options 
		ProConfigoptSet(L"raster_plot_dpi" ,wchrDPI);
		ProConfigoptSet(L"tiff_compression" ,wchrCompr);
		ProConfigoptSet(L"tiff_type" ,wchrType);

		//Get Print option. "TIFF" is the default file format
		//"TIFF" format is default and available by PTC with Creo default installation
		ProPrintPrinterOpts objOpt;
		result = ProPrintPrinterOptionsGet("TIFF", &objOpt);
		if(result==PRO_TK_NO_ERROR)
		{
			//Set file path & other options
			ProStringToWstring(objOpt.filename, exportFileName);
			objOpt.delete_after = PRO_B_FALSE;
			objOpt.send_to_printer = PRO_B_FALSE;
			objOpt.save_to_file = PRO_B_TRUE;

			ProPrintMdlOpts objMdlopts;
			result = ProPrintMdlOptionsGet(drawing, &objMdlopts);

			ProPrintPlacementOpts objPlcOpts;
			result = ProPrintPlacementOptionsGet(&objPlcOpts);

			//Export TIFF file
			result = ProPrintExecute(id, &objOpt, &objMdlopts, &objPlcOpts);
		}

		//Set back to Original value
		ProConfigoptSet(L"raster_plot_dpi" , wchrDpiVal);
		ProConfigoptSet(L"tiff_compression" , wchrComprVal);
		ProConfigoptSet(L"tiff_type" , wchrTypeVal);

		if(result!=PRO_TK_NO_ERROR)
		{
			return false;
		}

	}
	catch (ProeException ex)
	{
		//Set back to Original value
		if(wchrDpiVal[0]!=NULL)
		{
			ProConfigoptSet(L"raster_plot_dpi" , wchrDpiVal);
		}
		if(wchrComprVal[0]!=NULL)
		{
			ProConfigoptSet(L"tiff_compression" , wchrComprVal);
		}
		if(wchrTypeVal[0]!=NULL)
		{
			ProConfigoptSet(L"tiff_type" , wchrTypeVal);
		}
		LOG << "ExportTifFile: Caught Outer exception" << endl;
		throw ex;
	}
	return true;
}

ProImportExportFile GetDrwExportFileType(const char *cDrwExptTp)
{
	std::map<std::string,ProImportExportFile> exptType;
	exptType["stp"] = PRO_STEP_FILE;	
	exptType["set"] = PRO_SET_FILE;			
	exptType["igs"] = PRO_IGES_FILE;
	exptType["she"] = PRO_MEDUSA_FILE;
	exptType["dxf"] = PRO_DXF_FILE;
	exptType["dwg"] = PRO_DWG_FILE;
	exptType["cgm"] = PRO_CGM_FILE;
	return exptType[cDrwExptTp];
}

ProProductviewFormat GetPlotFormat(const char *cDrwExptTp)
{
	std::map<std::string,ProProductviewFormat> exptType;
	exptType["pvs"] = PRO_PV_FORMAT_PVS;	
	exptType["ed"] = PRO_PV_FORMAT_ED;			
	exptType["edz"] = PRO_PV_FORMAT_EDZ;
	exptType["pvz"] = PRO_PV_FORMAT_PVZ;
	return exptType[cDrwExptTp];
}

int CheckIsPlotType(const char *sType)
{
	int iChk;
	char *pExptTYpe[] = {"pvs","plt","ed","edz","pvz"};
	for(int i = 0;i<5;i++)
	{
		iChk = _stricmp(sType,pExptTYpe[i]);
		if(iChk == 0)
			break;
	}
	return iChk;
}

void UDFDimensionValueSet_wrapper(char *cID,char *cDimName,double dDimValue)
{
	GeometryFacadeAsmCompPath path;
	GeometryFacadeMdl owner;    
	int feat_id[1];	
	GeometryFacadeLine pDimName,pInputDim;

	GeometryFacadeModelItem pGrpItem;
	GeometryFacadeDimension *pGrpDims;
	GetAsmcompPath(cID, &path);

	feat_id[0] = path.comp_id_table[path.table_num-1];

	path.table_num = path.table_num - 1;

	GeometryFacadeGetAsmCompPathMdl(&path, &owner);
	GeometryFacadeStringToWideString(pInputDim,cDimName);

	GeometryFacadeInitModelItem(owner,feat_id[0],PRO_GROUP,&pGrpItem);
	GeometryFacadeUdfDimensionsCollect((GeometryFacadeGroup*)&pGrpItem,&pGrpDims);
	int iDims = GeometryFacadeGetArraySize((GeometryFacadeArray)pGrpDims);
	for (int j = 0;j<iDims;j++)
	{
		GeometryFacadeUdfDimensionNameGet((GeometryFacadeGroup*)&pGrpItem,&pGrpDims[j],pDimName);
		int iCompare = GeometryFacadeCompareWideString(pDimName,pInputDim,GEOMETRY_FACADE_VALUE_UNUSED);
		if (iCompare == 0)
		{
			GeometryFacadeSetDimensionValue(&pGrpDims[j],dDimValue);
			RegenerateCurrentModel_wrapper();
			break;
		}
	}
}
int AddUDF_wrapper(wchar_t *sXMLRef, wchar_t *sUDFFile)
{	
	GeometryFacadeUdfdata pUDFData;
	GeometryFacadeUdfvardim *pVarDims = NULL;
	GeometryFacadeGroup pGroup;
	try
	{
		int i, current_length;
		wchar_t *start = NULL;
		wchar_t *end = NULL;	
		wchar_t *start_tag = L"<Constraint ";
		wchar_t *end_tag = L"</Constraint>";
		wchar_t cRefPrompt[255];
		wchar_t cPartID[255];
		wchar_t cPartRef[255];
		wchar_t cPartRefType[255];	
		wchar_t cFlpVal[2];
		GeometryFacadeMdl pRefMdl = NULL;
		int iDims = 0;

		GeometryFacadeUdfdataAlloc(&pUDFData);
		GeometryFacadeUdfdataPathSet(pUDFData,sUDFFile);

		//Get UDF dims & add them to UDf data
		GeometryFacadeUdfdataVardimsGet(pUDFData,&pVarDims);

		if(pVarDims != NULL)
			iDims = GeometryFacadeGetArraySize((GeometryFacadeArray)pVarDims);

		for (int j = 0;j<iDims;j++)
		{
			GeometryFacadeUdfdataUdfvardimAdd(pUDFData,pVarDims[j]);
		}

		for (i = 0; ;i++) 
		{
			// find location of the start tag in the constraints string.
			start = wcsstr(sXMLRef, start_tag);

			// exit when there is no start constraint tag found.
			if(!start)
			{
				break;
			}

			// find location of the end tag in the constraints string.
			end = wcsstr(sXMLRef, end_tag);

			current_length = int(end - start) + int(wcslen(end_tag));

			wchar_t current[4096];
			// Pull the next constraint from the constraints string.
			wcsncpy(current, start, current_length);

			// Terminate the constraint string.
			current[current_length] = '\0';		

			//GetAll UDF related data from XML
			getXMLAttributeValue(current, L"name1", cRefPrompt); //UDF Prompt
			getXMLAttributeValue(current, L"path2", cPartID); //part to which UDF to be added
			getXMLAttributeValue(current, L"ref2", cPartRefType); //part reference type
			getXMLAttributeValue(current, L"name2", cPartRef); //Name of part reference

			//Init part ref
			GeometryFacadeModelItem pPartRefItem;
			pRefMdl = NULL;
			GetAsmcompMdl(cPartID,&pRefMdl);
			GeometryFacadeInitModelItemByName(pRefMdl,PRO_TYPE_UNUSED,cPartRef,&pPartRefItem);


			//Select initialized Ref
			GeometryFacadeSelection pSelectedRef;
			pSelectedRef = GeometryFacadeAllocateSelection(NULL,&pPartRefItem);

			GeometryFacadeUdfreference pUDFReference;
			GeometryFacadeUdfreferenceAlloc(cRefPrompt,pSelectedRef,GEOMETRY_FACADE_B_FALSE,&pUDFReference);

			GeometryFacadeUdfdataReferenceAdd(pUDFData,pUDFReference);

			// D-05574: By default it will be NO_FLIP hence no need to set no Flip
			// add Orientation only for Flip.
			// Add Flip direction to each UDF Reference
			getXMLValue(current, cFlpVal);
			int iFlip = _wtoi(cFlpVal);
			if(iFlip == 0)
			{
				ProUdfdataOrientationAdd(pUDFData,PROUDFORIENT_FLIP);
			}

			// Increment the constraints to continue parse.
			sXMLRef = end + wcslen(end_tag);

			//Free UDF Reference..
			if(pUDFReference != NULL)
				ProUdfreferenceFree(pUDFReference);

			if(pSelectedRef != NULL)
				ProSelectionFree(&pSelectedRef);
		}
		//This option will disable/off Fix model UI in case of failures in UDF creation.
		GeometryFacadeUdfCreateOption pOptions = PROUDFOPT_FIX_MODEL_UI_OFF;//GEOMETRY_FACADE_UDFOPT_NO_REDEFINE;
		GeometryFacadeUdfCreate((GeometryFacadeSolid)pRefMdl,pUDFData,NULL,&pOptions,1,&pGroup);

	}
	catch(ProeException ex)
	{
		if(pVarDims != NULL)
			GeometryFacadeUdfvardimProarrayFree(pVarDims);

		if(pUDFData != NULL)
			ProUdfdataFree (pUDFData);

		throw ex;
	}

	if(pVarDims != NULL)
		GeometryFacadeUdfvardimProarrayFree(pVarDims);

	if(pUDFData != NULL)
		ProUdfdataFree (pUDFData);

	return pGroup.id;
}

//Not necessarily all the input assemblies will have components
//So exception GEOMETRY_FACADE_NOT_FOUND is caught & asembly renamed.
GeometryFacadeError RenameAssemblyComponent_wrapper(GeometryFacadeMdl mdlHandle , int iIsRSStandard)
{
	GeometryFacadeAppData appData;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdlData mdlData;
	char name[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeName newAssemblyName;

	try
	{
		GeometryFacadeVisitSolidFeature(GeometryFacadeSolid(mdlHandle),(GeometryFacadeFeatureVisitAction)FeatureVisitAction,(GeometryFacadeFeatureFilterAction)FeatureFilterAction ,(GeometryFacadeAppData)iIsRSStandard);
	}
	catch(ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
	}

	if(!iIsRSStandard)
	{
		//Rename assembly here
		GeometryFacadeGetMdlData(mdlHandle,&mdlData);
		GeometryFacadeWideStringToString(name,mdlData.name);
		strcat(name,"-");
		strcat(name,&suffix[0]);	
		GeometryFacadeStringToWideString(newAssemblyName,name);
		GeometryFacadeRenameMdl(mdlHandle,newAssemblyName); 	
	}

	GeometryFacadeStringToWideString(mdlData.path,&workingFolder[0]);
	GeometryFacadeBackupMdl(mdlHandle,&mdlData);
	ProMdlEraseAll(mdlHandle);

	return result;
}

//The API GeometryFacadeAsmCompMdl() throws exception when any component is not found in memory.
//This might occure when component is suppressed.So initially checking components suppress status.
//If found true,resume that component,rename it & restoore it back to its original state.
//Sometimes physical file for suppressed component might not proesent so it requires
//second catcjh of exception GEOMETRY_FACADE_NOT_FOUND , these time function returns without any operation.
GeometryFacadeError FeatureVisitAction(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData)
{
	GeometryFacadeMdl mdl = NULL;
	GeometryFacadeMdlData mdlData;
	char name[GEOMETRY_FACADE_LINE_SIZE];
	char type[GEOMETRY_FACADE_TYPE_SIZE];
	int compChk = 0;
	GeometryFacadeName newCompName;
	char *charTemp = NULL; //it stores the name of component & pushes into vector	
	GeometryFacadeFeatureStatus feat_status = GEOMETRY_FACADE_FEAT_ACTIVE;
	int iIsRsStandard = (int)appData;

	if ( feature != NULL)
	{		
		try
		{
			GeometryFacadeAsmCompMdl(feature,&mdl);
		}
		catch(ProeException ex)
		{
			if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
			{
				throw;
			}
			feat_status = GeometryFacadeGetFeatureStatus(feature);
			if (feat_status == GEOMETRY_FACADE_FEAT_SUPPRESSED)
			{
				GeometryFacadeFeatureResumeOptions options = GEOMETRY_FACADE_FEAT_RESUME_INCLUDE_PARENTS;
				int num_opts = 1;
				GeometryFacadeResumeFeature( (GeometryFacadeSolid)feature->owner, &feature->id, 1, &options, num_opts );
				try
				{
					GeometryFacadeAsmCompMdl(feature,&mdl);							
				}
				catch(ProeException ex)
				{
					if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
					{
						throw;
					}
					return GEOMETRY_FACADE_NO_ERROR;
				}

			}
			else
			{
				return GEOMETRY_FACADE_NO_ERROR;
			}
		}


		if(!iIsRsStandard)
		{
			charTemp = new char[1 + sizeof(newCompName)];

			//Check is this component a family table instance
			//If found true access its generic & rename it.
			IsCompFamilyTableInstance(mdl);
			GeometryFacadeGetMdlData(mdl,&mdlData);
			GeometryFacadeWideStringToString(name,mdlData.name);
			GeometryFacadeWideStringToString(type,mdlData.type);

			if(compList.size() == 0)
			{
				strcat(name,"-");
				//strcat(name,suffix.c_str());
				strcat(name,&suffix[0]);
				GeometryFacadeStringToWideString(newCompName,name);
				if (strncmp (type,"PRT",3) == 0)
				{	
					GeometryFacadeRenameMdl(mdl,newCompName);			//renaming happens here
					LOG << "Model renamed to : " << name << endl;
				}
				else
					if (strncmp (type,"ASM",3) == 0)					   //if comp is an assembly loop it again
					{
						RenameAssemblyComponent_wrapper(mdl , 0); //for sub-assembly RSStandard will be false
						//<TODO> Modify it when support for RSStandard is extended to assembly components</TODO>
					}
					//charTemp = new char[1 + sizeof(newCompName)];
					GeometryFacadeWideStringToString(charTemp, newCompName);					//convert wchar_t string to the char*
					compList.push_back(charTemp);							//insert name of component into a vector
			}
			else
			{
				//Here an check will be made in compList vector.It will search for current model name in list 
				//if it exist it will come out without renaming 
				for (int i=0;i<(int)compList.size();i++)
				{
					//printf ("i is: %d & comp %s",i,compList[i]); 
					//						char* strTemp = compList[i];

					compChk = strcmp(compList[i],name);

					if ( compChk == 0 ) 
						break;
				}

				if ( compChk != 0 )
				{
					strcat(name,"-");
					//strcat(name,suffix.c_str());	//adding suffix to the partname
					strcat(name,&suffix[0]);
					GeometryFacadeStringToWideString(newCompName,name);
					if (strncmp (type,"PRT",3) == 0)
					{		
						GeometryFacadeRenameMdl(mdl,newCompName);					//renaming happens here
						LOG << "Model renamed to : " << name << endl;
					}
					else
						if (strncmp (type,"ASM",3) == 0)
						{
							//RSStandard false for assembly components.
							RenameAssemblyComponent_wrapper(mdl  , 0);
						}
						//pushback in list
						//charTemp = new char[1 + sizeof(newCompName)];
						GeometryFacadeWideStringToString(charTemp, newCompName);
						compList.push_back(charTemp); //insert name of component into a vector
				}
			}
		}

		if (feat_status == GEOMETRY_FACADE_FEAT_SUPPRESSED)
		{
			GeometryFacadeFeatureDeleteOptions supoptions = GEOMETRY_FACADE_FEAT_DELETE_CLIP;
			GeometryFacadeSuppressFeature((GeometryFacadeSolid)feature->owner, &feature->id, 1, &supoptions, 1);
		}
	}


	return result;
}

GeometryFacadeError FeatureFilterAction(GeometryFacadeFeature* feature,GeometryFacadeAppData appData)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeFeatureType ftype;

	ftype = GeometryFacadeGetFeatureType(feature);	
	//ProFeatureTypeGet(feature,&ftype);

	if (ftype == GEOMETRY_FACADE_FEAT_COMPONENT)
		return (GEOMETRY_FACADE_NO_ERROR);
	return (GEOMETRY_FACADE_CONTINUE);        
}

//While renaming if an input part is an family table instance 
//then Generic part for that instance should be accessed
//and renamed.This is useful when Assembly file having FT used 
//multiple times.This activity is performed here.
void IsCompFamilyTableInstance(GeometryFacadeMdl mdl)
{
	char wGnrcName[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeMdl model = NULL;
	GeometryFacadeName wCompName;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdlData pMdlData;
	int compChk;
	char *cTemp = NULL; //it stores the name of component & pushes into vector
	cTemp = new char[1 + sizeof(wCompName)];

	try
	{
		GeometryFacadeSolidFamtableCheck(mdl);
	}
	catch(ProeException ex)
	{
		if (ex.GetResult() == GEOMETRY_FACADE_EMPTY)
		{			
			LOG << "Exception thrown is " << ex.GetResult() << endl;
			result = ProFaminstanceGenericGet(mdl,false,&model);
			if (result == GEOMETRY_FACADE_NO_ERROR)
			{
				GeometryFacadeGetMdlData(model,&pMdlData);
				GeometryFacadeWideStringToString(wGnrcName,pMdlData.name);
				if(vGnrcMdlList.size() == 0)
				{
					compChk = 1;
				}
				else
				{
					for (int i=0;i<(int)vGnrcMdlList.size();i++)
					{
						compChk = strcmp(vGnrcMdlList[i],wGnrcName);
						if ( compChk == 0 ) 
							break;
					}
				}

				if(compChk != 0)
				{
					strcat(wGnrcName,"-");						
					strcat(wGnrcName,&suffix[0]);
					GeometryFacadeStringToWideString(wCompName,wGnrcName);
					GeometryFacadeRenameMdl(model,wCompName);
					LOG << "Model is renamed to " << wGnrcName << endl;
					GeometryFacadeWideStringToString(cTemp, wCompName);
					vGnrcMdlList.push_back(cTemp);
				}
			}
		}
	}	
}

int AddSuffix_wrapper(std::string mdlwithext, std::string suff)
{
	// mdl_name comes with extension .asm/.prt

	GeometryFacadeMdl mdl;
	GeometryFacadeName wrking_name;
	std::string new_mdl_name,mdlname,mdltype;
	char p_new_mdl_name[GEOMETRY_FACADE_LINE_SIZE];
	int output = 0;

	// init suff data structure
	rename_data_t suff_data;
	suff_data.suff = suff;

	// get model name and type
	int windowId = UserModelLoad_wrapper((char*)mdlwithext.c_str(), &mdl, 0); // 0 -> don't display the model.

	GetMdlNameTypeFromString_wrapper(mdlwithext, mdlname, mdltype);

	// add suffix and rename the model
	new_mdl_name = mdlname + suff;
	strcpy(p_new_mdl_name, new_mdl_name.c_str());
	GeometryFacadeStringToWideString(wrking_name, p_new_mdl_name);
	GeometryFacadeRenameMdl(mdl, wrking_name);

	// Ff the model is an asm rename all components inside by adding the suffix.

	GeometryFacadeMdlType mdl_type = GeometryFacadeGetMdlType(mdl);
	if (mdl_type == GEOMETRY_FACADE_MDL_ASSEMBLY)
	{ 
		// If this component is an assembly, then visit it further.
		GeometryFacadeVisitSolidFeature( (GeometryFacadeSolid) mdl, (GeometryFacadeFeatureVisitAction)addSuffixVisitAction, NULL, (GeometryFacadeAppData)&suff_data );
	}

	GeometryFacadeSaveMdl(mdl);

	return windowId;
}


int GetMdlNameTypeFromString_wrapper(std::string mdl_name, std::string &mdlname, std::string &mdltype)
{
	std::string::size_type pos = mdl_name.find("."); // Position of the dot.
	if(pos != std::string::npos)
	{  
		// Found.
		mdlname = mdl_name.substr(0,pos);
		mdltype = mdl_name.substr(pos);
	}
	else
	{
		return -1;
	}

	return 0;
}


GeometryFacadeMdl LoadModel_wrapper(const std::string &theFileName)
{
	GeometryFacadeMdl model = NULL;
	GeometryFacadePath w_mdlpath;

	// Convert thefileName from an EUC (Extended UNIX Code) string into a wide string.
	GeometryFacadeStringToWideString(w_mdlpath, const_cast<char*>(theFileName.c_str()));

	// Load the model into memory.
	GeometryFacadeLoadMdl( w_mdlpath, GEOMETRY_FACADE_MDL_UNUSED, GEOMETRY_FACADE_B_FALSE, static_cast<GeometryFacadeMdl*>(&model) );

	// Display the model in the current view.
	// Note that this does not activate the window.
	GeometryFacadeDisplayMdl(model);

	// Get the current window id.
	int windowId = GeometryFacadeGetCurrentWindow();

	//ProWindowCurrentSet(windowId);

	// Activate the window.
	GeometryFacadeActivateWindow(windowId);

	return model;
}

//Issue has been observed where model has many regenerate failures.
//Due to these GeometryFacadeRegenerateSolid() returns GENERAL_ERROR
//These failures are not due to ProE Manager so catching these exception 
//should not cause any issues.
void RegenerateCurrentModel_wrapper() 
{
	GeometryFacadeMdl model;
	int iWinID;
	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&model); 


	try
	{
		GeometryFacadeRegenerateSolid(GeometryFacadeMdlToSolid(model), GEOMETRY_FACADE_REGEN_NO_FLAGS);
	}
	catch(ProeException ex)
	{
		if(ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
		{
			throw;
		}
	}

}


// FUNCTION :  UserModelLoad_wrapper()
// PURPOSE  :  Loads the model into Pro/Engineer.
// RETURNS  :  The id of the window that contains the model, or
//             -1 if it fails
//
// char *name (In) Name of the file that contains the model, e.g., "motor.mfg".
// GeometryFacadeMdl *loaded_part (Out) Handle to the loaded part.
// int display_model default is 1 to display, 0  not to display.
int UserModelLoad_wrapper(char *name, GeometryFacadeMdl *loaded_part, int display_model)
{
	GeometryFacadeMdl part;
	int j, i;

	char types[] = 
	{
		'p','r','t','\0',
		'a','s','m','\0',
		'm','f','g','\0',
		'l','a','y','\0',
		's','2','d','\0',
		'd','r','w','\0',
		'f','r','m','\0',  
		'r','e','p','\0',
		'm','r','k','\0',
		'd','g','m','\0'
	};

	i = 0;

	while( (name[i] != '.') && (name[i] != '\0') )
	{
		i++;
	}  

	if (name[i] == '\0')
	{
		// Not a Pro/E file.
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
	}

	i++;				// Point to the next char after '.'.

	j = 0;

	while(_stricmp(&name[i], &types[j]) != 0)
	{
		j = j + 4;

		if ( j > 36 ) 
		{
			// Not a Pro/E file extension, exit.
			throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
		}
	}

	j = j / 4;

	switch(j)
	{
	case 0:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_PART, &part);
		break;

	case 1:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_ASSEMBLY, &part);
		break;

	case 2:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_MFG, &part);
		break;

	case 3:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_LAYOUT, &part);
		break;       

	case 4:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_2DSECTION, &part);
		break;

	case 5:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DRAWING, &part);
		break;

	case 6:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DWGFORM, &part);
		break;

	case 7:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_REPORT, &part);
		break;

	case 8:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_MARKUP, &part);
		break;

	case 9:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DIAGRAM, &part);
		break;

	default:

		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
	}

	*loaded_part = part;

	if (display_model == 0)
	{  
		// No need to display the model, so exit.
		return 0;  
	}

	GeometryFacadeClearWindow(GEOMETRY_FACADE_VALUE_UNUSED);	// Clears what is in the main base window.

	GeometryFacadeDisplayMdl(part);
	int windowId = GeometryFacadeGetMdlWindow(part);

	GeometryFacadeActivateWindow(windowId);

	return windowId;
}


// FUNCTION :  UserModelLoad_wrapper()
// PURPOSE  :  Loads the model into Pro/Engineer.
// RETURNS  :  The id of the window that contains the model, or
//             -1 if it fails
//
// char *name (In) Name of the file that contains the model, e.g., "motor.mfg".
// GeometryFacadeMdl *loaded_part (Out) Handle to the loaded part.
// int display_model default is 1 to display, 0  not to display.
int UserModelLoad_wrapper( wchar_t *name, GeometryFacadeMdl *loaded_part, int display_model)
{
	GeometryFacadeMdl part;
	int j, i;

	wchar_t types[] =
	{
		L'p',L'r',L't',L'\0',
		L'a',L's',L'm',L'\0',
		L'm',L'f',L'g',L'\0',
		L'l',L'a',L'y',L'\0',
		L's',L'2',L'd',L'\0',
		L'd',L'r',L'w',L'\0',
		L'f',L'r',L'm',L'\0',
		L'r',L'e',L'p',L'\0',
		L'm',L'r',L'k',L'\0',
		L'd',L'g',L'm',L'\0'
	};

	i = 0;

	while ((name[i] != L'.') && (name[i] != L'\0'))
	{
		i++;
	}

	if (name[i] == L'\0')
	{
		// Not a Pro/E file.
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
	}

	i++;   // Point to the next char after '.'.

	j = 0;

	while (_wcsicmp(&name[i], &types[j]) != 0)
	{
		j = j + 4;

		if (j > 36)
		{
			// Not a Pro/E file extension, exit.
			throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
		}
	}

	j = j / 4;

	switch (j)
	{
	case 0:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_PART, &part);
		break;

	case 1:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_ASSEMBLY, &part);
		break;

	case 2:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_MFG, &part);
		break;

	case 3:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_LAYOUT, &part);
		break;

	case 4:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_2DSECTION, &part);
		break;

	case 5:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DRAWING, &part);
		break;

	case 6:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DWGFORM, &part);
		break;

	case 7:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_REPORT, &part);
		break;

	case 8:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_MARKUP, &part);
		break;

	case 9:

		GeometryFacadeRetrieveMdl(name, GEOMETRY_FACADE_MDL_DIAGRAM, &part);
		break;

	default:

		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);
	}

	*loaded_part = part;

	if (display_model == 0)
	{
		// No need to display the model, so exit.
		return 0;
	}

	GeometryFacadeClearWindow(GEOMETRY_FACADE_VALUE_UNUSED);	// Clears what is in the main base window.

	GeometryFacadeDisplayMdl(part);
	int windowId = GeometryFacadeGetMdlWindow(part);

	GeometryFacadeActivateWindow(windowId);

	return windowId;
}

void ZoomAllCurrentModel_wrapper() 
{
	GeometryFacadeMdl model;

	GeometryFacadeGetCurrentMdl(&model);

	int windowId = GeometryFacadeGetMdlWindow(model);

	GeometryFacadeRefitWindow(windowId);
}

/*FUnction which will load & display assembly file in newly created proe window
Commented by Milind as LoadModel_wrapper found suitable
GeometryFacadeMdl LoadDisplayModel(const std::string &theFileName)
{
GeometryFacadeMdl model = NULL;
GeometryFacadePath w_mdlpath;
// Convert thefileName from an EUC (Extended UNIX Code) string into a wide string.
GeometryFacadeStringToWideString(w_mdlpath, const_cast<char*>(theFileName.c_str()));

GeometryFacadeLoadMdl( w_mdlpath, GEOMETRY_FACADE_MDL_UNUSED, GEOMETRY_FACADE_B_FALSE, static_cast<GeometryFacadeMdl*>(&model));

// Display the model in the current view.
// Note that this does not activate the window.
GeometryFacadeDisplayMdl(model);

// Get the current window id.
int windowId = GeometryFacadeGetCurrentWindow();

// Activate the window.
GeometryFacadeActivateWindow(windowId);

return model;



//GeometryFacadeLoadMdl(full_path,type,ask_user_about_reps,p_handle);
//GeometryFacadeDisplayMdl(&p_handle);
//return p_handle;

}*/

// Private functions.
static GeometryFacadeError addSuffixVisitAction(GeometryFacadeFeature *theFeature_ptr, GeometryFacadeError status, GeometryFacadeAppData app_data)
{
	rename_data_t *p_rename_data = (rename_data_t*)app_data;
	GeometryFacadeFeatureType type = GeometryFacadeGetFeatureType(theFeature_ptr);

	GeometryFacadeName comp_name_w;
	char comp_name_c[GEOMETRY_FACADE_LINE_SIZE];
	std::set<GeometryFacadeMdl>::const_iterator comp_iter;

	if(GEOMETRY_FACADE_FEAT_COMPONENT == type)
	{
		GeometryFacadeMdl component;
		GeometryFacadeGetAsmCompMdl(theFeature_ptr, &component);  // Have to remember the component handle because of the mulitple instances of the same part.
		comp_iter = p_rename_data->component.find(component);
		if(comp_iter == p_rename_data->component.end())
		{ 
			// If this component was not already visited then rename it.

			GeometryFacadeGetMdlName(component, comp_name_w);
			GeometryFacadeWideStringToString(comp_name_c, comp_name_w);
			strcat(comp_name_c,p_rename_data->suff.c_str());
			GeometryFacadeStringToWideString(comp_name_w, comp_name_c);

			GeometryFacadeRenameMdl(component, comp_name_w);	// This is now name of model + suffix.
			// also remember this component
			p_rename_data->component.insert(component);

			GeometryFacadeMdlType mdl_type = GeometryFacadeGetMdlType(component);
			if (mdl_type == GEOMETRY_FACADE_MDL_ASSEMBLY)
			{ 
				// If this component is an assembly then visit it further.
				GeometryFacadeVisitSolidFeature((GeometryFacadeSolid) component, 
					(GeometryFacadeFeatureVisitAction)addSuffixVisitAction,
					NULL,
					(GeometryFacadeAppData)p_rename_data);
			}
		}
	}

	return GEOMETRY_FACADE_NO_ERROR;
}

//Here we will backup drawing which will also copy part/assembly file in release folder.
//There might be cases where drawing file is not available with geometry
//so catching exception & in that situation & performing normal model backup.
//If current Mdl is drawing it will have normal backup.
static void backupModel_wrapper(std::string sReleaseFolderPath , std::string sGeometryFileName , std::string sGeomReleaseFileName , std::string  sDrawingFileName, std::string sDrwReleaseFileName , std::string sAsmChildId , std::string sAsmChildRelName) 
{
	LOG << "backupModel_wrapper: Relasing model : "<< sGeometryFileName << " to relase folder." << endl;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdlData pData;
	GeometryFacadePath wReleaseFolderPath = {};	
	GeometryFacadeStringToWideString(wReleaseFolderPath,sReleaseFolderPath.c_str()); //Set Release folder path..

	//Check if drawing name is available , if it is  that means geometry has its corresponding drawing file as well.	
	if(sDrawingFileName.length() > 0)
	{
		//In this situation loading drawing file and taking its backup will copy geometry file along with drawing file in release folder.		
		GeometryFacadeMdl pDrwGeometry = NULL;
		GeometryFacadeMdl pDrawing = LoadModel_wrapper(sDrawingFileName);
		GeometryFacadeGetMdlData(pDrawing, &pData);			
		GeometryFacadeCopyWideString(wReleaseFolderPath,pData.path, GEOMETRY_FACADE_VALUE_UNUSED);

		//check if Relase CAD file name is mapped , if yes Geometry file referenced in drawing will need to renamed.
		if(sGeomReleaseFileName.length() > 0)
		{
			GeometryFacadeName wGeomReleaseName= {};
			GeometryFacadeMdlType pGeomType;
			std::string sGeomName , sGeomType;

			GetMdlNameTypeFromString_wrapper(sGeometryFileName,sGeomName,sGeomType);
			if(sGeomType.compare(".prt") == 0 || sGeomType.compare(".PRT") == 0)
				pGeomType = GEOMETRY_FACADE_MDL_PART;
			else
				pGeomType = GEOMETRY_FACADE_MDL_ASSEMBLY;

			GeometryFacadeRetrieveMdl(sGeometryFileName.c_str(), pGeomType ,&pDrwGeometry);
			GeometryFacadeStringToWideString(wGeomReleaseName,sGeomReleaseFileName.c_str());
			GeometryFacadeRenameMdl(pDrwGeometry,wGeomReleaseName);			
		}

		if(strlen(sAsmChildId.c_str()) != 0)
			LOG << "backupModel_wrapper: Geometry file is static assembly , it children are mapped for Release Name" << endl;

		CheckAndPerformStaticAsmChildRenaming(sGeometryFileName , pDrwGeometry , sAsmChildId , sAsmChildRelName);
		GeometryFacadeBackupMdl(pDrawing, &pData);
	}
	else
	{
		GeometryFacadeMdl pGeometry = NULL;
		pGeometry = LoadModel_wrapper(sGeometryFileName);
		GeometryFacadeGetMdlData(pGeometry,&pData);
		GeometryFacadeCopyWideString(wReleaseFolderPath,pData.path,GEOMETRY_FACADE_VALUE_UNUSED);

		if(sGeomReleaseFileName.length() > 0)
		{
			GeometryFacadeName wGeomReleaseName = {};
			GeometryFacadeStringToWideString(wGeomReleaseName,sGeomReleaseFileName.c_str());			
			GeometryFacadeRenameMdl(pGeometry,wGeomReleaseName);
		}

		if(strlen(sAsmChildId.c_str()) != 0)
			LOG << "backupModel_wrapper: Geometry file is static assembly , it children are mapped for Release Name" << endl;

		CheckAndPerformStaticAsmChildRenaming(sGeometryFileName , pGeometry , sAsmChildId , sAsmChildRelName);
		GeometryFacadeBackupMdl(pGeometry,&pData);				
	}

	LOG << "backupModel_wrapper: Release file : " << sGeomReleaseFileName  << " created succesfully in release folder." << endl;
}

//bIsToWorking = will be True when restoring component names from Release To Working.
void CheckAndPerformStaticAsmChildRenaming(std::string sGeomFileName , GeometryFacadeMdl pParentAsmHandle , std::string sAsmChildId , std::string sAsmChildRelName , bool bIsToWorking)
{
	try
	{
		if(strlen(sAsmChildId.c_str()) != 0)
		{
			LOG << "CheckAndPerformStaticAsmChildRenaming: Static assembly components are Renamed , performing Rename operation." << endl;
			if(pParentAsmHandle == NULL)
			{
				GeometryFacadeMdlType pGeomType;
				std::string sGeomName , sGeomType;

				GetMdlNameTypeFromString_wrapper(sGeomFileName,sGeomName,sGeomType);
				if(sGeomType.compare(".prt") == 0 || sGeomType.compare(".PRT") == 0)
					pGeomType = GEOMETRY_FACADE_MDL_PART;
				else
					pGeomType = GEOMETRY_FACADE_MDL_ASSEMBLY;

				GeometryFacadeRetrieveMdl(sGeomFileName.c_str(), pGeomType ,&pParentAsmHandle);
				LOG << "CheckAndPerformStaticAsmChildRenaming: Static Assembly retreived.." << endl;
			}

			GeometryFacadeDisplayMdl(pParentAsmHandle);//make static assembly as displayed part
			LOG << "CheckAndPerformStaticAsmChildRenaming: Static Assembly set as displayed part...." << endl;

			std::vector<std::string> vChildId;
			std::vector<std::string> vChildRelName;

			//store each id and name of child in vector
			ProcessNoteText(sAsmChildId , "#||#" , vChildId);
			ProcessNoteText(sAsmChildRelName , "#||#" , vChildRelName);

			for(int i = 0 ; i<(int)vChildId.size() ; i++)
			{
				GeometryFacadeMdl pChildHandle = NULL;
				std::string sNewChildId , sChildOldId;
				if(bIsToWorking)
				{
					sNewChildId = GetNewChildIdValue(pParentAsmHandle , vChildId[i]);
					if(strlen(sNewChildId.c_str()))
					{
						sChildOldId = vChildId[i]; //it will be required to form name of parameter while deleting.
						vChildId[i] = sNewChildId;
					}
				}
				GetAsmcompMdl(vChildId[i] , &pChildHandle);
				if(pChildHandle != NULL)
				{				
					GeometryFacadeName wChildCrntName , wChildRelName;				
					GeometryFacadeGetMdlName(pChildHandle , wChildCrntName);
					GeometryFacadeStringToWideString(wChildRelName , vChildRelName[i].c_str());
					int iCmp = 0;
					ProWstringCompare(wChildCrntName , wChildRelName , GEOMETRY_FACADE_VALUE_UNUSED , &iCmp);
					if(iCmp != 0)
					{
						LOG << "CheckAndPerformStaticAsmChildRenaming: Renaming Static Assembly Component at Path <" << vChildId[i] << "> to New Name <"<<  vChildRelName[i].c_str() << ">"<< endl;

						///Here now we have static assembly component for Renaming.So process document name method will be used for this as well.
						//method will take care of replace components if there are multiple instances found , it will return ID of replaced component.
						//Same method will be used for Working_TO_Release and Release_TO_Working.
						int iCompId = ProcessDocumentNameForStaticAsmComponent_wrapper("" , vChildId[i] , const_cast<char*>(vChildRelName[i].c_str()));

						if(!bIsToWorking && iCompId != 0)
						{
							LOG << "CheckAndPerformStaticAsmChildRenaming: Static assembly child Renaming is performed from Working name To Release name , New Comp Id returned is <" << iCompId << ">" << endl;
							//It is Working To Release rename.
							//component had instances , so instead of Rename operation Replace is performed.
							//this new Id(iCompId) has to be preserved so that , while going for Release To Working replaced component can be identified and re-replacement will be performed.
							UpdateAndStoreNewComponentId(vChildId[i] , iCompId , pParentAsmHandle);
						}
						else if(bIsToWorking && (strlen(sChildOldId.c_str()) != 0))
						{
							DeleteParameter(pParentAsmHandle , sChildOldId.c_str());
						}
					}
				}
			}
			LOG << "CheckAndPerformStaticAsmChildRenaming: Completed" << endl; 
		}
	}
	catch(ProeException ex)
	{
		LOG << "CheckAndPerformStaticAsmChildRenaming: Caught Outer exception <" << sAsmChildId << "> and <" << sAsmChildRelName << ">." << endl;
	}
}

void DeleteParameter(GeometryFacadeMdl pParentAsmHandle , const char *cChildId)
{
	try
	{
		GeometryFacadeName wName;
		GetParameterName(cChildId , wName);
		GeometryFacadeParameter pParameter;
		GeometryFacadeModelItem pMdlItem;

		GeometryFacadeMdlToModelItem(pParentAsmHandle , &pMdlItem);
		if(ProParameterInit(&pMdlItem , wName , &pParameter) == GEOMETRY_FACADE_NO_ERROR)
		{
			ProParameterDelete(&pParameter);
		}
	}
	catch(ProeException ex)
	{
		LOG << "DeleteParameter: Caught Outer exception <" << cChildId  << ">." << endl;
	}
}


std::string GetNewChildIdValue(GeometryFacadeMdl pParentAsmHandle , std::string sCompOldId)
{
	std::string sNewCompId;
	try
	{
		std::vector<std::string> vCompIdPath;
		GeometryFacadeName wParamName;
		GeometryFacadeParameter parameter;
		GeometryFacadeParameterValue parvalue;
		GeometryFacadeModelItem pMdlItem;

		GetParameterName(sCompOldId , wParamName);
		GeometryFacadeMdlToModelItem(pParentAsmHandle , &pMdlItem);
		if(ProParameterInit(&pMdlItem, wParamName, &parameter) == GEOMETRY_FACADE_NO_ERROR)
		{
			GeometryFacadeGetParameterValue(&parameter, &parvalue);
			if (parvalue.type == GEOMETRY_FACADE_PARAM_STRING)
			{
				GeometryFacadeLine wParamVal;
				GeometryFacadeGetParameterValueValue(&parvalue, GEOMETRY_FACADE_PARAM_STRING, wParamVal);
				GeometryFacadeWideStringToString(const_cast<char*>(sNewCompId.c_str()) , wParamVal);
				LOG << "GetNewChildIdValue: New Id Path value retreived from Paramter as <" << sNewCompId.c_str() << ">." << endl;
			}
		}
	}
	catch(ProeException ex)
	{
		LOG << "GetNewChildIdValue: ERROR: While retreiving new component Id path " << endl;
	}
	return sNewCompId.c_str();
}

void GetParameterName(std::string sCompId , GeometryFacadeWideChar *wParameterName)
{	
	std::vector<std::string> vCompIdPath;

	//Now prepare name of PARAMETER , it will start with prefix as R 
	//complete name will be formed using Id path value so that unique Parameter name can be maintained.
	//Parameter will be created in parent static assembly and it will hold New Id path of the component.
	std::string sParamName = "R";
	ProcessNoteText(sCompId , "," , vCompIdPath);
	for(int j = 0; j <(int)vCompIdPath.size() ; j++)
	{
		sParamName.append(vCompIdPath[j]);
	}

	LOG << "GetParameterName: Parameter name compiled as <" << sParamName << ">" << endl;
	GeometryFacadeStringToWideString(wParameterName , sParamName.c_str());
}

void UpdateAndStoreNewComponentId(std::string sCompOldId ,int iCompId , GeometryFacadeMdl pParentAsmHandle)
{
	try
	{					
		std::vector<std::string> vCompIdPath;
		ProcessNoteText(sCompOldId , "," , vCompIdPath);

		int iCompIdPos = int(vCompIdPath.size()) -1;
		char cCompId[10];
		itoa(iCompId , cCompId , 10);
		vCompIdPath[iCompIdPos] = cCompId;

		std::string sNewIdPath;
		for(int j = 0; j <(int)vCompIdPath.size() ; j++)
		{
			if(strlen(sNewIdPath.c_str()) == 0)
				sNewIdPath = vCompIdPath[j];
			else
				sNewIdPath.append(",").append(vCompIdPath[j]);
		}

		LOG << "UpdateAndStoreNewComponentId: Old Comp Id path is <" << sCompOldId << "> & New Coomp Id path is <" << sNewIdPath << ">" << endl;

		//set parameter value
		GeometryFacadeParameterValue Pvalue;
		Pvalue.type = GEOMETRY_FACADE_PARAM_STRING;
		GeometryFacadeStringToWideString(Pvalue.value.s_val , sNewIdPath.c_str());

		GeometryFacadeName wParmName;
		GetParameterName(sCompOldId , wParmName);

		//Create Parameter with value as New Id Path of the component.
		GeometryFacadeParameter pParameter;
		GeometryFacadeModelItem pParentAsmMdlItem;
		GeometryFacadeMdlToModelItem(pParentAsmHandle , &pParentAsmMdlItem);
		GeometryFacadeCreateParameter(&pParentAsmMdlItem,wParmName,&Pvalue,&pParameter);

		LOG << "UpdateAndStoreNewComponentId: parameter created succesfully" << endl;
	}
	catch(ProeException ex)
	{
		LOG << "UpdateAndStoreNewComponentId: ERROR: While create and setting parameter value <" << ex.GetLine() <<  "> <" << ex.GetResult() << ">." << endl;
	}
}

static void BackupModelToWIP_wrapper(std::string sWIPFolderPath,std::string sGeometryFileRelName , std::string sGeomFileWIPName , std::string  sDrawingFileName, std::string sDrwReleaseFileName , std::string sAsmChildId , std::string sAsmChildWrkngName)
{
	LOG << "BackupModelToWIP_wrapper: Copying geometry file release name : "<< sGeometryFileRelName << " to working name." << endl;

	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdlData pData;
	GeometryFacadePath wWIPFolderPath = {};
	GeometryFacadeStringToWideString(wWIPFolderPath,sWIPFolderPath.c_str());

	if(sDrawingFileName.length() > 0)
	{
		GeometryFacadeMdl pDrwGeometry = NULL;
		GeometryFacadeName wGeomWIPName= {};
		GeometryFacadeMdlType pGeomType;
		std::string sGeomName , sGeomType;

		GetMdlNameTypeFromString_wrapper(sGeometryFileRelName,sGeomName,sGeomType);
		if(sGeomType.compare(".prt") == 0 || sGeomType.compare(".PRT") == 0)
			pGeomType = GEOMETRY_FACADE_MDL_PART;
		else
			pGeomType = GEOMETRY_FACADE_MDL_ASSEMBLY;

		GeometryFacadeRetrieveMdl(sGeometryFileRelName.c_str(), pGeomType ,&pDrwGeometry);		
		GeometryFacadeGetMdlData(pDrwGeometry, &pData);	

		GeometryFacadeCopyWideString(wWIPFolderPath,pData.path, GEOMETRY_FACADE_VALUE_UNUSED);		
		GeometryFacadeBackupMdl(pDrwGeometry,&pData);

		if(strlen(sAsmChildId.c_str()) != 0)
			LOG << "BackupModelToWIP_wrapper: Geometry file is static assembly , its children were renamed with Release Name , bring them now to Working Name" << endl;

		CheckAndPerformStaticAsmChildRenaming(sGeometryFileRelName , pDrwGeometry , sAsmChildId , sAsmChildWrkngName , true);

		GeometryFacadeStringToWideString(wGeomWIPName,sGeomFileWIPName.c_str());
		char cGeomFileCurrentName[GEOMETRY_FACADE_LINE_SIZE];
		ProWstringToString(cGeomFileCurrentName , pData.name);

		int iCmp = 0;
		ProName fileName;
		GeometryFacadeStringToWideString(fileName, sGeomFileWIPName.c_str());
		iCmp =  _wcsicmp(pData.name, fileName);

		if(iCmp != 0)
			GeometryFacadeRenameMdl(pDrwGeometry,wGeomWIPName);

		GeometryFacadeSaveMdl(pDrwGeometry);		

		//Load drawing file..
		GeometryFacadeMdl pDrawing = LoadModel_wrapper(sDrawingFileName);
		GeometryFacadeGetMdlData(pDrawing, &pData);			
		GeometryFacadeCopyWideString(wWIPFolderPath,pData.path, GEOMETRY_FACADE_VALUE_UNUSED);
		GeometryFacadeBackupMdl(pDrawing,&pData);
	}
	else
	{
		GeometryFacadeMdl pGeometry = NULL;
		pGeometry = LoadModel_wrapper(sGeometryFileRelName);		
		GeometryFacadeGetMdlData(pGeometry, &pData);			
		GeometryFacadeCopyWideString(wWIPFolderPath,pData.path, GEOMETRY_FACADE_VALUE_UNUSED);

		GeometryFacadeName wGeomWIPName = {};
		GeometryFacadeStringToWideString(wGeomWIPName,sGeomFileWIPName.c_str());				
		GeometryFacadeBackupMdl(pGeometry,&pData);

		if(strlen(sAsmChildId.c_str()) != 0)
			LOG << "BackupModelToWIP_wrapper: Geometry file is static assembly , its children were renamed with Release Name , bring them now to Working Name" << endl;

		CheckAndPerformStaticAsmChildRenaming(sGeometryFileRelName , pGeometry , sAsmChildId , sAsmChildWrkngName , true);

		int iCmp = 0;
		ProName fileName;
		GeometryFacadeStringToWideString(fileName, sGeomFileWIPName.c_str());
		iCmp =  _wcsicmp(pData.name, fileName);
		if (iCmp != 0)
		{
			GeometryFacadeRenameMdl(pGeometry, wGeomWIPName);
		}
	}

	LOG << "BackupModelToWIP_wrapper: Geometry file rename to working name : "<< sGeomFileWIPName << " completed." << endl;
}

//static void backupModel_wrapper(std::string thePathName) 
//{
//	GeometryFacadeMdl model,drawing;
//	GeometryFacadeMdlData data;
//	GeometryFacadePath thePathName_w;
//	char type[4];
//	char cDrwFile[GEOMETRY_FACADE_NAME_SIZE];
//	GeometryFacadeSolid *pDrwSlds = NULL;
//	GeometryFacadeError result;
//
//	GeometryFacadeGetCurrentMdl(&model);
//
//	GeometryFacadeStringToWideString(thePathName_w, const_cast<char*>(thePathName.c_str()));
//
//	GeometryFacadeGetMdlData(model, &data);
//	GeometryFacadeWideStringToString(type,data.type);
//
//	if (strncmp(type,"PRT",3) == 0 || strncmp(type,"ASM",3) == 0)
//	{
//		GeometryFacadeWideStringToString(cDrwFile,data.name);
//		strcat(cDrwFile,".drw");
//		try
//		{
//			GeometryFacadeRetrieveMdl(cDrwFile,GEOMETRY_FACADE_MDL_DRAWING,&drawing);
//			GeometryFacadeGetMdlData(drawing, &data);			
//			GeometryFacadeCopyWideString(thePathName_w, data.path, GEOMETRY_FACADE_VALUE_UNUSED);
//			GeometryFacadeBackupMdl(drawing, &data);
//		}
//		catch(ProeException ex)
//		{
//			LOG << "Exception handled " << ex.GetFile() << " : " << ex.GetLine() << " : " << ex.GetMsg() <<" : " << ex.GetResult() << endl;
//			GeometryFacadeGetMdlData(model, &data);			
//			GeometryFacadeCopyWideString(thePathName_w, data.path, GEOMETRY_FACADE_VALUE_UNUSED);
//			GeometryFacadeBackupMdl(model, &data);
//		}
//	}
//	else
//	{	
//		result = ProDrawingSolidsCollect((GeometryFacadeDrawing)model,&pDrwSlds);
//		LOG << "Solid collect result in backup " << result << endl;
//		GeometryFacadeCopyWideString(thePathName_w, data.path, GEOMETRY_FACADE_VALUE_UNUSED);
//		GeometryFacadeBackupMdl(model, &data);
//		GeometryFacadeDisplayMdl((GeometryFacadeMdl)pDrwSlds[0]);
//		int windowId = GeometryFacadeGetCurrentWindow();
//		GeometryFacadeActivateWindow(windowId);
//	}
//}


static void eraseCurrentModel_wrapper() 
{   
	GeometryFacadeMdl model = NULL;
	int ProeWindow = 0;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		ProeWindow = GeometryFacadeGetCurrentWindow();		
		result = ProWindowMdlGet(ProeWindow,&model);

		if (result == GEOMETRY_FACADE_NO_ERROR && model != NULL)
		{
			try
			{
				GeometryFacadeEraseMdl(model);				
			}
			catch (ProeException ex)
			{					
				throw;			
			}
		}
	}
	catch (ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_BAD_CONTEXT)
		{
			throw;
		}		
	}
}


//static int loadModel_wrapper(std::string PrtName, int display)
//{
//	GeometryFacadeMdl model;
//
//	return UserModelLoad_wrapper((char*)PrtName.c_str(), &model, display);
//}


static void renameModel_wrapper(std::string theIDPath, std::string theNewName) 
{
	// Get the model.
	GeometryFacadeMdl model = NULL;
	GetAsmcompMdl(theIDPath, &model);

	// Get the new name in to the proper format.
	GeometryFacadeName new_name_w;
	GeometryFacadeStringToWideString(new_name_w, const_cast<char*>(theNewName.c_str()));

	// Make the change.
	try
	{
		ProName wmdlName;
		ProMdlNameGet(model,wmdlName);

		ProName fileName;
		GeometryFacadeStringToWideString(fileName, theNewName.c_str());
		int iCmprRslt =  _wcsicmp(fileName, wmdlName);

		if(iCmprRslt != 0)
		{
			GeometryFacadeRenameMdl(model, new_name_w);
		}
	}
	catch(ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
		{
			if(model != NULL)
				ProMdlEraseAll(model);

			throw;
		}
	}

	if(model != NULL)
		ProMdlErase(model);
}


static void repaintCurrentModel_wrapper() 
{
	GeometryFacadeMdl model;
	int iWinID;
	ProError result = PRO_TK_NO_ERROR;

	ProWindowCurrentGet(&iWinID);
	ProWindowMdlGet(iWinID,&model); 
	//GeometryFacadeGetCurrentMdl(&model);

	// Get the window ID.
	int windowId = GeometryFacadeGetMdlWindow(model);

	GeometryFacadeRefreshWindow(windowId);
	result = ProTreetoolRefresh(model);
	LOG << "Tree tool refresh result : " << result << endl;
}


static void saveModel_wrapper() 
{
	GeometryFacadeMdl model;
	GeometryFacadeGetCurrentMdl(&model);

	ProMdldata pMdlData;	
	ProMdlDataGet(model,&pMdlData);
	ProLayerDisplaystatusSave(model);
	GeometryFacadeBackupMdl(model,&pMdlData);
	//GeometryFacadeSaveMdl(model);
}
