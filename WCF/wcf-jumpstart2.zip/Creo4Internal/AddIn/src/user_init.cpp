// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"
#include "Log.h"
#include "Utilities.h"
#include "Utility.h"
#include "user_init.h"


DECLARE_MSGIFILE




// global variable
std::string result_string;
std::wstring result_wstring;


int user_initialize(int argc, char *argv[], char *version, char *build, GeometryFacadeWideChar *error)
{
	// This is the starting point for loading the AddIn.  At this point, Pro/ENGINEER
	// has been started but the AddIn hasn't been loaded.  This is a good place to put
	// a breakpoint when the AddIn needs to be debugged from the beginning.  Just
	// place a breakpoint here & in the ProeConnector::LoadDll() method.  When the LoadDll()
	// breakpoint is hit, attach a debugger to the xtop process & then release the LoadDll()
	// breakpoint.  This breakpoint will be hit & you can begin debugging the AddIn from
	// the beginning.

	// The addin works in synchronous dll mode, so user_initialize()
	// is used to perform any necessary initialization.
	// NOTE: This means that you CANNOT link the AddIn with any of the Pro/TOOLKIT
	// or Pro/DEVELOP asynchronous mode libraries: protoolkit.lib, pt_asynchronous.lib
	// or prodevelop.lib.  Doing so gives bizarre failures when trying to load the AddIn.

	// Enable threading in Pro/ENGINEER.
	// Note that this slows down performance, so only enable if necessary.
	//status = ProEngineerMultithreadModeEnable();

	// We know that the Rulestream software version is the same
	// as the configuration directory name, and that the text 
	// directory name points to the configuration directory.
	// So let's extract the Rulestream version from the text
	// directory string.
	
	//it was added to find memory leaks
	//_CrtDumpMemoryLeaks();

	
	// Get the text directory.
	GeometryFacadePath textPath;
	GeometryFacadeGetToolkitApplTextPath(textPath);
	char cstring[GEOMETRY_FACADE_PATH_SIZE];
    GeometryFacadeWideStringToString(cstring, textPath);

	// Fortunately, textDir is the same as the RuleStream.ini path.
	char iniFile[1024];
	strncpy(iniFile, cstring, sizeof(cstring) - 1);
	strncat(iniFile, "RuleStream.ini", sizeof(cstring) - strlen(iniFile) - 1);
	
	// Store the ini file for future use.
	SetIniFile(iniFile);

	// Find the last directory separator.
	std::string stlstring = std::string(cstring);
	stlstring = stlstring.substr(0, stlstring.rfind('\\'));

	// Extract the RS version.
	std::string rsVersion = stlstring.substr(stlstring.rfind('\\') + 1);

	// Save the version number.
	SetSoftwareVersion( rsVersion.c_str() );
	
	// Display the message.
	stlstring = "Rulestream " + rsVersion + " running Pro/ENGINEER " + std::string(version) + "." + build + "."; 
	GeometryFacadeDisplayMessage(MSGFILE, "ADDIN %0s", stlstring.c_str());
	
	// Scroll the screen.
	GeometryFacadeClearMessage();

	LOG << stlstring << std::endl;
	LOG << "Text Directory: " << cstring << std::endl;

    return 0;
}


void user_terminate()
{
	// Clean up the logging class.
	Log::Destroy();

	return;
}