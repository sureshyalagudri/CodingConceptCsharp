// C/C++ header files.
#include <string>
#include <sstream>
#include <map>
#include <functional>


// Application header files.
#include "Layers.h"
#include "Models.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "Drawings.h"
#include "Log.h"

std::vector<std::wstring> StringSplit(std::wstring inputText, std::wstring delimiter);

//Variable to hold dimension string 
std::map<std::string, std::string> mStrMap;
map<std::string ,std::string> mMdlDimStr;
vector<int> lDimIds;
vector<int>::iterator DimItr;
GeometryFacadeDrawing pStoreDrwHandle = NULL;
int iCount = 0; //it is used to form dimension Name 

// Exported functions
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CreateProDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring newName;
	std::wstring drawingTemplateName;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1",&data);
		newName = data.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2",&data);
		drawingTemplateName = data.v.w;

		createProDrawing_wrapper(newName, drawingTemplateName);
	}
	catch (ProeException ex)
	{
		//Create a message with inputs here which will be then written ProEManager.log
		std::string sFailureMsg = "Failed to Create ProE Drawing : ";
		AddWStringToMsgString(sFailureMsg, newName);
		sFailureMsg.append(" Using Template : ");
		AddWStringToMsgString(sFailureMsg, drawingTemplateName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingCurrentSheetSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int sheet;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sheet = data.v.i;

		// Declare the output arguments and call the function.
		drawingCurrentSheetSet_wrapper(sheet);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Current Sheet : ";
		std::stringstream ss;
		ss << sheet;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingScaleSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int sheet;
	double scale;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sheet = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		scale = data.v.d;

		drawingScaleSet_wrapper(sheet, scale);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Scale for Sheet : ";
		std::stringstream ss;
		ss << sheet;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Scale : ");
		ss << scale;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewScaleSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring viewName;
	double scale;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		viewName = data.v.w;

		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		scale = data.v.d;

		drawingViewScaleSet_wrapper(viewName, scale);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set View : ";
		AddWStringToMsgString(sFailureMsg, viewName);
		std::stringstream ss;
		ss << scale;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingAnnotationDisplaySet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iAnnotId;
	std::wstring sAnnotDisplay;
	std::wstring sAnnotType;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iAnnotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sAnnotDisplay = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sAnnotType = data.v.w;

		DrawingAnnotationDisplaySet_wrapper(iAnnotId,sAnnotDisplay,sAnnotType);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Display for Annotation : ";
		AddWStringToMsgString(sFailureMsg, sAnnotType);
		sFailureMsg.append( " to : ");
		AddWStringToMsgString(sFailureMsg, sAnnotDisplay);
		std::stringstream ss;
		ss << iAnnotId;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelAnnotationDisplaySet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{

	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int iAnnotId;
	std::wstring sAnnotDisplay;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iAnnotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sAnnotDisplay = data.v.w;

		DrawingModelAnnotationDisplaySet_wrapper(iAnnotId,sAnnotDisplay);

	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Model Annotation : ";
		std::stringstream ss;
		ss << iAnnotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to : ");
		AddWStringToMsgString(sFailureMsg, sAnnotDisplay);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int iAnnotId;
	double dDimLocation;
	std::wstring sMoveDir;


	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iAnnotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		dDimLocation = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sMoveDir = data.v.w;

		DrawingModelDimensionLocationChange_wrapper(iAnnotId,dDimLocation,sMoveDir);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Change Location Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << iAnnotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Location : ");
		ss.str("");
		ss << dDimLocation;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" In the Direction : ");
		AddWStringToMsgString(sFailureMsg, sMoveDir);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionDecimalPlaceChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	int decimal;


	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		decimal = data.v.i;

		DrawingModelDimensionDecimalPlaceChange_wrapper(annotId,decimal);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set decimal place Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to decimal place : ");
		ss.str("");
		ss << decimal;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionUpperTolChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	double upper;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		upper = data.v.d;

		DrawingModelDimensionUpperTolChange_wrapper(annotId,upper);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Upper Tolerance Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to upper tolerance : ");
		ss.str("");
		ss << upper;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionLowerTolChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	double lower;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		lower = data.v.d;

		DrawingModelDimensionLowerTolChange_wrapper(annotId,lower);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Lower Tolerance Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to lower tolerance : ");
		ss.str("");
		ss << lower;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionToleranceDecimalPlaceChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	int decimal;


	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		decimal = data.v.i;

		DrawingModelDimensionToleranceDecimalPlaceChange_wrapper(annotId,decimal);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Tolerance decimal place Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Tolerance decimal place : ");
		ss.str("");
		ss << decimal;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableNameColumnChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	std::wstring tableName;
	int column;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		tableName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		column = data.v.i;	

		DrawingModelDimensionTableNameColumnChange_wrapper(annotId,tableName, column);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Table Name and Table Column Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Table Name : ");
		AddWStringToMsgString(sFailureMsg, tableName);
		sFailureMsg.append(" to Table column: ");
		ss.str("");
		ss << column;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableNameChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	std::wstring tableName;


	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		tableName = data.v.w;

		DrawingModelDimensionTableNameChange_wrapper(annotId,tableName);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Table Name Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Table Name : ");
		AddWStringToMsgString(sFailureMsg, tableName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableColumnChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError	result = GEOMETRY_FACADE_NO_ERROR;
	int annotId;
	int column;


	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		annotId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		column = data.v.i;

		DrawingModelDimensionTableColumnChange_wrapper(annotId,column);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to set Table Column Of Model Dimension with ID : ";
		std::stringstream ss;
		ss << annotId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Table Column : ");
		ss.str("");
		ss << column;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingDimensionLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iDimId;
	double dDimLocation;
	std::wstring sMoveDir;

	try
	{
		GeometryFacadeValueData data;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iDimId = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		dDimLocation = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sMoveDir = data.v.w;

		DrawingDimensionLocationChange_wrapper(iDimId,dDimLocation,sMoveDir);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Change Location Of Drawing Dimension with ID : ";
		std::stringstream ss;
		ss << iDimId;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Location : ");
		ss.str("");
		ss << dDimLocation;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" In the Direction : ");
		AddWStringToMsgString(sFailureMsg, sMoveDir);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingNoteLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	int iNoteID;
	double dNoteLoc;
	std::wstring sMoveDir;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		iNoteID = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		dNoteLoc = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sMoveDir = data.v.w;

		DrawingNoteLocationChange_wrapper(iNoteID,dNoteLoc,sMoveDir);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Change Location Of Drawing Note with ID : ";
		std::stringstream ss;
		ss << iNoteID;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to Location : ");
		ss.str("");
		ss << dNoteLoc;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" In the Direction : ");
		AddWStringToMsgString(sFailureMsg, sMoveDir);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingNoteTextSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring sNoteID;
	std::wstring sSheetID;
	std::wstring noteText;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sNoteID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		sSheetID = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		noteText = data.v.w;

		int iNoteID = stoi(sNoteID.c_str());
		int iSheetID = stoi(sSheetID.c_str());
		
		DrawingNoteTextSet_wrapper(iNoteID,iSheetID,noteText);
	}

	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Text for Note : ";
		AddWStringToMsgString(sFailureMsg, sNoteID);
		sFailureMsg.append(" on Sheet : ");
		AddWStringToMsgString(sFailureMsg, sSheetID);
		sFailureMsg.append(" to the Text : ");
		AddWStringToMsgString(sFailureMsg, noteText);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();

	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingRename_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring partName;
	std::wstring templatePartName;
	std::wstring drawingToRename;
	std::wstring newDrawingName;
	int iIsDrwGeomChanged = -1;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		partName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		templatePartName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		drawingToRename = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		newDrawingName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG5", &data);
		iIsDrwGeomChanged = data.v.i;

		drawingRename_wrapper(partName, templatePartName, drawingToRename, newDrawingName , iIsDrwGeomChanged);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to rename drawing: ";
		AddWStringToMsgString(sFailureMsg, drawingToRename);
		sFailureMsg.append(" to new drawing : ");
		AddWStringToMsgString(sFailureMsg, newDrawingName);
		sFailureMsg.append(" , Template part name was: ");
		AddWStringToMsgString(sFailureMsg, templatePartName);
		sFailureMsg.append(" of part : ");
		AddWStringToMsgString(sFailureMsg, partName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingCreateFromTemplate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring partName;
	std::wstring drawingToRename;
	std::wstring newDrawingName;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		partName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		drawingToRename = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		newDrawingName = data.v.w;

		DrawingCreateFromTemplate_wrapper(partName , drawingToRename , newDrawingName);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "DrawingCreateFromTemplate_task: Failed to rename drawing: ";
		AddWStringToMsgString(sFailureMsg, drawingToRename);
		sFailureMsg.append(" to new drawing : ");
		AddWStringToMsgString(sFailureMsg, newDrawingName);
		sFailureMsg.append(" for part : ");
		AddWStringToMsgString(sFailureMsg, partName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingSheetRegenerate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		drawingSheetRegenerate_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Regenerate Drawing Sheet";
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewRegenerate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		drawingViewRegenerate_wrapper();
	}
	catch (ProeException ex)
	{
		ex.m_message = "Failed to Regenerate Drawing View";
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}


GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetTableCell_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		int tableID = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		int raw = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		int column = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		std::wstring content = data.v.w;

		// Declare the output arguments and call the function.
		int output;
		setTableCell_wrapper(tableID, raw, column, content, output);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString (arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = output;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		// The GeometryFacadeExecuteToolkitTask() mechanism doesn't
		// allow passing exceptions, so save the error information.
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t *sViewName=NULL;
	double dDist;
	std::wstring sMoveDir;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sViewName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		dDist = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sMoveDir = data.v.w;

		DrawingViewLocationChange_wrapper(sViewName,dDist,sMoveDir);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Change View : ";
		AddWStringToMsgString(sFailureMsg, sViewName);
		sFailureMsg.append(" Location to : ");
		std::stringstream ss;
		ss << dDist;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" to the Direction : ");
		AddWStringToMsgString(sFailureMsg, sMoveDir);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewModelViewNameChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring viewName;
	std::wstring mdlViewName;
	std::wstring orientation;
	double xAngle;
	double yAngle;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		viewName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		mdlViewName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		orientation = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		xAngle = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG5", &data);
		yAngle = data.v.d;

		DrawingViewModelViewChange_wrapper(viewName, mdlViewName, orientation, xAngle, yAngle);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Change View : ";
		AddWStringToMsgString(sFailureMsg, viewName);
		sFailureMsg.append(" Model view:");
		AddWStringToMsgString(sFailureMsg, mdlViewName);
		sFailureMsg.append(" orientation:");
		AddWStringToMsgString(sFailureMsg, orientation);
		sFailureMsg.append(" X angle:");
		std::stringstream ss;
		ss << xAngle;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" Y angle:");
		ss.str("");
		ss << yAngle;
		sFailureMsg.append(ss.str());
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewSizeSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t *sViewName = NULL;
	double dViewSize;
	std::wstring sChangeDir;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		sViewName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		dViewSize = data.v.d;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		sChangeDir = data.v.w;

		DrawingViewSizeSet_wrapper(sViewName,dViewSize,sChangeDir);
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Set Size of View : ";
		AddWStringToMsgString(sFailureMsg, sViewName);
		sFailureMsg.append(" to the Size : ");
		std::stringstream ss;
		ss << dViewSize;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" in the Direction : ");
		AddWStringToMsgString(sFailureMsg, sChangeDir);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;

}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingRenameFTInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t *cModelName = NULL;
	wchar_t *cTempFile = NULL;
	wchar_t *cDrwFile = NULL;
	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cModelName = data.v.w;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		cTempFile = data.v.w;
	
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		cDrwFile = data.v.w;
		
		result = DrawingRenameFTInstance_wrapper(cModelName,cTempFile,cDrwFile);
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString (arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
		arg.value.v.i = result;
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Rename Drawing : ";
		AddWStringToMsgString(sFailureMsg, cDrwFile);
		sFailureMsg.append(" of FT Model : ");
		AddWStringToMsgString(sFailureMsg, cModelName);
		sFailureMsg.append(" Using Template file : ");
		AddWStringToMsgString(sFailureMsg, cTempFile);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;


}

// Exported functions.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetListOfDrawingRefModels_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	try
	{
		std::wstring allMdlList = GetListOfDrawingRefModels_wrapper();
		
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, allMdlList.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		LOG << "GetListOfDrawingRefModels_task: Caught Outer exception while retreiving list of models in current session." <<  endl;
	}
	return GEOMETRY_FACADE_NO_ERROR;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDrawingViewModelNames_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t * viewName;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		viewName = data.v.w;

		std::wstring allMdlList = GetDrawingViewModelNames_wrapper(viewName);
		
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, allMdlList.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		LOG << "GetDrawingViewModelNames_task: Caught Outer exception while retreiving list of models in current session." <<  endl;
	}
	return GEOMETRY_FACADE_NO_ERROR;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDrawingViewType_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t * viewName;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		viewName = data.v.w;

		std::wstring allMdlList = GetDrawingViewType_wrapper(viewName);
		
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, allMdlList.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		LOG << "GetDrawingViewType_task: Caught Outer exception while retreiving list of models in current session." <<  endl;
	}
	return GEOMETRY_FACADE_NO_ERROR;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddDrawingTable_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t* cTableInfo = NULL;
	int iSheet;
	wchar_t *cTableID = NULL;

	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cTableInfo = data.v.w;
	
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		iSheet = data.v.i;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		cTableID = data.v.w;
		
		std::wstring Table = AddDrawingTable_wrapper(cTableInfo,iSheet,cTableID);
		
	
		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, Table.c_str() );
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch (ProeException ex)
	{
		std::string sFailureMsg = "Failed to Add Drawing Table with info : \n";
		AddWStringToMsgString(sFailureMsg, cTableInfo);
		sFailureMsg.append(" On Sheet : ");
		std::stringstream ss;
		ss << iSheet;
		sFailureMsg.append(ss.str());
		sFailureMsg.append(" Table ID : ");
		AddWStringToMsgString(sFailureMsg, cTableID);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;

}

//This function is here to read & return current drawing attributes value.
//As we can read change in lower left corner and upper right corner after modifying
//scale of the view.
GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ReadDrawingProperties_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t* cDrwProperty = NULL;
	wchar_t* cDrwEntity = NULL;


	try
	{
		GeometryFacadeValueData data;
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		cDrwProperty = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		cDrwEntity = data.v.w;

		std::wstring cCurValue = ReadDrawingProperties_wrapper(cDrwProperty,cDrwEntity);

		*outputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

		GeometryFacadeArgument arg;
		GeometryFacadeStringToWideString(arg.label, "OUTPUT");
		arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
		GeometryFacadeSetValueDataWstring( &arg.value, cCurValue.c_str());
		GeometryFacadeAddArrayObject( (GeometryFacadeArray*)outputArguments, -1, 1, &arg );
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to Read Drawing Property : ";
		AddWStringToMsgString(sFailureMsg, cDrwProperty);
		sFailureMsg.append(" For Entity : ");
		AddWStringToMsgString(sFailureMsg, cDrwEntity);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}

	return result;
}

GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingMultipleSolidRename_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::wstring partName;
	std::wstring templatePartName;
	std::wstring drawingToRename;
	std::wstring newDrawingName;

	try
	{
		GeometryFacadeValueData data;
		
		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG1", &data);
		partName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG2", &data);
		templatePartName = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG3", &data);
		drawingToRename = data.v.w;

		GeometryFacadeGetArgumentByLabel(inputArguments, L"ARG4", &data);
		newDrawingName = data.v.w;

		DrawingMultipleSolidRename_wrapper(partName, templatePartName, drawingToRename, newDrawingName);
	}
	catch(ProeException ex)
	{
		std::string sFailureMsg = "Failed to rename drawing(having multiple parts referred) : ";
		AddWStringToMsgString(sFailureMsg, drawingToRename);
		sFailureMsg.append(" to new drawing : ");
		AddWStringToMsgString(sFailureMsg, newDrawingName);
		sFailureMsg.append(" , Template part name was : ");
		AddWStringToMsgString(sFailureMsg, templatePartName);
		sFailureMsg.append(" of part : ");
		AddWStringToMsgString(sFailureMsg, partName);
		ex.m_message = sFailureMsg;
		SaveErrorInfo(ex);
		result = (GeometryFacadeError)ex.GetResult();
	}
	return result;
}
// Private functions.
std::wstring ReadDrawingProperties_wrapper(wchar_t* cDrwProperty, wchar_t* cDrwEntity)
{
	//char *cCurValue = NULL;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl pDrawing;
	ProName wViewName;
	ProView *pViewHandle;
	GeometryFacadeVector outline[2],pDrwOutline1;
	std::wstringstream sValue;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	GeometryFacadeCollectDrawingViews((ProDrawing)pDrawing, &pViewHandle);
	int iNoView = GeometryFacadeGetArraySize(pViewHandle);

	for ( int i = 0 ; i<iNoView;i++)
	{
		ProDrawingViewNameGet((ProDrawing)pDrawing,pViewHandle[i],wViewName);

		if (wcscmp(wViewName,cDrwEntity) == 0)
		{
			int sheet = GeometryFacadeGetDrawingViewSheet((ProDrawing)pDrawing, pViewHandle[i]);
			ProDrawingCurrentSheetSet((ProDrawing)pDrawing,sheet);
			GeometryFacadeRegenerateDrawingSheet((ProDrawing)pDrawing, sheet);
			
			GeometryFacadeGetDrawingViewOutline((ProDrawing)pDrawing,pViewHandle[i], outline);   
			//Prohandle pDrawingHdl = (Prohandle)pDrawing;
			if (wcscmp(cDrwProperty,L"Position Lower Left") == 0)
			{
				//<Replaced>GetDrawingVectorCoOrdinates(pDrawingHdl,outline[0],pDrwOutline1);
				GetDrawingVectorCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,outline[0],pDrwOutline1);
				sValue << pDrwOutline1[0] << L"," << pDrwOutline1[1];
			}
			else if(wcscmp(cDrwProperty,L"Position Upper Right") == 0)
			{
				//<Replaced>GetDrawingVectorCoOrdinates(pDrawing,sheet,outline[1],pDrwOutline1);
				GetDrawingVectorCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,outline[1],pDrwOutline1);
				sValue << pDrwOutline1[0] << L"," << pDrwOutline1[1];
			}
		}
	}
	
	return sValue.str();
}

std::wstring AddDrawingTable_wrapper(wchar_t *cTableInfo,int iSheet , wchar_t *cTableID)
{
	wchar_t cCellText[GEOMETRY_FACADE_PATH_SIZE],cNoColn[10],cNoRow[10],cXposition[10],cYposition[10],cColnWid[GEOMETRY_FACADE_PATH_SIZE],cRowHt[10],CHeaderTxt[GEOMETRY_FACADE_PATH_SIZE],
	cClonAlignmt[GEOMETRY_FACADE_PATH_SIZE];
	std::vector<std::wstring> vAllRwTxt;
	std::vector<std::wstring> vCell;
	std::vector<std::wstring> vHeader;
	std::vector<std::wstring> vClnAlgn,vClnWid;
	int iNoColn = 0,iNoRow = 0;
	GeometryFacadePoint3D pOrigin;
	double dRowHt[50],dColnWid[50];
	int i,j,current_length,m;
	GeometryFacadeHorzJust pJustification[50];
	GeometryFacadeMdl pCrntDrw;
	GeometryFacadeDwgtabledata pTableData;
	GeometryFacadeDwgtableSizetype pSize = PRODWGTABLESIZE_CHARACTERS;
	GeometryFacadeDrawingTable pTable,pExistingTable;
	wchar_t current[4096];
	wchar_t *start_tag = L"<GenericTable ";
	wchar_t *end_tag = L"/>";
	wchar_t *start = NULL;
	wchar_t *end = NULL;
	wchar_t TablesIDs[100];

	GeometryFacadeGetCurrentMdl(&pCrntDrw);
	GeometryFacadeSetCurrentDrawingSheet((GeometryFacadeDrawing)pCrntDrw,iSheet);
	
	//cTableID variable hold's ID's of existing tables on sheet
	//Here those will be processed & respective tables will be deleted.
	if(wcslen(cTableID) != 0)
	{
		std::vector<std::wstring> IDList;
		ProcessNoteText(cTableID,L",",IDList);
		for(int l = 0;l<(int)IDList.size();l++)
		{
			int ID = _wtoi(const_cast<wchar_t*>(IDList[l].c_str()));
			GeometryFacadeInitModelItem(pCrntDrw, ID, GEOMETRY_FACADE_DRAW_TABLE, &pExistingTable);
			GeometryFacadeDwgtableDelete(&pExistingTable,1);
		}
	}

	for (m = 0; ;m++)
	{
		// find location of the start tag in the constraints string.
		start = wcsstr(cTableInfo, start_tag);

		// exit when there is no start constraint tag found.
		if(!start)
		{
			break;
		}

		// find location of the end tag in the constraints string.
		end = wcsstr(cTableInfo, end_tag);

		current_length = int(end - start) + int(wcslen(end_tag));

		// Pull the next constraint from the constraints string.
		wcsncpy(current, start, current_length);

		// Terminate the constraint string.
		current[current_length] = L'\0';

		getXMLAttributeValue(current, L"CellText", cCellText);
		//This Function processes given string splits it using delimiter & stores each cell text in a vector
		ProcessNoteText(cCellText,L"~",vAllRwTxt);

		//Get Table position
		getXMLAttributeValue(current, L"XPosition", cXposition);
		getXMLAttributeValue(current, L"YPosition", cYposition);
		pOrigin[0] = _wtof(cXposition);
		pOrigin[1] = _wtof(cYposition);
		pOrigin[2] = 0.0;

		//Get Row & column attribute 
		getXMLAttributeValue(current, L"ColumnCount", cNoColn);
		iNoColn = _wtoi(cNoColn);
		getXMLAttributeValue(current, L"RowCount", cNoRow);
		iNoRow = _wtoi(cNoRow);
		iNoRow += 1;//Added 1 for header
		getXMLAttributeValue(current, L"RowHeight", cRowHt);	
		getXMLAttributeValue(current, L"ColumnWidths", cColnWid);
		ProcessNoteText(cColnWid,L"|",vClnWid);
		getXMLAttributeValue(current, L"ColumnAlignments", cClonAlignmt);
		ProcessNoteText(cClonAlignmt,L"|",vClnAlgn);
		getXMLAttributeValue(current, L"HeaderText", CHeaderTxt);
		ProcessNoteText(CHeaderTxt,L"|",vHeader);

		GeometryFacadeDwgtabledataAlloc(&pTableData);
		GeometryFacadeDwgtabledataSizetypeSet(pTableData,pSize);

		for (i = 0;i<iNoColn;i++)
		{
			//Set Algnment for each column here
			if(i<vClnAlgn.size() && i<vClnWid.size())
			{
				if (wcscmp(vClnAlgn[i].c_str(),L"1") == 0)
				{
					pJustification[i] = GEOMETRY_FACADE_HORZJUST_LEFT;
				}
				else if (wcscmp(vClnAlgn[i].c_str(),L"2") == 0)
				{
					pJustification[i] = GEOMETRY_FACADE_HORZJUST_CENTER;
				}
				else if (wcscmp(vClnAlgn[i].c_str(),L"3") == 0)
				{
					pJustification[i] = GEOMETRY_FACADE_HORZJUST_RIGHT; 
				}

				//Here set width of each column
				dColnWid[i] = _wtof(vClnWid[i].c_str());
			}
		}

		for(j = 0;j<iNoRow;j++)
		{
			dRowHt[j] = _wtof(cRowHt);
		}	

		GeometryFacadeDwgtabledataColumnsSet(pTableData,iNoColn,dColnWid,pJustification);
		GeometryFacadeDwgtabledataRowsSet(pTableData,iNoRow,dRowHt);
		//Input of table origin is in drawing co-ordinates
		//So we need to convert it to screen Coordinate in  pScrnOrigin.
		GeometryFacadePoint3D pScrnOrigin;
		GeometryFacadeName wSheetSize;
		GeometryFacadeMatrix pMatrix,pInvMatrix;
		GeometryFacadeDrawingSheetTrfGet((GeometryFacadeDrawing)pCrntDrw,iSheet,wSheetSize,pMatrix);
		GeometryFacadeUtilMatrixInvert(pMatrix,pInvMatrix);
		GeometryFacadePntTrfEval(pOrigin,pInvMatrix,pScrnOrigin);


		GeometryFacadeDwgtabledataOriginSet(pTableData,pScrnOrigin);
		GeometryFacadeDrawingTableCreate((GeometryFacadeDrawing)pCrntDrw,pTableData,false,&pTable);

		//Set Table header first
		// Column
		for (i = 1;i<=iNoColn;i++)
		{
			if(i<(vHeader.size()+1))
			{
				UsrTableTextAdd(&pTable,i,1,(wchar_t*)vHeader[i-1].c_str());
			}
		}

		//Now set each cell value
		int k = 0;
		// Row
		for (i = 1;i<iNoRow;i++)
		{
			if(i<(vAllRwTxt.size()+1))
			{
				std::wstring sTxt = vAllRwTxt[i-1];
				k = 0;
				ProcessNoteText(sTxt,L"|",vCell);
				
				// Column
				for(j = 1;j<=iNoColn;j++)
				{
					if(k<vCell.size())
					{
						UsrTableTextAdd(&pTable,j,i+1,(wchar_t*)vCell[k].c_str());
					}
					k++;
				}
				vCell.clear();
			}
		}

		GeometryFacadeDwgtableDisplay(&pTable);
		// Increment the constraints to continue parse.
		cTableInfo = end + wcslen(end_tag);
		
		if ( m > 0)
		{
			wchar_t temp[10];
			wcscat(TablesIDs,L",");
			_itow(pTable.id,temp,10);
			wcscat(TablesIDs,temp);
		}
		else
		{
			_itow(pTable.id,TablesIDs,10);
		}
			
	}

	GeometryFacadeRegenerateDrawingSheet((GeometryFacadeDrawing)pCrntDrw,iSheet);

	return TablesIDs;
}


GeometryFacadeError DrawingRenameFTInstance_wrapper(std::wstring mdl_name, std::wstring tmp_name, std::wstring drw_name)
{
	GeometryFacadeMdl pCrntMdl = NULL , pGercMdl = NULL;
	GeometryFacadeMdlData pMdlData;
//	GeometryFacadePath wDrwPath;
	GeometryFacadeDrawing pDrwHandle;
	GeometryFacadeSolid *pDrwSlds;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	wchar_t wrkng_name[GEOMETRY_FACADE_FILE_NAME_SIZE] , p_mdl_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
		p_tmp_name[GEOMETRY_FACADE_FILE_NAME_SIZE],p_drw_name[GEOMETRY_FACADE_FILE_NAME_SIZE];
	std::wstring mdlname, mdltype;

	std::wstring::size_type pos = mdl_name.find(L"."); // position of the dot
	if(pos != std::wstring::npos)
	{ 
		mdlname = mdl_name.substr(0,pos);
		mdltype = mdl_name.substr(pos);
	}
	else
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);	// mdl_name does not have "."
	}

	wcsncpy(p_mdl_name, mdlname.c_str(), sizeof(p_mdl_name)/sizeof(wchar_t));
	wcsncpy(p_tmp_name, tmp_name.c_str(), sizeof(p_tmp_name)/sizeof(wchar_t));
	wcsncpy(p_drw_name, drw_name.c_str(), sizeof(p_drw_name)/sizeof(wchar_t));
	
	//Get current model here
	GeometryFacadeGetCurrentMdl(&pCrntMdl);
	GeometryFacadeGetMdlData(pCrntMdl,&pMdlData);
	
	wcsncpy(wrkng_name, p_mdl_name, sizeof(wrkng_name)/sizeof(wchar_t));
	wcsncat(wrkng_name, mdltype.c_str(), sizeof(wrkng_name) - wcslen(wrkng_name) - 1);
	int windowId = UserModelLoad_wrapper(wrkng_name, &pGercMdl, 0); //open part file here
	//rename it back to its template name
	GeometryFacadeRenameMdl(pGercMdl, p_tmp_name);
	
	//display drawing here
	wcsncpy(wrkng_name, p_drw_name, sizeof(wrkng_name)/sizeof(wchar_t));
	wcsncat(wrkng_name, L".drw", sizeof(wrkng_name) - wcslen(wrkng_name) - 1);
	windowId = UserModelLoad_wrapper(wrkng_name, (GeometryFacadeMdl*)&pDrwHandle);	// Default is 1 for display so this will display the drawing.

	// Rename the opened geometry file back to its run-time file name.
	GeometryFacadeRenameMdl(pGercMdl, p_mdl_name);
	// Probably not needed, as saving the drawing will save the geometry file.
	GeometryFacadeSaveMdl(pGercMdl);
	//rename drawing 
	try
	{
	GeometryFacadeRenameMdl((GeometryFacadeMdl)pDrwHandle, pMdlData.name);
	}
	catch(ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
		{
			throw;
		}
		LOG << "Drwing file with instance name already exist " << endl;
	}
	result = ProDrawingSolidsCollect(pDrwHandle,&pDrwSlds);
	if (result == GEOMETRY_FACADE_NO_ERROR)
	{
		int iNoSld = GeometryFacadeGetArraySize((GeometryFacadeArray)pDrwSlds);
		LOG << "Total solids found : " << iNoSld << endl;

		for(int i = 0;i<iNoSld;i++)
		{
			result = ProDrawingSolidReplace(pDrwHandle,pDrwSlds[i],(GeometryFacadeSolid)pCrntMdl,PRO_B_TRUE);
			LOG << "Result of drawing solid replace is : " << result << endl;
		}
	}
	else
	{
		LOG << "Error occured while retreiving drawing solids no action performed on drawing file " << endl;
	}

	windowId = GeometryFacadeGetCurrentWindow();
	
	GeometryFacadeActivateWindow(windowId);

	GeometryFacadeSaveMdl((GeometryFacadeMdl)pDrwHandle);
	return result;
}

//It will process list of part file and perform drawing rename operation..
static void DrawingMultipleSolidRename_wrapper(std::wstring sPartCrntName,std::wstring sPartTemplateName,std::wstring sDrwName,std::wstring sDrwNewName)
{
	try
	{
		wchar_t cPartCrntName[GEOMETRY_FACADE_LINE_SIZE],
			cPartTemplateName[GEOMETRY_FACADE_LINE_SIZE],
			cDrwName[GEOMETRY_FACADE_LINE_SIZE];

		LOG << "DrawingMultipleSolidRename_wrapper: Started" << endl;

		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		std::vector<wstring> vPartNameList,vPartTemplateNmList;
		GeometryFacadeMdl pWorkingMdl = NULL,pDrwModel = NULL;

		//Get list of part names...
		//Part Name string has part names having comma seperated values , so process it and collecting its value in a vector.
		ProcessNoteText(sPartCrntName,L",",vPartNameList);
		//Part Template name also has string with comma seperated values..
		ProcessNoteText(sPartTemplateName,L",",vPartTemplateNmList);

		//Get models with current name and rename them with template name.
		//these parts were having name as template name when drawing file was scanned.Renaming it in following way
		//will help to load drawing file without any error.
		for(int i = 0;i < (int)vPartNameList.size();i++)
		{
			wcsncpy(cPartCrntName, vPartNameList[i].c_str(), sizeof(cPartCrntName)/sizeof(wchar_t));
			wcsncpy(cPartTemplateName, vPartTemplateNmList[i].c_str(), sizeof(cPartTemplateName)/sizeof(wchar_t));

			//at first index of Part Name list generic part will be present
			//it will renamed in using model rename API
			if(i == 0) 
			{
				pWorkingMdl = RenameCurrentModel(vPartNameList[i],cPartTemplateName);
			}
			else if(CheckIfFamilyTableInstance(pWorkingMdl , cPartCrntName)) //All later parts are considered as FT instances so thr renaming has to happen using family table. 
			{
				//Now use the generic model and rename FT instance..
				if(pWorkingMdl != NULL)
				{
					std::wstring::size_type pos = vPartNameList[i].find(L"."); // position of the dot
					std::wstring sPartName;

					if(pos != wstring::npos)
						sPartName = vPartNameList[i].substr(0,pos); //remove extension from part name to form new model name.

					if(_wcsicmp(sPartName.c_str(),cPartTemplateName) != 0)
					{
						char partCrntName[GEOMETRY_FACADE_LINE_SIZE];
						GeometryFacadeWideStringToString(partCrntName, cPartCrntName);
						char partTemplateName[GEOMETRY_FACADE_LINE_SIZE];
						GeometryFacadeWideStringToString(partTemplateName, cPartTemplateName);
						LOG << "DrawingMultipleSolidRename_wrapper: renaming family table instance : " << partCrntName << " to : " << partTemplateName << endl;
						RenameFamilyTableInstance(pWorkingMdl,cPartCrntName,cPartTemplateName);
						LOG << "DrawingMultipleSolidRename_wrapper: rename family table instance finished" << endl;
					}
				}
			}
			else 
			{
				RenameCurrentModel(vPartNameList[i],cPartTemplateName);
			}
		}

		//Now load the drawing file and rename it to the new drawing file..
		wcsncpy(cDrwName, sDrwName.c_str(), sizeof(cDrwName)/sizeof(wchar_t));
		wcsncat(cDrwName, L".drw", sizeof(cDrwName) - wcslen(cDrwName) - 1);
		char drwName[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(drwName, cDrwName);
		LOG << "DrawingMultipleSolidRename_wrapper: Loading drawing file : " << drwName << endl;
		int windowId = UserModelLoad_wrapper(cDrwName, &pDrwModel);	// Default is 1 for display so this will display the drawing.

		//Rename this drawing file..
		if(_wcsicmp(sDrwName.c_str(),sDrwNewName.c_str()) != 0)
		{
			char drwNewName[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeWideStringToString(drwNewName, sDrwNewName.c_str());
			LOG << "DrawingMultipleSolidRename_wrapper: Renaming drawing file to " << drwNewName << endl;
			GeometryFacadeRenameMdl(pDrwModel, sDrwNewName.c_str());
		}

		//Now rename back all geometry files and family table instances to their 
		//working names...
		for(int i = 0;i < (int)vPartNameList.size();i++)
		{
			wcsncpy(cPartCrntName, vPartNameList[i].c_str(), sizeof(cPartCrntName)/sizeof(wchar_t));
			wcsncpy(cPartTemplateName, vPartTemplateNmList[i].c_str(), sizeof(cPartTemplateName)/sizeof(wchar_t));

			std::wstring::size_type pos = vPartNameList[i].find(L"."); // position of the dot
			std::wstring sPartName;

			if(pos != wstring::npos)
				sPartName = vPartNameList[i].substr(0,pos); //remove extension from part name to form new model name.

			if(i == 0) 
			{
				//We already have generic model handle rename it here..
				if(_wcsicmp(cPartTemplateName,sPartName.c_str()) != 0)
				{
					char prtName[GEOMETRY_FACADE_LINE_SIZE];
					GeometryFacadeWideStringToString(prtName, sPartName.c_str());
					LOG << "DrawingMultipleSolidRename_wrapper: Generic file renamed back to : " << prtName << endl;
					try
					{
						GeometryFacadeRenameMdl(pWorkingMdl, sPartName.c_str());
					}
					catch(ProeException ex)
					{
						LOG << "DrawingMultipleSolidRename_wrapper: Fails to rename back model "<< prtName << endl;
					}
				}
			}
			else if(CheckIfFamilyTableInstance(pWorkingMdl , cPartTemplateName))   
			{
				if(pWorkingMdl != NULL)
				{
					if(_wcsicmp(sPartName.c_str(),cPartTemplateName) != 0)
					{
						char prtTemplateName[GEOMETRY_FACADE_LINE_SIZE];
						GeometryFacadeWideStringToString(prtTemplateName, cPartTemplateName);
						char prtCrntName[GEOMETRY_FACADE_LINE_SIZE];
						GeometryFacadeWideStringToString(prtCrntName, cPartCrntName);
						LOG << "DrawingMultipleSolidRename_wrapper: renaming family table instance : " << prtTemplateName << " to : " << prtCrntName << endl;
						RenameFamilyTableInstance(pWorkingMdl,cPartTemplateName,cPartCrntName);
						LOG << "DrawingMultipleSolidRename_wrapper: rename family table instance finished" << endl;
					}
				}		
			}
			else
			{
				//append extension to the TemplateName..
				wstring sExtn;
				if(pos != wstring::npos)
					sExtn = vPartNameList[i].substr(pos);

				wcscat(cPartTemplateName , sExtn.c_str());
				RenameCurrentModel(cPartTemplateName , const_cast<wchar_t*>(sPartName.c_str()));
			}
		}

		//Now save top level model..
		GeometryFacadeSaveMdl(pWorkingMdl);

		//Set Generic part as current solid
		GeometryFacadeMdl pDrwHandle = NULL;
		int iWinID;
		ProWindowCurrentGet(&iWinID);
		ProWindowMdlGet(iWinID,&pDrwHandle);

		ProDrawingCurrentsolidSet((GeometryFacadeDrawing)pDrwHandle,(GeometryFacadeSolid)pWorkingMdl);

		LOG << "DrawingMultipleSolidRename_wrapper: Completed" << endl;
	}
	catch(ProeException ex)
	{
		LOG << "DrawingMultipleSolidRename_wrapper: Caught Outer exception "<< endl;
		throw ex;
	}
}

bool CheckIfFamilyTableInstance(GeometryFacadeMdl pGnrcMdl , wchar_t *cInstanceCrntName)
{
	bool bIsFTInstance = false;
	GeometryFacadeError result;
	ProFamtable pFmTbl;
	ProFaminstance pFmInst;

	//check if instance name has extension(.prt) if yes remove it
	std::wstring sTempName = cInstanceCrntName;
	std::wstring::size_type pos = sTempName.find(L"."); // position of the dot
	std::wstring sInstCrntName,sInstTemplateName;

	if(pos != wstring::npos)
		sInstCrntName = sTempName.substr(0,pos);
	else
		sInstCrntName = cInstanceCrntName;

	result = ProFamtableInit(pGnrcMdl,&pFmTbl);
	if(result == GEOMETRY_FACADE_NO_ERROR)
	{
		result = ProFaminstanceInit(&sInstCrntName[0],&pFmTbl,&pFmInst);
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			ProFaminstanceVerifyStatus pInstVerified;
			result = ProFaminstanceIsVerified(&pFmInst,&pInstVerified);
			if(result == GEOMETRY_FACADE_NO_ERROR)
				bIsFTInstance = true;
		}
	}

	return bIsFTInstance;
}

//This will initialize instances of family table and will rename to the template name.
//Only instances which are used in drawing will be renamed in this process. 
void RenameFamilyTableInstance(GeometryFacadeMdl pGnrcMdl,wchar_t *cInstanceCrntName,wchar_t *cInstanceTemplateName)
{
	GeometryFacadeError result;
	ProFamtable pFmTbl;
	ProFaminstance pFmInst;

	//check if instance name has extension(.prt) if yes remove it
	std::wstring sTempName = cInstanceCrntName;
	std::wstring::size_type pos = sTempName.find(L"."); // position of the dot
	std::wstring sInstCrntName,sInstTemplateName;

	if(pos != wstring::npos)
		sInstCrntName = sTempName.substr(0,pos);
	else
		sInstCrntName = cInstanceCrntName;
	
	//check if template name has extension(.prt) if yes remove it
	sTempName = cInstanceTemplateName;
	pos = sTempName.find(L".");
	if(pos != wstring::npos)
		sInstTemplateName = sTempName.substr(0,pos);
	else
		sInstTemplateName = cInstanceTemplateName;

	result = ProFamtableInit(pGnrcMdl,&pFmTbl);
	result = ProFaminstanceInit(&sInstCrntName[0],&pFmTbl,&pFmInst);
	if(result == GEOMETRY_FACADE_NO_ERROR)
	{
		LOG << "DrawingRename: Instance initialization completed , get model out of it." << endl;
		char instTemplateName[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(instTemplateName, sInstTemplateName.c_str());
		GeometryFacadeMdl pInstModel = NULL;
		result = ProFaminstanceCreate(&pFmInst,&pInstModel);
		LOG << "DrawingRename: Model created with result : " <<  result << "Renaming instance as : " << instTemplateName << endl;
		GeometryFacadeRenameMdl(pInstModel, sInstTemplateName.c_str());
		GeometryFacadeSaveMdl(pGnrcMdl);
		result = ProMdlErase(pInstModel);
		LOG << "DrawingRename: Instance is renamed to : " << instTemplateName << endl;
	}
	else
	{
		char instCrntName[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(instCrntName, sInstCrntName.c_str());
		LOG << "DrawingRename: Instance initialization failed with result as : " << result << " for instance having current name : " << instCrntName << endl;
	}

}

GeometryFacadeMdl RenameCurrentModel(std::wstring sCrntModel,wchar_t *cMdlTemplName)
{
	//std::string mdlname, mdltype;
	wchar_t cPartWkngName[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeMdl pModel = NULL;

	char crntModel[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeWideStringToString(crntModel, sCrntModel.c_str());
	char mdlTemplName[GEOMETRY_FACADE_LINE_SIZE];
	GeometryFacadeWideStringToString(mdlTemplName, cMdlTemplName);
	LOG << "DrawingRename: Renaming part file : " << crntModel << " to the template name : " << mdlTemplName << endl;
	
	//try to clear session for parts having name as model template name...
	//Erase not displayed part.This will remove parts having name same as template name.
	CheckAndRemoveDrawing(cMdlTemplName,PRO_MDL_DRAWING);
	CheckAndRemoveDrawing(cMdlTemplName,PRO_MDL_PART);

	// Open the run-time geometry file.
	wcsncpy(cPartWkngName, sCrntModel.c_str(), sizeof(cPartWkngName)/sizeof(wchar_t));	
	int windowId = UserModelLoad_wrapper(cPartWkngName, &pModel, 0); // do not display
	
	std::wstring mdlname;
	std::wstring::size_type pos = sCrntModel.find(L"."); // position of the dot to remove extension
	if(pos != std::wstring::npos)
	{ 
		mdlname = sCrntModel.substr(0,pos);
	}

	//Now rename it to the template file..
	if(_wcsicmp(mdlname.c_str(),cMdlTemplName) != 0)
	{
		GeometryFacadeRenameMdl(pModel, cMdlTemplName);
	}
	
	LOG << "DrawingRename: model rename completed" << endl;
	return pModel;
}

static void DrawingCreateFromTemplate_wrapper(std::wstring mdl_name, std::wstring drw_name, std::wstring NewDrwName)
{
	wchar_t p_drw_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
		p_new_drw_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
		p_mdl_name[GEOMETRY_FACADE_FILE_NAME_SIZE];
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl curModel;
	//ProMdlType mdl_type;
	GeometryFacadeMdlData data;
	//char *TEMPLATE_NAME = p_drw_name;
	GeometryFacadeModel dModel;
	ProDwgcreateOptions options = (ProDwgcreateOptions)0;
	ProDrawing created_drawing = NULL;

	
	wcsncpy(p_drw_name, drw_name.c_str(), sizeof(p_drw_name)/sizeof(wchar_t));
	wcsncpy(p_new_drw_name, NewDrwName.c_str(), sizeof(p_new_drw_name)/sizeof(wchar_t));
	wcsncpy(p_mdl_name, mdl_name.c_str(), sizeof(p_mdl_name)/sizeof(wchar_t));

	CleanSessionForExistingFiles(p_new_drw_name , PRO_MDL_DRAWING);	

	UserModelLoad_wrapper(p_mdl_name , &curModel , 0);
	GeometryFacadeGetMdlData(curModel, &data);
	GeometryFacadeCopyWideString(data.name , dModel.name , GEOMETRY_FACADE_VALUE_UNUSED);
	GeometryFacadeCopyWideString(data.type , dModel.type , GEOMETRY_FACADE_VALUE_UNUSED);

	GeometryFacadeCreateDrawingFromTemplate (p_new_drw_name, p_drw_name, &dModel , options, &created_drawing);
	GeometryFacadeRetrieveMdl(p_drw_name , PRO_MDL_DRAWING,(ProMdl*)&created_drawing);
	GeometryFacadeClearWindow(GEOMETRY_FACADE_VALUE_UNUSED); // Clears what is in the main base window.

	GeometryFacadeDisplayMdl((ProMdl*)created_drawing);
	// Get the current window id.
	int windowId = GeometryFacadeGetCurrentWindow();

	// Activate the window.
	GeometryFacadeActivateWindow(windowId);
	
	drawingSheetRegenerate_wrapper();
}


//Method is similar to what CheckAndRemoveDrawing() does , used for FT instances as well. so instead of modifying it adding new method.
//here trying to make it specifically to remove existing files from session which has simialr name as NewFileName and type as pMdlType.
//<TODO> Make one function to perform session cleanup.
void CleanSessionForExistingFiles(wchar_t* NewFileName , ProMdlType pMdlType)
{
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl *pSessionMdls = NULL;
		int iNoMdls = -1;
		
		result = ProSessionMdlList(pMdlType ,&pSessionMdls, &iNoMdls);
		for(int i = 0; i< iNoMdls; i++)
		{
			ProMdlType pSessMdlType = GeometryFacadeGetMdlType(pSessionMdls[i]);
			if(pSessMdlType == pMdlType)
			{
				GeometryFacadeFileName wSessFileName;
				int iIsMatch = UtilStrcmp(wSessFileName, NewFileName);

				if(iIsMatch == 0)
				{
					ProMdlEraseAll(pSessionMdls[i]);
				}
			}
		}
	}
	catch(ProeException ex)
	{
		LOG << "CleanSessionForExistingFiles: Caught Outer Exception " << endl;
	}
}

// Use as drawingRename_wrapper("block10.prt","block","drw0001","new_drw_name");
//
// In the directory there should be block10.prt and drw0001.drw, after the call
// there will be block10.prt and new_drw_name.drw that is associated with block10.prt
//
// The function loads block10.prt, renames it to block.prt so that drw0001.drw can be opened (because it is going to look for block.prt) then it 
// renames block.prt back to block10.prt and drw0001.drw to new_drw_name.drw
//B- 05543 - With new support for empty templates , code required for it is moved to seperate method. This code strictly processes drawing files which refer single solid
static void drawingRename_wrapper(std::wstring mdl_name, std::wstring tmp_name, std::wstring drw_name, std::wstring NewDrwName , int iIsDrwGeomChanged)
{ 
	try
	{
		// Note: drw_name is WITHOUT type ".drw", tmp_name is WITHOUT type ".asm" or ".prt",
		// while mdl_name comes WITH a type ".asm" or ".prt".

		// Handling drawings in Pro/Engineer is complicated by the fact that
		// drawings contain a link to their associated geometry file.  This
		// means that a drawing file such as block.drw contains an embedded
		// reference to its geometry file, block.prt.  This causes problems for
		// RS because we treat the "real" geometry file (block.prt) as a 
		// template file & rename it to something like block-10.prt instead.
		// Once the geometry file has been renamed, it becomes impossible to
		// load the drawing file because the geometry file it references (block.prt)
		// does not exist.
		//
		// The solution we came up with is this:
		//
		// 1) Load the run-time geometry file (block-10.prt).
		// 2) Rename it back to the template file name (block.prt) using GeometryFacadeRenameMdl().
		// 3) Load the template drawing file (block.drw) which will now load because the
		//    geometry file it references (block.prt) exists.
		// 4) Rename the geometry file (block.prt) back to its run-time name (block-10.prt)
		//    using GeometryFacadeRenameMdl().
		// 5) Save the gemoetry file.
		// 6) Rename the template drawing file to block-10.drw using GeometryFacadeRenameMdl().
		// 7) Save the drawing file.
		//
		// Note that this all could be avoided if Pro/Toolkit provided a way to rename
		// the drawing file reference without opening the drawing file.  Remember, the
		// whole problem stems from not being able to open the drawing file because the
		// geometry file it references has been renamed.  If Pro/Toolkit had a function
		// that allowed renaming the drawing file reference without opening the drawing
		// ( e.g., ProDrawingRename(GeometryFacadeName oldName, GeometryFacadeName newName) ) this could all be avoided.
		////<Milind>.Modified drawingRename_wrapper() to handle empty drawing file scenario.
		////drawing file retreival API is added it will return GENERAL_ERROR if solid exist & then nSolids will assign 1 & drawing file will be created
		////by following earlier approach.
		////If this  is zero ,template file(empty) is confirmed & then new drawing file using ProDrawingFromTmpltCreate() will be created.

		wchar_t p_mdl_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
			p_tmp_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
			p_drw_name[GEOMETRY_FACADE_FILE_NAME_SIZE], 
			wrkng_name[GEOMETRY_FACADE_FILE_NAME_SIZE],
			p_new_drw_name[GEOMETRY_FACADE_FILE_NAME_SIZE];
		GeometryFacadeMdl model, drw_model;
		std::wstring mdlname, mdltype;
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

		// Get the type.
		std::wstring::size_type pos = mdl_name.find(L"."); // position of the dot
		if(pos != std::wstring::npos)
		{ 
			mdlname = mdl_name.substr(0,pos);
			mdltype = mdl_name.substr(pos);
		}
		else
		{
			throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);	// mdl_name does not have "."
		}

		wcsncpy(p_mdl_name, mdlname.c_str(), sizeof(p_mdl_name)/sizeof(wchar_t));
		wcsncpy(p_tmp_name, tmp_name.c_str(), sizeof(p_tmp_name)/sizeof(wchar_t));
		wcsncpy(p_drw_name, drw_name.c_str(), sizeof(p_drw_name)/sizeof(wchar_t));
		wcsncpy(p_new_drw_name, NewDrwName.c_str(), sizeof(p_new_drw_name)/sizeof(wchar_t));

		//Erase not displayed part.This will remove parts having name same as document name.
		CleanSessionForExistingFiles(p_new_drw_name , PRO_MDL_DRAWING);
		CheckAndRemoveDrawing(p_drw_name,PRO_MDL_PART);

		GeometryFacadeMdl pProcsdMdl = NULL;
		if(iIsDrwGeomChanged == 1)
		{
			//specifically required to rename old drawing geometry to temporary name.
			//this rename will ensure that Rename operation done on current geometry in next processing works fine.
			//Old geometry renamed here will be restored to its current name once we are done with drawing reload.		
			LOG << "drawingRename_wrapper: Check is pre-processing required before going for drawing rename." << endl;
			pProcsdMdl = CheckIsPreProcessingDone(mdl_name , p_tmp_name , p_drw_name , p_new_drw_name);
		}

		//changes starts here	
		wcsncpy(wrkng_name, p_drw_name, sizeof(wrkng_name)/sizeof(wchar_t));
		wcsncat(wrkng_name, L".drw", sizeof(wrkng_name) - wcslen(wrkng_name) - 1);

		//Verification added for geometry template name(p_tmp_name) , following function will try to load drawing file
		//using given template name if failed it will modify template name and will append "-XXX" to it.
		std::wstring sTemp = mdl_name.substr(0,mdl_name.find_last_of(L"-"));

		if(_wcsicmp(sTemp.c_str(),p_tmp_name) != 0)
			VerifyDrawingSolidReferenced(mdl_name,p_tmp_name,p_drw_name);

		// Open the run-time geometry file.
		wcsncpy(wrkng_name, p_mdl_name, sizeof(wrkng_name)/sizeof(wchar_t));
		wcsncat(wrkng_name, mdltype.c_str(), sizeof(wrkng_name) - wcslen(wrkng_name) - 1); // add the type here ".asm" or ".prt"
		int windowId = UserModelLoad_wrapper(wrkng_name, &model, 0); // display?

		//Compare current model name and template name
		//if both are same no need to rename.
		char pTmpName[GEOMETRY_FACADE_LINE_SIZE];
		GeometryFacadeWideStringToString(pTmpName, p_tmp_name);
		int iCmp = _wcsicmp(p_mdl_name,p_tmp_name);
		if (iCmp != 0) //Rename geometry only if it does not already exist.
		{
			// Rename the opened geometry file to its template file name so that 
			// the drawing can be loaded (and renamed).
			// BEWARE!  GeometryFacadeRenameMdl() will return the undocumented error
			// GEOMETRY_FACADE_GENERAL_ERROR if the model is managed by Pro/Intralink
			// and the appropriate measures weren't taken to make the files
			// writeable.  One thing you can do as a RS user is to add the
			// following option to your Pro/Engineer config.pro file:
			//
			// let_proe_rename_pdm_objects yes
			//
			// This will at least allow you to rename components, but who
			// knows what other problems you may encounter further down the line.
			//Get Mode name 
			try
			{
				GeometryFacadeRenameMdl(model, p_tmp_name);
			}
			catch(ProeException ex)
			{
				LOG << "drawingRename_wrapper: Fail to rename geometry file to " << pTmpName << endl;
			}
		}

		// Open the template drawing file.
		wcsncpy(wrkng_name, p_drw_name, sizeof(wrkng_name)/sizeof(wchar_t));
		wcsncat(wrkng_name, L".drw", sizeof(wrkng_name) - wcslen(wrkng_name) - 1);
		windowId = UserModelLoad_wrapper(wrkng_name, &drw_model);	// Default is 1 for display so this will display the drawing.

		if(iCmp != 0) //Rename geometry only if it does not already exist.
		{
			// Rename the opened geometry file back to its run-time file name.
			// This rename not only updates the file name on disk, but
			// because the drawing file is in memory, it will also update
			// the reference inside of the drawing file to point to the
			// new geometry file name.  This is the key to this whole process. 
			try
			{
				GeometryFacadeRenameMdl(model, p_mdl_name);
			}
			catch(ProeException ex)
			{
				char mdlName[GEOMETRY_FACADE_LINE_SIZE];
				GeometryFacadeWideStringToString(mdlName, p_mdl_name);
				LOG << "drawingRename_wrapper: Fail to rename geometry file to " << mdlName << endl;
			}
			// Probably not needed, as saving the drawing will save the geometry file.
			GeometryFacadeSaveMdl(model);
		}

		//Rename drawing only if existing name and new name are different.
		iCmp = _wcsicmp(drw_name.c_str(),NewDrwName.c_str());
		if(iCmp != 0) //Rename drawing only if it does not already exist.
		{
			// Rename the template drawing file to the match the geometry file name.
			// This rename, among other things, will rename the drawing
			// file on disk from the template file name to the run-time file name.
			try
			{
				GeometryFacadeRenameMdl(drw_model, p_new_drw_name);
			}
			catch(ProeException ex)
			{
				LOG << "drawingRename_wrapper: Fail to rename drawing file to " << pTmpName << endl;
			}
		}
		// This save is needed to write out the new drawing
		// file with the updated geometry file reference.
		GeometryFacadeSaveMdl(drw_model);

		if(iIsDrwGeomChanged == 1 && (pProcsdMdl != NULL))
		{
			char tempName[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeWideStringToString(tempName, p_tmp_name);
			LOG << "drawingRename_wrapper: Post-processing started for renamed drawing solid." << endl;
			try
			{
				GeometryFacadeRenameMdl(pProcsdMdl , p_tmp_name);
			}
			catch(ProeException ex)
			{

				LOG << "drawingRename_wrapper: Fail to rename drawing file to " << tempName << endl;
			}
			ProMdlEraseAll(pProcsdMdl);
			LOG << "drawingRename_wrapper: Post-processing: Drawing old Geometry is restored to its original name <" << tempName <<  ">" << endl;
		}
		//extra to erase old drawing file 
		//result = ProMdlErase(part);
	}
	catch(ProeException ex)
	{
		LOG << "drawingRename_wrapper: Caught Outer Exception " << endl;
		throw ex;
	}
}

//we hv got input arguments like-
//p_mdl_name = Block.prt = New model
//p_drwGeome = Cone.prt = Geometry referenced in drawing file
//p_drw_name = drawing current name
//p_new_drw_name = drawing new name
//in case if DrawingRename is called for geometry replace , drawing name input value will be iqual.
GeometryFacadeMdl CheckIsPreProcessingDone(wstring p_mdl_name , wchar_t *p_drwGeom , wchar_t *p_drw_name , wchar_t *p_new_drw_name)
{	
	GeometryFacadeMdl pProcMdl = NULL;
	try
	{
		int iDrwComp = UtilStrcmp(p_drw_name , p_new_drw_name);

		if(iDrwComp == 0)
		{
			GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
			wstring sName, sType;

			// Get the type.
			std::wstring::size_type pos = p_mdl_name.find(L"."); // position of the dot
			if (pos != std::wstring::npos)
			{
				sName = p_mdl_name.substr(0, pos);
				sType = p_mdl_name.substr(pos);
			}
			else
			{
				throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR);	// mdl_name does not have "."
			}

			int iGeomComp = _wcsicmp(sName.c_str(), p_drwGeom);
			if(iGeomComp != 0)
			{
				sName = p_drwGeom;
				sName.append(sType);

				UserModelLoad_wrapper(const_cast<wchar_t*>(sName.c_str()), &pProcMdl);
				if(pProcMdl != NULL && iGeomComp)
				{
					char drwName[GEOMETRY_FACADE_LINE_SIZE];
					GeometryFacadeWideStringToString(drwName, p_drwGeom);
					LOG << "CheckIsPreProcessingDone: Pre-processing started for Drawing Geometry <" << drwName << ">" << endl;
					GeometryFacadeName wGeomTempName = {};
					GeometryFacadeStringToWideString(wGeomTempName , "RS_Temp_Part");
					GeometryFacadeRenameMdl(pProcMdl , wGeomTempName);
					LOG << "CheckIsPreProcessingDone: Pre-processing Completed" << endl;
				}
			}
		}

		if(pProcMdl == NULL)
		{
			char drwName[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeWideStringToString(drwName, p_drw_name);
			LOG << "CheckIsPreProcessingDone: NO pre-processing done for drawing <" << drwName << "> solid."<< endl;
		}
	}
	catch(ProeException ex)
	{
		LOG << "CheckIsPreProcessingDone: Caught Outer exception" << endl;
	}

	return pProcMdl;
}
//It was added to check if p_tmp_name is correct and geometry with same name is referenced in the drawing.
//if drawing fails to load with current p_tmp_name ,it will be modified with suffix append.
//If worked same will be returned.
//<TODO> Currently drawing is opened and draiwng failure is taken as a measure
// to verify is drawing referencing correct solid.
//Find better way to get name of geometry referenced in drawing.
void VerifyDrawingSolidReferenced(std::wstring p_mdl_name,wchar_t *p_tmp_name,wchar_t *p_drw_name)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl pMdlRetreived = NULL;
	GeometryFacadeName wMdlOriginalName;
	wchar_t cMdlName[GEOMETRY_FACADE_FILE_NAME_SIZE];
	wcsncpy(cMdlName,p_mdl_name.c_str(),sizeof(cMdlName)/sizeof(wchar_t));

	try
	{
		//First try with given p_tmp_name
		UserModelLoad_wrapper(cMdlName,&pMdlRetreived,0);
		ProMdlNameGet(pMdlRetreived,wMdlOriginalName);
		if(_wcsicmp(p_mdl_name.c_str(),p_tmp_name) != 0)
		{
			GeometryFacadeRenameMdl(pMdlRetreived, p_tmp_name);
		}
		int ichk = LoadDrawingWithSolid(p_drw_name);
		if(ichk != 0)
		{
			//Given p_tmp_name is not valid and drawing would fail in that 
			//case so now try loading drawing appeding "-" and RS suffix to p_tmp_name.
			std::wstring sTemp = p_mdl_name;
			sTemp = sTemp.substr(sTemp.find_last_of(L"-"));
			sTemp = sTemp.substr(0,sTemp.find_first_of(L"."));
			//Append suffix to the p_tmp_name
			wcsncat(p_tmp_name,sTemp.c_str(), sizeof(p_tmp_name) - wcslen(p_tmp_name) - 1);
			GeometryFacadeRenameMdl(pMdlRetreived, p_tmp_name);
			ichk = LoadDrawingWithSolid(p_drw_name);
			if (ichk == 0)
			{
				char drwName[GEOMETRY_FACADE_LINE_SIZE];
				GeometryFacadeWideStringToString(drwName, p_drw_name);
				char tmpName[GEOMETRY_FACADE_LINE_SIZE];
				GeometryFacadeWideStringToString(tmpName, p_tmp_name);
				LOG << "Drawing file " << drwName << " has geometry file with name " << tmpName << " in it.So modified geomTemplateName is changed to " << tmpName << endl;
			}
		}
		
		//Rename geometry with original name.
		if(_wcsicmp(p_mdl_name.c_str(),p_tmp_name) != 0)
		{
			GeometryFacadeRenameMdl(pMdlRetreived,wMdlOriginalName);
		}
	} // no need to throw exception as this is just a verification process.Errors here should not stop further rename.
	catch(ProeException ex){}
	catch(exception ex){}
}

int LoadDrawingWithSolid(wchar_t *p_drw_name)
{
	int iResult = 1;
	GeometryFacadeMdl pDrwRetreived = NULL;
	wchar_t cDrwName[GEOMETRY_FACADE_FILE_NAME_SIZE];
	wcscpy(cDrwName,p_drw_name);

	try
	{
		wcsncat(cDrwName, L".drw", sizeof(cDrwName) - wcslen(cDrwName) - 1);
		UserModelLoad_wrapper(cDrwName,&pDrwRetreived,0);
		//Drawing load succesful , we have model with correct name in WIP , so erase this drawing from session.
		ProMdlErase(pDrwRetreived);
		iResult = 0;
	}// no need to throw exception as this is just a verification process.Errors here should not stop further rename.
	catch(ProeException ex){}
	catch(exception ex){}

	return iResult;

}

//Following method will collect list of models/geometries in current ProE session.
//if pMdlTp = PRO_MDL_PART , Only parts which are familt table instance will be erased.
//if pMdlTp = PRO_MDl_GEOMETRY ,only drawing which has original name(=cWrkngDrwName) will get erased.
//Following operation basically identifies geometry/drawing in session which could cause naming conflict while renaming 
//in further DrawingRename().
void CheckAndRemoveDrawing(wchar_t * cWrkngDrwName,ProMdlType pMdlTp)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	GeometryFacadeMdl *pDrwMdl = NULL;
	int iNoDrwMdl = 0;

	result = ProSessionMdlList(pMdlTp,&pDrwMdl,&iNoDrwMdl);
	LOG << "Models in session : " << iNoDrwMdl << " while Model Type is : " << int(pMdlTp) << endl;
	if(pMdlTp == PRO_MDL_PART)
	{
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			for(int i = 0;i<iNoDrwMdl;i++)
			{
				result = ProSolidFamtableCheck((ProSolid)pDrwMdl[i]);
				if(result == PRO_TK_EMPTY)
				{
					result = ProMdlErase(pDrwMdl[i]);
					LOG << "Geometry file at index : " << i << " having family table instance is erased with result : " << result << endl;					
				}
			}
		}
	}
	else
	{
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			for(int i = 0;i<iNoDrwMdl;i++)
			{
				ProName wMdlNm = {};

				result = ProMdlNameGet(pDrwMdl[i],wMdlNm);
				std::wstring wTemp = wMdlNm;
				int iCmp = 0;
				int iPos = wTemp.find_last_of(L"-");
				wstring sDrwNm = wTemp.substr(0,iPos);
				iCmp = _wcsicmp(sDrwNm.c_str(),cWrkngDrwName);
				if(iCmp == 0)
				{
					char* sTemp=NULL;
					GeometryFacadeWideStringToString(sTemp, cWrkngDrwName);
					LOG << "ProE session already has : " << sTemp << " so erasing it.. with result : " << result << endl;
					result = ProMdlErase(pDrwMdl[i]);
				}
			}
		}
	}
	if(pDrwMdl != NULL)
		ProArrayFree((ProArray*)&pDrwMdl);
}

int UsrTableTextAdd(ProDwgtable *table,int col,int row,wchar_t *text)
{
	ProError result; 
	ProWstring *lines;
	
	if(!text)
	{
		return 1;
	}

	// Need to allocate array to add table cell text
	ProArrayAlloc(1, sizeof(ProWstring), 1, (ProArray*)&lines);
	lines[0] = (wchar_t*)calloc(wcslen(text) + 1, sizeof(wchar_t));
	wcscpy(lines[0], text);
	GeometryFacadeEnterDrawingTableText(table, col, row, lines);
	ProArrayFree((ProArray*)&lines);
	
	return 1;
}


//static int userTableTextAdd(GeometryFacadeDrawingTable *table, int col, int row, char *text)
// {
//    GeometryFacadeWideString *lines = (GeometryFacadeWideString*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeWideString), 1);
//    lines[0] = (GeometryFacadeWideChar*)calloc(strlen(text) + 1, sizeof(GeometryFacadeWideChar));
//    GeometryFacadeStringToWideString(lines[0], text);
//    GeometryFacadeEnterDrawingTableText(table, col, row, lines);
//    GeometryFacadeFreeArray( (GeometryFacadeArray*)&lines );
//
//	return 0;
//}

void drawingViewScaleSet_wrapper(std::wstring viewName, double scale)
{
	GeometryFacadeDrawing drawing;
	GeometryFacadeView *views;
	GeometryFacadeName wViewName;
	//std::string sViewName;

	GeometryFacadeGetCurrentMdl((GeometryFacadeMdl*)&drawing);

	GeometryFacadeCollectDrawingViews(drawing, &views);
	int n_views = GeometryFacadeGetArraySize(views);

	for ( int i = 0 ; i<n_views;i++)
	{
		ProDrawingViewNameGet(drawing,views[i],wViewName);
		if (wcscmp(viewName.c_str(), wViewName) == 0)
		{
			int sheet = GeometryFacadeGetDrawingViewSheet(drawing, views[i]);
			ProDrawingCurrentSheetSet(drawing,sheet);
			ProDrawingViewScaleSet(drawing,views[i],scale);
			ProDrawingViewRegenerate(drawing,views[i]);
		}
	}
}


static void setTableCell_wrapper(int table_id, int raw, int column, std::wstring content, int &output)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeDrawingTable dwgtbl;

	GeometryFacadeGetCurrentMdl(&drawing);
	GeometryFacadeInitModelItem(drawing, table_id, GEOMETRY_FACADE_DRAW_TABLE, &dwgtbl);

//	userTableTextAdd( &dwgtbl, column, raw, (char*)content.c_str() );

	output = 0;
}


static void drawingCurrentSheetSet_wrapper(int sheet)
{
	GeometryFacadeDrawing drawing;
	GeometryFacadeGetCurrentMdl( (GeometryFacadeMdl*)&drawing );

	GeometryFacadeSetCurrentDrawingSheet(drawing, sheet);
}


static void drawingScaleSet_wrapper(int sheet, double scale)
{
	GeometryFacadeDrawing drawing;
	GeometryFacadeGetCurrentMdl( (GeometryFacadeMdl*)&drawing );

	GeometryFacadeSetDrawingScale(drawing, NULL, sheet, scale);  // NULL for now (we'll see if we need to specify the solid here).
	try
	{
		GeometryFacadeRegenerateDrawingSheet((ProDrawing)drawing, sheet);
	}
	catch(ProeException ex)
	{
		if(ex.GetResult() != GEOMETRY_FACADE_GENERAL_ERROR)
		{
			throw;
		}
	}
}

// Any exception in Refit would prevent drawing save.Performing Save before refit.
static void drawingSheetRegenerate_wrapper() 
{
  	GeometryFacadeDrawing drawing;

	GeometryFacadeGetCurrentMdl( (GeometryFacadeMdl*)(&drawing) );

	int n_sheets = GeometryFacadeCountDrawingSheets(drawing);

	for (int i=1;i<=n_sheets;i++)
	{
		ProDrawingCurrentSheetSet(drawing,i);
		//ProDrawingCurrentSheetGet(drawing,&currenTSheet);
		GeometryFacadeRegenerateDrawingSheet(drawing, i);
	}
	
	if (n_sheets > 0)
		ProDrawingCurrentSheetSet(drawing, 1);

	int iWin;
	ProWindowCurrentGet(&iWin);
	ProDrawingtreeRefresh(drawing,iWin);

	//This step is required to save all the changes made in drawing file.
	GeometryFacadeSaveMdl((GeometryFacadeMdl*)drawing);

	//After setting dimension tolerance, drawing solid has to get save when drawing is saved
	//but Creo save API has limitation on it. As a work around save the drawing solids also 
	//This code can be removed once the limitations is removed by PTC
	ProError result;
	ProSolid* pSolids;
	result = ProDrawingSolidsCollect((ProDrawing )drawing,&pSolids);
	if(result == PRO_TK_NO_ERROR)
	{
		int solids = GeometryFacadeGetArraySize(pSolids);
		for (int i = 0;i<solids;i++)
		{
			GeometryFacadeSaveMdl((GeometryFacadeMdl*)pSolids[i]);
		}
	}

	//Free array
	ProArrayFree((GeometryFacadeArray*)&pSolids);

	//Window Refit
	GeometryFacadeRefitWindow(iWin);
}


static void drawingViewRegenerate_wrapper() 
{
  	GeometryFacadeDrawing drawing;

	GeometryFacadeGetCurrentMdl( (GeometryFacadeMdl*)(&drawing) );

	// Retrieve all the views in this drawing.
	GeometryFacadeView *views;
	GeometryFacadeCollectDrawingViews(drawing, &views);

	// Determine the number of views retrieved.
	int nviews = GeometryFacadeGetArraySize(views);

	// Cycle through all the views & call GeometryFacadeRegenerateDrawingView() on each.
	for (int view = 0 ; view < nviews; view++)
	{
		// View ID's start at 1.
		GeometryFacadeRegenerateDrawingView(drawing, view + 1);
	}
}


void DrawingAnnotationDisplaySet_wrapper(int iAnnotId, std::wstring sAnnotDisplay,std::wstring sAnnotType)
{
	GeometryFacadeMdl pDrawing;
	ProDimension pAnnotHandle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProType pAnnotType;

	if (sAnnotType.compare(L"NOTE") == 0)
	{
		pAnnotType = PRO_NOTE;
	}
	else if (sAnnotType.compare(L"DIM") == 0)
	{
		pAnnotType = PRO_DIMENSION;
	}

	GeometryFacadeGetCurrentMdl(&pDrawing);
	GeometryFacadeInitModelItem(pDrawing, iAnnotId, pAnnotType, &pAnnotHandle);

	if (sAnnotDisplay.compare(L"False") == 0)
	{
		result = ProModelitemHide(&pAnnotHandle);
	}
	else
	{
		result = ProModelitemUnhide(&pAnnotHandle);
	}

}


void DrawingModelAnnotationDisplaySet_wrapper(int iAnnotId,std::wstring sAnnotDisplay)
{
	GeometryFacadeMdl pDrawing;
	ProDimension pAnnotHandle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	GetDrawingSolids(iAnnotId,pDrawing,&pAnnotHandle);

	if (sAnnotDisplay.compare(L"False") == 0)
	{
		result = ProModelitemHide(&pAnnotHandle);
	}
	else
	{
		result = ProModelitemUnhide(&pAnnotHandle);
	}
}

void GetDrawingSolids(int iAnnotId,GeometryFacadeMdl pDrawing,ProDimension* pAnnotHandle)
{
	ProSolid* pSolids;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	result = ProDrawingSolidsCollect((GeometryFacadeDrawing)pDrawing,&pSolids);
	int nSolids = GeometryFacadeGetArraySize(pSolids);

	for (int i = 0;i<nSolids;i++)
	{
		try
		{
			GeometryFacadeInitModelItem(pSolids[i], iAnnotId, PRO_DIMENSION, pAnnotHandle);
		}
		catch(ProeException ex)
		{
			if(ex.GetResult() != GEOMETRY_FACADE_BAD_CONTEXT)
			{
				throw;
			}
		}

		if ( pAnnotHandle != NULL)
		break;
	}

	ProArrayFree((GeometryFacadeArray*)&pSolids);

}

void DrawingNoteLocationChange_wrapper(int iNoteID,double dNoteLoc,std::wstring sMoveDir)
{
	GeometryFacadeMdl pDrawing;
	ProDtlnote pNoteHandle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDetailAttach pAttach,pNewAttach;
	GeometryFacadeDetailAttachType pAttachType;
	GeometryFacadeView pView;
	GeometryFacadeVector pLocVector,pNewLoc;
	GeometryFacadeSelection pAttachPnt;
	GeometryFacadeDetailNoteData pNoteData;
	double dScrnLocn; 
	int iCurrentSheet;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	ProDrawingCurrentSheetGet((ProDrawing)pDrawing,&iCurrentSheet);
	GeometryFacadeRegenerateDrawingSheet((ProDrawing)pDrawing, iCurrentSheet);
	GeometryFacadeInitModelItem(pDrawing, iNoteID, PRO_NOTE, &pNoteHandle);	
	GeometryFacadeGetDetailNoteData(&pNoteHandle, NULL, GEOMETRY_FACADE_DISPMODE_NUMERIC, &pNoteData);
	GeometryFacadeGetDetailNoteDataAttachment(pNoteData, &pAttach);
    GeometryFacadeGetDetailAttachment(pAttach, &pAttachType, &pView,pLocVector, &pAttachPnt);
	//Prohandle pDrwHdl = (Prohandle)pDrawing;
	//<Replaced>GetDrawingVectorCoOrdinates(pDrwHdl,pLocVector,pNewLoc);
	GetDrawingVectorCoOrdinates((GeometryFacadeDrawing)pDrawing,iCurrentSheet,pLocVector,pNewLoc); //convert screen to drawing as input distance value is in drawing co-ordinates



	if (sMoveDir.compare(L"X_Distance") == 0)
	{
		dScrnLocn = (pLocVector[0] * dNoteLoc)/pNewLoc[0];
		pNewLoc[0] = dScrnLocn;
		pNewLoc[1] = pLocVector[1];
		pNewLoc[2] = pLocVector[2];

	}
	else
	{
		dScrnLocn = (pLocVector[1] * dNoteLoc)/pNewLoc[1];
		pNewLoc[0] = pLocVector[0];
		pNewLoc[1] = dScrnLocn;
		pNewLoc[2] = pLocVector[2];

	}
	//<TODO> Here ratio is calculated to get screen-cordinates back
	//Implement proper function to get back screen co-ordinates from drawing co-ordinates.
	result = ProDtlattachAlloc(pAttachType,pView,pNewLoc,pAttachPnt,&pNewAttach);
	result = ProDtlnotedataAttachmentSet(pNoteData,pNewAttach);
	result = ProDtlnoteModify(&pNoteHandle,NULL,pNoteData);
	result = ProDtlnoteShow(&pNoteHandle);
}
//<TODO>Milind:Need to modify this function to handle hidden note updation.currently 
//exception is handled which comes while erasing the hidden note.
void DrawingNoteTextSet_wrapper(int iNoteID, int iSheetID, std::wstring noteText)
{
	GeometryFacadeMdl pDrawing;
	ProDtlnote pNoteHandle;
	GeometryFacadeDetailNoteData pNoteData;
	ProDtlnoteline *pLines = NULL;
	ProDtlnotetext *pTexts = NULL, *oTexts = NULL;
	int iNoLine, iNoText;
	ProComment newNote = { 0 }, txt = { 0 };
	int k, j;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	std::vector<std::wstring> vNoteLines;

	//ProcessNoteText(noteText, "||", vNoteLines);
	vNoteLines = StringSplit(noteText, L"||");
	GeometryFacadeGetCurrentMdl(&pDrawing);
	ProDrawingCurrentSheetSet((GeometryFacadeDrawing)pDrawing, iSheetID);
	GeometryFacadeInitModelItem(pDrawing, iNoteID, PRO_NOTE, &pNoteHandle);
	GeometryFacadeGetDetailNoteData(&pNoteHandle, NULL, GEOMETRY_FACADE_DISPMODE_NUMERIC, &pNoteData);
	GeometryFacadeCollectDetailNoteDataLines(pNoteData, &pLines);
	iNoLine = GeometryFacadeGetArraySize((GeometryFacadeArray)pLines);

	for (j = 0; j < (int)vNoteLines.size(); j++)
	{
		//GeometryFacadeCollectDetailNoteLineTexts(pLines[j], &pTexts);
		//iNoText = GeometryFacadeGetArraySize( (GeometryFacadeArray)pTexts);
		//std::vector<std::string> vNoteText;
		////ProcessNoteText(vNoteLines[j],"`",vNoteText);
		//vNoteText.push_back(vNoteLines[j]);
		//for (k = 0; k < (int)vNoteText.size(); k++)
		//{
		//	GeometryFacadeGetDetailNoteTextString(pTexts[k], txt);
		//	char *Temp = &vNoteText[k][0];
		//	ProStringToWstring(newNote,Temp);

		//	if ( ( result = ProDtlnotetextStringSet(pTexts[k], newNote) ) != GEOMETRY_FACADE_NO_ERROR )
		//	{
		//		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
		//	}

		//	if ( ( result = ProDtlnotelineTextsSet(pLines[j], pTexts) ) != GEOMETRY_FACADE_NO_ERROR )
		//	{
		//		throw ProeException( __FILE__, __LINE__, result, GetErrorString(result) );
		//	}
		//}

		// Allocate only one text per line
		result = ProArrayAlloc(1, sizeof(ProDtlnotetext), 1, (ProArray*)&oTexts);
		if (PRO_TK_NO_ERROR == result)
		{
			// Allocate memory to first text 
			//ProDtlnotetextAlloc(&oTexts[0]);

			GeometryFacadeCollectDetailNoteLineTexts(pLines[j], &pTexts);
			iNoText = GeometryFacadeGetArraySize((GeometryFacadeArray)pTexts);
			oTexts[0] = pTexts[0];

			// copy the value to notetext 
			if ((result = ProDtlnotetextStringSet(oTexts[0], &vNoteLines[j][0])) != GEOMETRY_FACADE_NO_ERROR)
			{
				throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
			}

			// Update the notetext for given line.
			if ((result = ProDtlnotelineTextsSet(pLines[j], oTexts)) != GEOMETRY_FACADE_NO_ERROR)
			{
				throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
			}
		}
	}

	if ((result = ProDtlnoteldataLinesSet(pNoteData, pLines)) != GEOMETRY_FACADE_NO_ERROR)
	{
		throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
	}

	result = ProDtlnoteErase(&pNoteHandle);
	if (result == GEOMETRY_FACADE_NO_ERROR)
	{
		if ((result = ProDtlnoteModify(&pNoteHandle, NULL, pNoteData)) != GEOMETRY_FACADE_NO_ERROR)
		{
			throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
		}

		if ((result = ProDtlnoteShow(&pNoteHandle)) != GEOMETRY_FACADE_NO_ERROR)
		{
			throw ProeException(__FILE__, __LINE__, result, GetErrorString(result));
		}

		GeometryFacadeFreeDetailNoteText(oTexts[0]);
		GeometryFacadeFreeArray((GeometryFacadeArray*)&oTexts);

		for (k = 1; k < iNoText; k++)
		{
			GeometryFacadeFreeDetailNoteText(pTexts[k]);
		}
	}
	GeometryFacadeFreeArray((GeometryFacadeArray*)&pTexts);

	for (j = 0; j < iNoLine; j++)
	{
		GeometryFacadeFreeDetailNoteLine(pLines[j]);
	}
	GeometryFacadeFreeArray((GeometryFacadeArray*)&pLines);

}

std::vector<std::wstring> StringSplit(std::wstring inputText, std::wstring delimiter)
{
	size_t pos = 0;
	std::wstring s, token;
	std::vector<std::wstring> result;

	s.assign(inputText);
	while ((pos = s.find(delimiter)) != std::wstring::npos) {
		token = s.substr(0, pos);
		result.push_back(token);
		s.erase(0, pos + delimiter.length());
	}
	result.push_back(s);

	return result;
}

void ProcessNoteText(std::string sInputText ,std::string delimeter, vector<std::string> &vNoteStr)
{	
	size_t found;	
	std::string sNoteLine =  "";

	int pos = 0;
	found = sInputText.find_first_of(delimeter);
	if (found == string::npos)
	{
		vNoteStr.push_back(sInputText);
	}
	
	while (found!=string::npos)
	{		
		sNoteLine = sInputText.substr(pos,found);			
		vNoteStr.push_back(sNoteLine);
		std::string noteTemp = sInputText.substr(found+strlen(delimeter.c_str()));
		sInputText = noteTemp;
		found=noteTemp.find_first_of(delimeter);
		if (found == string::npos)
		{					
			vNoteStr.push_back(sInputText);
		}		
	}
}

void ProcessNoteText(std::wstring sInputText, std::wstring delimeter, vector<std::wstring> &vNoteStr)
{
	size_t found;
	std::wstring sNoteLine = L"";
	int pos = 0;

	try
	{
		found = sInputText.find_first_of(delimeter);
		if (found == wstring::npos)
		{
			vNoteStr.push_back(sInputText);
		}

		while (found != wstring::npos)
		{
			sNoteLine = sInputText.substr(pos, found);
			vNoteStr.push_back(sNoteLine);
			std::wstring noteTemp = sInputText.substr(found + wcslen(delimeter.c_str()));
			sInputText = noteTemp;
			found = noteTemp.find_first_of(delimeter);
			if (found == wstring::npos)
			{
				vNoteStr.push_back(sInputText);
			}
		}
	}
	catch (const std::exception &ex)
	{
		LOG << "Caught Exception in ProcessNoteText:" << ex.what() << endl;
		throw ex;
	}
}

void DrawingDimensionLocationChange_wrapper(int iDimId,double dDimLocation,std::wstring sMoveDir)
{
	GeometryFacadeMdl pDrawing;
	GeometryFacadeDimension pDimHandle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProDimlocation pDimLocationData;
	GeometryFacadeBoolean bHasElbow;
	GeometryFacadePoint3D pDimLocPoint;
	GeometryFacadeVector pNewDimLocPoint;
	GeometryFacadeVector pNewDimDrwLoc;
	double dElbowLen,dScrnLoc;
	int iCurrentSheet;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	ProDrawingCurrentSheetGet((ProDrawing)pDrawing,&iCurrentSheet);
	GeometryFacadeRegenerateDrawingSheet((ProDrawing)pDrawing, iCurrentSheet);
	GeometryFacadeInitModelItem(pDrawing, iDimId, PRO_DIMENSION, &pDimHandle);	
	result = ProDimensionLocationGet(&pDimHandle,NULL,(ProDrawing)pDrawing,&pDimLocationData);

	result = ProDimlocationTextGet(pDimLocationData,&bHasElbow,pDimLocPoint,&dElbowLen);
	//Prohandle pDrwHdl = (Prohandle)pDrawing;
	//<Replaced>GetDrawingVectorCoOrdinates(pDrwHdl,pDimLocPoint,pNewDimDrwLoc);
	GetDrawingVectorCoOrdinates((GeometryFacadeDrawing)pDrawing,iCurrentSheet,pDimLocPoint,pNewDimDrwLoc);

	if (sMoveDir.compare(L"X_Distance") == 0)
	{
		dScrnLoc = (pDimLocPoint[0] * dDimLocation)/pNewDimDrwLoc[0];//dDimLocation;
		pNewDimLocPoint[0] = dScrnLoc;
		pNewDimLocPoint[1] = pDimLocPoint[1];
		pNewDimLocPoint[2] = pDimLocPoint[2];
	}
	else
	{
		dScrnLoc = (pDimLocPoint[1] * dDimLocation)/pNewDimDrwLoc[1];//dDimLocation;
		pNewDimLocPoint[0] = pDimLocPoint[0];
		pNewDimLocPoint[1] = dScrnLoc;
		pNewDimLocPoint[2] = pDimLocPoint[2];
	}

	result = ProDrawingDimensionMove((ProDrawing)pDrawing,&pDimHandle,pNewDimLocPoint);	
	ProDimlocationFree(pDimLocationData);
}

void DrawingModelDimensionLocationChange_wrapper(int iAnnotId,double dDimLocation,std::wstring sMoveDir)
{
	GeometryFacadeMdl pDrawing;	
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension pDimHandle;	
	ProDimlocation pDimLocationData;
	GeometryFacadeBoolean bHasElbow,bIsShown;
	GeometryFacadePoint3D pDimLocPoint;
	GeometryFacadeVector pNewDimLocPoint;
	GeometryFacadeVector pNewDimDrwLoc;
	double dElbowLen,dScrnLoc;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	GetDrawingSolids(iAnnotId,pDrawing,&pDimHandle);

	ProAnnotationIsShown(&pDimHandle,(GeometryFacadeDrawing)pDrawing,&bIsShown);

	if (bIsShown)
	{

		result = ProDimensionLocationGet(&pDimHandle,NULL,(GeometryFacadeDrawing)pDrawing,&pDimLocationData);

		result = ProDimlocationTextGet(pDimLocationData,&bHasElbow,pDimLocPoint,&dElbowLen);

		//Prohandle pDrwHdl = (Prohandle)pDrawing;
		GeometryFacadeView pView;
		result = ProDrawingDimensionViewGet((GeometryFacadeDrawing)pDrawing,&pDimHandle,&pView);		
		int sheet = GeometryFacadeGetDrawingViewSheet((GeometryFacadeDrawing)pDrawing,pView);
		//<Replaced>GetDrawingPointCoOrdinates(pDrwHdl,pDimLocPoint,pNewDimDrwLoc);
		GetDrawingPointCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,pDimLocPoint,pNewDimDrwLoc);

		if (sMoveDir.compare(L"X_Distance") == 0)
		{
			dScrnLoc = (pDimLocPoint[0] * dDimLocation)/pNewDimDrwLoc[0];//dDimLocation;
			pNewDimLocPoint[0] = dScrnLoc;
			pNewDimLocPoint[1] = pDimLocPoint[1];
			pNewDimLocPoint[2] = pDimLocPoint[2];
		}
		else
		{
			dScrnLoc = (pDimLocPoint[1] * dDimLocation)/pNewDimDrwLoc[1];//dDimLocation;
			pNewDimLocPoint[0] = pDimLocPoint[0];
			pNewDimLocPoint[1] = dScrnLoc;
			pNewDimLocPoint[2] = pDimLocPoint[2];
		}

		result = ProDrawingDimensionMove((GeometryFacadeDrawing)pDrawing,&pDimHandle,pNewDimLocPoint);

		ProDimlocationFree(pDimLocationData);

	}

}
void DrawingViewLocationChange_wrapper(wchar_t *sChkViewName,double dDist,std::wstring sMoveDir)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl pDrawing;
	ProName wViewName;	
	ProView *pViewHandle;
	ProPoint3d pViewLocation;
	ProSelection pSelRef;

	GeometryFacadeGetCurrentMdl(&pDrawing);
	
	//<TODO-Milind>find the way to init view handle.
	//result = ProModelitemByNameInit(pDrawing,PRO_VIEW,wViewName,(ProModelitem*)&pViewHandle);

	GeometryFacadeCollectDrawingViews((ProDrawing)pDrawing, &pViewHandle);
	int iNoView = GeometryFacadeGetArraySize(pViewHandle);

	for ( int i = 0 ; i<iNoView;i++)
	{
		ProDrawingViewNameGet((ProDrawing)pDrawing,pViewHandle[i],wViewName);

		if (wcscmp(wViewName,sChkViewName) == 0)
		{
			int sheet = GeometryFacadeGetDrawingViewSheet((ProDrawing)pDrawing, pViewHandle[i]);
			ProDrawingCurrentSheetSet((ProDrawing)pDrawing,sheet);

			result = ProDrawingViewOriginGet((ProDrawing)pDrawing,pViewHandle[i],pViewLocation,&pSelRef);

			if (sMoveDir.compare(L"X_Distance") == 0)
			{
				pViewLocation[0] = dDist;
			}
			else
			{
				pViewLocation[1] = dDist;
			}	

			result = ProDrawingViewOriginSet((ProDrawing)pDrawing,pViewHandle[i],pViewLocation,pSelRef);

			result = ProDrawingViewRegenerate((ProDrawing)pDrawing,pViewHandle[i]);
			
		}
	}

}

void DrawingViewSizeSet_wrapper(wchar_t *sChkViewName,double dViewSize,std::wstring sChangeDir)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl pDrawing;
	ProName wViewName;	
	ProView *pViewHandle;
	ProPoint3d pViewOutline[2];
	ProPoint3d pDrwPnt1,pDrwPnt2;
	double dCurViewLen,dCurViewHt; //This parameters will have length & height of default view
	double dLenWS1,dHtWS1; //This parameter will have length & height after setting scale 1
	double dLenRatio,dHtRatio;
	double dNewScale;

	GeometryFacadeGetCurrentMdl(&pDrawing);	

	//<TODO-Milind>find the way to init view handle.
	//result = ProModelitemByNameInit(pDrawing,PRO_VIEW,wViewName,(ProModelitem*)&pViewHandle);

	GeometryFacadeCollectDrawingViews((ProDrawing)pDrawing, &pViewHandle);
	int iNoView = GeometryFacadeGetArraySize(pViewHandle);

	for ( int i = 0 ; i<iNoView;i++)
	{
		ProDrawingViewNameGet((ProDrawing)pDrawing,pViewHandle[i],wViewName);

		if (wcscmp(wViewName,sChkViewName) == 0 && dViewSize != 0)
		{
			int sheet = GeometryFacadeGetDrawingViewSheet((ProDrawing)pDrawing, pViewHandle[i]);
			ProDrawingCurrentSheetSet((ProDrawing)pDrawing,sheet);
			//1st calculate default height & length of the view
			result = ProDrawingViewOutlineGet((ProDrawing)pDrawing,pViewHandle[i],pViewOutline);
			//Prohandle pDrwHdl = (Prohandle)pDrawing;
			GetDrawingPointCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,pViewOutline[0],pDrwPnt1);
			GetDrawingPointCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,pViewOutline[1],pDrwPnt2);
			dCurViewLen = pDrwPnt2[0] - pDrwPnt1[0];
			dCurViewHt = pDrwPnt2[1] - pDrwPnt1[1];
			//Here setting view scale to 1 & again calculating height & length of the view.
			result = ProDrawingViewScaleSet((ProDrawing)pDrawing, pViewHandle[i],1.00);
			result = ProDrawingViewRegenerate((ProDrawing)pDrawing,pViewHandle[i]);	
			result = ProDrawingViewOutlineGet((ProDrawing)pDrawing,pViewHandle[i],pViewOutline);
			GetDrawingPointCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,pViewOutline[0],pDrwPnt1);
			GetDrawingPointCoOrdinates((GeometryFacadeDrawing)pDrawing,sheet,pViewOutline[1],pDrwPnt2);
			dLenWS1 = pDrwPnt2[0] - pDrwPnt1[0];
			dHtWS1 = pDrwPnt2[1] - pDrwPnt1[1];
			//Now calculate new view scale.
			if(sChangeDir.compare(L"ViewLength") == 0)
			{
				dLenRatio = dViewSize / dLenWS1;
				dHtRatio = dCurViewHt / dHtWS1;
				if (dLenRatio < dHtRatio)
				{
					dNewScale = dLenRatio;
				}
				else
				{
					dNewScale = dHtRatio;
				}
			}
			else
			{
				dLenRatio = dCurViewLen / dLenWS1;
				dHtRatio = dViewSize / dHtWS1;
				if (dLenRatio < dHtRatio)
				{
					dNewScale = dLenRatio;
				}
				else
				{
					dNewScale = dHtRatio;
				}
			}
			//Apply new scale here
			result = ProDrawingViewScaleSet((ProDrawing)pDrawing, pViewHandle[i],dNewScale);
			result = ProDrawingViewRegenerate((ProDrawing)pDrawing,pViewHandle[i]);			

		}
		else
		{
			char changeDir[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeWideStringToString(changeDir, sChangeDir.c_str());
			LOG << "Could not set size to " << changeDir << " " << dViewSize;
		}
	}
}

static void createProDrawing_wrapper(std::wstring theNewName, std::wstring theDrawingTemplateName) 
{
	GeometryFacadeModel new_model; 	/* (In) The name and type of the solid model to be used in the new drawing. NULL, if the drawing is to be created without a drawing model. */
	GeometryFacadeDrawingCreateOptions options = (GeometryFacadeDrawingCreateOptions)0; /* (In) Flags for drawing creation. Options include: */
    GeometryFacadeDrawing drawing; 	/* (Out) The new drawing */
    
    //------------------------------------------------------------------
    //  Use the current model to create the drawing.
    //------------------------------------------------------------------

	GeometryFacadeMdl solid_mdl;
	GeometryFacadeMdlData data;

    GeometryFacadeGetCurrentMdl(&solid_mdl); 
    
	GeometryFacadeMdlType mdl_type = GeometryFacadeGetMdlType(solid_mdl);
    if (mdl_type != GEOMETRY_FACADE_MDL_PART && mdl_type != GEOMETRY_FACADE_MDL_ASSEMBLY)
	{
		throw ProeException(__FILE__, __LINE__, GEOMETRY_FACADE_INVALID_TYPE);
	}

    GeometryFacadeGetMdlData(solid_mdl, &data);

    GeometryFacadeCopyWideString(data.name, new_model.name, GEOMETRY_FACADE_VALUE_UNUSED);
    GeometryFacadeCopyWideString(data.type, new_model.type, GEOMETRY_FACADE_VALUE_UNUSED);

	options = GEOMETRY_FACADE_DWGCREATE_DISPLAY_DRAWING;

	try
	{
		GeometryFacadeCreateDrawingFromTemplate(theNewName.c_str(), theDrawingTemplateName.c_str(), &new_model, options, &drawing);
	}
	catch (ProeException ex)
	{
		// TODO: is this because GEOMETRY_FACADE_GENERAL_ERROR was returned?   
	   GeometryFacadeCreateDrawingFromTemplate(theNewName.c_str(), theDrawingTemplateName.c_str(), &new_model, options, &drawing);
	}
}


void drawingTables(GeometryFacadeDrawing drawing, std::string &output)
{
	std::ostringstream sout;
	GeometryFacadeDrawingTable *table;
	GeometryFacadeModelItem drawingitem;
	GeometryFacadeParameter *p_parameters;
	std::map<std::string,std::string> pmap;

	GeometryFacadeMdlToModelItem(drawing,&drawingitem);

	// Collect all parameters first.
	CollectParameters(&drawingitem, &p_parameters);
	int n_params = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_parameters );
	for(int i = 0; i < n_params; i++)
	{
		GeometryFacadeParameterValue parval;
		GeometryFacadeGetParameterValue(&p_parameters[i],&parval);
		if(GEOMETRY_FACADE_PARAM_STRING == parval.type)
		{
			char c_line[GEOMETRY_FACADE_LINE_SIZE], c_name[GEOMETRY_FACADE_LINE_SIZE];
			GeometryFacadeWideStringToString(c_name, p_parameters[i].id);
			GeometryFacadeWideStringToString(c_line, parval.value.s_val);
			pmap[c_name] = c_line; 
		}
	}

	GeometryFacadeFreeArray ((GeometryFacadeArray*)&p_parameters);

	GeometryFacadeCollectDrawingTables(drawing, &table);
	int n_tables = GeometryFacadeGetArraySize( (GeometryFacadeArray)table );

	int rows, cols, n_lines, n_texts;
	for (int i = 0; i < n_tables; i++)
	{	
		GeometryFacadeDetailNote note;
		GeometryFacadeDetailNoteData notenumerdata, notesymbdata;
		GeometryFacadeDetailNoteLine *lines;
		GeometryFacadeDetailNoteText *texts;

		rows = GeometryFacadeCountDrawingTableRows(&table[i]);
		cols = GeometryFacadeCountDrawingTableColumns(&table[i]);

		sout << "<TABLE id=\"" << table[i].id << "\" rows =\"" << rows << "\" columns = \"" << cols << "\">" << "\n";

		for (int r = 1; r <= rows; r++)
		{
			for (int c = 1; c <= cols; c++)
			{
				sout << "\t<CELL row = \"" << r << "\" column = \"" << c << "\" parameter=\"";

				GeometryFacadeGetDrawingTableCellNote(&table[i],c,r,&note);

				// option set to SYMBOLIC before substitution of the parameters
				GeometryFacadeGetDetailNoteData(&note, NULL, GEOMETRY_FACADE_DISPMODE_SYMBOLIC, &notesymbdata);

				GeometryFacadeCollectDetailNoteDataLines(notesymbdata, &lines);
			    n_lines = GeometryFacadeGetArraySize( (GeometryFacadeArray)lines );
				for (int l= 0; l < n_lines; l++)
				{
					 GeometryFacadeCollectDetailNoteLineTexts(lines[l], &texts);
					 n_texts = GeometryFacadeGetArraySize( (GeometryFacadeArray)texts );

					for (int t= 0; t < n_texts; t++)
					{
						GeometryFacadeLine string;
						char c_string[GEOMETRY_FACADE_LINE_SIZE];
						std::string stl_string;

						GeometryFacadeGetDetailNoteTextString (texts[t], string);
						GeometryFacadeWideStringToString (c_string, string);
						stl_string = c_string;

						std::map<std::string,std::string>::const_iterator it_first = pmap.begin();
						std::map<std::string,std::string>::const_iterator it_last = pmap.end();

						while (it_last != it_first) {
							std::string::size_type pos = stl_string.find((*it_first).first); 
							if(pos != std::string::npos)
							{
								sout << (*it_first).first;
								break;
							}
							it_first++;
						}
					}
					GeometryFacadeFreeArray( (GeometryFacadeArray*)&texts );
				}

				GeometryFacadeFreeArray( (GeometryFacadeArray*)&lines );		

				sout << "\">";
				// End of symbol data.

				// Option set to NUMERIC after substitution of the parameters.
				GeometryFacadeGetDetailNoteData(&note, NULL, GEOMETRY_FACADE_DISPMODE_NUMERIC, &notenumerdata);

				GeometryFacadeCollectDetailNoteDataLines(notenumerdata, &lines);
			    n_lines = GeometryFacadeGetArraySize ((GeometryFacadeArray)lines );
				for (int l= 0; l < n_lines; l++)
				{
					GeometryFacadeCollectDetailNoteLineTexts(lines[l], &texts);
					n_texts = GeometryFacadeGetArraySize( (GeometryFacadeArray)texts );

					for (int t= 0; t < n_texts; t++)
					{
						GeometryFacadeLine string;
						char c_string[GEOMETRY_FACADE_LINE_SIZE];
						GeometryFacadeGetDetailNoteTextString(texts[t], string);
						GeometryFacadeWideStringToString(c_string, string);
						sout << c_string;

					}

					GeometryFacadeFreeArray( (GeometryFacadeArray*)&texts );
				}

				GeometryFacadeFreeArray( (GeometryFacadeArray*)&lines );
				// End of numer data.

				sout << "</CELL>" << "\n";
			}
		}

		sout << "</TABLE>" << "\n";
	}

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&table );

	output = sout.str();	
}

//removed static keyword
int drawingViews(GeometryFacadeDrawing drawing, map<int ,std::string> &mViewStr , bool bIsTempltSldUsd)
{
	//std::string s1;
	//userListViews(drawing,s1);
	//tmp_sum = s1.str();
	ProError result;
	int view, sheet;
     GeometryFacadeSolid solid;
     GeometryFacadeMdlData mdata;
     GeometryFacadeVector outline[2],pDrwOutline1,pDrwOutline2;
     double scale;
     GeometryFacadeDrawingViewDisplay display;
     char *sstyle = NULL;
     GeometryFacadeView *views;
	 char cViewSolidName[GEOMETRY_FACADE_LINE_SIZE] = {};
	 std::stringstream sout;
	 GeometryFacadeName viewName;
	 map<std::string ,std::string> mDimStr;
	 ProPoint3d pViewLocation;
	 ProSelection pSelRef;
	 double dViewLength,dViewHeight;
	 

	 //map<int ,std::string> mViewStr;
     //char *fname = "views.txt";

	// Open a text file to contain the information to be displayed.
	//fp = fopen(fname, "w");

	// Get the current drawing.
	//GeometryFacadeGetCurrentMdl((GeometryFacadeMdl*)&drawing);
	 //Handled no view situation.Important for scanning templates

	 int n_views;
	 try
	 {
		 // Collect the views into an array.
		 GeometryFacadeCollectDrawingViews(drawing, &views);
		 n_views = GeometryFacadeGetArraySize(views);
	 }
	 catch (ProeException ex)
	 {
		 if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		 {
			 throw;
		 }
		 return 0;
	 }

	 //collect list of drawing dimensions first	 	
	try
	{
		//make vector empty before getting filled below.
		mStrMap.clear();
 		ProDrawingDimensionVisit(drawing,PRO_DIMENSION,(ProDimensionVisitAction)DrawingDimensionVisitAction,NULL,(GeometryFacadeAppData)&mDimStr);
	}
	catch(ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
	}

	if(!bIsTempltSldUsd)
	{
		//make vector empty before getting filled below. 
		mMdlDimStr.clear();
		//collect list of model dimensions
		GetModelDimensionString(drawing,mMdlDimStr);
	}
			
	for(view = 0; view < n_views; view++)
    { 
		GeometryFacadeBoolean isViewErased = GEOMETRY_FACADE_B_FALSE;
		 ProDrawingViewIsErased(drawing , views[view]  , &isViewErased);

		if(isViewErased)
			continue;

		// Get the sheet number for this view.
		sheet = GeometryFacadeGetDrawingViewSheet(drawing, views[view]);

		//If drawing file is using templates , no need to compile view solid name
		//it should be empty.
		if(!bIsTempltSldUsd)
		{			
			// Get the name of the solid that the view contains.
			GeometryFacadeFileName wSldName;
			GeometryFacadeGetDrawingViewSolid(drawing, views[view], &solid);
			GeometryFacadeGetMdlData( (GeometryFacadeMdl)solid, &mdata );
			GeometryFacadeCopyWideString(mdata.name, wSldName , GEOMETRY_FACADE_VALUE_UNUSED);
			ProWstringConcatenate(L"." , wSldName , GEOMETRY_FACADE_VALUE_UNUSED);
			ProWstringConcatenate(mdata.type , wSldName , GEOMETRY_FACADE_VALUE_UNUSED);			

			GeometryFacadeWideStringToString(cViewSolidName , wSldName);

			char temp[4];
			sprintf(temp , ".%d" , mdata.version);
			strcat(cViewSolidName , temp);
		}

		// Get the outline, scale, and display state.
        GeometryFacadeGetDrawingViewOutline(drawing, views[view], outline);   
		//Prohandle pDrawingHdl = (Prohandle)drawing;
		GetDrawingVectorCoOrdinates(drawing,sheet,outline[0],pDrwOutline1);
		GetDrawingVectorCoOrdinates(drawing,sheet,outline[1],pDrwOutline2);
		//<Replaced>GetDrawingVectorCoOrdinates(pDrawingHdl,outline[0],pDrwOutline1);
		//GetDrawingVectorCoOrdinates(pDrawingHdl,outline[1],pDrwOutline2);</Replaced>
		dViewLength = pDrwOutline2[0] - pDrwOutline1[0];
		dViewHeight = pDrwOutline2[1] - pDrwOutline1[1];
        scale = GeometryFacadeGetDrawingViewScale(drawing, views[view]);   
		ProBoolean isScaleUD;
		ProDrawingViewScaleIsUserdefined(drawing,views[view],&isScaleUD);
        display = GeometryFacadeGetDrawingViewDisplay(drawing, views[view]);
		ProDrawingViewNameGet(drawing,views[view],viewName);
		char sViewName[1+sizeof(viewName)];
		GeometryFacadeWideStringToString(sViewName, viewName);
		
		ProDrawingViewOriginGet(drawing,views[view],pViewLocation,&pSelRef); 

        switch(display.style)
        {         
			case GEOMETRY_FACADE_DISPSTYLE_DEFAULT: 
				sstyle = "default"; 
				break;
				
			case PRO_DISPSTYLE_FOLLOW_ENVIRONMENT:
				sstyle = "follow environment";
				break;

			case GEOMETRY_FACADE_DISPSTYLE_WIREFRAME: 
				
				sstyle = "wireframe"; 
				break;

			case GEOMETRY_FACADE_DISPSTYLE_HIDDEN_LINE: 

				sstyle = "hidden line"; 
				break;

			case GEOMETRY_FACADE_DISPSTYLE_NO_HIDDEN:

				sstyle = "no hidden";
				break;

			case GEOMETRY_FACADE_DISPSTYLE_SHADED: 
				
				sstyle = "shaded"; 
				break;         
         }        
		
		//Get View Type
		ProViewType viewType;
		result = ProDrawingViewTypeGet(drawing,views[view],&viewType); 
		if(result==PRO_TK_NO_ERROR && viewType==PRO_VIEW_GENERAL)
		{
			ProCharName viewName;
			if(GetCurrentModelViewName(drawing, views[view], viewName))
			{
				sout << "\n\t\t\t\t<VIEW name= \""<<sViewName<<"\" id=\""<<sViewName<<"\" sheet=\""<<sheet<<"\" PartFile=\"" << cViewSolidName  << "\" X_Distance = \"" << pViewLocation[0] << "\" Y_Distance = \"" << pViewLocation[1] << "\" ViewLength=\"" << dViewLength << "\" ViewHeight = \"" << dViewHeight << "\" PositionLowerLeft=\"" << pDrwOutline1[0]<< "," << pDrwOutline1[1] << "\" PositionUpperRight = \"" << pDrwOutline2[0]<< "," << pDrwOutline2[1] <<"\" Scale=\"" << scale <<"\" IsScaleUserDefined=\"" << isScaleUD <<"\" DisplayStyle=\"" << sstyle << "\" mdlViewName=\"" << viewName << "\" >";

			}
			else
			{
				sout << "\n\t\t\t\t<VIEW name= \""<<sViewName<<"\" id=\""<<sViewName<<"\" sheet=\""<<sheet<<"\" PartFile=\"" << cViewSolidName  << "\" X_Distance = \"" << pViewLocation[0] << "\" Y_Distance = \"" << pViewLocation[1] << "\" ViewLength=\"" << dViewLength << "\" ViewHeight = \"" << dViewHeight << "\" PositionLowerLeft=\"" << pDrwOutline1[0]<< "," << pDrwOutline1[1] << "\" PositionUpperRight = \"" << pDrwOutline2[0]<< "," << pDrwOutline2[1] <<"\" Scale=\"" << scale <<"\" IsScaleUserDefined=\"" << isScaleUD <<"\" DisplayStyle=\"" << sstyle << "\" mdlViewName=\"" << "" << "\">";
			}

		}
		else
		{
			sout << "\n\t\t\t\t<VIEW name= \""<<sViewName<<"\" id=\""<<sViewName<<"\" sheet=\""<<sheet<<"\" PartFile=\"" << cViewSolidName  << "\" X_Distance = \"" << pViewLocation[0] << "\" Y_Distance = \"" << pViewLocation[1] << "\" ViewLength=\"" << dViewLength << "\" ViewHeight = \"" << dViewHeight << "\" PositionLowerLeft=\"" << pDrwOutline1[0]<< "," << pDrwOutline1[1] << "\" PositionUpperRight = \"" << pDrwOutline2[0]<< "," << pDrwOutline2[1] <<"\" Scale=\"" << scale <<"\" IsScaleUserDefined=\"" << isScaleUD <<"\" DisplayStyle=\"" << sstyle << "\" >";
		}

		//Add dimension string for this sViewName -

		std::map<std::string, std::string>::iterator chkViewdim = mStrMap.find(sViewName);
		std::map<std::string,std::string>::iterator chkModeldim = mMdlDimStr.find(sViewName);

		if( chkViewdim != mStrMap.end())
		{
			sout << "\n\t\t<DIMS id = \"1\" name= \"Drawing_Dimension\" typename = \"Drawing Dimensions\">";
			std::string sDim = mStrMap[sViewName];
			sout << sDim;
			sout << "\n\t\t</DIMS>\n";
		}

		if ( chkModeldim != mMdlDimStr.end())
		{
			sout << "\n\t\t<DIMS id = \"1\" name= \"Model_Dimension\" typename = \"Model Dimensions\">";
			std::string sMdlDim = mMdlDimStr[sViewName];
			sout << sMdlDim;
			sout << "\n\t\t</DIMS>\n";
		}
		
		sout <<  "  " << "</VIEW>";

		std::string sTest = mViewStr[sheet];
		if (sTest.empty() == true)
		{
			mViewStr[sheet] = sout.str();
		}
		else
		{
			sTest = sTest + " " + sout.str();
			mViewStr[sheet] = sTest;
			sTest.erase();
		}
	
		
		sout.str("");
		
	 }

	return 0;
}

//B-05950: There is no Get API for model view name
//This is a workaround method to get Model view name 
//This method can be removed in future if Get API is available
bool GetCurrentModelViewName(ProDrawing drawing, ProView view, ProCharName name)
{
	ProError result;
	bool found=false;

	if(view==NULL)
	{
		return found;
	}

	//Get View transpormation metrix
	ProMatrix drwMetrix;
	result = ProDrawingViewTransformGet(drawing, view, PRO_B_TRUE, drwMetrix);
	if(result!=PRO_TK_NO_ERROR)
	{
		return found;
	}

	//Normalize matrix
	MatrixNormalize(drwMetrix);

	//Get current drawing solid 
	ProSolid drwSolid;
	result = ProDrawingCurrentsolidGet(drawing, &drwSolid);
	if(result!=PRO_TK_NO_ERROR)
	{
		return found;
	}

	ProLine * viewNames;
	ProLine * altNames;
	int count;
	result = ProViewNamesGet(drwSolid, &viewNames, &altNames, &count);
	if(result==PRO_TK_NO_ERROR)
	{
		for(int j=0; j<count; j++)
		{
			ProView view1;
			result = ProViewNameToView(drwSolid, viewNames[j], &view1); 
			if(result==PRO_TK_NO_ERROR)
			{
				ProMatrix mdlMetrix;
				result = ProViewMatrixGet(drwSolid, view1, mdlMetrix);

				//Normalize matrix
				MatrixNormalize(mdlMetrix);

				if(CompareMatrix(drwMetrix, mdlMetrix))
				{
					//Found and copy name
					ProWstringToString(name, viewNames[j]);
					found = true;
					break;
				}
			}
		}
	}

	//Free array
	ProArrayFree((ProArray*)&viewNames);
	ProArrayFree((ProArray*)&altNames);

	return found;
}
bool CompareMatrix(ProMatrix Metrix1,ProMatrix Metrix2)
{
	bool isSameOrientation = true;
	for (int j = 0; j < 3 && isSameOrientation; ++j)
	{
		for (int k = 0; k < 3 && isSameOrientation; ++k)
		{
			if(Metrix1[j][k] != Metrix2[j][k])
			{
				isSameOrientation = false;
			}
		}
	}

	return isSameOrientation;
}

//Function to normalize a 4 x 4 transformation matrix
void MatrixNormalize(ProMatrix m)
{
	int row,col;
	double scale;

	//Get the scaling factor
	scale = sqrt(m[0][0]*m[0][0] + m[0][1]*m[0][1] + m[0][2]*m[0][2]);

	//Remove the scaling
	for(row=0; row<3; row++)
	{
		for(col=0; col<3; col++)
		{
			m[row][col] /= scale;
		}
	}

	//Remove the shift
	m[3][0] = 0.0;
	m[3][1] = 0.0;
	m[3][2] = 0.0;
}

int detailSymbolInsts(GeometryFacadeDrawing drawing, std::string &output)
{
    GeometryFacadeDetailSymbolInst *p_symins;
	GeometryFacadeDetailSymbolInstData  syminst_data;

	std::ostringstream sout;

	sout << "========= Symbol Instances ===========\n";
	
	GeometryFacadeCollectDrawingDetailSymbolInsts(drawing, GEOMETRY_FACADE_VALUE_UNUSED, &p_symins);
	int n_syminsts = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_symins );

	for (int i = 0; i < n_syminsts; i++)
	{
		GeometryFacadeGetDetailSymbolInstData(&p_symins[i], GEOMETRY_FACADE_DISPMODE_SYMBOLIC, &syminst_data);

		// Get ID.
		int id = GeometryFacadeGetDetailSymbolInstDataId(syminst_data);
		sout << "ID: " << id <<"\n";

		// Get color.
		sout << "Color: \n\t";
		GeometryFacadeColor color = GeometryFacadeGetDetailSymbolInstDataColor(syminst_data);
		std::ostringstream s1;
		userColorPrint(s1,color);
		sout << s1.str();

		// Get height.
		double height = GeometryFacadeGetDetailSymbolInstDataHeight(syminst_data);
		sout << "Height: "<< height << "\n";

		// Get angle.
		double angle = GeometryFacadeGetDetailSymbolInstDataAngle(syminst_data);
		sout << "Angle: " << angle << "\n";

		// Get elbow length.
		GeometryFacadeBoolean is_default;
		double el_len = 0.0;
		GeometryFacadeGetDetailSymbolInstDataElbowLength(syminst_data, &is_default, &el_len);
		sout << "Elbow length: " << el_len << " Is Default: " << is_default << "\n";

		// Get display status.
		GeometryFacadeBoolean is_displayed = GeometryFacadeIsDetailSymbolInstDataDisplayed(syminst_data);
		sout << "Displ status: " << is_displayed << "\n";

		// Get attachment type.
		GeometryFacadeDetailSymbolDefAttachType atype = GeometryFacadeGetDetailSymbolInstDataAttachType(syminst_data);
		sout << "Attachment type: " << atype << "\n";
	}

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_symins );

	output = sout.str();

	return 0;
}


int detailSymbolInfo(GeometryFacadeDrawing drawing, std::string &output)
{
    GeometryFacadeDetailSymbolDef *p_symdef;
	GeometryFacadeDetailSymbolDefData symdef_data;
	std::ostringstream sout;
	
	//sout << "=========== Symbol Definitions ===========\n";
	
    GeometryFacadeCollectDrawingDetailSymbolDefs(drawing, &p_symdef);
    int n_symdefs = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_symdef );
	for (int i = 0; i < n_symdefs; i++)
	{
		
		GeometryFacadeGetDetailSymbolDefData(&p_symdef[i], &symdef_data);

		// Get ID.
		int id = GeometryFacadeGetDetailSymbolDefDataId(symdef_data);
		
		// Get height.
		double height = GeometryFacadeGetDetailSymbolDefDataHeight(symdef_data);

		//sout << "\t<SYMBOL ID= \""<<id<<"\" Height=\"" << height << "\" >" << "  " << "</SYMBOL>\n";
		
		
	}

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_symdef );

	output = sout.str();

	return 0;
}


int detailNoteInfo(GeometryFacadeDrawing drawing, std::string &output,int sheet)
{
	GeometryFacadeDetailNote *p_notes = NULL;
	int n_leaders = 0, j, n_lines = 0, n_texts = 0, k, id;
	GeometryFacadeDetailNoteData note_data;
	GeometryFacadeBoolean flag;
	double param = 0.0;
	GeometryFacadeDetailAttach attach;
	GeometryFacadeDetailAttachType type;
	GeometryFacadeView view;
	GeometryFacadeVector location;
	GeometryFacadeVector pDrwLoc;
	GeometryFacadeSelection attach_point;
	GeometryFacadeDetailNoteLine *p_lines = NULL;
	GeometryFacadeDetailNoteText *p_texts = NULL;
	GeometryFacadeLine string;
	GeometryFacadeCharLine line;
	GeometryFacadeName font;
	char buffer[30];
	std::string sText,sLineText;
	char *cChkSpl = NULL;	

	std::ostringstream sout;

	//Handled no note condition .Important for scanning templates
	int n_notes;
	try
	{
		GeometryFacadeCollectDrawingDetailNotes(drawing, NULL, sheet, &p_notes);
		n_notes = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_notes );
	}
	catch (ProeException ex)
	{
		if (ex.GetResult() != GEOMETRY_FACADE_NOT_FOUND)
		{
			throw;
		}
		return 0;
	}

	for (int i = 0; i < n_notes; i++)
	{
		GeometryFacadeGetDetailNoteData(&p_notes[i], NULL, GEOMETRY_FACADE_DISPMODE_NUMERIC, &note_data);
		id = GeometryFacadeGetDetailNoteDataId(note_data);
		_itoa(i+1,buffer,10);
		char noteName[100] = "NOTE-";
		strcat(noteName,buffer);
		char commonID[10] = "";
		char buffer1[10] = "";
		_itoa(id,buffer1,10);
		strcat(commonID,buffer1);
		strcat(commonID,"-");
		char buffer2[10] = "";
		_itoa(sheet,buffer2,10);
		strcat(commonID,buffer2);
		
		// Get attachment.
		GeometryFacadeGetDetailNoteDataAttachment(note_data, &attach);
		GeometryFacadeGetDetailAttachment(attach, &type, &view, location, &attach_point); 
		//Prohandle pDrawingHdl = Prohandle(drawing);
		//<Replaced>GetDrawingVectorCoOrdinates(pDrawingHdl,location,pDrwLoc);		
		GetDrawingVectorCoOrdinates(drawing,sheet,location,pDrwLoc);		

		// Get texts.
		GeometryFacadeCollectDetailNoteDataLines(note_data, &p_lines);

		n_lines = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_lines );
		for (j = 0; j < n_lines; j++)
		{
			GeometryFacadeCollectDetailNoteLineTexts(p_lines[j], &p_texts);				
			n_texts = GeometryFacadeGetArraySize( (GeometryFacadeArray)p_texts );

			for (k = 0; k < n_texts; k++)
			{
				GeometryFacadeGetDetailNoteTextString(p_texts[k], string);
				GeometryFacadeWideStringToString(line, string);
								
				//Convert the Speacial cahrs and append 
				sLineText.append(GetValidStringValue(line));	
			}

			if (n_lines > 1)
			{
				if (j != (n_lines-1))
				{
					sLineText.append("||");
				}
			}
			sText.append(sLineText);

			sLineText = "";
			if (j == (n_lines-1))
			{
				sout << "\t\t\t<NOTES id = \""<<commonID<< "\" name= \""<<noteName<<"\" typename = \""<<"NOTE"<<"\" sheet = \""<<sheet<<"\">"<<"\n";
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"X_Distance"<<"\">"<<pDrwLoc[0]<<"</NOTE>"<<"\n";
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Y_Distance"<<"\">"<<pDrwLoc[1]<<"</NOTE>"<<"\n";
				param = GeometryFacadeGetDetailNoteTextHeight (p_texts[0]);
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Height"<<"\">"<<param<<"</NOTE>"<<"\n";
				param = GeometryFacadeGetDetailNoteTextWidth(p_texts[0]);
				param = GeometryFacadeGetDetailNoteTextSlant(p_texts[0]); 
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Slant"<<"\">"<<param<<"</NOTE>"<<"\n";
				param = GeometryFacadeGetDetailNoteTextThickness(p_texts[0]); 
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Thickness"<<"\">"<<param<<"</NOTE>"<<"\n";
				GeometryFacadeGetDetailNoteTextFont(p_texts[0], font);
				GeometryFacadeWideStringToString(line, font);   
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Font"<<"\">"<<line<<"</NOTE>"<<"\n";
				flag = GeometryFacadeGetDetailNoteTextUnderLine(p_texts[0]);
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Uline"<<"\">"<<( (flag == GEOMETRY_FACADE_B_TRUE) ? "Yes" : "No" )<<"</NOTE>"<<"\n";
				std::string sLayerName  = "";
				sLayerName = GetNoteLayerName(drawing,note_data);
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Layer"<<"\">"<<sLayerName<<"</NOTE>"<<"\n";
				sout << "\t\t\t\t<NOTE id = \""<<id<< "\" type= \""<<"linear"<<"\" name = \""<<"Display"<<"\">"<<"True"<<"</NOTE>"<<"\n";
				sout << "\t\t\t\t<NOTE id = \""<<commonID<< "\" type= \""<<"linear"<<"\" name = \""<<"NoteText"<<"\">"<<sText<<"</NOTE>"<<"\n";

				std::wstring NoteRefMdl = GetModelReferencedInNote(&p_notes[i] , drawing);
				if(wcslen(NoteRefMdl.c_str()) != 0)
				{
					char noteRefMdl[GEOMETRY_FACADE_LINE_SIZE];
					GeometryFacadeWideStringToString(noteRefMdl, NoteRefMdl.c_str());
					sout << "\t\t\t\t<NOTE id = \""<<commonID<< "\" type= \""<<"linear"<<"\" name = \""<<"NoteModel"<<"\">"<< noteRefMdl <<"</NOTE>"<<"\n";
				}

				sText = "";
				sout << "\t\t\t</NOTES>\n";
			}						
		}		

		for (k = 0; k < n_texts; k++)
		{
			GeometryFacadeFreeDetailNoteText(p_texts[k]);
		}

		GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_texts );

		for (j = 0; j < n_lines; j++)
		{
			GeometryFacadeFreeDetailNoteLine(p_lines[j]);
		}

		GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_lines );
	}	

	GeometryFacadeFreeArray( (GeometryFacadeArray*)&p_notes );
	output = output+sout.str();

	return 0;
}

//If Drawing Note is Referring model which is neither drawing nor current solid , return such part name.
//D-04780 - Handling parametric notes. Fix for D-05083 is added
std::wstring GetModelReferencedInNote(GeometryFacadeDetailNote *p_note , GeometryFacadeDrawing drawing)
{
	std::wstring mdlName;
	try
	{
		int lines, i;
		bool first = true;
		GeometryFacadeDetailNoteData note_data;
		GeometryFacadeDetailNoteLine * noteLines = NULL;

		//Get each line
		GeometryFacadeGetDetailNoteData(p_note, NULL, GEOMETRY_FACADE_DISPMODE_NUMERIC, &note_data);
		GeometryFacadeCollectDetailNoteDataLines(note_data, &noteLines);
		lines = GeometryFacadeGetArraySize( (GeometryFacadeArray)noteLines );
		for (i = 0; i < lines; i++)
		{
			GeometryFacadeMdl pNoteMdl = NULL;
			GeometryFacadeName pMdlName;
			GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;		
			GeometryFacadeMdl pCrntSolid;

			//Get model ref for each line 
			//Note: Argument text_index should be increased to get multiple note symbols
			//Currently there is no API support to get note text_index counts, Hence used while loop
			int j=0;
			while(ProDtlnoteModelrefGet(p_note , NULL , i , j , &pNoteMdl)== GEOMETRY_FACADE_NO_ERROR)
			{
				if(pNoteMdl != drawing)
				{
					result = ProDrawingCurrentsolidGet((GeometryFacadeDrawing)drawing , (GeometryFacadeSolid*)&pCrntSolid);
					if(pCrntSolid != pNoteMdl)
					{
						wstring name;
						result = ProMdlNameGet(pNoteMdl , pMdlName);
						name = pMdlName;

						GeometryFacadeMdlType pMdlType = GeometryFacadeGetMdlType(pNoteMdl);
						if(pMdlType == GEOMETRY_FACADE_MDL_PART)
						{
							name.append(L".PRT");
						}
						else if(pMdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
						{
							name.append(L".ASM");
						}

						if(first == true)
						{
							mdlName.append(name);
							first = false;
						}
						else
						{
							mdlName.append(L",").append(name);
						}
					}
				}
				//Increment of j
				j=j+1;
			}
		}

		//Clear Array
		GeometryFacadeFreeArray( (GeometryFacadeArray*)&noteLines );
	}
	catch(ProeException ex)
	{
		LOG << "GetModelReferencedInNote: Caught Outer exception" << endl;
	}
	return mdlName;
}

std::string GetNoteLayerName(GeometryFacadeDrawing drawing,GeometryFacadeDetailNoteData note_data)
{
	ProError pErrStatus;
	ProLayerItem pLayerItem;
	ProLayer *pLayer;	
	int iNoteId;
	GeometryFacadeName wname = {};
	char *name = new char[1+sizeof(GeometryFacadeName)];
	std::string returnString("NoLayer");

	pErrStatus = ProDtlnotedataIdGet(note_data,&iNoteId);

	pErrStatus = ProLayerItemInit(PRO_LAYER_NOTE,iNoteId,drawing,&pLayerItem);

	pErrStatus = ProLayeritemLayersGet((GeometryFacadeDrawing)drawing,&pLayerItem,&pLayer);
	
	if (pErrStatus == GEOMETRY_FACADE_NO_ERROR)
	{
		GeometryFacadeGetModelItemName(&pLayer[0],wname);
		ProWstringToString(name, wname);		
		returnString = name;		
	}

	delete[] name;
	return returnString;
}

void GetDrawingVectorCoOrdinates(GeometryFacadeDrawing pDrawing,int iDrawingSheet,ProVector pInVector,ProVector pOutVector)
{
	//<Replaced>wchar_t    wSize[10];
    ProMatrix  pMatrix;
	ProName wSize;

    //<Replaced>prodb_drawing_sheet_info(pDrawing, wSize, pMatrix);
	ProDrawingSheetTrfGet(pDrawing,iDrawingSheet,wSize,pMatrix);
	ProVectorTrfEval(pInVector,pMatrix,pOutVector);
}

void GetDrawingPointCoOrdinates(GeometryFacadeDrawing pDrawing,int iDrawingSheet,GeometryFacadePoint3D pInVector,GeometryFacadePoint3D pOutVector)
{
	//<Replaced>wchar_t    wSize[10];
    ProMatrix  pMatrix;
	ProName wSize;

    //<Replaced>prodb_drawing_sheet_info(pDrawing, wSize, pMatrix);
	ProDrawingSheetTrfGet(pDrawing,iDrawingSheet,wSize,pMatrix);
	ProPntTrfEval(pInVector,pMatrix,pOutVector);
}

static void userColorPrint(std::ostringstream &sout, GeometryFacadeColor color)
{
    switch (color.method)
    {
		case GEOMETRY_FACADE_COLOR_METHOD_DEFAULT:

			sout << "Default\n";
			break;

		case GEOMETRY_FACADE_COLOR_METHOD_TYPE:

			sout << "Type: " << color.value.type << "\n";
			break;

		case GEOMETRY_FACADE_COLOR_METHOD_RGB:

			sout << "red:" << color.value.map.red << " green: " << color.value.map.green << " blue: " << color.value.map.blue << "\n";
			break;

		default:

			 break;
    }
}


/*====================================================================*\ 
FUNCTION : userListViews()
PURPOSE  : Command to list view info in an information window 
\*====================================================================*/
static int userListViews(GeometryFacadeDrawing drawing, std::string &output) 
{
     int view, sheet;
     GeometryFacadeSolid solid;
     GeometryFacadeMdlData mdata;
     GeometryFacadeVector outline[2];
     double scale;
     GeometryFacadeDrawingViewDisplay display;
     char *sstyle;
     GeometryFacadeView *views;
     GeometryFacadeCharName name, type;
	 std::stringstream sout;
     //char *fname = "views.txt";

	// Open a text file to contain the information to be displayed.
	//fp = fopen(fname, "w");

	// Get the current drawing.
	//GeometryFacadeGetCurrentMdl((GeometryFacadeMdl*)&drawing);

	// Collect the views into an array.
	GeometryFacadeCollectDrawingViews(drawing, &views);
    int n_views = GeometryFacadeGetArraySize(views);

	for(view = 0; view < n_views; view++)
    { 
		// Get the sheet number for this view.
		sheet = GeometryFacadeGetDrawingViewSheet(drawing, views[view]);

		// Get the name of the solid that the view contains.
		GeometryFacadeGetDrawingViewSolid(drawing, views[view], &solid);
        GeometryFacadeGetMdlData( (GeometryFacadeMdl)solid, &mdata );
        GeometryFacadeWideStringToString(name, mdata.name);
        GeometryFacadeWideStringToString(type, mdata.type);

		// Get the outline, scale, and display state.
        GeometryFacadeGetDrawingViewOutline(drawing, views[view], outline);         
        scale = GeometryFacadeGetDrawingViewScale(drawing, views[view]);         
        display = GeometryFacadeGetDrawingViewDisplay(drawing, views[view]);

		// Write the information to the text file.
		/*sout << "View " << view+1 << "\n";
        sout << "    Solid        : " << name <<"." << type << "." << mdata.version << "\n";
        sout << "    Sheet        : " << sheet <<"\n";
        sout << "    Lower left   : " << outline[0][0]<< "," << outline[0][1] << "\n";
        sout << "    Upper right  : " << outline[1][0]<< "," << outline[1][1] << "\n";
        sout << "    Scale        : " << scale<<"\n";*/
        switch(display.style)
        {         
			case GEOMETRY_FACADE_DISPSTYLE_DEFAULT: 
				
				sstyle = "default"; 
				break;

			case GEOMETRY_FACADE_DISPSTYLE_WIREFRAME: 
				
				sstyle = "wireframe"; 
				break;

			case GEOMETRY_FACADE_DISPSTYLE_HIDDEN_LINE: 

				sstyle = "hidden line"; 
				break;

			case GEOMETRY_FACADE_DISPSTYLE_NO_HIDDEN:

				sstyle = "no hidden";
				break;

			case GEOMETRY_FACADE_DISPSTYLE_SHADED: 
				
				sstyle = "shaded"; 
				break;         
         }

         //sout << "    Disp style   : " << sstyle << "\n";
		sout << "\t<VIEW number= \""<<view+1<<"\" Part File=\"" << name <<"." << type << "." << mdata.version << "\" Position Lower left=\"" << outline[0][0]<< "," << outline[0][1] << "\" Position Upper right = \"" << outline[1][0]<< "," << outline[1][1] <<"\" Scale=\"" << scale <<"\" Display style=\"" << sstyle << "\" >" << "  " << "</VIEW>\n";
	 }

   return 0;
}


ProError DrawingDimensionVisitAction(ProDimension* pDimension,ProError pErrStatus,ProAppData pAppData)
{
	double dDimVal,dElbowLen;
	ProView pDrwView = NULL;
	GeometryFacadeDrawing pDrawing = (GeometryFacadeDrawing)pDimension->owner;
	ProTextStyle pDimTxtStle;
	ProDimlocation pDimLocation;
	ProBoolean bhasElbow;
	ProPoint3d pDimPoint,pDimDrwPnt;
	std::stringstream sOut;	
	GeometryFacadeName pViewName = {0};
	GeometryFacadeName pDimName = {0};
	//typedef std::map<std::string, std::string> mStrMap;
	//std::map<std::string, std::string> mStrMap;
	//std::map<char, std::string> mStrMap;	
	//mStrMap& mDimStr = *static_cast<std::map<std::string, std::string>*>(pAppData);//(map<std::string,std::string> *) pAppData;
	
   	if (pDimension != NULL)
	{
		//pErrStatus = ProDimensionTextGet(pDimension,&pDimText);
		//GeometryFacadeWideStringToString(pDimChar, (const GeometryFacadeWideChar*)pDimText);

		//pErrStatus = ProDimensionValuedisplayGet(pDimension,&pDimDisVal);
		//GeometryFacadeWideStringToString(pDimChar, pDimDisVal);
		
		pErrStatus = ProDimensionValueGet(pDimension,&dDimVal);

		pErrStatus = ProDimensionTextstyleGet(pDimension,&pDimTxtStle);
		
		//pErrStatus = ProDimensionTypeGet(pDimension,&pDimtype);

		pErrStatus = ProDrawingDimensionViewGet(pDrawing,pDimension,&pDrwView);	
		
		if(pErrStatus != PRO_TK_NO_ERROR || pDrwView == NULL)
			return PRO_TK_NO_ERROR;

		pErrStatus = ProDrawingViewNameGet(pDrawing,pDrwView,pViewName);
		//std::string sViewName = "";
		char cViewName[1+sizeof(pViewName)];
		GeometryFacadeWideStringToString(cViewName, pViewName);
		std::string sViewName = cViewName;
				

		pErrStatus = ProDimensionLocationGet(pDimension,NULL,pDrawing,&pDimLocation);

		pErrStatus = ProDimlocationTextGet(pDimLocation,&bhasElbow,pDimPoint,&dElbowLen);
		//Prohandle pDrawingHdl = (Prohandle)pDrawing;
		int sheet = GeometryFacadeGetDrawingViewSheet(pDrawing, pDrwView);
		GetDrawingPointCoOrdinates(pDrawing,sheet,pDimPoint,pDimDrwPnt);
		double dXdistance = pDimDrwPnt[0];
		double dYDistance = pDimDrwPnt[1];

			// Get the type of the dimension.
		GeometryFacadeCharName dim_typename;
		GeometryFacadeCharName cDimName;
		GeometryFacadeDimensionType dim_type = GeometryFacadeGetDimensionType(pDimension);

		switch (dim_type) 
		{
			case GEOMETRY_FACADE_DIMTYPE_LINEAR:
				strcpy(dim_typename,"linear");
				break;

			case GEOMETRY_FACADE_DIMTYPE_ANGLE:
				strcpy(dim_typename, "angular");
				break;

			case GEOMETRY_FACADE_DIMTYPE_DIAMETER:
				strcpy(dim_typename, "diameter");
				break;

			case GEOMETRY_FACADE_DIMTYPE_RADIUS:
				strcpy(dim_typename, "radius");
				break;

			case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:
				strcpy(dim_typename, "UNKNOWN");
				break;

			default:
				strcpy(dim_typename, "XXX");
				break;
		}

		ProDimensionSymbolGet(pDimension,pDimName);
		GeometryFacadeWideStringToString(cDimName, pDimName);
		LOG << "Drawing View Name : " << cViewName << " and Dimension Name : " << cDimName << endl;
		char cXmlTag[1000];
		//std::string XMLTag;
		sprintf(cXmlTag, "\n\t\t\t\t\t<DDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\">%f</DDIM>", 
			pDimension->id, cDimName, dim_typename, dXdistance, dYDistance,dDimVal);

		//sOut << "\n\t\t\t\t<DDIM id = \""<<pDimension->id<< "\" type= \""<<dim_typename<<"\" X_Distance = \""<<dXdistance<<"\" Y_Distance = \""<<dYDistance<<"\">"<<dDimVal<<"</DDIM>";

		std::string sXmlTag = cXmlTag;
		//mStrMap[sViewName];

		//std::map<std::string, std::string>::iterator mchkViewName = mStrMap.find(sViewName);
		std::string sTest = mStrMap[cViewName];

		//////char *sTest = new char[1000];
		//////char *sTest = new char[sizeof((*mDimStr)[sViewName]) + 1 + 1];
		////char *sTest = (*mDimStr)[sViewName];
		//mchkViewName = mDimStr->find(sViewName);

		if (sTest.empty())
		{
			//mStrMap.insert(std::make_pair(sViewName,sXmlTag));
			//std::string strTemp = "new_view_7";
			//mStrMap.insert(pair<char[1+sizeof(pViewName)],string>(cViewName,sXmlTag));
			//mStrMap.insert ( pair<string,string>("milind_bad_gujar","100") );
			//
			//mchkViewName=mStrMap.begin();
			//mStrMap.insert (mchkViewName, pair<string,string>("mohsin","300"));
			mStrMap[cViewName] = cXmlTag;
			
		}
		else
		{
			sTest = sTest + " " + cXmlTag;
			mStrMap[cViewName] = sTest;
			sTest.erase();
			//mchkViewName->second += std::string(" ") + sXmlTag;
		}
		//sOut.str("");
		sXmlTag = "";
	}
	return pErrStatus;
}


void GetModelDimensionString(GeometryFacadeDrawing pDrawing,map<std::string ,std::string> &mMdlDimStr)
{
	GeometryFacadeView *pViews = NULL;
	int iNoViews,i;
	GeometryFacadeSolid pSolid;
	pStoreDrwHandle = pDrawing;
	iCount = 0;
	lDimIds.clear();

	GeometryFacadeCollectDrawingViews(pDrawing, &pViews);
	iNoViews = GeometryFacadeGetArraySize(pViews);

	for(i = 0;i<iNoViews;i++)
	{
		GeometryFacadeGetDrawingViewSolid(pDrawing,pViews[i],&pSolid);
		GeometryFacadeVisitSolidDimension(pSolid,PRO_B_FALSE,(GeometryFacadeDimensionVisitAction)SolidModelDimensionVisitAction,(GeometryFacadeDimensionFilterAction)SolidModelDimensionFilterAction,(GeometryFacadeAppData)&mMdlDimStr);
	}
}

GeometryFacadeError SolidModelDimensionVisitAction(GeometryFacadeDimension *pDimension, GeometryFacadeError status, GeometryFacadeAppData pData) 
{
	GeometryFacadeDrawing pDrawing = pStoreDrwHandle;
	GeometryFacadeError result = PRO_TK_NO_ERROR;
	bool bIsIDExist = false;
	double dDimVal,dElbowLen;
	int decimal=0;
	GeometryFacadeView pView;
	GeometryFacadeName pViewName,pDimName;
	ProDimlocation pDimLocation;
	ProBoolean bHasElbow;
	ProPoint3d pDimPoint,pDimDrwPnt;	
			
	if (!lDimIds.empty())
	{
		DimItr = std::find_if(lDimIds.begin(), lDimIds.end(), std::bind2nd(std::equal_to<int>(), pDimension->id));
		if(DimItr != lDimIds.end())
			bIsIDExist = true;		
		else		
			lDimIds.push_back(pDimension->id);		
	}
	else
	{
		lDimIds.push_back(pDimension->id);
	}

	if (!bIsIDExist)
	{
		result = ProDimensionValueGet(pDimension,&dDimVal);
		result = ProDimensionDecimalsGet(pDimension, &decimal);
		result = ProDrawingDimensionViewGet(pDrawing,pDimension,&pView);	
		result = ProDrawingViewNameGet(pDrawing,pView,pViewName);		
		char cViewName[1+sizeof(pViewName)];
		GeometryFacadeWideStringToString(cViewName, pViewName);
		std::string sViewName = cViewName;

		result = ProDimensionLocationGet(pDimension,NULL,pDrawing,&pDimLocation);

		result = ProDimlocationTextGet(pDimLocation,&bHasElbow,pDimPoint,&dElbowLen);
		//Prohandle pDrawingHdl = (Prohandle)pDrawing;
		int sheet = GeometryFacadeGetDrawingViewSheet(pDrawing,pView);
		GetDrawingPointCoOrdinates(pDrawing,sheet,pDimPoint,pDimDrwPnt);
		double dXdistance = pDimDrwPnt[0];
		double dYDistance = pDimDrwPnt[1];

		GeometryFacadeCharName cDimType;
		GeometryFacadeCharName cDimName;
		GetDimensionType(pDimension,cDimType);
		ProDimensionSymbolGet(pDimension,pDimName);
		GeometryFacadeWideStringToString(cDimName, pDimName);
		LOG << "Drawing View Name : " << cViewName << " and Dimension Name : " << cDimName << endl;
		
		char cXmlTag[1000];		
		
		//Get tolerance type
		ProDimToleranceType tolType;
		result = ProDimensionToltypeGet(pDimension, &tolType);
		if(result==PRO_TK_NO_ERROR)
		{
			GeometryFacadeCharName tolTypeChar;
			GetToleranceType(tolType, tolTypeChar);

			double upper=0.0, lower=0.0;
			ProDimensionToleranceGet(pDimension, &upper, &lower);

			int tolDecimal=0;
			result = ProDimensionTolerancedecimalsGet(pDimension, &tolDecimal);
			if(result != PRO_TK_NO_ERROR)
			{
				//For default decimal places set 0
				tolDecimal=0;
			}

			ProToleranceTable table;
			ProName tableName;
			int column;
			result = ProDimensionTollabelGet(pDimension, &table, tableName, &column);
			if(result == PRO_TK_BAD_CONTEXT||result == PRO_TK_E_NOT_FOUND)
			{
				if(tolType==PRO_TOL_LIMITS)
				{
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" TolType=\"%s\" Upper_Tolerance=\"%f\" Lower_Tolerance=\"%f\" Tol_Decimal_Places=\"%d\">%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,tolTypeChar,upper, lower, tolDecimal, dDimVal);
				}
				else if(tolType==PRO_TOL_PLUS_MINUS)
				{
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\" TolType=\"%s\" Upper_Tolerance=\"%f\" Lower_Tolerance=\"%f\" Tol_Decimal_Places=\"%d\">%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,tolTypeChar,upper, lower, tolDecimal, dDimVal);
				}
				else if(tolType==PRO_TOL_PLUS_MINUS_SYM || tolType==PRO_DIM_TOL_SYM_SUPERSCRIPT)
				{
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\" TolType=\"%s\" Tolerance=\"%f\" Tol_Decimal_Places=\"%d\">%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,tolTypeChar, upper, tolDecimal, dDimVal);
				}
				else
				{			
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\" TolType=\"%s\" >%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,tolTypeChar, dDimVal);
				}

				//Set no error to continue for next dimension
				result = PRO_TK_NO_ERROR;
			}
			else if(result ==PRO_TK_NO_ERROR)
			{
				GeometryFacadeCharName tolTableChar;
				GetToleranceTable(table, tolTableChar);

				if(table==PROTOLTABLE_GENERAL||table==PROTOLTABLE_BROKEN_EDGE)
				{
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\" TolType=\"%s\" TolTable=\"%s\" Tol_Decimal_Places=\"%d\">%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,tolTypeChar, tolTableChar, tolDecimal, dDimVal);
				}
				else if(table==PROTOLTABLE_SHAFTS||table==PROTOLTABLE_HOLES)
				{
					char cMdlName[GEOMETRY_FACADE_LINE_SIZE];
					ProWstringToString(cMdlName , tableName);
					sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\" TolType=\"%s\" TolTable=\"%s\" Table_Name=\"%s\" Table_Column=\"%d\" Tol_Decimal_Places=\"%d\">%f</MDIM>", 
						pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,tolTypeChar, tolTableChar, cMdlName, column, tolDecimal, dDimVal);
				}
			}
		}
		else
		{
			sprintf(cXmlTag, "\n\t\t\t\t\t<MDIM id=\"%d\" name=\"%s\" type=\"%s\" X_Distance=\"%f\" Y_Distance=\"%f\" Decimal_Places=\"%d\">%f</MDIM>", 
				pDimension->id, cDimName, cDimType, dXdistance, dYDistance,decimal,dDimVal);
		}

		std::string sXmlTag = cXmlTag;

		std::string sTest = mMdlDimStr[cViewName];
		if (sTest.empty())
		{			
			mMdlDimStr[cViewName] = cXmlTag; 			
		}
		else
		{
			sTest = sTest + " " + cXmlTag;
			mMdlDimStr[cViewName] = sTest;
			sTest.erase();			
		}		
		sXmlTag = "";		
	}

	return result;
}

GeometryFacadeError SolidModelDimensionFilterAction(GeometryFacadeDimension *pDimension,GeometryFacadeAppData pData)
{
	GeometryFacadeDrawing pDrawing = pStoreDrwHandle;
	GeometryFacadeBoolean bIsShown;
	ProAnnotationIsShown((ProAnnotation*)pDimension,pDrawing,&bIsShown);
		
	if (bIsShown)
	return PRO_TK_NO_ERROR;

	return PRO_TK_CONTINUE;
}

//To get tolarance table string
void GetToleranceTable(ProToleranceTable tolTable, GeometryFacadeCharName tolTableChar)
{
		switch (tolTable) 
		{
			case PROTOLTABLE_NONE:
				strcpy(tolTableChar,"none");
				break;

			case PROTOLTABLE_GENERAL:
				strcpy(tolTableChar, "General");
				break;

			case PROTOLTABLE_BROKEN_EDGE:
				strcpy(tolTableChar, "Broken Edge");
				break;

			case PROTOLTABLE_SHAFTS:
				strcpy(tolTableChar, "Shaft");
				break;

			case PROTOLTABLE_HOLES:
				strcpy(tolTableChar, "Hole");
				break;

			default:
				strcpy(tolTableChar, "UNKNOWN");
				break;
		}
}

//To get tolarance type string
void GetToleranceType(ProDimToleranceType tolType, GeometryFacadeCharName tolTypeChar)
{
		switch (tolType) 
		{
			case PRO_TOL_DEFAULT:
				strcpy(tolTypeChar,"Nominal");
				break;

			case PRO_TOL_PLUS_MINUS:
				strcpy(tolTypeChar, "Plus-Minus");
				break;

			case PRO_TOL_LIMITS:
				strcpy(tolTypeChar, "Limits");
				break;

			case PRO_TOL_PLUS_MINUS_SYM:
				strcpy(tolTypeChar, "+- Symmetric");
				break;

			case PRO_DIM_TOL_SYM_SUPERSCRIPT:
				strcpy(tolTypeChar, "+- Symmetric (Superscript)");
				break;

			default:
				strcpy(tolTypeChar, "UNKNOWN");
				break;
		}
}

void GetDimensionType(ProDimension* pDimension,GeometryFacadeCharName cDimType)
{
	//GeometryFacadeCharName cDimType;
		GeometryFacadeDimensionType pDimType = GeometryFacadeGetDimensionType(pDimension);
		switch (pDimType) 
		{
			case GEOMETRY_FACADE_DIMTYPE_LINEAR:
				strcpy(cDimType,"linear");
				break;

			case GEOMETRY_FACADE_DIMTYPE_ANGLE:
				strcpy(cDimType, "angular");
				break;

			case GEOMETRY_FACADE_DIMTYPE_DIAMETER:
				strcpy(cDimType, "diameter");
				break;

			case GEOMETRY_FACADE_DIMTYPE_RADIUS:
				strcpy(cDimType, "radius");
				break;

			case GEOMETRY_FACADE_DIMTYPE_UNKNOWN:
				strcpy(cDimType, "UNKNOWN");
				break;

			default:
				strcpy(cDimType, "XXX");
				break;
		}		
}

//ProE API fails to return template view information. So here Addin will create a temporary drawing file
//using the template file. This drawing file will then be used for further scanning.
bool GetTemplateDrawing(GeometryFacadeDrawing* drwtemplHandle , GeometryFacadeName wDrwTempNm)
{
	bool bIsTempDrwCreated = false;
	try
	{
		GeometryFacadeLine wSolidTempPath;
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl pTemplSolid = NULL;
		char cSldTemplPath[GEOMETRY_FACADE_PATH_SIZE];
		GeometryFacadeMdlData templData;
		GeometryFacadeModel pModel;
		ProDwgcreateOptions options = (ProDwgcreateOptions)0;
		GeometryFacadeDrawing created_drawing = NULL;
		GeometryFacadeName drwTempName = L"RSTempDrawing";

		ProConfigoptGet(L"template_Solidpart" , wSolidTempPath);
		GeometryFacadeWideStringToString(cSldTemplPath , wSolidTempPath);
		GeometryFacadeRetrieveMdl(cSldTemplPath , PRO_MDL_PART , &pTemplSolid);

		LOG << "Template solid retreived" << endl;

		GeometryFacadeGetMdlData (pTemplSolid , &templData);
		ProWstringCopy(templData.name , pModel.name , GEOMETRY_FACADE_VALUE_UNUSED);
		ProWstringCopy(templData.type , pModel.type , GEOMETRY_FACADE_VALUE_UNUSED);

		LOG << "Creating drawing from template" << endl;
		GeometryFacadeCreateDrawingFromTemplate (drwTempName , wDrwTempNm , &pModel , options, &created_drawing);		
		
		GeometryFacadeRetrieveMdl("RSTempDrawing" , GEOMETRY_FACADE_MDL_DRAWING , (GeometryFacadeMdl*)&created_drawing);
		GeometryFacadeDisplayMdl(created_drawing);

		ProMdlErase(pTemplSolid);

		LOG << "Drawing from template created with result <" <<  result <<  ">" << endl;
		*drwtemplHandle = created_drawing;
		bIsTempDrwCreated = true;

	}
	catch(ProeException ex)
	{
		LOG << "GetTemplateDrawing: Failed while creating drawing file from template"<< endl;
	}

	return bIsTempDrwCreated;
}

//To get list of drawing notes reference model names. D-05083
static std::wstring GetListOfDrawingRefModels_wrapper()
{
	std::wstring allMdlLst;

	try
	{
		bool first=true;
		
		//Get current drawing
		ProError result=PRO_TK_GENERAL_ERROR;
		GeometryFacadeMdl drawing;
		result = ProMdlCurrentGet(&drawing);
		if(result != PRO_TK_NO_ERROR)
		{
			LOG << "GetListOfDrawingRefModels_wrapper: drawing not found and Returning final list " << endl;
			return allMdlLst;
		}

		//Get drawing no of sheets
		int n_sheets = GeometryFacadeCountDrawingSheets((ProDrawing)drawing);
		for(int sheet = 1; sheet <= n_sheets; sheet++)
		{
			int notesSize;
			GeometryFacadeDetailNote * notes = NULL;
			try
			{
				GeometryFacadeCollectDrawingDetailNotes((ProDrawing )drawing, NULL, sheet, &notes);
				notesSize = GeometryFacadeGetArraySize( (GeometryFacadeArray)notes );
			}
			catch (ProeException ex)
			{
				return allMdlLst;
			}

			for (int i = 0; i < notesSize; i++)
			{
				//Get model Ref for each note 
				std::wstring noteRefMdl = GetModelReferencedInNote(&notes[i] , (ProDrawing)drawing);
				if(wcslen(noteRefMdl.c_str()) != 0)
				{
					if(first==true)
					{
						allMdlLst.append(noteRefMdl);
						first = false;
					}
					else
					{
						allMdlLst.append(L",").append(noteRefMdl);
					}
				}
			}	
			//Clear Notes
			GeometryFacadeFreeArray( (GeometryFacadeArray*)&notes );
		}
	}
	catch(ProeException ex)
	{
		LOG << "GetListOfDrawingRefModels_wrapper: Failed while getting drawing notes reference models"<< endl;
		throw ex;
	}

	return allMdlLst;
}

//B-05950: To get list of drawing view model view  names
static std::wstring GetDrawingViewModelNames_wrapper(std::wstring viewName)
{
	ProError result;
	std::wstring mdlNames=L"";
	try
	{
		bool first=true;

		//Get current drawing
		GeometryFacadeMdl drawing;
		GeometryFacadeGetCurrentMdl(&drawing);	

		//<TODO-Milind>find the way to init view handle.
		//result = ProModelitemByNameInit(pDrawing,PRO_VIEW,wViewName,(ProModelitem*)&pViewHandle);
		GeometryFacadeView *views;
		GeometryFacadeCollectDrawingViews((ProDrawing)drawing, &views);
		int iNoView = GeometryFacadeGetArraySize(views);

		for ( int i = 0 ; i<iNoView;i++)
		{
			ProName wViewName;
			ProDrawingViewNameGet((ProDrawing)drawing,views[i],wViewName);

			if (wcscmp(wViewName,viewName.c_str()) == 0)
			{
				//Get current drawing solid 
				ProSolid drwSolid;
				result = ProDrawingCurrentsolidGet((ProDrawing )drawing, &drwSolid);
				if(result==PRO_TK_NO_ERROR)
				{

					ProLine * viewNames;
					ProLine * altNames;
					int count;
					result = ProViewNamesGet(drwSolid, &viewNames, &altNames, &count);
					if(result==PRO_TK_NO_ERROR)
					{

						for (int j = 0; j < count; j++)
						{

							if(first==true)
							{
								mdlNames.append(viewNames[j]);
								first = false;
							}
							else
							{
								mdlNames.append(L",").append(viewNames[j]);
							}
						}	

						//Clear Arrays
						GeometryFacadeFreeArray( (GeometryFacadeArray*)&viewNames);
						GeometryFacadeFreeArray( (GeometryFacadeArray*)&altNames);
						
						break;
					}
				}
			}
		}
		
		//Free array
		GeometryFacadeFreeArray( (GeometryFacadeArray*)&views);
	}
	catch(ProeException ex)
	{
		LOG << "GetDrawingViewModelNames_wrapper: Failed while getting drawing view model view names"<< endl;
		throw ex;
	}

	return mdlNames;
}

//B-05950: To set drawing view model view name
void DrawingViewModelViewChange_wrapper(std::wstring viewName, std::wstring mdlViewName, std::wstring orientation, double xAngle, double yAngle)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeMdl pDrawing;
	ProName wViewName;
	ProView *views;
	ProPoint3d pViewLocation;
	ProSelection pSelRef;

	try
	{
		GeometryFacadeGetCurrentMdl(&pDrawing);	

		GeometryFacadeCollectDrawingViews((ProDrawing)pDrawing, &views);
		int iNoView = GeometryFacadeGetArraySize(views);

		for ( int i = 0 ; i<iNoView;i++)
		{
			ProDrawingViewNameGet((ProDrawing)pDrawing,views[i],wViewName);

			if (wcscmp(wViewName,viewName.c_str()) == 0)
			{

				GeometryFacadeSetDrawingViewMdlNameSet((ProDrawing)pDrawing,views[i], &mdlViewName[0], &orientation[0], xAngle, yAngle);
				result = ProDrawingViewRegenerate((ProDrawing)pDrawing,views[i]);
				break;
			}

		}
		//Free array
		GeometryFacadeFreeArray( (GeometryFacadeArray*)&views);
	}
	catch(ProeException ex)
	{
		LOG << "DrawingViewModelViewChange_wrapper: Failed while setting drawing view model view name"<< endl;
		throw ex;
	}
}

//B-05950: To get drawing view type
static std::wstring GetDrawingViewType_wrapper(std::wstring viewName)
{
	ProError result;
	std::wstring viewTypeName=L"";
	try
	{
		bool first=true;

		//Get current drawing
		GeometryFacadeMdl drawing;
		GeometryFacadeGetCurrentMdl(&drawing);

		//Collect views
		GeometryFacadeView *views;
		GeometryFacadeCollectDrawingViews((ProDrawing)drawing, &views);
		int iNoView = GeometryFacadeGetArraySize(views);

		for ( int i = 0 ; i<iNoView;i++)
		{
			ProName wViewName;
			ProDrawingViewNameGet((ProDrawing)drawing,views[i],wViewName);

			if (wcscmp(wViewName,viewName.c_str()) == 0)
			{
				//Get drawing view type
				ProViewType viewType;
				result = ProDrawingViewTypeGet((ProDrawing)drawing,views[i], &viewType);
				if(result == PRO_TK_NO_ERROR)
				{
					switch (viewType) 
					{
					case PRO_VIEW_GENERAL:
						viewTypeName = L"General";
						break;

					case PRO_VIEW_PROJECTION:
						viewTypeName = L"Projection";
						break;

					case PRO_VIEW_AUXILIARY:
						viewTypeName = L"Auxiliary";
						break;

					case PRO_VIEW_DETAIL:
						viewTypeName = L"Detail";
						break;

					case PRO_VIEW_REVOLVE:
						viewTypeName = L"Revolve";
						break;

					case PRO_VIEW_COPY_AND_ALIGN:
						viewTypeName = L"CopyandAlign";
						break;

					case PRO_VIEW_OF_FLAT_TYPE:
						viewTypeName = L"FlatType";
						break;

					default:
						viewTypeName = L"XXX";
						break;
					}

					break;
				}
			}
		}

		//Free array
		GeometryFacadeFreeArray( (GeometryFacadeArray*)&views);
	}
	catch(ProeException ex)
	{
		LOG << "GetDrawingViewType_wrapper: Failed while getting drawing view type"<< endl;
		throw ex;
	}
	
	return viewTypeName;
}

void DrawingModelDimensionDecimalPlaceChange_wrapper(int dimId,int decimal)
{
	GeometryFacadeMdl drawing;	
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;	
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		//Set drawing model dimension decimal places
		GeometryFacadeSetDimensionDecimalValue(&dimHandle,decimal);
	}
}

void DrawingModelDimensionUpperTolChange_wrapper(int dimId,double value)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		//Get 
		double upper=0.0, lower=0.0;
		GeometryFacadeGetDimensionToleranceValue(&dimHandle, &upper, &lower);
	
		//Set drawing model dimension upper Tolerance
		GeometryFacadeSetDimensionToleranceValue(&dimHandle, value, lower);
	}
}

void DrawingModelDimensionLowerTolChange_wrapper(int dimId,double value)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		//Get 
		double upper=0.0, lower=0.0;
		GeometryFacadeGetDimensionToleranceValue(&dimHandle, &upper, &lower);
	
		//Set drawing model dimension lower Tolerance
		GeometryFacadeSetDimensionToleranceValue(&dimHandle, upper, value);
	}
}

void DrawingModelDimensionToleranceDecimalPlaceChange_wrapper(int dimId,int decimal)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		//Set drawing model dimension tolerance decimal place
		GeometryFacadeSetDimensionToleranceDecimalValue(&dimHandle,decimal);
	}
}

void DrawingModelDimensionTableNameChange_wrapper(int dimId, std::wstring tableName)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		ProToleranceTable table;
		ProName temp;
		int column;

		GeometryFacadeGetDimensionTableNameColumnValue(&dimHandle, &table, temp, &column);

		//Set drawing model dimension Table name
		GeometryFacadeSetDimensionTableNameColumnValue(&dimHandle, table, const_cast<wchar_t*>(tableName.c_str()), column);
	}
}

void DrawingModelDimensionTableNameColumnChange_wrapper(int dimId, std::wstring tableName, int column)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		ProToleranceTable table;
		ProName temp;
		int tempColumn;

		GeometryFacadeGetDimensionTableNameColumnValue(&dimHandle, &table, temp, &tempColumn);

		//Set the drawing model dimension Table name and column
		GeometryFacadeSetDimensionTableNameColumnValue(&dimHandle, table, const_cast<wchar_t*>(tableName.c_str()), column);
	}
}

void DrawingModelDimensionTableColumnChange_wrapper(int dimId, int column)
{
	GeometryFacadeMdl drawing;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	GeometryFacadeDimension dimHandle;
	GeometryFacadeBoolean bIsShown;

	GeometryFacadeGetCurrentMdl(&drawing);
	GetDrawingSolids(dimId, drawing,&dimHandle);

	ProAnnotationIsShown(&dimHandle,(GeometryFacadeDrawing)drawing,&bIsShown);

	if (bIsShown)
	{
		ProToleranceTable table;
		ProName tableName;
		int temp;
		GeometryFacadeGetDimensionTableNameColumnValue(&dimHandle, &table, tableName, &temp);

		//Set drawing model dimension Table column
		GeometryFacadeSetDimensionTableNameColumnValue(&dimHandle, table, tableName, column);
	}
}
