#ifndef CONSTRAINTS_H
#define CONSTRAINTS_H


// C/C++ header files.
#include <string>
#include <sstream>
#include <map>
#include <vector> 

// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BuildConstraints_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError FixPosition_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ShowConstraints_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
void BuildConstraints_wrapper(wchar_t * xmlIn); 
void BuildFixPosConstraints_wrapper(wchar_t * xmlIn); 


// Private functions.
static void buildConstraint(wchar_t *xml, GeometryFacadeAsmCompPath *asmCompPath, GeometryFacadeAsmCompConstraint *asmCompConstraint);
static void fixPosition_wrapper(std::string idPath, double x, double y, double z); 
static GeometryFacadeAsmCompConstraintType getConstraintTypeFromString(char *typeString);
static GeometryFacadeAsmCompConstraintType getProConstraintType(char *typeString, char *reference1Type, char *reference2Type);
static GeometryFacadeType getProReferenceType(char *type); 
//commented line from VS 2003 modified for VS 2008
//static void getXMLAttributeValue(const char *xml, char *attribute, char *value); 
void getXMLAttributeValue(char *xml, char *attribute, char *value);
void getXMLAttributeValue(wchar_t *xml, wchar_t *attribute, wchar_t *value);
//commented line from VS 2003 modified for VS 2008
void getXMLValue(char *xml, char *value); 
void getXMLValue(wchar_t *xml, wchar_t *value);
static void showConstraints_wrapper(std::string idPath);
static void userAsmcompConstraintsHighlight(GeometryFacadeAsmComp *asmComp);
void ProcessPartNameText(std::wstring sInputText ,std::wstring delimeter, vector<std::wstring> &vNoteStr);
void GetModelIDString(GeometryFacadeMdl pContainerAsm,std::vector<std::wstring> vPrtNames,std::wstring &smdlIds);
void InitHandleOfStaticAssemblyFeature(std::wstring sRef,GeometryFacadeMdl mdl,wchar_t idpath[255],wchar_t refname[255],std::wstring &smdlIds);
double degree2radian(double degree);
#endif // CONSTRAINTS_H