#ifndef PROCESSXML_H
#define PROCESSXML_H


// C/C++ header files.
#include <string>
#include <sstream>
#include <map>
#include <ProFaminstance.h>

// Application header files.
#include "ProToolkitFacade.h"


#import <msxml6.dll> no_implementation raw_interfaces_only	// named_guids


// Macro that calls a COM method returning HRESULT value:
#define HRCALL(a, errmsg) \
{ \
    hr = (a); \
    if (FAILED(hr)) { \
        dprintf( "%s:%d  HRCALL Failed: %s\n  0x%.8x = %s\n", __FILE__, __LINE__, errmsg, hr, #a ); \
        throw hr; \
    } \
}


// Macro that calls a COM method returning HRESULT value:
#define TESTHR(a) \
{ \
    hr = (a); \
    if (FAILED(hr)) { \
        dprintf( "%s:%d  TESTHR Failed: %s\n  0x%.8x = %s\n", __FILE__, __LINE__, hr, #a ); \
        throw hr; \
    } \
}


// To change MSXML versions change this define. -rpm 
#define XML MSXML2


enum NodeNames 
{
	UNKNOWN = -1,
	MODEL,
	COMP,
	SUBCOMP,
	FEATURE,
	DIM,
	MATE,
	CONSTRAINT,
	CONSTRAINTS
};


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessXMLMessage_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
std::string XMLFeatureTagGet(GeometryFacadeFeature *feature, std::string sSuppressed,std::string &tag);
std::string XMLModelTagGet(GeometryFacadeMdl model, std::string &tag);


// Private functions.
static XML::IXMLDOMDocument3* domFromCOM();
static void dprintf(char *format, ...);
static NodeNames getNodeName(_bstr_t name);
static int getAttributeValueChar(XML::IXMLDOMElement *element, _bstr_t name, char *value);
static int getAttributeValueInt(XML::IXMLDOMElement *element, _bstr_t name, int *value); 
static int getAttributeValueDouble(XML::IXMLDOMElement *element, _bstr_t name, double *value); 
static int processCompNode(XML::IXMLDOMElement *element); 
static int processConstraintNode(XML::IXMLDOMElement *element); 
static int processConstraintsNode(XML::IXMLDOMElement *element); 
static int processFeatureNode(XML::IXMLDOMElement *element); 
static int processModelNode(XML::IXMLDOMElement *element); 
static int processNode(XML::IXMLDOMElement *element); 
static int processSubCompNode(XML::IXMLDOMElement *element); 
static char* processXMLMessage_wrapper(std::string xml);
int GetInstanceNumber(std::string filename);
void GetFamilyTableData(GeometryFacadeMdl theModel,std::string &sScanStr);
GeometryFacadeError VisitFamilyTableInstanceAction(ProFaminstance* instance,GeometryFacadeError status,ProAppData app_data);

#endif // PROCESSXML_H