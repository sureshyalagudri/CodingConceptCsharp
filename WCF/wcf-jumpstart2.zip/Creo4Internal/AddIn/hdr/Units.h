#ifndef UNITS_H
#define UNITS_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


// Public functions.
void DimensionUnitGet(GeometryFacadeDimension *tdimension, GeometryFacadeUnitItem *unit);
void GetUnitSystemXML(GeometryFacadeMdl *model, std::string &part);


#endif // UNITS_H
