#ifndef COMPONENTS_H
#define COMPONENTS_H


// C/C++ header files.
#include <string>

//ProToolkit headers
//#include <pd_prototype.h>

// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddComponentWithSuffix_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddSuffix_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DeleteComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ReplaceProEPartFile_task(GeometryFacadeArgument *inputArguments,GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CheckModifyingEntityExistInPart_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
int AddComponent_wrapper(std::string filePath, std::string ownerIdPath); 
void DeleteComponent_wrapper(std::string idPath); 


// Private functions.
static int addComponentWithSuffix_wrapper(std::string modelWithExtension, std::string suffix, std::string ownerIdPath);
static void retrieveComponent_wrapper(std::string path, GeometryFacadeMdl *model); 
int ReplaceProEPartFile_wrapper(std::string sCrntFleID,std::string sNewFleNm,std::string sIDath);
int CheckModifyingEntityExistInPart_wrapper(wchar_t *cPartEntityType , wchar_t *cPartEntityName , char *cIdPath);
int GetNewPartModelID(GeometryFacadeMdl pOwnerAsm,std::string sNewMdlName , int iFeatNumber);
bool CheckComponentForUDF(ProMdl owner,int feat_id,std::string idPath , GeometryFacadeMdl *pModel);
GeometryFacadeError NewMdlFeatureVisitAction(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData);

int CheckLayerExist(char *cIdPath);
int CheckParameterExist(wchar_t *cPartEntityName , char *cIdPath);
int CheckFamilyTableInstanceExist(wchar_t *cPartEntityName , char *cIdPath);
int CheckSketchTextExist(char *cIdPath);
int CheckDimensionExist(char *cIdPath);
int CheckPartEntityExist_ForCommon(char *cIdPath , GeometryFacadeType pEntityType);

#endif // COMPONENTS_H