#ifndef SCAN_H
#define SCAN_H


// C/C++ header files.
#include <string>
#include <hash_set>


// Application header files.
#include "ProToolkitFacade.h"
#include <ProUdf.h>


typedef struct all_solid_dims
{
	std::string *XMLstring_ptr;
	stdext::hash_set<int> dim;
	FILE* xmlFile;
	std::vector<std::string> compoScanned;
} all_solid_dims_t;


typedef struct 
{
   char *name;
   double value;
} ScanData; 


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ScanUDF_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CheckPartsReferencedInDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Private functions.
static void drawingParameters(GeometryFacadeDrawing drawing, std::string &output);
void CheckSketchText(GeometryFacadeFeature *theFeature_ptr,std::string &sTextTag);
static int drawingSheets(GeometryFacadeDrawing drawing, std::string &output,int sheet);
static GeometryFacadeError scanDimensionVisitAction(GeometryFacadeDimension *dimension, GeometryFacadeError status, GeometryFacadeAppData sppData);
static std::string scanDrawing_wrapper(string fileName, FILE * xmlFile);
static GeometryFacadeError scanFeatVisitAction(GeometryFacadeFeature *feature, GeometryFacadeError status, GeometryFacadeAppData appData);
static GeometryFacadeError scanUDFFeatFilterAction(GeometryFacadeFeature *feature,GeometryFacadeAppData appData);
static std::string scanModel_wrapper(string fileName, FILE * xmlFile);
static GeometryFacadeError scanParameterAction(GeometryFacadeParameter *parameter, GeometryFacadeError status, GeometryFacadeAppData appData);
static GeometryFacadeError userCollectAllDimensionsAction(GeometryFacadeDimension *dimension, GeometryFacadeError status, GeometryFacadeAppData sppData);
static GeometryFacadeError userDimensionVisitAction(GeometryFacadeDimension *dimension, GeometryFacadeError status, GeometryFacadeAppData appData);
void GetUDFPropertiesXML(GeometryFacadeMdl model, std::string &output);
ProError scanGroupVisitAction(ProGroup* pGroup,ProError result,ProAppData data);
ProError VisitGroupSubFeatures(ProFeature* pFeature,ProError result,ProAppData app_data);
ProGroupStatus CheckIsFeatureGroupMember(ProFeature* pFeats);
GeometryFacadeError ScanUDF_wrapper(char *cUDFPath,const char *cUDFPart, FILE * xmlFile);
void GetUDFXMLTag(char *cUDFPath,std::string &sScanData);
void GetUDFDimensionXML(GeometryFacadeUdfdata pUDFData,std::string &sScanData);
void GetUDFExternalSymbols(GeometryFacadeUdfdata pUDFData,std::string &sScanData);
void GetUDFReferenceXML(GeometryFacadeUdfdata pUDFData,std::string &sScanData);
void GetUDFFeaturesXML(GeometryFacadeUdfdata pUDFData,const char *cUDFPart, FILE * xmlFile);
std::string CheckIsFeatureSuppressed(ProFeature *feat);
string CheckPartsReferencedInDrawing_wrapper(string fileName);


#endif // SCAN_H