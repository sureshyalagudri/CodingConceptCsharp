#ifndef LAYERS_H
#define LAYERS_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError LayerDisplayStatusSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
void GetLayerPropertiesXML(GeometryFacadeMdl model, std::string &output);


// Private functions.
static void layerDisplayStatusSet_wrapper(int layerID, int status);
ProError ModelLayerVisitAction(ProLayer* pLayer,ProAppData pAppData);


#endif // LAYERS_H