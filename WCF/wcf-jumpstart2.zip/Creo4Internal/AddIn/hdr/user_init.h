#ifndef USERINIT_H
#define USERINIT_H

//added to find memory leaks
/*#ifdef _DEBUG
   #ifndef DBG_NEW
      #define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
      #define new DBG_NEW
   #endif
#endif */
// Application header files.
#include "ProToolkitFacade.h"


// Public functions.
extern "C"
{
	int user_initialize(int argc, char *argv[], char *version, char *build, GeometryFacadeWideChar *error);
	void user_terminate();
}


#endif // USERINIT_H
