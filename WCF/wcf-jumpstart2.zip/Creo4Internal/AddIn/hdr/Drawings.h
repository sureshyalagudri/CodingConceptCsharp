#ifndef DRAWINGS_H
#define DRAWINGS_H


// C/C++ header files.
#include <string>
#include <fstream>
#include <algorithm>



// Application header files.
#include "ProToolkitFacade.h"

//Protoolkit Header
#include <ProAnnotation.h>
#include <ProDrawingView.h>
#include <ProObjects.h>
//#include <pd_prototype.h>
#include <UtilMatrix.h>

// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError CreateProDrawing_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingCurrentSheetSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingRename_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingScaleSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingSheetRegenerate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewRegenerate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetTableCell_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingNoteTextSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewScaleSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingAnnotationDisplaySet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingDimensionLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewModelViewNameChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingNoteLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingViewSizeSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelAnnotationDisplaySet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionLocationChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingRenameFTInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddDrawingTable_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ReadDrawingProperties_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingMultipleSolidRename_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingCreateFromTemplate_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetListOfDrawingRefModels_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDrawingViewModelNames_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDrawingViewType_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionDecimalPlaceChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionUpperTolChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionLowerTolChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionToleranceDecimalPlaceChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableNameChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableNameColumnChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DrawingModelDimensionTableColumnChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);

}


// Private functions.
static void createProDrawing_wrapper(std::wstring newName, std::wstring drawingTemplateName);
int detailNoteInfo(GeometryFacadeDrawing drawing, std::string &output,int sheet); //removed static word
int detailSymbolInfo(GeometryFacadeDrawing drawing, std::string &output); //removed static word
int detailSymbolInsts(GeometryFacadeDrawing drawing, std::string &output); //removed static word
static void drawingCurrentSheetSet_wrapper(int sheet);
static void drawingRename_wrapper(std::wstring modelName, std::wstring tempName, std::wstring drawingName, std::wstring newDrawingName , int iDrwGeomChanged);
static void drawingScaleSet_wrapper(int sheet, double scale);
void drawingTables(GeometryFacadeDrawing drawing, std::string &output); //removed static word
static void drawingSheetRegenerate_wrapper();
static void drawingViewRegenerate_wrapper();
int drawingViews(GeometryFacadeDrawing drawing, map<int ,std::string> &mViewStr , bool bIsTempltSldUsed); //removed static word
int UsrTableTextAdd(ProDwgtable *table,int col,int row,wchar_t *text);
//static int userTableTextAdd(GeometryFacadeDrawingTable *table, int column, int row, char *text);
static void setTableCell_wrapper(int tableID, int raw, int column, std::wstring content, int &output);
static void userColorPrint(std::ostringstream &oss, GeometryFacadeColor color);
static int userListViews(GeometryFacadeDrawing drawing, std::string &output);
void drawingViewScaleSet_wrapper(std::wstring viewName, double scale);
ProError DrawingDimensionVisitAction(ProDimension* dimension,ProError status,ProAppData data);
void DrawingAnnotationDisplaySet_wrapper(int iAnnotId, std::wstring bAnnotDisplay,std::wstring sAnnotType);
void DrawingModelAnnotationDisplaySet_wrapper(int iAnnotId,std::wstring sAnnotDisplay);
void GetDrawingSolids(int iAnnotId,GeometryFacadeMdl pDrawing,ProDimension* pAnnotHandle);
void DrawingDimensionLocationChange_wrapper(int iDimId,double dDimLocation,std::wstring sMoveDir);
void DrawingViewLocationChange_wrapper(wchar_t *sViewName,double dDist,std::wstring sMoveDir);
std::string GetNoteLayerName(GeometryFacadeDrawing drawing,GeometryFacadeDetailNoteData note_data);
void GetDrawingVectorCoOrdinates(GeometryFacadeDrawing pDrawing,int iDrawingSheet,ProVector pInVector,ProVector pOutVector);
void GetDrawingPointCoOrdinates(GeometryFacadeDrawing pDrawing,int iDrawingSheet,GeometryFacadePoint3D pInVector,GeometryFacadePoint3D pOutVector);
//void GetScreenVectorCoOrdinates(Prohandle pDrawing,ProVector pInVector,ProVector pOutVector);
void DrawingNoteLocationChange_wrapper(int iNoteID,double dNoteLoc,std::wstring sMoveDir);
void DrawingViewSizeSet_wrapper(wchar_t *sViewName,double dViewSize,std::wstring sChangeDir);
void DrawingNoteTextSet_wrapper(int iNoteID,int iSheetID,std::wstring noteText);
void GetModelDimensionString(GeometryFacadeDrawing drawing,map<std::string ,std::string> &mMdlDimStr);
GeometryFacadeError SolidModelDimensionVisitAction(GeometryFacadeDimension *pDimension, GeometryFacadeError status, GeometryFacadeAppData pData); 
GeometryFacadeError SolidModelDimensionFilterAction(GeometryFacadeDimension *pDimension,GeometryFacadeAppData pData);
void GetDimensionType(ProDimension* pDimension,GeometryFacadeCharName cDimType);
void DrawingModelDimensionLocationChange_wrapper(int iAnnotId,double dDimLocation,std::wstring sMoveDir);
GeometryFacadeError DrawingRenameFTInstance_wrapper(std::wstring mdl_name, std::wstring tmp_name, std::wstring drw_name);
void ProcessNoteText(std::string sInputText ,std::string delimeter, vector<std::string> &vNoteStr);
void ProcessNoteText(std::wstring sInputText, std::wstring delimeter, vector<std::wstring> &vNoteStr);
std::wstring AddDrawingTable_wrapper(wchar_t *cTableInfo,int iSheet , wchar_t * iTableID);
std::wstring ReadDrawingProperties_wrapper(wchar_t* cDrwProperty, wchar_t* cDrwEntity);
void CheckAndRemoveDrawing(wchar_t * cWrkngDrwName,ProMdlType pMdlTp);
void VerifyDrawingSolidReferenced(std::wstring p_mdl_name,wchar_t *p_tmp_name, wchar_t *p_drw_name);
int LoadDrawingWithSolid(wchar_t *p_drw_name);
static void DrawingMultipleSolidRename_wrapper(std::wstring sPartCrntName,std::wstring sPartTemplateName,std::wstring sDrwName,std::wstring sDrwNewName);
GeometryFacadeMdl RenameCurrentModel(std::wstring sCrntModel,wchar_t *cMdlTemplName);
void RenameFamilyTableInstance(GeometryFacadeMdl pGnrcMdl, wchar_t *cInstanceCrntName, wchar_t *cInstanceTemplateName);
std::wstring GetModelReferencedInNote(GeometryFacadeDetailNote *p_note , GeometryFacadeDrawing drawing);
bool CheckIfFamilyTableInstance(GeometryFacadeMdl pWorkingMdl , wchar_t *cPartCrntName);
static void DrawingCreateFromTemplate_wrapper(std::wstring mdl_name, std::wstring drw_name, std::wstring NewDrwName);
bool GetTemplateDrawing(GeometryFacadeDrawing* drwtemplHandle , GeometryFacadeName wDrwTempNm);
void CleanSessionForExistingFiles(wchar_t* NewDrwName , ProMdlType pMdlType);
GeometryFacadeMdl CheckIsPreProcessingDone(std::wstring p_mdl_name , wchar_t *p_drwGeom , wchar_t *p_drw_name , wchar_t *p_new_drw_name);
static std::wstring GetListOfDrawingRefModels_wrapper();
static std::wstring GetDrawingViewModelNames_wrapper(std::wstring viewName);
bool GetCurrentModelViewName(ProDrawing drawing, ProView view, ProCharName name);
bool CompareMatrix(ProMatrix Metrix1,ProMatrix Metrix2);
void MatrixNormalize(ProMatrix m);
void DrawingViewModelViewChange_wrapper(std::wstring viewName, std::wstring mdlViewName, std::wstring orientation, double xAngle, double yAngle);
static std::wstring GetDrawingViewType_wrapper(std::wstring viewName);
void GetToleranceType(ProDimToleranceType tolType, GeometryFacadeCharName tolTypeChar);
void GetToleranceTable(ProToleranceTable tolTable, GeometryFacadeCharName tolTableChar);
void DrawingModelDimensionDecimalPlaceChange_wrapper(int annotId,int decimal);
void DrawingModelDimensionUpperTolChange_wrapper(int annotId,double decimal);
void DrawingModelDimensionLowerTolChange_wrapper(int annotId,double decimal);
void DrawingModelDimensionToleranceDecimalPlaceChange_wrapper(int annotId,int decimal);
void DrawingModelDimensionTableNameChange_wrapper(int annotId,std::wstring tableName);
void DrawingModelDimensionTableColumnChange_wrapper(int annotId,int column);
void DrawingModelDimensionTableNameColumnChange_wrapper(int dimId, std::wstring tableName, int column);
#endif // DRAWINGS_H
