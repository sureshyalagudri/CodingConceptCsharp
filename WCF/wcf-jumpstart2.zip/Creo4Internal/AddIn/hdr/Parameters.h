#ifndef PARAMETERS_H
#define PARAMETERS_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetDoubleParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetIntParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetBoolParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetStringParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetDoubleParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetIntParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetStringParameter_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetParameterValue_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
double getDoubleParameter_wrapper(std::wstring parameterName);
int getIntParameter_wrapper(std::wstring parameterName);
std::wstring getStringParameter_wrapper(std::wstring parameterName);
void setDoubleParameter_wrapper(std::wstring parameterName, std::string sModelID, double value);
void setIntParameter_wrapper(std::wstring parameterName, std::string sModelID, int value);
void setStringParameter_wrapper(std::wstring parameterName, std::string sModelID, std::wstring value);
void setBoolParameter_wrapper(std::wstring parameterName, std::string sModelID, int value);
std::wstring GetParameterValue_wrapper(std::string sModelID, std::wstring parameterName);


#endif // PARAMETERS_H