#ifndef DIMENSIONS_H
#define DIMENSIONS_H


// Application header files.
#include "ProToolkitFacade.h"


typedef struct 
{
	wchar_t *name;
	double value;
} DimensionData; 


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionGetValue_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionGetValueByIdPath_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionSetByName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DimensionSetValueByIdPath_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
void DimensionSetValueByIdPath_wrapper(std::string idPath, double valueIn); 


// Private functions.
static double dimensionGetValue_wrapper(std::string idPath);
static wchar_t* dimensionGetValueByIdPath_wrapper(std::string idPath); 
static void dimensionSetByName_wrapper(std::wstring name, double value); 
static GeometryFacadeError dimensionSetFilterAction(GeometryFacadeDimension *dimension, GeometryFacadeAppData appData); 
static GeometryFacadeError dimensionSetVisitAction(GeometryFacadeDimension *dimension, GeometryFacadeError filterStatus, GeometryFacadeAppData appData); 


#endif // DIMENSIONS_H