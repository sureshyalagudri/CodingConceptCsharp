#ifndef MASSPROPERTIES_H
#define MASSPROPERTIES_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetMassProperties_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetMassProperty_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
void GetMassPropertiesXML(GeometryFacadeMdl *model, std::string &massProperties);


// Private functions.
static void getMassProperties_wrapper(std::string idPath);
static wchar_t* getMassProperty_wrapper(std::string idPath, std::wstring massProperty);
static void logMassProperties(GeometryFacadeMassProperty *massProperty);


#endif // MASSPROPERTIES_H