#ifndef MODELS_H
#define MODELS_H


// C/C++ header files.
#include <string>
#include <vector>
#include <ProFamtable.h>
#include <ProFaminstance.h>
//<Replaced>#include <pd_prototype.h>
#include <ProAssembly.h>
#include <ProPDF.h>
#include <ProIntf3Dexport.h>

// Application header files.
#include "ProToolkitFacade.h"
#include "Constraints.h"
#include "Log.h"
#include "Drawings.h"
#include "Components.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BackupModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError EraseCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError LoadModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameAssemblyComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RegenerateCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RepaintCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ClearProeWindow_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RegenerateAssemblyFile_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
//	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RetrieveModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SaveModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ZoomAllCurrentModel_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError AddUDF_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError UDFDimensionValueSet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ExportFileTypes_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessFamilyTableInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessDocumentName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError RenameFamilyTableInstance_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError BackupModelToWIP_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ProcessDocumentNameForStaticAsmComponent_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetListOfModelsInSession_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetModelNameByID_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SaveModelByID_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError EraseModelByName_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.
int AddSuffix_wrapper(std::string modelWithExtension, std::string suffix);
int GetMdlNameTypeFromString_wrapper(std::string modelName1, std::string &modelName2, std::string &modelType);
GeometryFacadeMdl LoadModel_wrapper(const std::string &fileName);
void RegenerateCurrentModel_wrapper();
int UserModelLoad_wrapper(char *name, GeometryFacadeMdl *loadedPart, int displayModel = 1); // Default is to display model.
int UserModelLoad_wrapper(wchar_t *name, GeometryFacadeMdl *loadedPart, int displayModel = 1); // Default is to display model.
void ZoomAllCurrentModel_wrapper();


// Private functions.
static GeometryFacadeError addSuffixVisitAction(GeometryFacadeFeature *feature, GeometryFacadeError status, GeometryFacadeAppData appData);
//static void backupModel_wrapper(std::string pathName);
static void backupModel_wrapper(std::string sReleaseFolderPath , std::string sGeometryFileName , std::string sDrawingFileName,std::string sGeomReleaseFileName , std::string sDrwReleaseFileName , std::string sAsmChildId , std::string sAsmChildRelName); 
static void BackupModelToWIP_wrapper(std::string sWIPFolderPath,std::string sGeometryFileRelName , std::string sGeomFileWIPName , std::string  sDrawingFileName, std::string sDrwReleaseFileName , std::string sAsmChildId , std::string sAsmChildWrkngName);
static void eraseCurrentModel_wrapper(); 
//static int loadModel_wrapper(std::string partName, int display);
static void renameModel_wrapper(std::string idPath, std::string newName);
static void repaintCurrentModel_wrapper();
static void saveModel_wrapper(); 

GeometryFacadeMdl LoadDisplayModel(const std::string &theFileName);
GeometryFacadeError RenameAssemblyComponent_wrapper(GeometryFacadeMdl mdlHandle , int iIsRSStandard);
GeometryFacadeError FeatureVisitAction(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData);
GeometryFacadeError FeatureFilterAction(GeometryFacadeFeature* feature,GeometryFacadeAppData appData);
int AddUDF_wrapper(wchar_t *sXMLRef, wchar_t *sUDFFile);
void UDFDimensionValueSet_wrapper(char *cID,char *cDimName,double dDimValue);
void clearComplist();
void IsCompFamilyTableInstance(GeometryFacadeMdl mdl);
void ExportFileTypes_Wrapper(char *cDrwFile,char *cDrwExptType,char *cMdlFile,char *cMdlExptType,char *cRelaseDirPath,char *cExportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported);
void ExportDrawingFile(std::vector<std::string> vDrwExptTp,char *cRelaseDirPath,char *ExportFileName, char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported);
void ExportModelFile(std::vector<std::string> vMdlExptTp,char *cRelaseDirPath,char *cExportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree, std::string &cTypeNotExported);
bool ExportTifFile(char *cRelaseDirPath,char *cExportFileName,char* exportFactOne, char* exportFactTwo, char* exportFactThree);
int CheckIsPlotType(const char *sType);
ProProductviewFormat GetPlotFormat(const char *cDrwExptTp);
ProImportExportFile GetDrwExportFileType(const char *cDrwExptTp);
ProIntf3DExportType Get3DExportType(const char *cMdlExptTp);
ProOutputAssemblyConfiguration GetConfigurationForExportType(const char *cMdlExptTp);
int ProcessFamilyTableInstance_wrapper(char *cInstanceName,std::string cIDPath);
int ProcessFamilyTableInstance(char *cInstanceName,int *iMdlId,GeometryFacadeMdl pGnrcMdl,GeometryFacadeMdl pOwnerAsm);
int CheckInstanceWithCurrentPart(GeometryFacadeMdl pModel,char *cInstanceName);
int CheckInstanceForGeneric(GeometryFacadeMdl pModel,char *cInstanceName);
int ProcessFamilyTableInstanceOfRoot(char *cInstanceName,GeometryFacadeMdl pRootMdl);
int ProcessDocumentName_wrapper(string sOwnerId,char *cDocumentName);
bool CheckParameterExist(GeometryFacadeModelItem pInstMdlItm,const char *CParmName,char *cInstName,char *cInstNewNm);
void SetNewValueForParamater(GeometryFacadeParameter pParamObj,GeometryFacadeParameterValue *pParamVal,char *cParamVal);
void EarseModelInSession(char *cDocumentName,GeometryFacadeMdlType pMdlTp);
void RenameFamilyTableInstance_wrapper(char *cInstCrntNm,char *cInstNewNm,char *cGnrcPath);
std::string GetValidParameterName(std::string cInstCrntNm);
void CheckAndPerformStaticAsmChildRenaming(std::string sGeomFileName , GeometryFacadeMdl pParentAsmHandle , std::string sAsmChildId , std::string sAsmChildRelName , bool bIsToWorking = false);
void RenameStaticAssemblyCompnent(std::string sOwnerId , GeometryFacadeMdl pOwnerHndl , char *cDocumentName);
void GetAllAssemblyChildrens(std::string sStaticId);
int ProcessDocumentNameForStaticAsmComponent_wrapper(std::string sStaticAsmId , std::string sComponentId , char* cDocumentName);
void GetAllComponentNameOfStaticAssembly(GeometryFacadeMdl pStaticAsm , std::string sCompToRename , bool bIncludeSubAsm);
GeometryFacadeError CollectAllAsmCompName(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData);
GeometryFacadeError CollectSingleLevelCompName(GeometryFacadeFeature *feature,GeometryFacadeError result,GeometryFacadeAppData appData);
GeometryFacadeError CollectComponentInstanceId(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData);
void AddComponentInstanceIntoList(GeometryFacadeFeature *feature , std::string *sCompToRename , bool bIncludeSubAsm);
GeometryFacadeMdl GetPartToReplace(GeometryFacadeMdl pCompToRename , char *cDocumentName);
int PerformComponentReplacement(GeometryFacadeMdl pContainerAsm , GeometryFacadeMdl pPartToReplace , std::string sCompCompletePath , std::string sStaticId , char *NewComponentName);
void CollectAllInstanceId(GeometryFacadeMdl pContainerAsm , char* CompCrntName);
void ReConstrainReplacedComponent(GeometryFacadeMdl pContainerAsm , std::string sCompCompletePath , std::string sStaticId , GeometryFacadeAsmCompConstraint *pAsmConstr);
std::string GetCompCurrentIdPath(GeometryFacadeAsmCompPath pAsmCompPath , std::string sStaticId);
void UpdateAndStoreNewComponentId(std::string sCompOldId ,int iCompId , GeometryFacadeMdl pParentAsmHandle);
std::string GetNewChildIdValue(GeometryFacadeMdl pParentAsmHandle , std::string sCompOldId);
void GetParameterName(std::string sCompId , GeometryFacadeWideChar *wstr);
static std::string GetListOfModelsInSession_wrapper();
std::string GetListOfModel(GeometryFacadeMdlType pMdlType);
void DeleteParameter(GeometryFacadeMdl pParentAsmHandle , const char *cChildId);
static std::wstring GetModelNameByID_wrapper(std::string idPath);
static void SaveModelByID_wrapper(std::string idPath);
#endif // MODELS_H
