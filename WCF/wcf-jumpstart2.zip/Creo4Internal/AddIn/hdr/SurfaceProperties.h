#ifndef SURFACEPROPERTIES_H
#define SURFACEPROPERTIES_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	// Ambient Light functions.
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetAmbientLight_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetAmbientLight_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);

	// Color functions.
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetColor_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetColor_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);

	// Shininess functions.
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetShininess_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetShininess_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);

	// Transparency functions.
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError GetTransparency_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetTransparency_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Public functions.

// Color functions.
void GetModelColor(GeometryFacadeMdl model, std::wstring &color);

// Misc. functions.
void GetSurfaceProperties(GeometryFacadeMdl &model, GeometryFacadeSurfaceProperties &properties);
void GetSurfaceProperties(std::string idPath, GeometryFacadeSurfaceProperties &properties);
void GetSurfacePropertiesXML(GeometryFacadeMdl &model, std::string &surfaceProperties);
void SetSurfaceProperties(GeometryFacadeMdl &model, int type, int id, int surfaceSide, GeometryFacadeSurfaceProperties *properties);


// Private functions.

// Shininess functions.
static std::wstring getAmbientLight_wrapper(std::string idPath);
static void setAmbientLight_wrapper(std::string idPath, double ambientLight);

// Color functions.
static void createGeometryFacadeColorMap(std::wstring colorString, GeometryFacadeColorMap *colormap);
static std::wstring getColor_wrapper(std::string idPath);
static void setColor_wrapper(std::string idPath, std::wstring color);

// Shininess functions.
static std::wstring getShininess_wrapper(std::string idPath);
static void setShininess_wrapper(std::string idPath, double shininess);

// Transparency functions.
static double getTransparency_wrapper(std::string idPath);
static void setTransparency_wrapper(std::string idPath, double transparency);
static void UpdateModelAppearance(GeometryFacadeAsmItem &asmItem, GeometryFacadeAsmCompPath path, int id, GeometryFacadeMdl model, GeometryFacadeSurfaceProperties &properties);


#endif // SURFACEPROPERTIES_H