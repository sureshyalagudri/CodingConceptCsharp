#ifndef UTILITIES_H
#define UTILITIES_H


// C/C++ header files.
#include <string>


// Application header files.
#include "ProToolkitFacade.h"


#define DECLARE_MSGIFILE static GeometryFacadeName msg_file;
#define MSGFILE GeometryFacadeStringToWideString(msg_file, "msg_addin.txt")


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DirectoryChange_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError DirectoryCurrentGet_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError OutputMessage_task(GeometryFacadeArgument *inputs, GeometryFacadeArgument **outputs);
}


// Private functions.
static void directoryChange_wrapper(std::wstring absolutePath);
static wchar_t* directoryCurrentGet_wrapper();
static std::string outputMessage_wrapper(std::string message);


#endif // UTILITIES_H