#ifndef FEATURES_H
#define FEATURES_H


// C/C++ header files.
#include <string>
#include <ProSecdim.h>


// Application header files.
#include "ProToolkitFacade.h"
#include <vector>


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError HideFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ResumeFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetFeatureDisplayStatus_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError ShowFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SuppressFeature_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetSketchText_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError SetUDFFeatureStatus_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


//component Data container for visit function
struct ComponentData
{
	bool found;
	int compid;
	ProCharName compName;
	std::vector<std::string> compNameContainer;
};

// Private functions.
static void hideFeature_wrapper(std::string idPath);
static void resumeFeature_wrapper(std::string idPath, std::wstring staticFile);
static void setFeatureDisplayStatus_wrapper(int featureID, int statusFlag, int &output);
static void showFeature_wrapper(std::string idPath);
static void suppressFeature_wrapper(std::string idPath, std::wstring staticFile);
void SetSketchText_wrapper(std::string sFeatId,std::wstring sNewText);
GeometryFacadeError SetTextValue(GeometryFacadeFeature pFeature,std::wstring iSectId);
std::wstring SetUDFFeatureStatus_Wrapper(char *cFeatID, wchar_t *cFeat, wchar_t *cStatus);
bool GetAlternateOwnerPath(GeometryFacadeAsmCompPath path, GeometryFacadeAsmCompPath & new_path);
GeometryFacadeError CollectComponentInstanceNamebyID(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData);
void CollectAllComponentsId(GeometryFacadeMdl pContainerAsm , ComponentData &objCompData);
GeometryFacadeError CollectComponentInstanceNamebyID(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData);
GeometryFacadeError ComponentFilterAction(GeometryFacadeFeature* feature,GeometryFacadeAppData appData);
GeometryFacadeError CollectComponentsbyId(GeometryFacadeFeature *feature , GeometryFacadeError result,GeometryFacadeAppData appData);


#endif // FEATURES_H