#ifndef WINDOW_H
#define WINDOW_H


// Application header files.
#include "ProToolkitFacade.h"


// Exported functions.
extern "C"
{
	GEOMETRY_FACADE_DLL_EXPORT GeometryFacadeError WindowCurrentClose_task(GeometryFacadeArgument *inputArguments, GeometryFacadeArgument **outputArguments);
}


// Private functions.
static void windowCurrentClose_wrapper();


#endif // WINDOW_H