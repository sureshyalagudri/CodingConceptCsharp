﻿/*=============================================================================
                     Copyright (c) 2013 Siemens PLM Software
                       Unpublished - All rights reserved
===============================================================================
File(description) : Client.cs
Client class communicating between CreoWrapper and Integration Driver.  
===============================================================================
Date                  Name                    Description of Change
12-Jan-2013          gd3adf                   Updated to Creo 3.0
23-Aug-2018          Pranjali                 Updated to Creo 4.0

  
$HISTORY$
'===========================================================================‘*/

using System;
using System.Globalization;
using System.Reflection;
using System.Runtime.InteropServices;
using ProEngineerDriver;

namespace Creo4Internal
{
    public class Client : IDriverImpl
    {
        #region Creo4Wrapper DLL Import

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetModelCurrentName", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getmodelcurrentname(string iIdpath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "CheckModifyingEntityExistInPart", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int checkmodifyingentityexistInpart(string sEntityType, string sEntityName, string sIdPath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetCurrentSessionConnectionId", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr getcurrentsessionconnectionId(int iProcessId);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetListOfModelsInSession", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getsessioncomponentlist();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetListOfDrawingRefModels", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getdrwnoterefmodelslist();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetDrawingViewModelNames", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getDrwViewModelNames(string viewName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetDrawingViewType", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getDrwViewType(string viewName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ProcessDocumentNameForStaticAsmComponent", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int processdocumentnameforstaticasmcomponent(string sStaticIdPath, string sCompIdPath , string sDocumentName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetParameterValue", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getparametervalue(string sIdPath , string sParamName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "RegenerateSelectedPart", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void regenerateselectedpart(string sIdPath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "IntegrationCurrentModeGet", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr integrationcurrentmodeget();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "RenameModel", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void renamemodel(string sIdPath, string sNewName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ScanUDF", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr scanUDF(string sUDFPath, string uUDFPart, string xmlFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "AddUDF", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int addudf(string sXmlRef, string sUDFFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "UDFDimensionValueSet", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void UDFdimensionvalueset(string sId, string sDimName, double dDimValue);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "setUDFfeaturestatus", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr setUDFfeaturestatus(string sFeatPath, string sFeat, string sStatus);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "exportfiletypes", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr exportfiletypes(string sDrwExptType, string sMdlExptType, string sRelaseDirPath,
                                                     string sDrwFile, string sMdlFile,string ExportFileName, string sExportFactorOne, string sExportFactorTwo, string sExportFactorThree);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "AddComponentWithSuffix", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode
            )]
        private static extern int addComponentWithSuffix(string modelName, string suffix, string ownerIdPath);

        //Assembly rename function
        [DllImport("Creo4Wrapper.dll", EntryPoint = "RenameAssemblyComponent",
            CallingConvention = CallingConvention.Cdecl)]
        private static extern void renameassemblycomponent(string suffix, string workingFolder, int IsRSStandard);

        //Assembly clear function
        [DllImport("Creo4Wrapper.dll", EntryPoint = "ClearProeWindow", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr clearproewindow(int i);

        //Assembly rename function
        [DllImport("Creo4Wrapper.dll", EntryPoint = "RegenerateAssemblyFile", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode
            )]
        private static extern void regenerateassemblyfile(string asmHandle);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ProcessFamilyTableInstance",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int processfamilytableinstance(string sInstanceName, string sInstIdPath);

        //RenameFamilyTableInstance
        [DllImport("Creo4Wrapper.dll", EntryPoint = "RenameFamilyTableInstance",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int renamefamilytableinstance(string sInstCrntNm, string sInstNewNm, string sIdPath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DeleteComponent", CallingConvention = CallingConvention.Cdecl)]
        private static extern void deleteComponent(string idPath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ReplaceProEPartFile", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int replaceproepartfile(string sCrntFlId, string sNewFlNm, string sPathId);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ProcessDocumentName", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int processdocumentname(string sOwnerId, string sDocumentName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "PreProcessDocumentName", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int preprocessdocumentname(string sExistingFile, string sMdlType, string sEarlierName);

        // Constraint functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "BuildConstraints", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void buildConstraints(string xml);

        // Dimension functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DimensionGetValue", CallingConvention = CallingConvention.Cdecl)]
        private static extern double dimensionGetValue(string path);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DimensionSetValueByIdPath", CallingConvention = CallingConvention.Cdecl)]
        private static extern void dimensionSetValueByIdPath(string path, double value);

        // Drawing functions.
        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingCreateFromTemplate", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingcreatefromtemplate(string partName, string drawingToRename, string newDrawingName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingScaleSet", CallingConvention = CallingConvention.Cdecl)]
        private static extern void drawingScaleSet(int sheet, double value);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingNoteTextSet", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingnotetextset(string noteId, string sheetId, string noteText);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingViewScaleSet", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingviewscaleset(string viewName, double viewScale);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingRename", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingRename(string partName, string templatePartName, string drawingToRename,
                                                 string newDrawingName, int iDrwGeomChanged);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingMultipleSolidRename",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingmultiplesolidrename(string partName, string templatePartName,
                                                              string drawingToRename, string newDrawingName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingSheetRegenerate", CallingConvention = CallingConvention.Cdecl
            )]
        private static extern void drawingSheetRegenerate();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ScanDrawing", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr scanDrawing(string fileName, string xmlFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "CheckPartsReferencedInDrawing",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr checkpartsreferencedindrawing(string fileName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingAnnotationDisplaySet",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingannotationdisplayset(int iAnnotId, string sAnnotStatus, string sAnnotType);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelAnnotationDisplaySet",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingmodelannotationdisplayset(int iAnnotId, string sAnnotStatus);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingDimensionLocationChange",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingdimensionlocationchange(int iDimId, double dDimDist, string sMoveDirection);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionLocationChange",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingmodeldimensionlocationchange(int iDimId, double dDimDist,
                                                                       string sMoveDirection);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionDecimalPlaceChange", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DrwModelDimensionDecimalPlaceChange(int iDimId, int dimDecimal);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionUpperTolChange", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DrwModelDimensionUpperTolChange(int iDimId, double upper);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionLowerTolChange", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DrwModelDimensionLowerTolChange(int iDimId, double lower);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionToleranceDecimalPlaceChange", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DrwModelDimensionToleranceDecimalPlaceChange(int iDimId, int dimDecimal);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionTableNameColumnChange", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void DrwModelDimensionTableNameColumnChange(int dimId, string tableName, int column);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionTableNameChange", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void DrwModelDimensionTableNameChange(int iDimId, string tableName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingModelDimensionTableColumnChange", CallingConvention = CallingConvention.Cdecl)]
        private static extern void DrwModelDimensionTableColumnChange(int iDimId, int column);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingViewLocationChange",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingviewlocationchange(string sViewName, double dMoveDist, string sMoveDirection);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingViewModelViewChange", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drwViewModelViewChange(string viewName, string mdlViewName, string orientation, double xAngle, double yAngle);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingNoteLocationChange",
            CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingnotelocationchange(int iNoteId, double dMoveDist, string sMoveDirection);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DrawingViewSizeSet", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void drawingviewsizeset(string sViewName, double dViewSize, string sChangeDir);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "AddDrawingTable", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr adddrawingtable(string iTableInfo, int iSheet, string sTableId);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ReadDrawingProperties", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)
        ]
        private static extern IntPtr readdrawingproperties(string sDrwProperty, string sDrwEntity);

        // Engineer functions.

        // Use the C++ mangled name here so we can get exceptions. 32 and 64 have same mangled name
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?ConnectToEngineer@@YAHH@Z",
            CallingConvention = CallingConvention.Cdecl)]
        private static extern int connectToEngineer(int proEngineerProcessId);

        // 64Bit = "?LoadDll@@YAXHPEBDQEBD1W4ProBooleans@@@Z" 32Bit = "?LoadDll@@YAXHPBDQBD1W4ProBooleans@@@Z"
#if BUILD64BIT
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?LoadDll@@YAXHPEBDQEBD1W4ProBooleans@@@Z", CallingConvention = CallingConvention.Cdecl)]
#else
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?LoadDll@@YAXHPBDQBD1W4ProBooleans@@@Z",
            CallingConvention = CallingConvention.Cdecl)]
#endif
        private static extern void loadDll(int proEngineerHandle, string dllName, string execFile, string textDir,
                                           bool userDisplay);

        // Use the C++ mangled name here so we can get exceptions.
        // 64bit = "?StartEngineer@@YAHPEBDQEAPEBD0H@Z" 32bit = "?StartEngineer@@YAHPBDQAPBD0H@Z"
#if BUILD64BIT
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?StartEngineer@@YAHPEBDQEAPEBD0H@Z", CallingConvention = CallingConvention.Cdecl)]
#else
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?StartEngineer@@YAHPBDQAPBD0H@Z",
            CallingConvention = CallingConvention.Cdecl)]
#endif
        private static extern int startEngineer(string proePath, string[] arguments, string prodevTextPath,
                                                int proeStartTimeout);

        // Use the C++ mangled name here so we can get exceptions. 32 and 64 have same mangled name
        [DllImport("Creo4Wrapper.dll", EntryPoint = "?StopEngineer@@YAXH@Z", CallingConvention = CallingConvention.Cdecl)
        ]
        private static extern void stopEngineer(int proEngineerHandle);


        [DllImport("Creo4Wrapper.dll", EntryPoint = "EraseAll", CallingConvention = CallingConvention.Cdecl)]
        private static extern void eraseall();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "CloseCurrentDrawing", CallingConvention = CallingConvention.Cdecl)]
        private static extern void closecurrentdrawing();

        // Feature functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ResumeFeature", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void resumeFeature(string theIdPath, string staticFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SuppressFeature", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void suppressFeature(string theIdPath, string staticFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetSketchText", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setsketchtext(string sIdPath, string sNewText);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ShowFeature", CallingConvention = CallingConvention.Cdecl)]
        private static extern void showfeature(string sIdPath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "HideFeature", CallingConvention = CallingConvention.Cdecl)]
        private static extern void hidefeature(string sIdPath);

        // Layer functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "LayerDisplayStatusSet", CallingConvention = CallingConvention.Cdecl)
        ]
        private static extern void layerDisplayStatusSet(int layerId, int status);

        // Mass property functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetMassProperty", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getMassProperty(string idPath, string property);

        // Misc. functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "AddSession", CallingConvention = CallingConvention.Cdecl)]
        private static extern void addSession(int proEngineerHandle, int appPid, string appName, int proEngineerPid,
                                              string proEngineerName);

        //[DllImport("Creo4Wrapper.dll", EntryPoint = "GetAddInErrorInfo", CallingConvention = CallingConvention.Cdecl)]
        //private static extern IntPtr getAddInErrorInfo();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetSessionTable", CallingConvention = CallingConvention.Cdecl)]
        private static extern void getSessionTable(ref int sessionTableIndex, ref IntPtr appPidTablePtr,
                                                   ref IntPtr appNameTablePtr, ref IntPtr proEngineerPidTablePtr,
                                                   ref IntPtr proEngineerNameTablePtr, ref IntPtr proEngineerHiddenTable,
                                                   ref IntPtr proEngineerStartedOrConnectedTable);

        //[DllImport("Creo4Wrapper.dll", EntryPoint = "GetWrapperErrorInfo", CallingConvention = CallingConvention.Cdecl)]
        //private static extern IntPtr getWrapperErrorInfo();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "Initialize", CallingConvention = CallingConvention.Cdecl)]
        private static extern void initialize(string iniFile, string version);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "Log", CallingConvention = CallingConvention.Cdecl)]
        private static extern IntPtr log(string message);

        // Model functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "BackupModel", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void backupModel(string pathName, string geometryName, string geomReleaseName, string drawingName, string drwReleaseName, string AsmChildIdPath, string AsmChildRelName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "BackupModelToWIP", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void backupModelToWIP(string WIPPath, string geometryRelName, string geomWIPName, string drawingName, string drwReleaseName, string AsmChildIdPath, string AsmChildWrkngName);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "EraseCurrentModel", CallingConvention = CallingConvention.Cdecl)]
        private static extern void eraseCurrentModel();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "LoadModel", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern int loadModel(string filename);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "RegenerateCurrentModel", CallingConvention = CallingConvention.Cdecl
            )]
        private static extern void regenerateCurrentModel();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "RepaintCurrentModel", CallingConvention = CallingConvention.Cdecl)]
        private static extern void repaintCurrentModel();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SaveModel", CallingConvention = CallingConvention.Cdecl)]
        private static extern void saveModel();

        [DllImport("Creo4Wrapper.dll", EntryPoint = "ScanModel", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr scanModel(string fileName, string xmlFile);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetDoubleParameter", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setDoubleParameter(string parameterName, string sModelId, double value);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetIntParameter", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setIntParameter(string parameterName, string sModelId, int value);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetBoolParameter", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setBoolParameter(string parameterName, string sModelId, int value);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetStringParameter", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setStringParameter(string parameterName, string sModelId, string value);

        // Surface property functions.

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetAmbientLight", CallingConvention = CallingConvention.Cdecl)]
        private static extern void setAmbientLight(string idPath, double ambientLight);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetColor", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void setColor(string idPath, string color);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetShininess", CallingConvention = CallingConvention.Cdecl)]
        private static extern void setShininess(string idPath, double shininess);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SetTransparency", CallingConvention = CallingConvention.Cdecl)]
        private static extern void setTransparency(string idPath, double transparency);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "DirectoryChange", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void directoryChange(string absoultePath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "GetModelNameByID", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr getmodelnamebyid(string iIdpath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "SaveModelByID", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern IntPtr saveModelbyId(string iIdpath);

        [DllImport("Creo4Wrapper.dll", EntryPoint = "EraseModelByName", CallingConvention = CallingConvention.Cdecl, CharSet = CharSet.Unicode)]
        private static extern void erasemodelbyname(string modelName);
        #endregion

        /*============================= Interface Implementation ================================*/

        public Client()
        {
            try
            {
                string[] version = Assembly.GetExecutingAssembly().GetName().Version.ToString().Split('.');

                // Get the version numbers.
                string major = version[0];
                string minor = version[1];
                string revision = version[2];

                // This is used to pass along any info in .NET to C++.
                string versionStr = major + "." + minor + "." + revision;
                string niFile = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData) +
                                @"\RuleStream\" + major + "." + minor + "." + revision + @"\RuleStream.ini";

                initialize(niFile, versionStr);
            }
            catch (Exception)
            {
                throw new Exception();
            }
        }

        public int StartEngineer(string proePath, string[] arguments, string prodevTextPath, int proeStartTimeout)
        {
            int iProeHandle;
            try
            {
                iProeHandle = startEngineer(proePath, arguments, prodevTextPath, proeStartTimeout);
            }
            catch (Exception)
            {
                throw new Exception("StartEngineer: Outer exception caught for Inputs ProePath : " + proePath +
                                    " TextPath : " + prodevTextPath + " TimeOut : " +
                                    proeStartTimeout.ToString(CultureInfo.InvariantCulture));
            }
            return iProeHandle;
        }


        public int ConnectToEngineer(int proeProcessId)
        {
            int connectOutput;
            try
            {
                connectOutput = connectToEngineer(proeProcessId);
            }
            catch (Exception)
            {
                throw new Exception("ConnectToEngineer: Outer exception caught for Inputs ProcessID : " +
                                    proeProcessId.ToString(CultureInfo.InvariantCulture));
            }
            return connectOutput;
        }

        public void StopEngineer(int proEngineerHandle)
        {
            try
            {
                stopEngineer(proEngineerHandle);
            }
            catch (Exception)
            {
                throw new Exception("StopEngineer: Outer exception caught for Inputs ProEngineer Handle : " +
                                    proEngineerHandle.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void LoadDll(int proEngineerHandle, string dllName, string execFile, string textDir, bool userDisplay)
        {
            try
            {
                loadDll(proEngineerHandle, dllName, execFile, textDir, userDisplay);
            }
            catch (Exception)
            {
                throw new Exception("StartEngineer: Outer exception caught for Inputs ProEngineer Handle :" +
                                    proEngineerHandle.ToString(CultureInfo.InvariantCulture) + " DLL Name : " + dllName +
                                    " Executing File : " +
                                    execFile + " Text Dir : " + textDir + " User Display : " + userDisplay.ToString());
            }
        }

        public void AddSession(int proEngineerHandle, int appPid, string appName, int proEngineerPid,
                               string proEngineerName)
        {
            try
            {
                addSession(proEngineerHandle, appPid, appName, proEngineerPid, proEngineerName);
            }
            catch (Exception)
            {
                throw new Exception("AddSession: Outer exception caught for Inputs ProEngineer Handle :" +
                                    proEngineerHandle.ToString(CultureInfo.InvariantCulture) + " Application ID : " +
                                    appPid.ToString(CultureInfo.InvariantCulture) +
                                    " Application Name : " + appName + " ProEngineer Process Id : " + proEngineerPid +
                                    " ProEngineer Name : " + proEngineerName);
            }
        }

        public void DirectoryChange(string directoryPath)
        {
            try
            {
                directoryChange(directoryPath);
            }
            catch (Exception)
            {
                throw new Exception("DirectoryChange: Outer exception caught for Inputs Directory Path : " +
                                    directoryPath);
            }
        }

        public void EraseCurrentModel()
        {
            try
            {
                eraseCurrentModel();
            }
            catch (Exception)
            {
                throw new Exception("EraseCurrentModel: Outer exception caught for Inputs");
            }
        }


        public int LoadModel(string modelName)
        {
            int iModelHandle;
            try
            {
                iModelHandle = loadModel(modelName);
            }
            catch (Exception)
            {
                throw new Exception("LoadModel: Outer exception caught for Inputs Model Name : " + modelName);
            }
            return iModelHandle;
        }


        public string ScanModel(string fileName, string xmlFile)
        {
            string sScanString;
            try
            {
                sScanString = Marshal.PtrToStringAuto(scanModel(fileName, xmlFile));
            }
            catch (Exception)
            {
                throw new Exception("ScanModel: Outer exception caught for Inputs Model file : " + fileName);
            }
            return sScanString;
        }


        public string ScanDrawing(string fileName, string xmlFile)
        {
            string sScanString;
            try
            {
                sScanString = Marshal.PtrToStringAuto(scanDrawing(fileName, xmlFile));
            }
            catch (Exception)
            {
                throw new Exception("ScanDrawing: Outer exception caught for Inputs Drawing file : " + fileName);
            }
            return sScanString;
        }


        public string ScanUDF(string udfPath, string udfPartPath, string xmlFile)
        {
            string sScanString;
            try
            {
                sScanString = Marshal.PtrToStringAuto(scanUDF(udfPath, udfPartPath, xmlFile));
            }
            catch (Exception)
            {
                throw new Exception("ScanUDF: Outer exception caught for Inputs UDF path :" + udfPath +
                                    " UDF Part Path : " + udfPartPath);
            }
            return sScanString;
        }

        public string CheckPartsReferencedInDrawing(string fileName)
        {
            string sDrwSolids;
            try
            {
                sDrwSolids = Marshal.PtrToStringAuto(checkpartsreferencedindrawing(fileName));
            }
            catch (Exception)
            {
                throw new Exception(
                    "CheckPartsReferencedInDrawing: Outer exception caught for Inputs Drawing file : " + fileName);
            }
            return sDrwSolids;
        }

        public void EraseAll()
        {
            try
            {
                eraseall();
            }
            catch (Exception)
            {
                throw new Exception("EraseAll: Outer exception caught");
            }
        }

        public void SaveModel()
        {
            try
            {
                saveModel();
            }
            catch (Exception)
            {
                throw new Exception("SaveModel: Outer exception caught");
            }
        }

        public void Log(string message)
        {
            try
            {
                log(message);
            }
            catch (Exception)
            {
                throw new Exception("Log: Outer exception caught");
            }
        }


        public void RenameAssemblyComponent(string compId, string workingFolder , int IsRSStandard)
        {
            try
            {
                renameassemblycomponent(compId, workingFolder , IsRSStandard);
            }
            catch (Exception)
            {
                throw new Exception("RenameAssemblyComponent: Outer exception caught for Inputs Component Id : " +
                                    compId + " Working Folder : " + workingFolder);
            }
        }


        public void RegenerateCurrentModel()
        {
            try
            {
                regenerateCurrentModel();
            }
            catch (Exception)
            {
                throw new Exception("RegenerateCurrentModel: Outer exception caught");
            }
        }


        public void RepaintCurrentModel()
        {
            try
            {
                repaintCurrentModel();
            }
            catch (Exception)
            {
                throw new Exception("RepaintCurrentModel: Outer exception caught");
            }
        }


        public void BackupModel(string folderName, string geometryName, string geomReleaseName, string drawingName, string drwReleaseName, string AsmChildIdPath, string AsmChildRelName)
        {
            try
            {
                backupModel(folderName, geometryName, geomReleaseName, drawingName, drwReleaseName, AsmChildIdPath , AsmChildRelName);
            }
            catch (Exception)
            {
                throw new Exception("BackupModel: Outer exception caught for Inputs Folder Name : " + folderName);
            }
        }


        public string ExportFileTypes(string drawingExportType, string modelExportType, string releaseFolder,
                                      string drawingFile, string modelFile,string ExportFileName, string sExportFactorOne, string sExportFactorTwo, string sExportFactorThree)
        {
            string exportTypeResult;
            try
            {
                exportTypeResult =
                    Marshal.PtrToStringAuto(
                        (exportfiletypes(drawingExportType, modelExportType, releaseFolder, drawingFile, modelFile,ExportFileName, sExportFactorOne, sExportFactorTwo, sExportFactorThree)));
            }
            catch (Exception)
            {
                throw new Exception("ExportFileTypes: Outer exception caught for Inputs Drawing Export Types : " +
                                    drawingExportType + " Model Export Types : " + modelExportType +
                                    " Release Folder : " + releaseFolder + " Drawing File : " + drawingFile +
                                    " Model File : " + modelFile + " Factor one" + sExportFactorOne + " Factor Two" + sExportFactorTwo + " Factore Three "+ sExportFactorThree);
            }
            return exportTypeResult;
        }


        public void CloseCurrentDrawing()
        {
            try
            {
                closecurrentdrawing();
            }
            catch (Exception)
            {
                throw new Exception("CloseCurrentDrawing: Outer exception caught");
            }
        }


        public string ClearProeWindow(int i)
        {
            string currentAssemblyHandle;
            try
            {
                currentAssemblyHandle = Marshal.PtrToStringAuto(clearproewindow(i));
            }
            catch (Exception)
            {
                throw new Exception("ClearProeWindow: Outer exception caught");
            }
            return currentAssemblyHandle;
        }

        public void RegenerateAssemblyFile(string assemblyHandle)
        {
            try
            {
                regenerateassemblyfile(assemblyHandle);
            }
            catch (Exception)
            {
                throw new Exception("RegenerateAssemblyFile: Outer exception caught for Inputs Assembly Handle : " +
                                    assemblyHandle);
            }
        }

        public int AddComponentWithSuffix(string componentName, string suffix, string parentPath)
        {
            int componentId;
            try
            {
                componentId = addComponentWithSuffix(componentName, suffix, parentPath);
            }
            catch (Exception)
            {
                throw new Exception("AddComponentWithSuffix: Outer exception caught for Inputs Component Name :" +
                                    componentName + " Suffix : " + suffix + " Parent Path : " + parentPath);
            }
            return componentId;
        }


        public int AddUDF(string udfReferences, string udfPath)
        {
            int udfId;
            try
            {
                udfId = addudf(udfReferences, udfPath);
            }
            catch (Exception)
            {
                throw new Exception("AddUDF: Outer exception caught for Inputs UDF References : " + udfReferences +
                                    " UDF Path : " + udfPath);
            }
            return udfId;
        }


        public void DeleteComponent(string componentPath)
        {
            try
            {
                deleteComponent(componentPath);
            }
            catch (Exception)
            {
                throw new Exception("DeleteComponent: Outer exception caught for Inputs Component Path : " +
                                    componentPath);
            }
        }


        public string GetMassPropertyValue(string componentPath, string massPropertyName)
        {
            string massPropertyValue;
            try
            {
                massPropertyValue = Marshal.PtrToStringAuto((getMassProperty(componentPath, massPropertyName)));
            }
            catch (Exception)
            {
                throw new Exception("GetMassPropertyValue: Outer exception caught for Inputs Component Path : " +
                                    componentPath + " Mass Property Name :" + massPropertyName);
            }
            return massPropertyValue;
        }


        public double DimensionGetValue(string dimensionIdPath)
        {
            double dimensionValue;
            try
            {
                dimensionValue = dimensionGetValue(dimensionIdPath);
            }
            catch (Exception)
            {
                throw new Exception("DimensionGetValue: Outer exception caught for Inputs Dimension Id : " +
                                    dimensionIdPath);
            }
            return dimensionValue;
        }


        public void Set3DSketchText(string sketchPath, string newValue)
        {
            try
            {
                setsketchtext(sketchPath, newValue);
            }
            catch (Exception)
            {
                throw new Exception("Set3DSketchText: Outer exception caught for Inputs Sketch Path :" + sketchPath +
                                    " New Text : " + newValue);
            }
        }

        public void SetBoolParameter(string parameterName, string componentPath, int parameterValue)
        {
            try
            {
                setBoolParameter(parameterName, componentPath, parameterValue);
            }
            catch (Exception)
            {
                throw new Exception("SetBoolParameter: Outer exception caught for Inputs Parameter Name : " +
                                    parameterName + " Component Path : " + componentPath + "Parameter Value : " +
                                    parameterValue.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SetDoubleParameter(string parameterName, string componentPath, double parameterValue)
        {
            try
            {
                setDoubleParameter(parameterName, componentPath, parameterValue);
            }
            catch (Exception)
            {
                throw new Exception("SetDoubleParameter: Outer exception caught for Inputs Parameter Name : " +
                                    parameterName + " Component Path : " + componentPath + "Parameter Value : " +
                                    parameterValue.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SetIntParameter(string parameterName, string componentPath, int parameterValue)
        {
            try
            {
                setIntParameter(parameterName, componentPath, parameterValue);
            }
            catch (Exception)
            {
                throw new Exception("SetIntParameter: Outer exception caught for Inputs Parameter Name : " +
                                    parameterName + " Component Path : " + componentPath + "Parameter Value : " +
                                    parameterValue.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SetStringParameter(string parameterName, string componentPath, string parameterValue)
        {
            try
            {
                setStringParameter(parameterName, componentPath, parameterValue);
            }
            catch (Exception)
            {
                throw new Exception("SetStringParameter: Outer exception caught for Inputs Parameter Name : " +
                                    parameterName + " Component Path : " + componentPath + "Parameter Value : " +
                                    parameterValue);
            }
        }


        public void UDFDimensionValueSet(string udfPath, string dimensionName, double newValue)
        {
            try
            {
                UDFdimensionvalueset(udfPath, dimensionName, newValue);
            }
            catch (Exception)
            {
                throw new Exception("UDFDimensionValueSet: Outer exception caught for Inputs UDF Path : " + udfPath +
                                    "  Dimension Name : " + dimensionName + " New Value : " +
                                    newValue.ToString(CultureInfo.InvariantCulture));
            }
        }


        public void BuildConstraints(string constrainString)
        {
            try
            {
                buildConstraints(constrainString);
            }
            catch (Exception)
            {
                throw new Exception("BuildConstraints: Outer exception caught");
            }
        }

        public void DimensionSetValueByIdPath(string dimensionIdPath, double newValue)
        {
            try
            {
                dimensionSetValueByIdPath(dimensionIdPath, newValue);
            }
            catch (Exception)
            {
                throw new Exception("DimensionSetValueByIdPath: Outer exception caught for Inputs Dimension Id : " +
                                    dimensionIdPath + " New Value : " + newValue.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void PreProcessDocumentName(string fileName, string fileType, string fileEarlierName)
        {
            try
            {
                preprocessdocumentname(fileName, fileType, fileEarlierName);
            }
            catch (Exception)
            {
                throw new Exception("PreProcessDocumentName: Outer exception caught for Inputs File Name : " + fileName +
                                    " File Type : " + fileType + " File Earlier Name : " + fileEarlierName);
            }
        }

        public int ProcessDocumentName(string componentPath, string newName)
        {
            int result;
            try
            {
                result = processdocumentname(componentPath, newName);
            }
            catch (Exception)
            {
                throw new Exception("ProcessDocumentName: Outer exception caught for Inputs Component Path :" +
                                    componentPath + " New Name : " + newName);
            }
            return result;
        }

        public int ProcessFamilyTableInstance(string instanceName, string componentPath)
        {
            int result;
            try
            {
                result = processfamilytableinstance(instanceName, componentPath);
            }
            catch (Exception)
            {
                throw new Exception("ProcessFamilyTableInstance: Outer exception caught for Inputs Instance Name : " +
                                    instanceName + " Component Path : " + componentPath);
            }
            return result;
        }

        public void RenameFamilyTableInstance(string instanceCurrentName, string instanceNewName, string componentPath)
        {
            try
            {
                renamefamilytableinstance(instanceCurrentName, instanceNewName, componentPath);
            }
            catch (Exception)
            {
                throw new Exception(
                    "RenameFamilyTableInstance: Outer exception caught for Inputs Current Instance Name : " +
                    instanceCurrentName + " Instance New Name : " + instanceNewName + " Component Path : " +
                    componentPath);
            }
        }

        public int ReplaceProEPartFile(string currentComponetId, string newComponentName, string currentComponentPath)
        {
            int newCompId;
            try
            {
                newCompId = replaceproepartfile(currentComponetId, newComponentName, currentComponentPath);
            }
            catch (Exception)
            {
                throw new Exception("ReplaceProEPartFile: Outer exception caught for Inputs Current Component Id :" +
                                    currentComponetId + " New Component Name : " + newComponentName +
                                    " Current Component Path : " + currentComponentPath);
            }
            return newCompId;
        }

        public string SetUDFFeatureStatus(string udfId, string featureName, string statusValue)
        {
            string udfFeatureStatus;
            try
            {
                udfFeatureStatus = Marshal.PtrToStringAuto(setUDFfeaturestatus(udfId, featureName, statusValue));
            }
            catch (Exception)
            {
                throw new Exception("SetUDFFeatureStatus: Outer exception caught for Inputs UDF Id : " + udfId +
                                    " Feature Name : " + featureName + " Status Value : " + statusValue);
            }
            return udfFeatureStatus;
        }


        public void LayerDisplayStatusSet(int layerId, int status)
        {
            try
            {
                layerDisplayStatusSet(layerId, status);
            }
            catch (Exception)
            {
                throw new Exception("LayerDisplayStatusSet: Outer exception caught for Inputs Layer Id " +
                                    layerId.ToString(CultureInfo.InvariantCulture) + " Status : " + status);
            }
        }

        public void ResumeFeature(string componentPath, string staticFile)
        {
            try
            {
                resumeFeature(componentPath, staticFile);
            }
            catch (Exception)
            {
                throw new Exception("ResumeFeature: Outer exception caught for Inputs Component Path : " + componentPath);
            }
        }

        public void SetAmbientLight(string componentPath, double value)
        {
            try
            {
                setAmbientLight(componentPath, value);
            }
            catch (Exception)
            {
                throw new Exception("SetAmbientLight: Outer exception caught for Inputs Component Path : " +
                                    componentPath + " Value : " + value.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SetColor(string componentPath, string value)
        {
            try
            {
                setColor(componentPath, value);
            }
            catch (Exception)
            {
                throw new Exception("SetColor: Outer exception caught for Inputs Component Path : " + componentPath +
                                    " Value : " + value);
            }
        }

        public void SetShininess(string componentPath, double value)
        {
            try
            {
                setShininess(componentPath, value);
            }
            catch (Exception)
            {
                throw new Exception("SetShininess: Outer exception caught for Inputs Component Path : " + componentPath +
                                    " Value : " + value.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SetTransparency(string componentPath, double value)
        {
            try
            {
                setTransparency(componentPath, value);
            }
            catch (Exception)
            {
                throw new Exception("SetTransparency: Outer exception caught for Inputs Component Path : " +
                                    componentPath + " Value : " + value.ToString(CultureInfo.InvariantCulture));
            }
        }

        public void SuppressFeature(string componentPath, string staticFile)
        {
            try
            {
                suppressFeature(componentPath, staticFile);
            }
            catch (Exception)
            {
                throw new Exception("SuppressFeature: Outer exception caught for Inputs Component Path : " +
                                    componentPath);
            }
        }

        public void ShowFeature(string componentPath)
        {
            try
            {
                showfeature(componentPath);
            }
            catch (Exception)
            {
                throw new Exception("ShowFeature: Outer exception caught for Inputs Component Path : " +
                                    componentPath);
            }
        }

        public void HideFeature(string componentPath)
        {
            try
            {
                hidefeature(componentPath);
            }
            catch (Exception)
            {
                throw new Exception("HideFeature: Outer exception caught for Inputs Component Path : " +
                                    componentPath);
            }
        }


        public void DrawingMultipleSolidRename(string modelCurrentName, string modelOriginalName, string drawingFileName,
                                               string newDrawingName)
        {
            try
            {
                drawingmultiplesolidrename(modelCurrentName, modelOriginalName, drawingFileName, newDrawingName);
            }
            catch (Exception)
            {
                throw new Exception("DrawingMultipleSolidRename: Outer exception caught for Inputs Current Solids : " +
                                    modelCurrentName + " Solids Original Name : " + modelOriginalName +
                                    " Drawing File : " + drawingFileName + " New Drawing Name : " + newDrawingName);
            }
        }


        public void DrawingRename(string modelCurrentName, string modelOriginalName, string drawingFileName,
                                  string newDrawingName, int iDrwGeomChanged)
        {
            try
            {
                drawingRename(modelCurrentName, modelOriginalName, drawingFileName, newDrawingName , iDrwGeomChanged);
            }
            catch (Exception)
            {
                throw new Exception("DrawingRename: Outer exception caught for Inputs Current Model : " +
                                    modelCurrentName + " Model Original Name : " + modelOriginalName +
                                    " Drawing File : " + drawingFileName + " New Drawing Name : " + newDrawingName);
            }
        }


        public string ReadDrawingProperties(string drawingPropertyName, string viewName)
        {
            string propertyValue;
            try
            {
                propertyValue = Marshal.PtrToStringAuto((readdrawingproperties(drawingPropertyName, viewName)));
            }
            catch (Exception)
            {
                throw new Exception(
                    "ReadDrawingProperties: Outer exception caught for Inputs Drawing Property Name : " +
                    drawingPropertyName + " View Name : " + viewName);
            }
            return propertyValue;
        }


        public void DrawingSheetRegenerate()
        {
            try
            {
                drawingSheetRegenerate();
            }
            catch (Exception)
            {
                throw new Exception("DrawingSheetRegenerate: Outer exception caught");
            }
        }


        public string AddDrawingTable(string tableDataString, int sheetNumber, string tableIdString)
        {
            string tableId;
            try
            {
                tableId = Marshal.PtrToStringAnsi(adddrawingtable(tableDataString, sheetNumber, tableIdString));
            }
            catch (Exception)
            {
                throw new Exception("AddDrawingTable: Outer exception caught for Inputs Table Data : " + tableDataString +
                                    " Sheet Number : " + sheetNumber + " TableId : " + tableIdString);
            }
            return tableId;
        }


        public void DrawingScaleSet(int sheetNumber, double newScaleValue)
        {
            try
            {
                drawingScaleSet(sheetNumber, newScaleValue);
            }
            catch (Exception)
            {
                throw new Exception("DrawingScaleSet: Outer exception caught for Inputs Sheet Number : " + sheetNumber +
                                    " New Scale : " + newScaleValue);
            }
        }


        public void DrawingViewLocationChange(string viewName, double newLocationValue, string moveDirection)
        {
            try
            {
                drawingviewlocationchange(viewName, newLocationValue, moveDirection);
            }
            catch (Exception)
            {
                throw new Exception("DrawingViewLocationChange: Outer exception caught for Inputs View Name : " +
                                    viewName + " New Location Value : " + newLocationValue + " Move Direction : " +
                                    moveDirection);
            }
        }

        public void DrawingViewModelViewChange(string viewName, string mdlViewName, string orientation, double xAngle, double yAngle)
        {
            try
            {
                drwViewModelViewChange(viewName, mdlViewName, orientation, xAngle, yAngle);
            }
            catch (Exception)
            {
                throw new Exception("DrawingViewLocationChange: Outer exception caught for Inputs View Name : " +
                                    viewName + " Model view : " + mdlViewName + " Orientation : " + orientation + " X angle : " + xAngle + " Y angle : " + yAngle);
            }
        }

        public void DrawingViewScaleSet(string viewName, double newScaleValue)
        {
            try
            {
                drawingviewscaleset(viewName, newScaleValue);
            }
            catch (Exception)
            {
                throw new Exception("DrawingViewScaleSet: Outer exception caught for Inputs View Name : " + viewName +
                                    " New Scale Value : " + newScaleValue);
            }
        }

        public void DrawingViewSizeSet(string viewName, double newViewSize, string changeParameter)
        {
            try
            {
                drawingviewsizeset(viewName, newViewSize, changeParameter);
            }
            catch (Exception)
            {
                throw new Exception("DrawingViewSizeSet: Outer exception caught for Inputs View Name : " + viewName +
                                    " New View Size : " + newViewSize + " Change Parameter : " + changeParameter);
            }
        }


        public void DrawingAnnotationDisplaySet(int annotationId, string displayValue, string annotationType)
        {
            try
            {
                drawingannotationdisplayset(annotationId, displayValue, annotationType);
            }
            catch (Exception)
            {
                throw new Exception("DrawingAnnotationDisplaySet: Outer exception caught for Inputs Annotation Id : " +
                                    annotationId + " Display Value : " + displayValue + " Annotation Type : " +
                                    annotationType);
            }
        }

        public void DrawingNoteLocationChange(int noteId, double locationValue, string moveDirection)
        {
            try
            {
                drawingnotelocationchange(noteId, locationValue, moveDirection);
            }
            catch (Exception)
            {
                throw new Exception("DrawingNoteLocationChange: Outer exception caught for Inputs Note Id : " + noteId +
                                    " Location Value : " + locationValue + " Move Direction : " + moveDirection);
            }
        }

        public void DrawingNoteTextSet(string noteId, string sheetId, string newTextVale)
        {
            try
            {
                drawingnotetextset(noteId, sheetId, newTextVale);
            }
            catch (Exception)
            {
                throw new Exception("DrawingNoteTextSet: Outer exception caught for Inputs Note Id : " + noteId +
                                    " Sheet Id : " + sheetId + " New Text Value : " + newTextVale);
            }
        }


        public void DrawingDimensionLocationChange(int dimId, double locationValue, string moveDirection)
        {
            try
            {
                drawingdimensionlocationchange(dimId, locationValue, moveDirection);
            }
            catch (Exception)
            {
                throw new Exception("DrawingDimensionLocationChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " location value : " + locationValue + " move direction : " + moveDirection);
            }
        }

        public void DrawingModelAnnotationDisplaySet(int modelDimId, string dimStatus)
        {
            try
            {
                drawingmodelannotationdisplayset(modelDimId, dimStatus);
            }
            catch (Exception)
            {
                throw new Exception(
                    "DrawingModelAnnotationDisplaySet: Outer exception caught for Inputs Model Dim Id : " + modelDimId +
                    " Dim Status : " + dimStatus);
            }
        }

        public void DrawingModelDimensionLocationChange(int dimId, double locationValue, string moveDirection)
        {
            try
            {
                drawingmodeldimensionlocationchange(dimId, locationValue, moveDirection);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionLocationChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " location value : " + locationValue + " move direction : " + moveDirection);
            }
        }

        public void DrawingModelDimensionDecimalPlaceChange(int dimId, int dimDecimal)
        {
            try
            {
                DrwModelDimensionDecimalPlaceChange(dimId, dimDecimal);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionDecimalPlaceChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " decimal place value : " + dimDecimal);
            }
        }

        public void DrawingModelDimensionUpperTolChange(int dimId, double upperTolerance)
        {
            try
            {
                DrwModelDimensionUpperTolChange(dimId, upperTolerance);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionUpperTolChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " upper tolerance value : " + upperTolerance);
            }
        }

        public void DrawingModelDimensionLowerTolChange(int dimId, double lowerTolerance)
        {
            try
            {
                DrwModelDimensionLowerTolChange(dimId, lowerTolerance);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionLowerTolChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " lower tolerance value : " + lowerTolerance);
            }
        }

        public void DrawingModelDimensionToleranceDecimalPlaceChange(int dimId, int dimDecimal)
        {
            try
            {
                DrwModelDimensionToleranceDecimalPlaceChange(dimId, dimDecimal);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionToleranceDecimalPlaceChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " tolerance decimal value : " + dimDecimal);
            }
        }
        public void DrawingModelDimensionTableNameColumnChange(int dimId, string tableName, int column)
        {
            try
            {
                DrwModelDimensionTableNameColumnChange(dimId, tableName, column);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionTableNameChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " table name value : " + tableName + " table column value : " + column);
            }
        }

        public void DrawingModelDimensionTableNameChange(int dimId, string tableName)
        {
            try
            {
                DrwModelDimensionTableNameChange(dimId, tableName);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionTableNameChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " table name value : " + tableName);
            }
        }

        public void DrawingModelDimensionTableColumnChange(int dimId, int column)
        {
            try
            {
                DrwModelDimensionTableColumnChange(dimId, column);
            }
            catch (Exception)
            {
                throw new Exception("DrawingModelDimensionTableColumnChange: Outer exception caught for Inputs Dim Id : " +
                                    dimId + " table column value : " + column);
            }
        }

        public void GetSessionTable(ref int sessionTableIndex, ref IntPtr appPidTablePtr, ref IntPtr appNameTablePtr,
                                    ref IntPtr proEngineerPidTablePtr, ref IntPtr proEngineerNameTablePtr,
                                    ref IntPtr proEngineerHiddenTable, ref IntPtr proEngineerStartedOrConnectedTable)
        {
            try
            {
                getSessionTable(ref sessionTableIndex, ref appPidTablePtr, ref appNameTablePtr,
                                ref proEngineerPidTablePtr, ref proEngineerNameTablePtr, ref proEngineerHiddenTable,
                                ref proEngineerStartedOrConnectedTable);
            }
            catch (Exception)
            {
                throw new Exception("GetSessionTable: Outer exception caught");
            }
        }


        public void BackupModelToWIP(string WIPfolderName, string geomRelName, string geomWIPName, string drawingName, string drwReleaseName, string AsmChildIdPath, string AsmChildWrkngName)
        {
            try
            {
                backupModelToWIP(WIPfolderName, geomRelName, geomWIPName, drawingName, drwReleaseName , AsmChildIdPath , AsmChildWrkngName);
            }
            catch (Exception)
            {
                throw new Exception("BackupModelToWIP: Caught Outer Exception ");
            }
        }

        void IDriverImpl.RenameModel(string sIdPath, string sNewName)
        {
            try
            {
                renamemodel(sIdPath, sNewName);
            }
            catch (Exception)
            {
                throw new Exception("RenameModel: Caught Outer Exception ");
            }
        }


        string IDriverImpl.IntegrationCurrentModeGet()
        {
            string sIntegrationMode = string.Empty;
            try
            {
                sIntegrationMode = Marshal.PtrToStringAnsi(integrationcurrentmodeget());
            }
            catch (Exception)
            {
                throw new Exception("IntegrationCurrentModeGet: Caught Outer Exception ");
            }
            return sIntegrationMode;
        }



        public void RegenerateSelectedPart(string sIdPath)
        {
            try
            {
                regenerateselectedpart(sIdPath);
            }
            catch (Exception)
            {
                throw new Exception("RegenerateSelectedPart: Caught Outer Exception ");
            }
        }


        public string GetParameterValue(string sIdPath, string sParamName)
        {
            string sParamValue = string.Empty;
            try
            {
                sParamValue = Marshal.PtrToStringAuto(getparametervalue(sIdPath, sParamName));
            }
            catch (Exception)
            {
                throw new Exception("GetParameterValue: Caught Outer Exception ");
            }
            return sParamValue;
        }


        public int ProcessDocumentNameForStaticAsmComponent(string sStaticIdPath, string sCompIdPath, string sDocumentName)
        {
            int iCompId = 0;
            try
            {
                iCompId = processdocumentnameforstaticasmcomponent(sStaticIdPath, sCompIdPath, sDocumentName);
            }
            catch (Exception)
            {
                throw new Exception("ProcessDocumentNameForStaticAsmComponent: Caught Outer Exception ");
            }
            return iCompId;
        }


        public string GetSessionComponentList()
        {
            string sCompLst = string.Empty;
            try
            {
                sCompLst = Marshal.PtrToStringAuto(getsessioncomponentlist());
            }
            catch (Exception)
            {
                throw new Exception("GetSessionComponentList: Caught Outer Exception ");
            }
            return sCompLst;
        }

        public string GetDrwNoteRefModelsList()
        {
            string sCompLst = string.Empty;
            try
            {
                sCompLst = Marshal.PtrToStringAuto(getdrwnoterefmodelslist());
            }
            catch (Exception)
            {
                throw new Exception("GetDrwNoteRefModelsList: Caught Outer Exception ");
            }
            return sCompLst;
        }

        public string GetDrawingViewModelNames(string viewName)
        {
            string sCompLst = string.Empty;
            try
            {
                sCompLst = Marshal.PtrToStringAuto(getDrwViewModelNames(viewName));
            }
            catch (Exception)
            {
                throw new Exception("GetDrawingViewModelNames: Caught Outer Exception ");
            }
            return sCompLst;
        }

        public string GetDrawingViewType(string viewName)
        {
            string sCompLst = string.Empty;
            try
            {
                sCompLst = Marshal.PtrToStringAuto(getDrwViewType(viewName));
            }
            catch (Exception)
            {
                throw new Exception("GetDrawingViewType: Caught Outer Exception ");
            }
            return sCompLst;
        }

        public string GetCurrentSessionConnectionId(int iProcessId)
        {
            string sConnectId = string.Empty;
            try
            {
                sConnectId = Marshal.PtrToStringAnsi(getcurrentsessionconnectionId(iProcessId));
            }
            catch (Exception)
            {
                throw new Exception("GetCurrentSessionConnectionId: Caught Outer Exception ");
            }
            return sConnectId;
        }


        public int CheckModifyingEntityExistInPart(string sEntityType, string sEntityName, string sIdPath)
        {
            int iExist = -1;
            try
            {
                iExist = checkmodifyingentityexistInpart(sEntityType, sEntityName, sIdPath);
            }
            catch (Exception)
            {
                throw new Exception("CheckModifyingEntityExistInPart: Caught Outer Exception ");
            }
            return iExist;
        }


        public string GetModelCurrentName(string sIdPath)
        {
            string sMdlName = string.Empty;
            try
            {
                sMdlName = Marshal.PtrToStringAuto(getmodelcurrentname(sIdPath));
            }
            catch (Exception)
            {
                throw new Exception("GetModelCurrentName: Caught Outer Exception ");
            }
            return sMdlName;
        }

        public string GetModelNamebyID(string idPath)
        {
            string mdlName = string.Empty;
            try
            {
                mdlName = Marshal.PtrToStringAuto(getmodelnamebyid(idPath));
            }
            catch (Exception)
            {
                throw new Exception("GetModelNamebyID: Caught Outer Exception ");
            }
            return mdlName;
        }

        public void SaveModelByID(string compId)
        {
            try
            {
                saveModelbyId(compId);
            }
            catch (Exception)
            {
                throw new Exception("SaveModelbyID: Outer exception caught");
            }
        }

        public void EraseModelByName(string modelName)
        {
            try
            {
                erasemodelbyname(modelName);
            }
            catch (Exception)
            {
                throw new Exception("EraseModelByName: Outer exception caught");
            }
        }

        public void DrawingCreateFromTemplate(string partName, string drawingToRename, string newDrawingName)
        {
            try
            {
                drawingcreatefromtemplate(partName, drawingToRename, newDrawingName);
            }
            catch (Exception)
            {
                throw new Exception("DrawingCreateFromTemplate: Caught Outer Exception");
            }
        }
    }
}