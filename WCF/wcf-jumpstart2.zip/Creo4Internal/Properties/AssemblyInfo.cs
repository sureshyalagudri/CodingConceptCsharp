﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;


// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Review the values of the assembly attributes

[assembly: AssemblyTitle("RuleStream Creo Internal")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Creo")]

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ac24cd52-1e54-4bb7-bc12-9a5f5a31898c")]

