// Pro/Toolkit header files.
#include <ProToolkit.h>
#include <ProUtil.h>


// Application header files.
#include "Log.h"
#include "ProeException.h"
#include "init.h"


/*-------------------------------------------------------------*\
  Function:     user_initialize()
  Purpose:      To initiate the user's options
\*-------------------------------------------------------------*/
int user_initialize(int argc, char *argv[], char *version, char *build, wchar_t *error)
{
	// It may not be obvious, but by virtue of calling ProEngineerStart(), 
	// ProeWrapper becomes a simple asynchronous application.  This means
	// that it can optionally have a user_initialize() and a user_terminate()
	// function.
	//
	// If you are looking to put anything in this function, chances are
	// you really want the user_initialize() of the addin, and not this
	// user_initialize().  The addin operates in synchronous dll mode, and
	// so we do initialization type stuff in its user_initialize() function.

	LOG << "ProeWrapper::user_initialize(" << argc << ", " << argv[0] << ", " << version << ", " << build << ")" << std::endl;

    return 0;
}


/*-------------------------------------------------------------*\
  Function:     user_terminate()
  Purpose:      To handle any termination actions
\*-------------------------------------------------------------*/
void user_terminate()
{
	// Clean up the logging class.
	Log::Destroy();

	return;
}
