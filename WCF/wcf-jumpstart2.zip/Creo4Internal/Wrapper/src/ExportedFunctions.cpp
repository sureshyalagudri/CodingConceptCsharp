// C/C++ header files.
#include <cstdio>
#include <typeinfo.h>
#include <cstdarg>
#include <io.h>
#include <iostream>

// Application header files.
#include "Log.h"
#include "ProeException.h"
#include "ProToolkitFacade.h"
#include "Utility.h"
#include "ExportedFunctions.h"

// Pro/Toolkit header files.
#include <ProCore.h>
#include <ProMode.h>

#import <Log4ProE.tlb> named_guids raw_interfaces_only

// This module is is responsible for marshalling the arguments
// for all the various ProToolkitFacade functions & then using
// the GeometryFacadeExecuteToolkitTask() function to call the
// appropriate function inside of the AddIn.
//
// Basically, every function that needs to be called from the
// .NET world has an equivalent wrapper function here & that
// wrapper function marshalls the arguments via the executeTask()
// function.  Currently, this is done using C variable arguments,
// but function templates would be nicer (but harder to implement
// as RTTI would need to be used).
//
// The format of the marshalling is as follows:
//
// 1) All functions passed to executeTask() must take at least
//    two arguments - one input & one output.
//
// 2) Input arguments come first (left to right) & are represented
//    by lower case format specifiers (e.g., %s for char*).  It is
//    a requirement of the GeometryFacadeExecuteToolkitTask() that
//    at least one input argument be specified, so if no input
//    argument is needed, use %p as the format specifier & NULL as
//    the value.
//
// 3) Output arguments follow input arguments & are represented by
//    upper case format specifiers (e.g., %D for double).  If no
//    output arguments are needed, one still must be specified by
//    the %P format specifier.  Just use NULL as the value.

static const int SESSION_TABLE_SIZE = 256;

static Log4ProE::ILog4ProEPtr oLog4ProE = NULL;

// Create a shared memory region for the Pro/ENGINEER integration to use.
// This will enable sharing information among multiple RSA & RSE sessions.
// Collectively the data in here is refered to as the session table, as
// it holds various RSA, RSE & Pro/ENGINEER session information.
// TODO: A better mechanism, such as a dictionary with a key of process ID,
// might be better here.
#pragma data_seg(".shared")

	// Approximately 87 KBytes of shared memory.

	// Holds the number of entries in the session table.
	// 4 bytes.
	int g_sessionTableIndex = 0;

	// Hold the PID's of the app (RSA or RSE).
	// 1 Kbyte.
	int g_appPIDTable[SESSION_TABLE_SIZE] = {0};

	// Holds the app name (RsArchitect or RsEngineer).
	// 8 KBytes.
	char g_appNameTable[SESSION_TABLE_SIZE][32] = {""};

	// Hold the PID's of Pro/ENGINEER sessions started by RSA/RSE.
	// 1 Kbyte.
	int g_proEngineerPIDTable[SESSION_TABLE_SIZE] = {0};

	// Holds the name of the Pro/ENGINNER process (xtop).
	// 8 KBytes.
	char g_proEngineerNameTable[SESSION_TABLE_SIZE][32] = {""};

	// Holds the Pro/ENGINEER handle that is returned from
	// ProEngineerConnectionStart() or ProEngineerConnect().
	// 2 KBytes.
	GeometryFacadeProcessHandle g_proEngineerProcessHandleTable[SESSION_TABLE_SIZE] = {0};

	// Holds whether or not the Pro/ENGINEER session is hidden.
	// 1 KBytes.
	int g_proEngineerHiddenTable[SESSION_TABLE_SIZE] = {0};

	// Holds whether this Pro/ENGINEER session was started or connected to.
	// 1 KBytes.
	int g_proEngineerStartedOrConnected[SESSION_TABLE_SIZE] = {0};

	// Holds the Pro/ENGINEER DLL handle that is returned from
	// GeometryFacadeLoadDll().
	// 1 KByte.
	GeometryFacadeToolkitDllHandle g_proEngineerDllHandleTable[SESSION_TABLE_SIZE] = {0};

	// Holds the connection ID that was obtained from the
	// Pro/ENGINEER handle since this information cannot
	// be obtained from another process.
	// 64 KBytes.
	char g_proEngineerConnectionIdTable[SESSION_TABLE_SIZE][GEOMETRY_FACADE_CONNECT_ID_SIZE] = {""};

#pragma data_seg()
#pragma comment(linker, "/SECTION:.shared,RWS")

// Global Pro/ENGINEER DLL handle for executeTask().
static GeometryFacadeToolkitDllHandle g_proEngineerDllHandle;

// Component functions.
EXPORT int AddComponent(const char *filePath, const char *ownerIDPath)
{
	int output = 0;
	executeTask("AddComponent_task", "%s %s %D", filePath, ownerIDPath, &output);

	return output;
}

EXPORT int AddComponentWithSuffix(const wchar_t *modelName, const wchar_t *suffix, const wchar_t *ownerIDPath)
{
	int output = 0;
	executeTask("AddComponentWithSuffix_task", "%w %w %w %D", modelName, suffix, ownerIDPath, &output);

	return output;
}
EXPORT void RenameAssemblyComponent(const char *suffix,const char *workingFolder , int IsRSStandard)
{
	int output = 0;
	executeTask("RenameAssemblyComponent_task", "%s %s %d %D",suffix,workingFolder, IsRSStandard , &output);
}

EXPORT const wchar_t* ClearProeWindow(int i)
{
	wchar_t * output = 0;
	executeTask("ClearProeWindow_task", "%d %W", i , &output);

	return output;
}

EXPORT void RegenerateAssemblyFile(wchar_t * asmHandle)
{
	int output = 0;
	executeTask("RegenerateAssemblyFile_task", "%w %D",asmHandle, &output);
}

EXPORT int ProcessFamilyTableInstance(const wchar_t *cInstName,const wchar_t *cOwnerID)
{
	int output = 0;
	executeTask("ProcessFamilyTableInstance_task", "%w %w %D",cInstName,cOwnerID,&output);
	return output;
}

EXPORT void RenameFamilyTableInstance(const wchar_t *cInstName,const wchar_t *cInstNewNm,const wchar_t *cGnrcPath)
{
	executeTask("RenameFamilyTableInstance_task", "%w %w %w %P",cInstName,cInstNewNm,cGnrcPath,NULL);
}

EXPORT void DeleteComponent(const char *idPath)
{
	executeTask("DeleteComponent_task", "%s %P", idPath, NULL);
}

EXPORT int AddSuffix(const char *modelName, const char *suffix)
{
	int output = 0;
	executeTask("AddSuffix_task", "%s %s %D", modelName, suffix, &output);

	return output;
}

EXPORT int ReplaceProEPartFile(const wchar_t *cCrntFleID,const wchar_t *cNeFlNm,const wchar_t *cIdPath)
{
	int output = 0;
	executeTask("ReplaceProEPartFile_task","%w %w %w %D",cCrntFleID,cNeFlNm,cIdPath,&output);
	return output;
}

EXPORT int ProcessDocumentName(const wchar_t *cOwnerId,const wchar_t *cDocumentName)
{
	int iOut;
	executeTask("ProcessDocumentName_task","%w %w %D",cOwnerId,cDocumentName,&iOut);
	return iOut;
}

EXPORT int ProcessDocumentNameForStaticAsmComponent(const wchar_t *cOwnerId,const wchar_t *cCompId , const wchar_t *cDocumentName)
{
	int iOut;
	executeTask("ProcessDocumentNameForStaticAsmComponent_task","%w %w %w %D", cOwnerId, cCompId , cDocumentName , &iOut);
	return iOut;
}

EXPORT const wchar_t* GetListOfModelsInSession()
{
	wchar_t *cAllMdlList = NULL;
	executeTask("GetListOfModelsInSession_task","%W", &cAllMdlList);
	return cAllMdlList;
}

EXPORT const wchar_t* GetListOfDrawingRefModels()
{
	wchar_t *cAllMdlList = NULL;
	executeTask("GetListOfDrawingRefModels_task","%W", &cAllMdlList);
	return cAllMdlList;
}

EXPORT const wchar_t* GetDrawingViewModelNames(const wchar_t * viewName)
{
	wchar_t *cAllMdlList = NULL;
	executeTask("GetDrawingViewModelNames_task","%w %W", viewName, &cAllMdlList);
	return cAllMdlList;
}

EXPORT const wchar_t* GetDrawingViewType(const wchar_t * viewName)
{
	wchar_t *cAllMdlList = NULL;
	executeTask("GetDrawingViewType_task","%w %W", viewName, &cAllMdlList);
	return cAllMdlList;
}

EXPORT void PreProcessDocumentName(const wchar_t* existingFile,const wchar_t * modelType,const wchar_t* earlierName)
{
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl pMdl;
		GeometryFacadeMdlType pMdlType;
		GeometryFacadeName wName;

		ProCharLine cExistingFile, cModelType, CEarlierName;
		GeometryFacadeWideStringToString(cExistingFile, existingFile);
		GeometryFacadeWideStringToString(cModelType, modelType);
		GeometryFacadeWideStringToString(CEarlierName, earlierName);

		if(_stricmp(cModelType,"MODEL") == 0)
		{
			pMdlType = GEOMETRY_FACADE_MDL_PART;
		}
		else if(_stricmp(cModelType,"ASSEMBLY") == 0)
		{
			pMdlType = GEOMETRY_FACADE_MDL_ASSEMBLY;
		}
		else
		{
			pMdlType = GEOMETRY_FACADE_MDL_UNUSED;
		}

		//Before retreiving check if model is already in session or retreiving it from hard disk
		//as we will need to erase it later.

		bool bMdlInSession = CheckIsModelInSession(cExistingFile,pMdlType);
		GeometryFacadeRetrieveMdl(cExistingFile,pMdlType,&pMdl);
		GeometryFacadeStringToWideString(wName,CEarlierName);
		GeometryFacadeRenameMdl(pMdl,wName);

		if(!bMdlInSession)
		{
			if(pMdlType == GEOMETRY_FACADE_MDL_ASSEMBLY)
			{
				result = ProMdlEraseAll(pMdl);
			}
			else
			{
				result = ProMdlErase(pMdl);
			}
			std::stringstream s;
			s << cModelType << " erased from ProE session with result as : " << result;
			LogDebug(s.str().c_str());
		}
	}
	catch(ProeException){}
	catch(exception){}
}

bool CheckIsModelInSession(const char *cExistingFile,GeometryFacadeMdlType pMdlType)
{
	try
	{
		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		GeometryFacadeMdl *pSessionMdlLst = NULL;
		int iNoMdl = 0;

		result = ProSessionMdlList(pMdlType,&pSessionMdlLst,&iNoMdl);
		LOG << "Models in session : " << iNoMdl << " while Model Type is : " << int(pMdlType) << endl;
		if(result == GEOMETRY_FACADE_NO_ERROR)
		{
			for(int i = 0;i<iNoMdl;i++)
			{
				ProName wMdlNm = {};
				char *cTemp = new char[sizeof(ProName)+1];
				std::string sTemp;
				result = ProMdlNameGet(pSessionMdlLst[i],wMdlNm);
				GeometryFacadeWideStringToString(cTemp,wMdlNm);
				int iCmp = 0;

				string sFileName = cExistingFile;
				size_t pos = sFileName.find_first_of(".");
				if(pos != string::npos)
				{
					sFileName = sFileName.substr(0,pos);
				}

				iCmp = _stricmp(cTemp,sFileName.c_str());
				if(iCmp == 0)
				{					
					LOG << "ProE session already has : " << cExistingFile << endl;
					delete []cTemp;
					if(pSessionMdlLst != NULL)
						ProArrayFree((ProArray*)&pSessionMdlLst);
					return true;
				}
				delete []cTemp;
			}
		}

		if(pSessionMdlLst != NULL)
			ProArrayFree((ProArray*)&pSessionMdlLst);
	}
	catch(ProeException){}
	return false;
}

// Constraint functions.
EXPORT void BuildConstraints(const wchar_t *xml)
{
	executeTask("BuildConstraints_task", "%w %P", xml, NULL);
}

EXPORT void ShowConstraints(const char *idPath)
{
	executeTask("ShowConstraints_task", "%s %P", idPath, NULL);
}

// Dimension functions.
EXPORT double DimensionGetValue(const char *idPath)
{
	double output = 0.0;
	executeTask("DimensionGetValue_task", "%s %G", idPath, &output);

	return output;
}

EXPORT const wchar_t* DimensionGetValueByIdPath(const char *idPath)
{
	wchar_t *output = NULL;
	executeTask("DimensionGetValueByIdPath_task", "%s %W", idPath, &output);

	return output;
}

EXPORT void DimensionSetByName(const wchar_t *name, double value)
{
	executeTask("DimensionSetByName_task", "%w %g %P", name, value, NULL);
}

EXPORT void DimensionSetValueByIdPath(const char *idPath, double value)
{
	executeTask("DimensionSetValueByIdPath_task", "%s %g %P", idPath, value, NULL);
}

// Drawing functions.
EXPORT void CreateProDrawing(const wchar_t *newName, const wchar_t *drawingTemplateName)
{
	executeTask("CreateProDrawing_task", "%w %w %P", newName, drawingTemplateName, NULL);
}

EXPORT void DrawingCurrentSheetSet(int sheet)
{
	executeTask("DrawingCurrentSheetSet_task", "%d %P", sheet, NULL);
}

EXPORT void DrawingCreateFromTemplate(const wchar_t *partName, const wchar_t *drawingToRename, const wchar_t *newDrawingName)
{
	executeTask("DrawingCreateFromTemplate_task", "%w %w %w %d", partName, drawingToRename, newDrawingName);
}

EXPORT void DrawingRename(const wchar_t *partName, const wchar_t *templatePartName, const wchar_t *drawingToRename, const wchar_t *newDrawingName , int iDrwGeomChanged)
{
	executeTask("DrawingRename_task", "%w %w %w %w %d %d", partName, templatePartName, drawingToRename, newDrawingName , iDrwGeomChanged);
}

EXPORT void DrawingMultipleSolidRename(const wchar_t *partName, const wchar_t *templatePartName, const wchar_t *drawingToRename, const wchar_t *newDrawingName)
{
	executeTask("DrawingMultipleSolidRename_task", "%w %w %w %w %d", partName, templatePartName, drawingToRename, newDrawingName);
}

EXPORT void DrawingScaleSet(int sheet, double scale)
{
	executeTask("DrawingScaleSet_task", "%d %g %P", sheet, scale, NULL);
}

EXPORT void DrawingViewScaleSet(const wchar_t *viewName ,double viewScale)
{
	executeTask("DrawingViewScaleSet_task", "%w %g %P", viewName, viewScale, NULL);
}

EXPORT void DrawingNoteTextSet(const wchar_t *noteID , const wchar_t *sheetID,const wchar_t *noteText)
{
	executeTask("DrawingNoteTextSet_task","%w %w %w %P",noteID,sheetID,noteText,NULL);
}

EXPORT void DrawingSheetRegenerate()
{
	executeTask("DrawingSheetRegenerate_task", "%p %P", NULL, NULL);
}

EXPORT void DrawingViewRegenerate()
{
	executeTask("DrawingViewRegenerate_task", "%p %P", NULL, NULL);
}

EXPORT const wchar_t * ScanDrawing(const wchar_t * fileName, const wchar_t *xmlFile)
{
	wchar_t *output = NULL;
	executeTask("ScanDrawing_task", "%w %w %W", fileName, xmlFile, &output);

	return output;
}

EXPORT const wchar_t *CheckPartsReferencedInDrawing(wchar_t* fileName)
{
	wchar_t *cDrwSolids = NULL;
	executeTask("CheckPartsReferencedInDrawing_task","%w %W",fileName, &cDrwSolids);
	return cDrwSolids;
}

EXPORT void DrawingAnnotationDisplaySet(int iDimID, wchar_t * cDimStatus, wchar_t *cAnnotType)
{
	executeTask("DrawingAnnotationDisplaySet_task", "%d %w %w %P", iDimID,cDimStatus, cAnnotType, NULL);
}

EXPORT void DrawingModelAnnotationDisplaySet(int iDimID, wchar_t * cDimStatus)
{
	executeTask("DrawingModelAnnotationDisplaySet_task", "%d %w %P", iDimID,cDimStatus, NULL);
}

EXPORT void DrawingDimensionLocationChange(int iDimID, double dDimLocVal, wchar_t * cMovDir)
{
	executeTask("DrawingDimensionLocationChange_task", "%d %g %w %P", iDimID,dDimLocVal, cMovDir, NULL);
}

EXPORT void DrawingModelDimensionLocationChange(int iDimID, double dDimLocVal, wchar_t * cMovDir)
{
	executeTask("DrawingModelDimensionLocationChange_task", "%d %g %w %P", iDimID,dDimLocVal, cMovDir, NULL);
}

EXPORT void DrawingModelDimensionDecimalPlaceChange(int iDimID, int decimal)
{
	executeTask("DrawingModelDimensionDecimalPlaceChange_task", "%d %d %P", iDimID,decimal, NULL);
}

EXPORT void DrawingModelDimensionUpperTolChange(int iDimID, double upper)
{
	executeTask("DrawingModelDimensionUpperTolChange_task", "%d %g %P", iDimID, upper, NULL);
}

EXPORT void DrawingModelDimensionLowerTolChange(int iDimID, double lower)
{
	executeTask("DrawingModelDimensionLowerTolChange_task", "%d %g %P", iDimID, lower, NULL);
}

EXPORT void DrawingModelDimensionToleranceDecimalPlaceChange(int iDimID, int decimal)
{
	executeTask("DrawingModelDimensionToleranceDecimalPlaceChange_task", "%d %d %P", iDimID, decimal, NULL);
}

EXPORT void DrawingModelDimensionTableNameColumnChange(int dimID, wchar_t * tableName, int column)
{
	executeTask("DrawingModelDimensionTableNameColumnChange_task", "%d %w %d %P", dimID, tableName, column, NULL);
}

EXPORT void DrawingModelDimensionTableNameChange(int iDimID, wchar_t * tableName)
{
	executeTask("DrawingModelDimensionTableNameChange_task", "%d %w %P", iDimID, tableName, NULL);
}

EXPORT void DrawingModelDimensionTableColumnChange(int iDimID, int column)
{
	executeTask("DrawingModelDimensionTableColumnChange_task", "%d %d %P", iDimID, column, NULL);
}

EXPORT void DrawingViewLocationChange(wchar_t *cViewName,double dDist, wchar_t *cMoveDir)
{
	executeTask("DrawingViewLocationChange_task", "%w %g %w %P", cViewName,dDist, cMoveDir, NULL);
}

EXPORT void DrawingViewModelViewChange(wchar_t * viewName, wchar_t * mdlViewName, wchar_t * orientation, double xAngle,double yAngle)
{
	executeTask("DrawingViewModelViewNameChange_task", "%w %w %w %g %g %P", viewName,mdlViewName, orientation, xAngle, yAngle, NULL);
}

EXPORT void DrawingNoteLocationChange(int iNoteId,double dDist, wchar_t *cMoveDir)
{
	executeTask("DrawingNoteLocationChange_task", "%d %g %w %P", iNoteId,dDist, cMoveDir, NULL);
}

EXPORT void DrawingViewSizeSet(wchar_t *cViewName,double dViewSize, wchar_t *cChangeDir)
{
	executeTask("DrawingViewSizeSet_task", "%w %g %w %P", cViewName,dViewSize, cChangeDir, NULL);
}

EXPORT const wchar_t * AddDrawingTable(wchar_t *cTableInfo,int iSheet, wchar_t *cTableID)
{
	wchar_t *output = NULL;
	executeTask("AddDrawingTable_task", "%w %d %w %W", cTableInfo,iSheet, cTableID,&output);
	return output;
}

EXPORT const wchar_t * ReadDrawingProperties(wchar_t* cDrwProperty, wchar_t* cDrwEntity)
{
	wchar_t *output = NULL;
	executeTask("ReadDrawingProperties_task", "%w %w %W", cDrwProperty,cDrwEntity,&output);
	return output;
}

EXPORT void EraseModelByName(const wchar_t * modelName)
{
	executeTask("EraseModelByName_task", "%w %P", modelName, NULL);
}

// Engineer functions.

// These functions are used for starting/stopping Pro/ENGINEER
// and loading the AddIn.  Note that these functions differ from
// all the rest in that they do not call into the AddIn.  This is
// because their functionality controls Pro/ENGINEER itself.

// This function has to be outside the facade because it uses ProEngineerConnect()
// which has to be linked with the Pro/TOOLKIT pt_asynchronous.lib library.  Since this
// library can't be linked with the AddIn (because the AddIn runs in DLL mode), we have
// to place this function here.
//
// Don't use the EXPORT macro here as it uses extern "C" & so we can't throw exceptions.
// Instead, use EXPORT_CPP.  Of course, this means we must use the mangled
// name when calling this function from .NET.  That name is currently "?ConnectToEngineer@@YAHH@Z".
EXPORT_CPP int ConnectToEngineer(int proEngineerProcessID)
{
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	// Get the handle associated with this process ID.
	char *connectionID = new char(1+sizeof(proEngineerProcessID));
	bool proEngineerHidden = false;
	for (int x = 0 ; x < g_sessionTableIndex ; x++)
	{
		if (g_proEngineerPIDTable[x] == proEngineerProcessID)
		{
			// Get the Pro/ENGINEER DLL handle associated with this PID.
			// Since we are connecting, we use the same one that was
			// used when this Pro/ENGINEER instance was started.
			// Store it in the global g_proEngineerDllHandle variable so
			// that executeTask() can access it.
			g_proEngineerDllHandle = g_proEngineerDllHandleTable[x];

			// Get Pro/ENGINEER connection ID associated with this PID.
			// Since we are connecting, we use the same one that was
			// used when this Pro/ENGINEER instance was started.
			connectionID = g_proEngineerConnectionIdTable[x];

			// Get Pro/ENGINEER hidden attribute associated with this PID.
			// Since we are connecting, we use the same one that was
			// used when this Pro/ENGINEER instance was started.
			proEngineerHidden = (bool)g_proEngineerHiddenTable[x];

			break;
		}
	}

	// Check if a match was found.
	//Commented by Milind
	/*if (connectionID == NULL)
	{
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		throw ex;
	}*/

	_itoa(proEngineerProcessID,connectionID,10);
	LogDebug("Connectting to Creo Session");
	GeometryFacadeBoolean random = GEOMETRY_FACADE_B_FALSE;
	GeometryFacadeProcessHandle proEngineerProcessHandle;
	if ( ( result = ProEngineerConnect("", NULL, NULL, "", PRO_B_TRUE, 60, &random, &proEngineerProcessHandle) ) != GEOMETRY_FACADE_NO_ERROR )
	{
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		LogFatal("Failed to Connect to Creo Session");
		LogError(GetErrorString(result).c_str());
		throw ex;
	}

	// Store the Creo handle in the session table.
	g_proEngineerProcessHandleTable[g_sessionTableIndex] = proEngineerProcessHandle;

	// Store the Creo hidden attribute in the session table.
    g_proEngineerHiddenTable[g_sessionTableIndex] = proEngineerHidden;

	// Store the Creo started/connected attribute in the session table.
	g_proEngineerStartedOrConnected[g_sessionTableIndex] = (int)false;

	// Store the Creo DLL handle in the session table.
	g_proEngineerDllHandleTable[g_sessionTableIndex] = g_proEngineerDllHandle;

	// Store the connection ID string in the session table.
	strcpy(g_proEngineerConnectionIdTable[g_sessionTableIndex], connectionID);

	//delete connectionID;

	return g_sessionTableIndex++;
}

EXPORT_CPP void LoadDll(int proEngineerHandle, const char *dllName, const GeometryFacadeCharPath execFile, const GeometryFacadeCharPath textDir, const GeometryFacadeBoolean userDisplay)
{
	// Store the Creo DLL handle in the global g_proEngineerDllHandle
	// variable so that executeTask() can access it.
	LogDebug("In wrapper to Load Addin");
	try
	{
		GeometryFacadeLoadDll(dllName, execFile, textDir, userDisplay, &g_proEngineerDllHandle);
	}
	catch(ProeException ex)
	{
		LogFatal("Failed to Load Addin,see following message");
		LogFatal(ex.m_message.c_str());
		throw ex;
	}

	LogDebug("Addin Load Completed");

	// Store the Pro/ENGINEER DLL handle in the session table.
	g_proEngineerDllHandleTable[proEngineerHandle] = g_proEngineerDllHandle;
	LogDebug("Session Table Updated with Addin DLL Handle");
}

EXPORT char *GetCurrentSessionConnectionId(int iProcessId)
{	
	for (int x = 0 ; x < g_sessionTableIndex ; x++)
	{
		if (g_proEngineerPIDTable[x] == iProcessId)
		{
			// Get Pro/ENGINEER connection ID associated with this PID.
			char cIndex[10];
			_itoa(x , cIndex , 10);
			std::string sLog = "GetCurrentSessionConnectionId: Return Session Id for ProE process at Index <";
			sLog.append(cIndex).append(">.");		
			LogDebug(sLog.c_str());
			return g_proEngineerConnectionIdTable[x];
		}
	}
	return "";
}

EXPORT void EraseAll()
{
	ProMdl p_handle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	/*const char *cAppName = "ProeAddin";
	ProToolkitDllHandle app_handle;
	GeometryFacadeName wAppName;
	GeometryFacadeStringToWideString(wAppName, cAppName);

	ProToolkitDllHandleGet(wAppName,&app_handle);*/

	result = ProMdlCurrentGet (&p_handle);
	result = ProMdlEraseNotDisplayed();
	result = ProMdlEraseAll(p_handle);	
}

EXPORT void CloseCurrentDrawing()
{
	ProMdl pMdlHandle;
	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
	ProMdlType pMdlType;

	result = ProMdlCurrentGet (&pMdlHandle);
	ProMdlTypeGet(pMdlHandle,&pMdlType);
	if (pMdlType == PRO_DRAWING)
	{
		LogDebug("Closing drawing file");
		result = ProMdlSave(pMdlHandle);
		result = ProMdlEraseAll(pMdlHandle);
	}
}

EXPORT char *IntegrationCurrentModeGet()
{
	ProMode pMode;
	ProError result = ProModeCurrentGet(&pMode);
	LOG << "IntegrationCurrentModeGet: Current Mode returned <" << pMode << "> with Result <" << result << endl;
	switch(pMode)
	{
	case PRO_MODE_DRAWING:
		return "DRAWING";
		break;
	default:
		return "MODEL";
		break;
	}
}

EXPORT wchar_t *GetModelCurrentName(wchar_t *cIdPath)
{
	static char cMdlName[GEOMETRY_FACADE_NAME_SIZE];
	GeometryFacadeName wMdlName;
	try
	{
		GeometryFacadeMdl pModel = NULL;
		GetAsmcompMdl(cIdPath , &pModel);
		if(pModel != NULL)
		{
			GeometryFacadeGetMdlName(pModel , wMdlName);
			GeometryFacadeWideStringToString(cMdlName , wMdlName);
			LOG << "GetCurrentModelName: Returning current model name as <" << cMdlName << "> at id path <" << cIdPath << ">." << endl;
		}
	}
	catch(ProeException ex)
	{
		LogError("GetCurrentModelName: Caught Outer exception ");
		strcpy(cMdlName , "");
	}
	return wMdlName;
}

EXPORT void RegenerateSelectedPart(wchar_t *idPath)
{
	try
	{
		GeometryFacadeMdl pSelPart = NULL;
		GetAsmcompMdl(idPath , &pSelPart);
		
		if(pSelPart != NULL)
		{
			GeometryFacadeRegenerateSolid((GeometryFacadeSolid)pSelPart , PRO_REGEN_UPDATE_INSTS);
		}
	}
	catch(ProeException ex)
	{
		LogError("RegenerateSelectedPart: Caught Outer Exception ");
	}
}

// This function has to be outside the facade because it uses ProEngineerConnectStart()
// which has to be linked with the Pro/TOOLKIT pt_asynchronous.lib library.  Since this
// library can't be linked with the AddIn (because the AddIn runs in DLL mode), we have
// to place this function here.  Note that ProEngineerStart() doesn't have this restriction,
// but if we use that we don't get back a handle to Pro/ENGINEER.
//
// Don't use the EXPORT macro here as it uses extern "C" & so we can't throw exceptions.
// Instead, use EXPORT_CPP.  Of course, this means we must use the mangled
// name when calling this function from .NET.  That name is currently "?StartEngineer@@YAHPBDQAPBD0H@Z".
EXPORT_CPP int StartEngineer(const char *proePath, const char *arguments[], const char *prodevTextPath, int proeStartTimeout)
{
	// Check if the environment variable PRO_COMM_MSG_EXE
	// exists & points to a valid pro_comm_msg.exe file.
	// If this environment variable is not set up properly,
	// all sorts of wierd errors occur, such as RSA & RSE
	// failing to start.

	//Create Instance of log4ProE
	LOG << "Create Instance of Log4ProE" << endl;
	CreateInstance();
	std::string temp;
	char *proCommMsgExe = getenv("PRO_COMM_MSG_EXE");
	int rval = 0;
	if ( rval = _access(proCommMsgExe, 0) )
	{
		std::string message = "The environment variable PRO_COMM_MSG_EXE points to nonexistent file '" + std::string(proCommMsgExe) + "'.";
		ProeException ex(__FILE__, __LINE__, rval, message);
		SaveErrorInfo(ex);
		LogFatal(message.c_str());
		throw ex;
	}
	LogDebug("Entered wrapper to start ProE session");
	temp = "PRO_COMM_MSG_EXE path : ";
	temp.append(proCommMsgExe);
	LogDebug(temp.c_str());
	// Append any arguments passed in to path.
	char buf[1024];
	strncpy(buf, proePath, sizeof(buf) - 1);

	bool proEngineerHidden = false;
	if (arguments)
	{
		for (int x = 0 ; arguments[x] != NULL ; x++)
		{
			if ( !strcmp(arguments[x], "-g:no_graphics") )
			{
				proEngineerHidden = true;
			}
			strncat(buf, " ", sizeof(buf) - 1);
			strncat(buf, arguments[x], sizeof(buf) - 1);
		}
	}

	// See if the Pro/ENGINEER session is hidden.  Checking the command-line arguments
    // for -g:no_graphics ought to do the trick.
	g_proEngineerHiddenTable[g_sessionTableIndex] = proEngineerHidden;

	// Marshall the arguments into an array for the thread function.
	const char *args[2] = {buf, prodevTextPath};

	//startEngineerThread(&args);

	// Spawn a thread to start Pro/ENGINEER.
	// This is done because ProEngineerStart() never
	// returns if it cannot connect to the license server.  This
	// is a bug, and a call was placed with PTC (call #5896741)
	// about it.  When this bug is fixed, the threading code can be
	// removed.  That is, unless we have to maintain compatability
	// with older versions of Pro/ENGINEER.  If that is the case,
	// then this code will have to be enclosed in an if/else based
	// on the Pro/ENGINEER version.
	////byMilind-
	////For WF 5.0 RSE hang issue is faced so commenting the threadcreation code & directly calling startEngineerThread.
	////This issue needs further investigation
	LogDebug("Start Engineer Thread");
	void *threadHandle = CreateThread(NULL, 0, startEngineerThread, &args, 0, NULL);
	LogDebug("Start Engineer Thread Completed");
	if (threadHandle)
	{
		// Thread was created successfully.  Wait proeStartTimeout
		// seconds for Pro/Engineer to start.  If the thread doesn't
		// return within proeStartTimeout seconds, assume that there
		// is a problem with starting Pro/ENGINEER and terminate the session.
		LogDebug("Starting wait mode");
		unsigned long rval = WaitForSingleObject(threadHandle, proeStartTimeout * 1000);
		std::stringstream ss;
		ss << rval;
		string sTemp = "Value of rval : ";
		sTemp.append(ss.str());
		LogDebug(sTemp.c_str());

		if (rval == WAIT_FAILED)
		{
			// WaitForSingleObject() failed.
			rval = GetLastError();
			ProeException ex( __FILE__, __LINE__);
			SaveErrorInfo(ex);
			sTemp = "Wait Failed with Last Error : ";
			ss.clear();
			ss << rval;
			sTemp.append(ss.str());
			LogFatal(sTemp.c_str());
			throw ex;
		}
		else if (rval == WAIT_TIMEOUT)
		{
			// Pro/ENGINEER failed to start within the allotted time.
			// End the session with a GEOMETRY_FACADE_NO_LICENSE error.
			// Note that this may not be the reason that Pro/ENGINEER
			// failed to start, but it's the best we can do.
			rval = GetLastError();
			LogFatal("Wait Timed out Close Creo Session");
			// Since we're terminating, we don't really care if these calls fail.
			GeometryFacadeStopEngineer();
			LogError("Creo Session Closed");
			// Now terminate the thread.
			TerminateThread(threadHandle, -1);
			LogError("Terminating Thread");
			ProeException ex( __FILE__, __LINE__, GEOMETRY_FACADE_NO_LICENSE, GetErrorString(GEOMETRY_FACADE_NO_LICENSE) );
			SaveErrorInfo(ex);
			throw ex;
		}
		else if (rval == WAIT_ABANDONED)
		{
			ProeException ex( __FILE__, __LINE__, GEOMETRY_FACADE_NO_LICENSE, GetErrorString(GEOMETRY_FACADE_NO_LICENSE) );
			SaveErrorInfo(ex);
			LogFatal("Wait Abondened Cannot Continue");
			throw ex;
		}
		else if (rval == WAIT_OBJECT_0)
		{
			LogDebug("Thread Signal successful");
		}
		else
		{
			LogError("Wait Returned Unexpected Value");
		}
	}
	else
	{
		// CreateThread() failed for some unknown reason.
		// We could call GetLastError() if we really want to know why.

		ProeException ex( __FILE__, __LINE__, GEOMETRY_FACADE_GENERAL_ERROR, GetErrorString(GEOMETRY_FACADE_GENERAL_ERROR) );
		SaveErrorInfo(ex);
		LogFatal("Thread Failed for Unknown Reasons");
		throw ex;
	}

	//This is added just to give time to ProE to run smoothly.
	int iStatus = 0;
	do
	{
		ProEngineerStatusGet();		
		iStatus++;

	}while(iStatus < 3);

	LogDebug("Finished Start Engineer,Exit Wrapper");
	return g_sessionTableIndex++;
}

// This function has to be outside the facade because it uses ProEngineerDisconnect()
// which has to be linked with the Pro/TOOLKIT pt_asynchronous.lib library.  Since this
// library can't be linked with the AddIn (because the AddIn runs in DLL mode), we have
// to place this function here.
//
// Don't use the EXPORT macro here as it uses extern "C" & so we can't throw exceptions.
// Instead, use EXPORT_CPP.  Of course, this means we must use the mangled
// name when calling this function from .NET.  That name is currently "?StopEngineer@@YAXH@Z".
EXPORT_CPP void StopEngineer(int proEngineerHandle)
{
	// Note that once you disconnect from a Pro/ENGINEER
	// session, you can no longer call GeometryFacadeStopEngineer()
	// on it as the connection information is lost.  Because
	// of this, we must determine which method ( GeometryFacadeStopEngineer()
	// or ProEngineerDisconnect() ) is called first.

	// Cycle through the session table to see if we
	// should stop Pro/ENGINEER or just disconnect.
	// If more than one RSA/RSE session is associated
	// with this proEngineerHandle, just disconnect.
	// If this is the only RSA/RSE session that is
	// associated with proEngineerHandle, stop Pro/ENGINEER.
	// Note that this mechanism doesn't care about what
	// session started Pro/ENGINEER.  So if the session that
	// started Pro/ENGINEER disconnects but there is still
	// another session connected to that session, then that
	// Pro/ENGINEER session will continue to run.
	int count = 0;
	for (int x = 0 ; x < g_sessionTableIndex ; x++)
	{
		if (g_proEngineerPIDTable[proEngineerHandle] == g_proEngineerPIDTable[x])
		{
			count++;
		}
	}

	// This was the last/only RSA/RSE session attached to this
	// Pro/ENGINEER session, so exit Pro/ENGINEER.
	if (count == 1)
	{
		GeometryFacadeStopEngineer();
	}
	else
	{
		// Get the Creo handle associated with proEngineerHandle.
		GeometryFacadeProcessHandle proEngineerProcessHandle = g_proEngineerProcessHandleTable[proEngineerHandle];

		GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;
		if ( ( result = ProEngineerDisconnect(&proEngineerProcessHandle, 60) ) != GEOMETRY_FACADE_NO_ERROR )
		{
			ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
			SaveErrorInfo(ex);
			LogFatal("Failed in Engineer Disconnect");
			LogError(GetErrorString(result).c_str());
			throw ex;
		}
	}

	// Clear session table entry.
	clearSessionTableEntry(proEngineerHandle);
}

// Feature functions.
EXPORT void SuppressFeature(const wchar_t *idPath, wchar_t * staticFile)
{
	executeTask("SuppressFeature_task", "%w %w %P", idPath, staticFile, NULL);
}

EXPORT void SetSketchText(const wchar_t *idPath,const wchar_t *NewText)
{
	executeTask("SetSketchText_task", "%w %w %P", idPath, NewText,NULL);
}

EXPORT void ResumeFeature(const wchar_t *idPath, wchar_t * staticFile)
{
	executeTask("ResumeFeature_task", "%w %w %P", idPath, staticFile, NULL);
}

EXPORT void ShowFeature(const char *idPath)
{
	executeTask("ShowFeature_task", "%s %P", idPath, NULL);
}

EXPORT void HideFeature(const char *idPath)
{
	executeTask("HideFeature_task", "%s %P", idPath, NULL);
}

EXPORT int CheckModifyingEntityExistInPart(wchar_t *cEntityType , wchar_t *cEntityName , wchar_t *cIdPath)
{
	int iReturn = -1;
	executeTask("CheckModifyingEntityExistInPart_task", "%w %w %w %D", cEntityType, cEntityName , cIdPath , &iReturn);
	return iReturn;
}

// Layer functions.
EXPORT void LayerDisplayStatusSet(int layerID, int status)
{
	executeTask("LayerDisplayStatusSet_task", "%d %d %P", layerID, status, NULL);
}

// Mass functions.
EXPORT void GetMassProperties(const char *idPath)
{
	executeTask("GetMassProperties_task", "%s %P", idPath, NULL);
}

EXPORT const wchar_t* GetMassProperty(const wchar_t *idPath, const wchar_t *property)
{
	wchar_t *output = NULL;
	executeTask("GetMassProperty_task", "%w %w %W", idPath, property, &output);

	return output;
}

// Misc. functions.

EXPORT void AddSession(int proEngineerHandle, int appPID, const char *appName, int proEngineerPID, const char *proEngineerName)
{
	if (proEngineerHandle < SESSION_TABLE_SIZE)
	{
		g_appPIDTable[proEngineerHandle] = appPID;
		strcpy(g_appNameTable[proEngineerHandle], appName);

		g_proEngineerPIDTable[proEngineerHandle] = proEngineerPID;
		strcpy(g_proEngineerNameTable[proEngineerHandle], proEngineerName);
	}
}

EXPORT const char* GetAddInErrorInfo()
{
	char *output = NULL;
	executeTask("GetAddInErrorInfo_task", "%p %S", NULL, &output);

	return output;
}

EXPORT void GetSessionTable(int &sessionTableIndex, int **appPIDTable, int **appNameTable, int **proEngineerPIDTable, int **proEngineerNameTable, int **proEngineerHiddenTable, int **proEngineerStartedOrConnected)
{
	sessionTableIndex = g_sessionTableIndex;

	*appPIDTable = g_appPIDTable;
	*appNameTable = reinterpret_cast<int*>(g_appNameTable);

	*proEngineerPIDTable = g_proEngineerPIDTable;
	*proEngineerNameTable = reinterpret_cast<int*>(g_proEngineerNameTable);
	*proEngineerHiddenTable = g_proEngineerHiddenTable;
	*proEngineerStartedOrConnected = g_proEngineerStartedOrConnected;
}

EXPORT void Initialize(const char *iniFile, const char *version)
{
	// This function is for passing along any .NET info
	// to the Wrapper.

	// Save the ini file.
    SetIniFile(iniFile);

	// Save the version.
	SetSoftwareVersion(version);

	//CreateInstance();
	//LogInfo("Wrapper initialized succesfully");
}

EXPORT void Log(const char *message)
{
	static bool loggingEnabled = IsLoggingEnabled();

	try
	{
		if (loggingEnabled)
		{
			LOGRAW << message << std::endl;
		}
	}
	catch(ProeException ex)
	{
		cout << "ProE exception : " << ex.GetMsg() << " : " << ex.GetFile() << " : " << ex.GetLine() << " : " << ex.GetResult() << endl;
	}
	catch(exception x)
	{
		cout << "Exception caught " << endl;
	}
}

EXPORT void OutputMessage(const char *str)
{
	executeTask("OutputMessage_task", "%s %P", str, NULL);
}

// Model functions.
EXPORT void BackupModel(const wchar_t *pathName,const wchar_t *GeometryName , const wchar_t *GeomReleaseName , const wchar_t *DrawingName , const wchar_t *DrwReleaseName , const wchar_t* AsmChildIdPath , const wchar_t* AsmChildRelName)
{
	executeTask("BackupModel_task", "%w %w %w %w %w %w %w %P", pathName, GeometryName , GeomReleaseName , DrawingName , DrwReleaseName , AsmChildIdPath , AsmChildRelName , NULL);
}

EXPORT void BackupModelToWIP(const wchar_t *WIPFullPath, const wchar_t *GeometryRelName , const wchar_t *GeomWIPName , const wchar_t *DrawingName , const wchar_t *DrwReleaseName, const wchar_t* AsmChildIdPath , const wchar_t* AsmChildWrkngName)
{
	executeTask("BackupModelToWIP_task", "%w %w %w %w %w %w %w %P", WIPFullPath, GeometryRelName , GeomWIPName , DrawingName , DrwReleaseName , AsmChildIdPath , AsmChildWrkngName , NULL);
}

EXPORT void EraseCurrentModel()
{
	executeTask("EraseCurrentModel_task", "%p %P", NULL, NULL);
}

EXPORT int LoadModel(const wchar_t *fileName)
{
	int output = 0;
	executeTask("LoadModel_task", "%w %D", fileName, &output);

	return output;
}

//EXPORT int LoadModel(const char *partName, int display)
//{
//	int output = 0;
//	executeTask("LoadModel_task", "%s %d %D", partName, display, &output);
//
//	return output;
//}

EXPORT void RegenerateCurrentModel()
{
	executeTask("RegenerateCurrentModel_task", "%p %P", NULL, NULL);
}

EXPORT void RenameModel(const wchar_t *idPath, const wchar_t *newName)
{
	executeTask("RenameModel_task", "%w %w %P", idPath, newName, NULL);
}

EXPORT void RepaintCurrentModel()
{
	executeTask("RepaintCurrentModel_task", "%p %P", NULL, NULL);
}

//EXPORT void RetrieveModel(const char *name, int type, int *handle)
//{
//	executeTask("RetrieveModel_task", "%s %d %D", name, type, handle);
//}

EXPORT void SaveModel()
{
	executeTask("SaveModel_task", "%p %P", NULL, NULL);
}

EXPORT const wchar_t* ScanModel( const wchar_t * fileName, const wchar_t *xmlFile)
{
	wchar_t *output = NULL;
	executeTask("ScanModel_task", "%w %w %W", fileName, xmlFile, &output);

	return output;
}

EXPORT void ZoomAllCurrentModel()
{
	executeTask("ZoomAllCurrentModel_task", "%p %P", NULL, NULL);
}

// Parameter functions.
EXPORT void SetIntParameter(const wchar_t *parameterName, wchar_t *cModelID ,int value)
{
	executeTask("SetIntParameter_task", "%w %w %d %P", parameterName, cModelID,value, NULL);
}

EXPORT void SetBoolParameter(const wchar_t *parameterName, wchar_t *cModelID,int value)
{
	executeTask("SetBoolParameter_task", "%w %w %d %P", parameterName, cModelID,value, NULL);
}

EXPORT void SetDoubleParameter(const wchar_t *parameterName, wchar_t *cModelID,double value)
{
	executeTask("SetDoubleParameter_task", "%w %w %g %P", parameterName, cModelID,value,NULL);
}

EXPORT void SetStringParameter(const wchar_t *parameterName, wchar_t *cModelID,const wchar_t *value)
{
	executeTask("SetStringParameter_task", "%w %w %w %P", parameterName, cModelID,value, NULL);
}

EXPORT int GetIntParameter(const wchar_t *parameterName)
{
	int output = 0;
	executeTask("GetIntParameter_task", "%w %D", parameterName, &output);

	return output;
}

EXPORT double GetDoubleParameter(const wchar_t *parameterName)
{
	double output = 0.0;
	executeTask("GetDoubleParameter_task", "%w %G", parameterName, &output);

	return output;
}

EXPORT const wchar_t* GetStringParameter(const wchar_t *parameterName)
{
	wchar_t *output = NULL;
	executeTask("GetStringParameter_task", "%w %W", parameterName, &output);

	return output;
}

EXPORT const wchar_t* GetParameterValue(const wchar_t* idPath , const wchar_t* paramName)
{
	wchar_t* output = NULL;
	executeTask("GetParameterValue_task", "%w %w %W", idPath , paramName , &output);
	
	return output;
}

// Position functions.
EXPORT void FixPosition(const char *idPath, double x, double y, double z)
{
	executeTask("FixPosition_task", "%s %g %g %g %P", idPath, x, y, z, NULL);
}

// Surface property functions.
EXPORT double GetAmbientLight(const char *idPath)
{
	double output = 0.0;
	executeTask("GetAmbientLight_task", "%s %G", idPath, &output);

	return output;
}

EXPORT void SetAmbientLight(const char *idPath, double value)
{
	executeTask("SetAmbientLight_task", "%s %g %P", idPath, value, NULL);
}

EXPORT const wchar_t* GetColor(const char *idPath)
{
	wchar_t *output = NULL;
	executeTask("GetColor_task", "%s %W", idPath, &output);

	return output;
}

EXPORT const wchar_t* GetModelNameByID(const wchar_t *idPath)
{
	wchar_t *output = NULL;
	executeTask("GetModelNameByID_task", "%w %W", idPath, &output);

	return output;
}

EXPORT void SaveModelByID(const wchar_t *idPath)
{
	executeTask("SaveModelByID_task", "%w %W", idPath, NULL);
}

EXPORT void SetColor(const wchar_t *idPath, const wchar_t *color)
{
	executeTask("SetColor_task", "%w %w %P", idPath, color, NULL);
}

EXPORT double GetShininess(const char *idPath)
{
	double output = 0.0;
	executeTask("GetShininess_task", "%s %G", idPath, &output);

	return output;
}

EXPORT void SetShininess(const char *idPath, double value)
{
	executeTask("SetShininess_task", "%s %g %P", idPath, value, NULL);
}

EXPORT double GetTransparency(const char *idPath)
{
	double output = 0.0;
	executeTask("GetTransparency_task", "%s %G", idPath, &output);

	return output;
}

EXPORT void SetTransparency(const char *idPath, double value)
{
	executeTask("SetTransparency_task", "%s %g %P", idPath, value, NULL);
}

// Utility functions.
EXPORT const wchar_t* DirectoryCurrentGet()
{
	wchar_t *output = NULL;
	executeTask("DirectoryCurrentGet_task", "%p %W", NULL, &output);

	return output;
}

EXPORT void DirectoryChange(const wchar_t *absolutePath)
{
	executeTask("DirectoryChange_task", "%w %P", absolutePath, NULL);
}

// Window functions.
EXPORT void WindowCurrentClose()
{
	executeTask("WindowCurrentClose_task", "%p %P", NULL, NULL);
}

// XML functions.
EXPORT const char* ProcessXMLMessage(const char *xml)
{
	char *output = NULL;
	executeTask("ProcessXMLMessage_task", "%s %S", xml, &output);

	return output;
}

//UDF functions
EXPORT const wchar_t* ScanUDF(const wchar_t *UDFPath, const wchar_t *cUDFPart, const wchar_t *xmlFile)
{
	wchar_t *output = NULL;
	executeTask("ScanUDF_task", "%w %w %w %W", UDFPath, cUDFPart, xmlFile, &output);

	return output;
}

EXPORT int AddUDF(const wchar_t *cXML,const wchar_t *cUDFPath)
{
	int output = NULL;
	executeTask("AddUDF_task", "%w %w %D", cXML,cUDFPath,&output );
	return output;
}

EXPORT void UDFDimensionValueSet(const wchar_t *cID,const wchar_t *cDimName,double dDimValue)
{
	executeTask("UDFDimensionValueSet_task", "%w %w %g %P", cID,cDimName,dDimValue,NULL);
}

EXPORT const wchar_t * setUDFfeaturestatus(wchar_t *cFeatPath,wchar_t *cFeat,wchar_t *cStatus)
{
	wchar_t *output = NULL;
	executeTask("SetUDFFeatureStatus_task", "%w %w %w %W", cFeatPath,cFeat,cStatus,&output);
	return output;
}

//ExportFunctions -
EXPORT const wchar_t * exportfiletypes(const wchar_t *cDrwExptType,const wchar_t *cMdlExptType,const wchar_t *cRelaseDirPath,const wchar_t *cDrwFile,const wchar_t *cMdlFile,const wchar_t * cExportFileName,const  wchar_t * exportFactOne, const wchar_t * exportFactTwo, const wchar_t * exportFactThree)
{
	wchar_t *output = NULL;
	executeTask("ExportFileTypes_task", "%w %w %w %w %w %w %w %w %w %W", cDrwExptType,cMdlExptType,cRelaseDirPath,cDrwFile,cMdlFile,cExportFileName,exportFactOne,exportFactTwo,exportFactThree,&output);
	return output;
}

// Private functions.

static void clearSessionTableEntry(int proEngineerHandle)
{
	if (proEngineerHandle < SESSION_TABLE_SIZE)
	{
		g_proEngineerPIDTable[proEngineerHandle] = 0;
		g_proEngineerNameTable[proEngineerHandle][0] = NULL;
		g_proEngineerHiddenTable[proEngineerHandle] = 0;
		g_appPIDTable[proEngineerHandle] = 0;
		g_appNameTable[proEngineerHandle][0] = NULL;
		g_proEngineerProcessHandleTable[proEngineerHandle] = GeometryFacadeProcessHandle();
		g_proEngineerDllHandleTable[proEngineerHandle] = NULL;
		g_proEngineerConnectionIdTable[proEngineerHandle][0] = NULL;
	}
}

// This function has to be outside the facade because it uses ProEngineerConnectIdExtract()
// which has to be linked with the Pro/TOOLKIT pt_asynchronous.lib library.  Since this
// library can't be linked with the AddIn (because the AddIn runs in DLL mode), we have
// to place this function here.
static char* connectIdExtract(GeometryFacadeProcessHandle proEngineerProcessHandle)
{
	// NOTE: It seems that you cannot call ProEngineerConnectIdExtract()
	// with a handle that was created in another process space and
	// obtain its connection string.  Because of this, it must be called
	// from the same process that created the handle.  Then the
	// connection string can be stored & used later on to
	// connect to another Pro/ENGINEER session.
	GeometryFacadeBoolean result = GEOMETRY_FACADE_B_FALSE;

	static char connectId[GEOMETRY_FACADE_CONNECT_ID_SIZE];
	if ( ( result = ProEngineerConnectIdExtract(proEngineerProcessHandle, connectId) ) != GEOMETRY_FACADE_B_TRUE )
	{
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		LogFatal("Failed to Extract Coonection ID String");
		LogError(GetErrorString(result).c_str());
		throw ex;
	}

	char cSessionIdex[10];
	_itoa(g_sessionTableIndex , cSessionIdex , 10);
	std::string sTemp = "Connection ID : ";
	sTemp.append(connectId).append("For Session at Index <").append(cSessionIdex).append(">");
	LogDebug(sTemp.c_str());

	
	return connectId;
}

static void executeTask(const char *taskName, const char *format, ...)
{
	// All calls to the Pro/TOOLKIT come through this method.
	// Therefore, it is  a great place to put a breakpoint to
	// see what's going on.

	// Allocate memory for the input arguments.
	GeometryFacadeArgument *inputArguments = (GeometryFacadeArgument*)GeometryFacadeAllocateArray(0, sizeof(GeometryFacadeArgument), 1);

	va_list ap;
	va_start(ap, format);

	int inputIntValue = 0;
	double inputDoubleValue = 0.0;
	char *inputStringValue = NULL;
	wchar_t* inputWideStringValue = NULL;

	int *outputIntValue = NULL;
	double *outputDoubleValue = NULL;
	char **outputStringValue = NULL;
	wchar_t** outputWideStringValue = NULL;

	const char *p = format;
	GeometryFacadeArgument arg;
	int x = 0;

	while(*p)
	{
		if (*p == 'd')
		{
			// Get the value as an int.
			inputIntValue = va_arg(ap, int);

			arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
			arg.value.v.i = inputIntValue;
		}
		else if (*p == 'g')
		{
			// Get the value as a double.
			inputDoubleValue = va_arg(ap, double);

			arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_DOUBLE;
			arg.value.v.d = inputDoubleValue;
		}
		else if (*p == 'p')
		{
			// Remove the NULL.
			va_arg(ap, char*);

			// For some reason, GeometryFacadeExecuteToolkitTask() requires
			// a valid GeometryFacadeArgument array to be passed in even if
			// there is no input, so we'll stick in a dummy value.
			arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_INT;
			arg.value.v.i = 0;
		}
		else if (*p == 's')
		{
			// Get the value as a char*.
			inputStringValue = va_arg(ap, char*);

			arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_STRING;
			GeometryFacadeSetValueDataString(&arg.value, inputStringValue);
		}
		else if (*p == 'w')
		{
			// Get the value as a char*.
			inputWideStringValue = va_arg(ap, wchar_t*);

			arg.value.type = GEOMETRY_FACADE_VALUE_TYPE_WSTRING;
			GeometryFacadeSetValueDataWstring(&arg.value, inputWideStringValue);
		}
		else if (*p == 'D')
		{
			// Get the value as an int*.
			outputIntValue = va_arg(ap, int*);
		}
		else if (*p == 'G')
		{
			// Get the value as a double*.
			outputDoubleValue = va_arg(ap, double*);
		}
		else if (*p == 'P')
		{
			// Remove the NULL.
			p++;
			continue;
		}
		else if (*p == 'S')
		{
			// Get the value as a char**.
			outputStringValue = va_arg(ap, char**);
		}
		else if (*p == 'W')
		{
			// Get the value as a char**.
			outputWideStringValue = va_arg(ap, wchar_t**);
		}
		else
		{
			// Discard this character.
			p++;
			continue;
		}

		// Skip over the last argument (the OUTPUT).
		if (*++p)
		{
			// If there are more format specifiers, this
			// argument is an input.
			// Set the argument name.  Can be ARG1 - ARG9.
			static char argName[5] = {'A', 'R', 'G', '#', '\0'};
			argName[3] = 0x31 + x++;
			GeometryFacadeStringToWideString(arg.label, argName);

			// Add this argument to inputArguments.
			GeometryFacadeAddArrayObject( (GeometryFacadeArray*)&inputArguments, -1, 1, &arg );
		}
	}

	va_end(ap);

	GeometryFacadeArgument *outputArguments = NULL;
	GeometryFacadeValueData data;

	// A great place for a logging statement.
	std::string sTemp = "Executing : ";
	sTemp.append(taskName);
	LogDebug(sTemp.c_str());
	// Call GeometryFacadeExecuteToolkitTask() to execute the specified ProeAddIn function.

//GeometryFacadeName wDllName;
//GeometryFacadeStringToWideString(wDllName, "ProeAddin");
//GeometryFacadeToolkitDllHandle dllHandle;
//ProError err = ProToolkitDllHandleGet(wDllName, &dllHandle);

	// Use g_proEngineerDllHandle for the Pro/ENGINEER DLL handle as it is the
	// one pointing to the correct Pro/ENGINEER instance.
	try
	{
		GeometryFacadeExecuteToolkitTask(g_proEngineerDllHandle, const_cast<char*>(taskName), inputArguments, &outputArguments);
	}
	catch(ProeException ex)
	{
		vector<std::string> vErrorStr;
		const char * p = GetAddInErrorInfo();

		ProcessErrorText(p,"||",vErrorStr);

		LogFatal(vErrorStr[3].c_str());
		LogError(vErrorStr[0].c_str());
		LogError(vErrorStr[1].c_str());
		LogError(vErrorStr[2].c_str());
		throw ex;
	}

	sTemp = "Completed : ";
	sTemp.append(taskName);
	LogDebug(sTemp.c_str());
	// Determine if this task should return any output.
	if (outputIntValue || outputDoubleValue || outputStringValue || outputWideStringValue)
	{
		// This task should have output, so grab it.
		GeometryFacadeGetArgumentByLabel(outputArguments, L"OUTPUT", &data);

		// Process the OUTPUT argument.
		if (data.type == GEOMETRY_FACADE_VALUE_TYPE_INT)
		{
			*outputIntValue = data.v.i;
			LOG << "Output for " << taskName << "() is " << *outputIntValue << std::endl;
		}
		else if (data.type == GEOMETRY_FACADE_VALUE_TYPE_DOUBLE)
		{
			*outputDoubleValue = data.v.d;
			LOG << "Output for " << taskName << "() is " << *outputDoubleValue << std::endl;
		}
		else if (data.type == GEOMETRY_FACADE_VALUE_TYPE_STRING)
		{
			// For strings, we need to copy the data before we free the memory.
			// TODO: Find a better mechanism for returning strings, as this one isn't reentrant.

			// Create a 128K static buffer.
			static char str[0x400000];
			strncpy(str, data.v.s, sizeof(str) - 1);
			str[sizeof(str) - 1] = NULL;

			*outputStringValue = str;

			//char *str = new char[sizeof(data.v.s) + 1];
			//strncpy(str,data.v.s,sizeof(str)-1);
			//*outputStringValue = str;
		}
		else if (data.type == GEOMETRY_FACADE_VALUE_TYPE_WSTRING)
		{
			// Create a 128K static buffer.
			static wchar_t wstr[0x400000];
			size_t count = sizeof wstr / sizeof *wstr;
			size_t dataLength = wcslen(data.v.w);
			if (count > dataLength)
			{
				wcsncpy(wstr, data.v.w, dataLength+1);
			}

			*outputWideStringValue = wstr;
		}

		// Free the memory allocated for outputArguments during the
		// GeometryFacadeExecuteToolkitTask() call.
		GeometryFacadeFreeArgumentArray(&outputArguments);
	}

	// Free the memory allocated for inputArguments.
	GeometryFacadeFreeArgumentArray(&inputArguments);

	// NOTE: We cannot pass any information from C++
	// to .NET via an exception.  We will get the error
	// information in .NET via GetErrorString().
}

void ProcessErrorText(std::string sInputText ,std::string delimeter, vector<std::string> &vErrorStr)
{
	size_t found;
	std::string sNoteLine =  "";

	int pos = 0;
	found = sInputText.find_first_of(delimeter);
	if (found == string::npos)
	{
		vErrorStr.push_back(sInputText);
	}

	while (found!=string::npos)
	{
		sNoteLine = sInputText.substr(pos,found);
		vErrorStr.push_back(sNoteLine);
		std::string noteTemp = sInputText.substr(found+strlen(delimeter.c_str()));
		sInputText = noteTemp;
		found=noteTemp.find_first_of(delimeter);
		if (found == string::npos)
		{
			vErrorStr.push_back(sInputText);
		}
	}
}

// Simple wrapper method used by GeometryFacadeStartEngineer()
// to create a thread for starting Pro/ENGINEER.
static unsigned long __stdcall startEngineerThread(void *arg)
{
	// Unmarshall the arguments.
	char **args = static_cast<char**>(arg);
	std::string errstr;

	GeometryFacadeError result = GEOMETRY_FACADE_NO_ERROR;

	GeometryFacadeProcessHandle proEngineerProcessHandle;
	if ( ( result = ProEngineerConnectionStart(args[0], args[1], &proEngineerProcessHandle) ) != GEOMETRY_FACADE_NO_ERROR )
	{
		ProeException ex( __FILE__, __LINE__, result, GetErrorString(result) );
		SaveErrorInfo(ex);
		errstr = "Failed to start Creo Session with Following Arguments ARG1 : ";
		errstr.append(args[0]).append(" ARG2 : ").append(args[1]);
		/*errstr.append(" ARG2 : ");
		errstr.append(args[1]);
		LogFatal(errstr.c_str());*/
		LogError(__FILE__);
		LogError(GetErrorString(result).c_str());
		throw ex;
	}

	LogDebug("Creo start successfully");

	g_proEngineerProcessHandleTable[g_sessionTableIndex] = proEngineerProcessHandle;
	strcpy( g_proEngineerConnectionIdTable[g_sessionTableIndex], connectIdExtract(proEngineerProcessHandle) );

	g_proEngineerStartedOrConnected[g_sessionTableIndex] = (int)true;

	return 0;
}

//Logging functions
static void CreateInstance()
{
	CoInitialize(NULL);
	HRESULT hRes = oLog4ProE.CreateInstance(Log4ProE::CLSID_Log4ProE);
	if(hRes == S_OK)
	{
		LOG << "Log Instance Created" << endl;
	}
	else
	{
		LOG << "Log instance creation failed with result as :" << hRes << endl;
	}
}

void LogInfo(char *cMsg)
{
	if(oLog4ProE != NULL)
	oLog4ProE->LogInfo(_bstr_t(cMsg));
}

void LogError(const char *cMsg)
{
	if(oLog4ProE != NULL)
	oLog4ProE->LogError(_bstr_t(cMsg));
}

void LogWarn(char *cMsg)
{
	if(oLog4ProE != NULL)
	oLog4ProE->LogWarn(_bstr_t(cMsg));
}

void LogDebug(const char *cMsg)
{
	if(oLog4ProE != NULL)
	oLog4ProE->LogDebug(_bstr_t(cMsg));
}

void LogFatal(const char *cMsg)
{
	if(oLog4ProE != NULL)
	oLog4ProE->LogFatal_2(_bstr_t(cMsg));
}
/*
void addInputArgument(ProArgument &proArg, const U arg)
{
	if ( !strcmp(typeid(arg).name(), "short") ||
		 !strcmp(typeid(arg).name(), "unsigned short") ||
		 !strcmp(typeid(arg).name(), "int") ||
		 !strcmp(typeid(arg).name(), "unsigned int") ||
		 !strcmp(typeid(arg).name(), "long") ||
		 !strcmp(typeid(arg).name(), "unsigned long") ||
		 !strcmp(typeid(arg).name(), "__int64") )

	{
		// This argument is of type PRO_VALUE_TYPE_INT.
		proArg.value.type = PRO_VALUE_TYPE_INT;
		proArg.value.v.i = arg.i;
	}
	else if ( !strcmp(typeid(arg).name(), "double") ||
		 !strcmp(typeid(arg).name(), "long double") )
	{
		// This argument is of type PRO_VALUE_TYPE_DOUBLE.
		proArg.value.type = PRO_VALUE_TYPE_DOUBLE;
		proArg.value.v.d = arg.d;
	}
//	else if ( )
//	{
//		// This argument is of type PRO_VALUE_TYPE_POINTER.
//	}
	else if ( !strcmp(typeid(arg).name(), "char") ||
		 !strcmp(typeid(arg).name(), "char *") ||
		 !strcmp(typeid(arg).name(), "class std::basic_string") )
	{
		// This argument is of type PRO_VALUE_TYPE_STRING.
		proArg.value.type = PRO_VALUE_TYPE_STRING;
		ProValuedataStringSet(&proArg.value, arg.cp);
	}
//	else if ( )
//	{
//		// This argument is of type PRO_VALUE_TYPE_WSTRING.
//	}
//	else if ( )
//	{
//		// This argument is of type PRO_VALUE_TYPE_SELECTION.
//	}
//	else if ( )
//	{
//		// This argument is of type PRO_VALUE_TYPE_TRANSFORM.
//	}
	else if ( !strcmp(typeid(arg).name(), "bool") )
	{
		// This argument is of type PRO_VALUE_TYPE_BOOLEAN.
	}
	else
	{
		// Unknown type.
	}
}

template <class T, class U, class V, class W, class X>
ProArgument* PackageInputArguments(const T arg1, const U arg2, const V arg3, const W arg4, const X arg5)
{
	ProError status;
	ProArgument arg;
	ProArgument *input_arguments;

	status = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*)&input_arguments);

	ProStringToWstring(arg.label, "ARG1");
	addInputArgument(arg, arg1);

	ProStringToWstring(arg.label, "ARG2");
	addInputArgument(arg, arg2);

	status = ProStringToWstring(arg.label, "ARG3");
	addInputArgument(arg, arg3);

	ProStringToWstring(arg.label, "ARG4");
	addInputArgument(arg, arg4);

	ProStringToWstring(arg.label, "ARG5");
	addInputArgument(arg, arg5);

	status = ProArrayObjectAdd( (ProArray*)&input_arguments, -1, 1, &arg );

	return input_arguments;
}

ProArgument* PackageInputArguments(const char *format, ...)
{
	ProArgument *inputArguments;

	// Allocate memory for the input arguments.
	ProError status = ProArrayAlloc(0, sizeof(ProArgument), 1, (ProArray*)&inputArguments);

	va_list ap;
	va_start(ap, format);
	int intValue = 0;
	double doubleValue = 0.0;
	char *stringValue = NULL;

	const char *p = format;
	ProArgument arg;
	int x = 0;

	while(*p)
	{
		if (*p == 'd')
		{
			// Get the value as an int.
			intValue = va_arg(ap, int);

			// This argument is of type PRO_VALUE_TYPE_INT.
			arg.value.type = PRO_VALUE_TYPE_INT;
			arg.value.v.i = intValue;
		}
		else if (*p == 'g')
		{
			// Get the value as a double.
			doubleValue = va_arg(ap, double);

			// This argument is of type PRO_VALUE_TYPE_DOUBLE.
			arg.value.type = PRO_VALUE_TYPE_DOUBLE;
			arg.value.v.d = doubleValue;
		}
		else if (*p == 's')
		{
			// Get the value as a string.
			stringValue = va_arg(ap, char*);

			// This argument is of type PRO_VALUE_TYPE_STRING.
			arg.value.type = PRO_VALUE_TYPE_STRING;
			ProValuedataStringSet(&arg.value, stringValue);
		}
		else
		{
			// Discard this character.
			p++;
			continue;
		}

		// Set the argument name.  Can be ARG1 - ARG9.
		static char argName[5] = {'A', 'R', 'G', '#', '\0'};
		argName[3] = 0x31 + x++;
		ProStringToWstring(arg.label, argName);

		// Add this argument to inputArguments.
		status = ProArrayObjectAdd( (ProArray*)&inputArguments, -1, 1, &arg );

		p++;
	}

	va_end(ap);

	return inputArguments;
}

ProValueData ExecuteTask(const char *taskName, ProArgument *inputArguments)
{
	ProError status = PRO_TK_NO_ERROR;
	ProError taskStatus = PRO_TK_NO_ERROR;
	ProArgument *outputArguments = NULL;
	ProValueData data;

	// Call ProToolkitTaskExecute() to execute the specified ProeAddIn function.
	if ( ( status = ProToolkitTaskExecute(g_appHandle, const_cast<char*>(taskName), inputArguments, &outputArguments, &taskStatus) ) == PRO_TK_NO_ERROR )
	{
		// The result returned from the task is stored in taskStatus.
		if (taskStatus == PRO_TK_NO_ERROR)
		{
			// Some tasks return output using ProValueData & the OUTPUT tag.
			// See if this task returned any output.
			if ( ( status = ProArgumentByLabelGet(outputArguments, L"OUTPUT", &data) ) != PRO_TK_E_NOT_FOUND)
			{
				// This task returned some output.
				if (status != PRO_TK_NO_ERROR)
				{
				}
			}

			// For strings, we need to copy the data before we free the memory.
			// TODO: Find a better mechanism for returning strings, as this one isn't reentrant.
			if (data.type == PRO_VALUE_TYPE_STRING)
			{
				// Create a 128K static buffer.
				static char str[0x20000];
				strncpy(str, data.v.s, sizeof(str) - 1);
				str[sizeof(str) - 1] = NULL;

				data.v.s = str;
			}

			// Free the memory allocated for outputArguments during the
			// ProToolkitTaskExecute call.
			// TODO: We probably don't care enough about the failure of
			// a free to abort the app, but we probably should log an error.
			ProArgumentProarrayFree(&outputArguments);
		}
		else
		{
		}
	}
	else
	{
		// The ProToolkitTaskExecute() call failed.
	}

	// Free the memory allocated for inputArguments.
	// TODO: We probably don't care enough about the failure of
	// a free to abort the app, but we probably should log an error.
	ProArgumentProarrayFree(&inputArguments);

	return data;
}
*/
