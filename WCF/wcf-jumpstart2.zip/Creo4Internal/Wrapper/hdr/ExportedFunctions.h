#ifndef EXPORTEDFUNCTIONS_H
#define EXPORTEDFUNCTIONS_H

// C/C++ header files.
#include <cstdarg>
#include <map>
#include <string>
#include <fstream>
#include <vector>
using namespace std;

// Pro/Toolkit header files.
#include <ProToolkitDll.h>
#include <ProToolkitErrors.h>

#define EXPORT extern "C" __declspec(dllexport)
#define EXPORT_CPP __declspec(dllexport)

// Public functions.

// Component functions.
EXPORT int AddComponent(const char *filePath, const char *ownerIDPath);
EXPORT int AddComponentWithSuffix(const wchar_t *modelName, const wchar_t *suffix, const wchar_t *ownerIDPath);
EXPORT void RenameAssemblyComponent(const char *suffix,const char *workingFolder , int IsRSStandard);
EXPORT const wchar_t* ClearProeWindow(int i);
EXPORT void RegenerateAssemblyFile(wchar_t * asmHandle);
EXPORT int AddSuffix(const char *modelName, const char *suffix);
EXPORT void DeleteComponent(const char *idPath);
EXPORT int ReplaceProEPartFile(const wchar_t *cCrntFleID,const wchar_t *cNeFlNm,const wchar_t *cIdPath);
EXPORT int ProcessFamilyTableInstance(const wchar_t *cInstName,const wchar_t *cOwnerID);
EXPORT void RenameFamilyTableInstance(const wchar_t *cInstName,const wchar_t *cInstNewNm,const wchar_t *cGnrcPath);
EXPORT int ProcessDocumentName(const wchar_t *cOwnerId,const wchar_t *cDocumentName);
EXPORT int ProcessDocumentNameForStaticAsmComponent(const wchar_t *cOwnerId,const wchar_t *cCompId , const wchar_t *cDocumentName);
EXPORT void PreProcessDocumentName(const wchar_t*cExistingFile,const wchar_t *cModelType,const wchar_t*CEarlierName);
bool CheckIsModelInSession(const char *cExistingFile,GeometryFacadeMdlType pMdlType);
EXPORT void RegenerateSelectedPart(wchar_t *idPath);

// Constraint functions.
EXPORT void BuildConstraints(const wchar_t *xml);
EXPORT void ShowConstraints(const char *idPath);

// Dimension functions.
EXPORT double DimensionGetValue(const char *idPath);
EXPORT const wchar_t* DimensionGetValueByIdPath(const char *idPath);
EXPORT void DimensionSetByName(const wchar_t *name, double value);
EXPORT void DimensionSetValueByIdPath(const char *idPath, double value);

// Drawing functions.
EXPORT void CreateProDrawing(const wchar_t *newName, const wchar_t *drawingTemplateName);
EXPORT void DrawingCurrentSheetSet(int sheet);
EXPORT void DrawingRename(const wchar_t *partName, const wchar_t *templatePartName, const wchar_t *drawingToRename, const wchar_t *newDrawingName , int iDrwGeomChanged);
EXPORT void DrawingScaleSet(int sheet, double scale);
EXPORT void DrawingNoteTextSet(const wchar_t *noteID , const wchar_t *sheetID, const wchar_t *noteText);
EXPORT void DrawingSheetRegenerate();
EXPORT void DrawingViewRegenerate();
EXPORT const wchar_t* ScanDrawing(const wchar_t * fileName, const wchar_t *xmlFile);
EXPORT void DrawingViewScaleSet(const wchar_t *viewName ,double viewScale);
EXPORT void DrawingAnnotationDisplaySet(int iDimID, wchar_t * cDimStatus, wchar_t *cAnnotType);
EXPORT void DrawingModelAnnotationDisplaySet(int iDimID, wchar_t * cDimStatus);
EXPORT void DrawingDimensionLocationChange(int iDimID, double dDimLocVal, wchar_t * cMovDir);
EXPORT void DrawingModelDimensionLocationChange(int iDimID, double dDimLocVal, wchar_t * cMovDir);
EXPORT void DrawingModelDimensionDecimalPlaceChange(int iDimID, int decimal);
EXPORT void DrawingModelDimensionUpperTolChange(int iDimID, double upper);
EXPORT void DrawingModelDimensionLowerTolChange(int iDimID, double lower);
EXPORT void DrawingModelDimensionToleranceDecimalPlaceChange(int iDimID, int decimal);
EXPORT void DrawingModelDimensionTableNameColumnChange(int dimID, wchar_t * tableName, int column);
EXPORT void DrawingModelDimensionTableNameChange(int iDimID, wchar_t * tableName);
EXPORT void DrawingModelDimensionTableColumnChange(int iDimID, int lower);
EXPORT void DrawingViewLocationChange(wchar_t *cViewName,double dDist, wchar_t *cMoveDir);
EXPORT void DrawingViewModelViewChange(wchar_t * viewName, wchar_t * mdlViewName, wchar_t * orientation, double xAngle,double yAngle);
EXPORT void DrawingNoteLocationChange(int iNoteId,double dDist, wchar_t *cMoveDir);
EXPORT void DrawingViewSizeSet(wchar_t *cViewName,double dViewSize, wchar_t *cChangeDir);
EXPORT const wchar_t * AddDrawingTable(wchar_t *cTableInfo,int iSheet, wchar_t *cTableID);
EXPORT const wchar_t * ReadDrawingProperties(wchar_t* cDrwProperty, wchar_t* cDrwEntity);
EXPORT const wchar_t *CheckPartsReferencedInDrawing(wchar_t* fileName);
EXPORT void DrawingMultipleSolidRename(const wchar_t *partName, const wchar_t *templatePartName, const wchar_t *drawingToRename, const wchar_t *newDrawingName);
EXPORT void DrawingCreateFromTemplate(const wchar_t *partName, const wchar_t *drawingToRename, const wchar_t *newDrawingName);

// Engineer functions.
EXPORT_CPP int ConnectToEngineer(int proEngineerProcessID);
EXPORT_CPP void LoadDll(int proEngineerProcessHandle, const char* appName, const GeometryFacadeCharPath execFile, const GeometryFacadeCharPath textDir, GeometryFacadeBoolean userDisplay);
EXPORT_CPP int StartEngineer(const char *proePath, const char *arguments[], const char *prodevTextPath, int proeStartTimeout);
EXPORT_CPP void StopEngineer(int proEngineerHandle);

// Feature functions.
EXPORT void HideFeature(const char *idPath);
EXPORT void ResumeFeature(const wchar_t *idPath, wchar_t * staticFile);
EXPORT void ShowFeature(const char *idPath);
EXPORT void SuppressFeature(const wchar_t *idPath, wchar_t * staticFile);
EXPORT void SetSketchText(const wchar_t *idPath,const wchar_t *NewText);
EXPORT int CheckModifyingEntityExistInPart(wchar_t *cEntityType , wchar_t *cEntityName , wchar_t *cIdPath);

// Layer functions.
EXPORT void LayerDisplayStatusSet(int layerID, int status);

// Mass property functions.
EXPORT void GetMassProperties(const char *idPath);
EXPORT const wchar_t* GetMassProperty(const wchar_t *idPath, const wchar_t *property);

// Misc. functions.
EXPORT void AddSession(int proEngineerHandle, int appPID, const char *appName, int proEngineerPID, const char *proEngineerName);
EXPORT const char* GetAddInErrorInfo();
EXPORT void GetSessionTable(int &sessionTableIndex, int **appPIDTable, int **appNameTable, int **proEngineerPIDTable, int **proEngineerNameTable, int **proEngineerHiddenTable, int **proEngineerStartedOrConnected);
EXPORT void Initialize(const char *iniFile, const char *version);
EXPORT void Log(const char *message);
EXPORT void ProeOutputMsg(const char *str);
EXPORT char *GetCurrentSessionConnectionId(int iProcessId);
EXPORT wchar_t *GetModelCurrentName(wchar_t *cIdPath);

// Model functions.
EXPORT void BackupModel(const wchar_t *pathName,const wchar_t *GeometryName , const wchar_t *GeomReleaseName , const wchar_t *DrawingName , const wchar_t *DrwReleaseName, const wchar_t* AsmChildIdPath , const wchar_t* AsmChildRelName);
EXPORT void BackupModelToWIP(const wchar_t *WIPFullPath, const wchar_t *GeometryRelName , const wchar_t *GeomWIPName , const wchar_t *DrawingName , const wchar_t *DrwReleaseName , const wchar_t* AsmChildIdPath , const wchar_t* AsmChildWrkngName);
EXPORT void EraseCurrentModel();
EXPORT int LoadModel(const wchar_t *fileName);
EXPORT const wchar_t* GetModelNameByID(const wchar_t *idPath);
EXPORT void SaveModelByID(const wchar_t *idPath);

//EXPORT int LoadModel(const char *partName, int display);
EXPORT void RegenerateCurrentModel();
EXPORT void RenameModel(const wchar_t *idPath, const wchar_t *newName);
EXPORT void RepaintCurrentModel();
//EXPORT void RetrieveModel(const char *name, int type, int *handle);
EXPORT void SaveModel();
EXPORT const wchar_t* ScanModel(const wchar_t * fileName, const wchar_t *xmlFile);
EXPORT void ZoomAllCurrentModel();

// Parameter functions.
EXPORT double GetDoubleParameter(const wchar_t *parameterName);
EXPORT int GetIntParameter(const wchar_t *parameterName);
EXPORT const wchar_t* GetStringParameter(const wchar_t *parameterName);
EXPORT void SetDoubleParameter(const wchar_t *parameterName, wchar_t *cModelID,double value);
EXPORT void SetIntParameter(const wchar_t *parameterName, wchar_t *cModelID ,int value);
EXPORT void SetBoolParameter(const wchar_t *parameterName, wchar_t *cModelID,int value);
EXPORT void SetStringParameter(const wchar_t *parameterName, wchar_t *cModelID,const wchar_t *value);
EXPORT const wchar_t* GetParameterValue(const wchar_t* idPath , const wchar_t* paramName);

// Position functions.
EXPORT void FixPosition(const char *idPath, double x, double y, double z);

// Surface property functions.
EXPORT double GetAmbientLight(const char *idPath);
EXPORT void SetAmbientLight(const char *idPath, double value);
EXPORT const wchar_t* GetColor(const char *idPath);
EXPORT void SetColor(const wchar_t *idPath, const wchar_t *color);
EXPORT double GetShininess(const char *idPath);
EXPORT void SetShininess(const char *idPath, double value);
EXPORT double GetTransparency(const char *idPath);
EXPORT void SetTransparency(const char *idPath, double value);

// Utility functions.
EXPORT void DirectoryChange(const wchar_t *absolutePath);
EXPORT const wchar_t* DirectoryCurrentGet();

// Window functions.
EXPORT void WindowCurrentClose();

EXPORT char *IntegrationCurrentModeGet();

// XML functions.
EXPORT const char* ProcessXMLMessage(const char *xml);

//misc
EXPORT void EraseAll();
EXPORT void EraseModelByName(const wchar_t * modelName);
EXPORT void CloseCurrentDrawing();
EXPORT const wchar_t* GetListOfModelsInSession();
EXPORT const wchar_t* GetListOfDrawingRefModels();
EXPORT const wchar_t* GetDrawingViewModelNames(const wchar_t * viewName);
EXPORT const wchar_t* GetDrawingViewType(const wchar_t * viewName);

//Group(UDF)Functions
EXPORT const wchar_t* ScanUDF(const wchar_t *UDFPath,const wchar_t *cUDFPart, const wchar_t *xmlFile);
EXPORT int AddUDF(const wchar_t *cXML,const wchar_t *cUDFPath);
EXPORT void UDFDimensionValueSet(const wchar_t *cID,const wchar_t *cDimName,double dDimValue);
EXPORT const wchar_t* setUDFfeaturestatus(wchar_t *cFeatPath,wchar_t *cFeat,wchar_t *cStatus);

//Export Type Function
EXPORT const wchar_t * exportfiletypes(const wchar_t *cDrwExptType,const wchar_t *cMdlExptType,const wchar_t *cRelaseDirPath,const wchar_t *cDrwFile,const wchar_t *cMdlFile,const wchar_t *ExportFileName, const wchar_t * exportFactOne, const wchar_t * exportFactTwo, const wchar_t * exportFactThree);

// Private functions.
static void clearSessionTableEntry(int proEngineerHandle);
static char* connectIdExtract(GeometryFacadeProcessHandle proEngineerProcessHandle);
static void executeTask(const char *taskName, const char *format, ...);
static bool getLoggingStatus();
static unsigned long __stdcall startEngineerThread(void *arg);

static void CreateInstance();
void LogInfo(char *cMsg);
void LogError(const char *cMsg);
void LogWarn(char *cMsg);
void LogDebug(const char *sMsg);
void LogFatal(const char *cMsg);
void ProcessErrorText(std::string sInputText ,std::string delimeter, vector<std::string> &vErrorStr);

#endif // EXPORTEDFUNCTIONS_H