#include <ProToolkit.h>


extern "C"
{
	int user_initialize(int argc, char *argv[], char *version, char *build, wchar_t *error);
	void user_terminate();
}
